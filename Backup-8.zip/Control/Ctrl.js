const fs = require('fs');
const chalk = require('chalk');
const { version } = require("../package.json")

// --------------( Settings Owner )-------------- \\
global.nomorowner = ["6283180190857", "6283132860356", "6287762009255"]
global.owner = "6287762009255"
global.versi = "3.2.0"
global.namaowner = "Tama - Official" // jangan di ubah
global.namadev = "Tama - Official" // jangan di ubah

// --------------( Settings Bot )-------------- \\
global.prefa = ["","!",".",",","#","/","🎭","〽️"]
global.filenames = "../Console/ZephCase.js"
global.packname = 'WhatsApp Bot TamaOfficial'
global.botname = 'Simple Bot V3 Gen 2'
global.generasi = 'Generasi 2'
global.title = 'Tama ☇ Official'
global.footer = 'WhatsApp Bots 2026'
global.author = 'Tama ☇ Official'
global.botname2 = 'Simple Bot V3 Gen 2'
global.wm = "Tama ☇ Official"
global.baileys = "@whiskeysockets/baileys" // jangan ubah
global.pairing = "TAMA1234" // jangan ubah

// --------------( Settings Telegram )-------------- \\
module.exports = {
  BOT_TOKEN: "7998258124:AAH356GpScGzh-7W8FZxatGECvB00mELeCQ", // Ganti Token Bot Mu
  OWNER_IDS: "7994557501" // Ganti Id Tele Mu
};

// --------------( Settings Sosmed )-------------- \\
global.ytdev = 'https://youtube.com/@ZephrineMods'
global.sosmed = 't.me/TamaModss'
global.tempatDB = 'database.json' // Jangan ubah
global.pairing_code = true // Jangan ubah
global.linkOwner = "https://wa.me/6283132860356" // jan di ubah

// --------------( Settings Nickname )-------------- \\
global.nick = {
aaa: "⭑̤⟅̊༑ ▾ ᴛᴀᴍᴀ ⿻ ᴏғғɪᴄɪᴀʟ ⿻ ▾ ༑̴⟆̊‏‎‏‎‏‎‏⭑̤‏‎‏‎‏‎‏",
sss: "ᴛᴀᴍᴀ ᴏғғɪᴄɪᴀʟ ༚👻⃰ꢵ"
}

// --------------( Settings Group )-------------- \\
global.linkgbbuypublic = "" // masukkan link grub reseller panel
global.linkgcreseller = "" // masukkan link grub reseller panel
global.linkGrup = "https://chat.whatsapp.com/GA2wiiKuj6PJfnjtD7oBiF"

// --------------( Settings Apikey )-------------- \\
global.apipayment = "new"
global.apipayment2 = "NabzxBotz"
global.apiSimpleBot = "simplebotz85"
global.apikey = "zakkigans12"

// --------------( Settings Jeda )-------------- \\

global.delayjpmch = 2000
global.delayJpm = 3500
global.delayPushkontak = 3000

// --------------( Settings Vercel )-------------- \\
global.vercelToken = "TsbRGoxunzLivHHSV9vX45nG"

// --------------( Settings Github )-------------- \\
global.githubToken = "-" //Your GitHub Token
global.githubUsername = "-" //Your GitHub Username

// --------------( Settings Saluran )-------------- \\
global.salurantestimoni = "https://whatsapp.com/channel/0029Vav8XGHL2ATznQc17P3A"
global.linkSaluran = "https://whatsapp.com/channel/0029Vaion3d6hENjxVNaMS02"
global.linkChannel = "https://whatsapp.com/channel/0029Vaion3d6hENjxVNaMS02"
global.idSaluran = "120363333324119584@newsletter"
global.namaSaluran = "Tamaa OfficiaL"
global.grubmarketplace = "https://chat.whatsapp.com/GA2wiiKuj6PJfnjtD7oBiF"

// --------------( Settings Orkut )-------------- \\
global.IdMerchant = "OK1755355"
global.ApikeyOrderKuota = "168947917342696541755355OKCT0C356C5BE567AEC3D8EA992E37B5D7A0"
global.QrisOrderKuota = "00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214703095830176330303UMI51440014ID.CO.QRIS.WWW0215ID20243219240010303UMI5204541153033605802ID5921MAULL STORE OK17553556006BEKASI61051711162070703A0163043D20"
global.pworkut = ""
global.pinorkut = ""
global.apidigitalocean = ""
global.pinH2H = ""
global.passwordH2H = ""

// --------------( Settings Token )-------------- \\
global.tokeninstall = "skyzodev"
global.bash = "bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)"

// --------------( Settings Cloudflare )-------------- \\
global.apitoken_cloudflare = ""
global.accountid_cloudflare = ""
global.email_cloudflare = ""


// --------------( Settings All Payment )-------------- \\
global.dana = "000"
global.namadana = 'R*****'
global.ovo = "Tidak Tersedia"
global.gopay = "000"
global.namagopay = 'R*****'

// --------------( Settings Thumbnail )-------------- \\
global.image = {
menu: "https://files.catbox.moe/gso3zc.jpg", 
reply: "https://files.catbox.moe/gso3zc.jpg", 
logo: "https://files.catbox.moe/gso3zc.jpg", 
dana: "https://img100.pixhost.to/images/667/540082364_skyzopedia.jpg", 
ovo: "https://img100.pixhost.to/images/667/540082774_skyzopedia.jpg", 
gopay: "https://img100.pixhost.to/images/667/540083275_skyzopedia.jpg", 
qris: "https://img100.pixhost.to/images/926/543616090_thandeveloper.jpg"
}
global.video = 'https://files.catbox.moe/5l5mpz.mp4'

// --------------( Settings Panel V1 )-------------- \\
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://robertganteng.hilmanofficial.tech" // Hapus Tanda / di akhir domain
global.apikey = "ptla_1TNzvcEjWUikXzPGu0Owzfbi3T4DptdzwIr8CEc1Hyl" //ptla
global.capikey = "ptlc_46u6DZCLxL4eTFjWOmSaqIC6VOEaV6D0F4fTsUkEWBi" //ptlc

// --------------( Settings Panel V2 )-------------- \\
global.eggV2 = "15" // Egg ID
global.nestidV2 = "5" // nest ID
global.locV2 = "1" // Location ID
global.domainV2 = "" // Hapus Tanda / di akhir domain
global.apikeyV2 = "" //ptla
global.capikeyV2 = "" //ptlc

// --------------( Settings Lainnya )-------------- \\
global.linktutor = 'https://youtu.be/bWsTCzmkI7E?si=gTsV3GXAl-W1V5rh'

// --------------( Settings Subdomain )-------------- \\
global.subdomain = {
"otwbosmuda.web.id": {
"zone": "1dc3bdff8f68916758a4cb3af33b3d70",
"apitoken": "xie11_kgLskI2BTKwxAfvkvBeQ8kqf3792vNjnXA"
},
"tamapriv.my.id": {
"zone": "d3a817f15c222339580b8614c1fa3f65",
"apitoken": "LDTdlOZ2XiCo4frtNtSP3XmkzTWfCTYG5XXYsIzs"
},
"tamaalwayssolo.biz.id": {
"zone": "3b02a83514466c0c1fa1237264fd34db",
"apitoken": "ykDAhWQJaNVFrVqUUocQGCsdJYqmyuCr2Uhqmigb"
},
"tamaoffc.biz.id": {
"zone": "177538af7fb12443a80892554d01206f",
"apitoken": "ZaVSjxa96NQDV6lQgspAVsVXrvVzdOpqL1z6PG0Z"
},
"cupencrew.my.id": {
"zone": "505292d6fa0c31a0f3c179e31da8e3f5", 
"apitoken": "yKkh3VluAjlvyy8i3VM_jw-Pjsq_liBv4QVJZrm0"
}, 
"cupentamvan.biz.id": {
"zone": "cde563dd21c04e2770bb66993dd667a3", 
"apitoken": "YPhb9lXkwFu0PrHgiT1XwQSyN5Rf3eAYiMdt0zJ9"
}, 
"cupenpendiem.shop": {
"zone": "a70c572f7c8f8bc0ad5ac2552e42e516", 
"apitoken": "VEtKD6sBAvgwQd1pYBV957Rno1feXoxqXPo1biij"
}, 
"skyzopedia.us.kg": {
"zone": "9e4e70b438a65c1d3e6d0e48b82d79de", 
"apitoken": "odilM9DpvLVPodbPyZwW7UcDKg1aIWsivJc0Vt_o"
}, 
"marketplace.us.kg": {
"zone": "2f33118c3db00b12c38d07cf1c823ed1", 
"apitoken": "6WS_Op6yuPOWcO17NiO-sOP8Vq9tjSAFZyAn82db"
}, 
"salwacantik.my.id": {
"zone": "f6aa1ed9ba7f7f4fcfa47b035e8c3c09", 
"apitoken": "2ltJMUmL2QZ-H3IQ0NGM8n84zxoJlU1D8Wwj26AB"
}, 
"xyro.web.id": {
"zone": "46d0cd33a7966f0be5afdab04b63e695", 
"apitoken": "CygwSHXRSfZnsi1qZmyB8s4qHC12jX_RR4mTpm62"
}, 
"xyroku.my.id": {
"zone": "f6d1a73a272e6e770a232c39979d5139", 
"apitoken": "0Mae_Rtx1ixGYenzFcNG9bbPd-rWjoRwqN2tvNzo"
}, 
"xyro.me": {
"zone": "a1c08ecd2f96516f2a85250b98850e8b", 
"apitoken": "f3IBOeIjRHYSsRhzxBO7yiwl-Twn3fqjmdkLdwlf"
}, 
"cloud-shopp.biz.id": {
"zone": "365f57282cbea3a6d5a738f107df244e", 
"apitoken": "hZKxD6afDLF-wsg1qVA-qbDK_h8lBE4NtqnVZPP8"
},
"serverpanell.biz.id": {
"zone": "225512a558115605508656b7bdf29b28", 
"apitoken": "XasxSSnGp8M9QixvT6AAlh1vEm4icVgzDyz7KDiF"
},
"market-panel.site": {
"zone": "d06bf5450ae51612a400bab1c4450283",
"apitoken": "kmb6AkpJ6XvHMzw2m0KbYKZOycIURNYMPA7Wm0BE",
},
"admin-panel.tech": {
"zone": "305d4757160a88486d3780785c7c9887",
"apitoken": "UH-aDtxu5Mm9oU8khMd5ZVg22f7nhnSkCORBn8zP",
},
"kang-panel.tech": {
"zone": "28baf36eb9ced4be271bdb6ea3320f41",
"apitoken": "MBiKuyoS0e0zJc8LKUjSXyLmgAf1IV9u86FJmVny",
},
"web-cabul.me": {
"zone": "4b24636040f0f2d799a8a1aaea568e57",
"apitoken": "OvRX-DghNjcPF9rlKElGCLIsPvv3Nd3khuDAUZ3q",
},
"king-hosting.live": {
"zone": "2e6eb183148e0ef9add390af271a8bb2",
"apitoken": "kcnnE1sESybx-P_nLkkiKtfZFqGhRmwFg9wL0cf6",
},
"tokopanel.software": {
"zone": "cc9638d4c289130ba070484625e6aefa",
"apitoken": "bcAP5z3gHvmQTlQ59qNB9BWmf0JiGt0C99FU6SXs",
},
"pannel-private.me": {
"zone": "71ad41d3c25085bd7b8a1135632c7c63",
"apitoken": "HfGKPUu1KrOVc3q51nkoJYZFQvIpA-AFOP-t6SNZ",
},
"hitam.systems": {
"zone": "cfaba3ef0065acc82facc17f1b79d50b",
"apitoken": "4o3tZAc5jOzA00joKpLYhG_616qCJxNLGlhawMEY",
},
"panel-run-bot.engineer": {
"zone": "678298eaac2e2a0dea25f693310ec6e0",
"apitoken": "8UmNiZZqEIAqWbM7XlcZofyvhc70NMs2_gXmmkug",
},
"uchiha.tech": {
"zone": "1b09e81ec29d760ff33e476a084de6ed",
"apitoken": "nzLwv-2uzMt3Ihsd5MVV2aLJ9EoovxrVK7Y4b2To",
},
"buyer-vps.site": {
"zone": "354e1c784bed5a8d93f458ec1ff86f35",
"apitoken": "rzOLIO1c-Me1X0owStLFUZ0ggfs_cxHDab2A7krF",
},
"arzanoffc.online": {
"zone": "43ca801f5c6a73a77da5f0243f4f8c1d",
"apitoken": "RZQft_gJGOJDskx6L6SxREJCvOKw0hclLjHUCNLS",
},
"hexaneuro.biz.id": {
"zone": "16273869fda58585fc435e4582a5ff56",
"apitoken": "y4wV0um-bvrVTvFVPrNrGEi590bPowvosRyNiGMn"
 },   
"mypanel.tech": {
"zone": "9c5460deca7c84273b46f2f047783636",
"apitoken": "0IBfmlUlCkYqoFPWYaqCmqI3_vWxkrFNbxrQjzX2"
}, 
"kedai-panel.me": {
"zone": "3ab91ea96368234719c9de7d260742e2",
"apitoken": "O22A19W7trZZ52bAXtF77aUVdGDdAk8PjQqwM7qv"
}, 
"control-pannel.site": {
"zone": "20c517d7dcc25d9cf516f5c4cf2d21ba",
"apitoken": "mAA84Qs4nJvLTaup0HTGrpVbgaSk-4vfUrcdHgCH"
}, 
"mypanelstore.xyz": {
"zone": "72f7362d7686d9158a8e389851fc379c", 
"apitoken": "V2y-I2o1s5E1tdCPpUSnT4FokV6WuxEUC2FqqVIX"
},
"panel-pvrt.my.id": {
"zone": "ee4060e03b223e8e0724908575b70c3b", 
"apitoken": "6HxTQ0VJZVcAJISlKsezttCNzpAAf7ubPy5EDOGR"
},
"ekiofficial.my.id": {
"zone": "df33365b44b11cbe51570a7ed981cae5", 
"apitoken": "rMJGbyeuwFVZJifsB3rIX-nRpIOOa4Wkrhu7V5Jo"
},
"ekiofficial.web.id": {
"zone": "e1b037c00268cae95076b58f7f78b1f6", 
"apitoken": "EJO7mHrBORH9XoQrnUvBqotMYxNm5bjB5UO2PeQE"
},
"eki-panelpvrt.my.id": {
"zone": "6b4cb792b77b6118e91d8604253ca572", 
"apitoken": "DsftwwFCAKrbSo-9r9hxqcscMw8Xvx8gQzTXMSz4"
},
"panelvip.biz.id": {
"zone": "70969a584446a244efe1461f5bb41ff5", 
"apitoken": "pzj2mcvQL1KUQCjj5XjSVPjLqKGCy8U7PtVFuOXr"
},
"shop-panel.biz.id": {
"zone": "62e0683ee057e0e2a39eaf73d18e6eb1", 
"apitoken": "opUN9xsI7mlS3CP8cJA9RbO5SB4gUpcyof9Yaeb7"
},
"centzzcloud.my.id": {
"zone": "749f1d7d69e9329195761b570010c00f", 
"apitoken": "9Su8A1EDXnt9-yGDb7YSGlY_ogJAw2vR9IDtpFrQ"
},
"pakvinsen.me": {
"zone": "3b8cb89265c0e026abaf3bc50ed57e76", 
"apitoken": "ttt0IHK50UKP2HltWUauuyDzkVPqnOEkx7M-5CFs"
},
"satoruuhost.tech": {
"zone": "086b2b4e1c65c22bfd8d5d86cbfa947f", 
"apitoken": "62XZSKEzz4mKM_1wAHK7-_JaA14VrQJDoWI2GeHT"
},
"hostsatoruu.biz.id": {
"zone": "30ea1aac05ca26dda61540e172f52ff4", 
"apitoken": "eZp1wNcc0Mj-btUQQ1cDIek2NZ6u1YW1Bxc2SB3z"
},
"mafiapnel.my.id": {
"zone": "34e28e0546feabb87c023f456ef033bf", 
"apitoken": "bHNaEBwaVSdNklVFzPSkSegxOd9OtKzWtY7P9Zwt"
},
"rexxaoffc.my.id": {
"zone": "f972ed410a833b28c8b5f166d6620d6a", 
"apitoken": "liq8sBPHwvbU2jWQYTCjo4BXafVPeopkAU4avUlP"
}, 
"rexxa.my.id": {
"zone": "b0d37cb6e9d6a7c2b0a82395cbdfd8b9", 
"apitoken": "fR2LO4Hz2y0U8dP3IHRwMHnWi_xKKa5RCZjWaXv3"
},
"gacorr.biz.id": {
"zone": "cff22ce1965394f1992c8dba4c3db539", 
"apitoken": "v9kYfj5g2lcacvBaJHA_HRgNqBi9UlsVy0cm_EhT"
},
"cafee.my.id": {
"zone": "0d7044fc3e0d66189724952fa3b850ce", 
"apitoken": "wAOEzAfvb-L3vKYE2Xg8svJpHfNS_u2noWSReSzJ"
}, 
"store-panell.my.id": {
"zone": "0189ecfadb9cf2c4a311c0a3ec8f0d5c", 
"apitoken": "eVI-BXIXNEQtBqLpdvuitAR5nXC2bLj6jw365JPZ"
}, 
"vipstoree.my.id": {
"zone": "72fd03404485ddba1c753fc0bf47f0b3", 
"apitoken": "J2_c07ypFEaen92RMS7irszQSrgZ_VFMfgNgzmp0"
}, 
"bokepp.biz.id": {
"zone": "46b8cab5631c6c23c5ec4a7ef1f10803", 
"apitoken": "A8df8PxnKIcxLUTE7XS4TRZBoLslvt4XjJb1XEyi"
}, 
"market-store.my.id": {
"zone": "4ae70eaa56096fdb94ef9050dde52220", 
"apitoken": "_T1fxXQLd6864mYGwgHmciZMiLURKNkyomaPv0sy"
},
"shop-panel.biz.id": {
"zone": "62e0683ee057e0e2a39eaf73d18e6eb1",
"apitoken": "opUN9xsI7mlS3CP8cJA9RbO5SB4gUpcyof9Yaeb7"
},
"pterodaytl.my.id": {
"zone": "828ef14600aaaa0b1ea881dd0e7972b2",
"apitoken": "75HrVBzSVObD611RkuNS1ZKsL5A_b8kuiCs26-f9"
},
"wannhosting.biz.id": {
"zone": "4e6fe33fb08c27d97389cad0246bfd9b",
"apitoken": "75HrVBzSVObD611RkuNS1ZKsL5A_b8kuiCs26-f9"
},   
"wannhosting.my.id": {
"zone": "0b36d11edd793b3f702e0591f0424339",
"apitoken": "OsSjhDZLdHImYTX8fdeiP1wocKwVnoPw5EiI85IF"
}, 
"xnxxx.tech": {
"zone": "639f9cde20c22b1d2f33b2fee54f8f59",
"apitoken": "MtWI3a9-9Za-fGKmwl0uNznqM94eljKgobkF36h1"
},
"pterodactyl-panel.web.id": {
"zone": "d69feb7345d9e4dd5cfd7cce29e7d5b0",
"apitoken": "32zZwadzwc7qB4mzuDBJkk1xFyoQ2Grr27mAfJcB"
},
"panelprivate.web.id": {
"zone": "61bcd80ff1ec9c3a5812f74d6ec24535",
"apitoken": "VnjVDtbb-fSTFIn-3Hckd_E_eseqyHH7u1TTAHMN"
},
"serverpanell.biz.id": {
"zone": "aac5555d4f60fcf48c9e901b938fffc0", 
"apitoken": "qd8OolI2_GIu3HLsTZvdk242ggDdD3_IGXMMSQ7P"
}, 
"privatehost.us.kg": {
"zone": "790918217c4add75b7684458518c5836", 
"apitoken": "qYv4NvEN6ZcUIv4dEXihjkmQMwbP_-3Qy_zFlAHv"
}, 
"botwhatsapp.us.kg": {
"zone": "fb1ac418c5564373a56c91d962b30dca", 
"apitoken": "rfQih0XNXiq7AyEuDoLjoFfHX2mhYf_9kddAdKIo"
}, 
"pteroserver.us.kg": {
"zone": "f693559a94aebc553a68c27a3ffe3b55", 
"apitoken": "ZPAXx7CL51PtbGweL2pE3BsI3x0hgTgLuy56iXuo"
}, 
"digitalserver.us.kg": {
"zone": "df13e6e4faa4de9edaeb8e1f05cf1a36", 
"apitoken": "HXVf4soYFM3iiOewHZ6tk6LEnG9f7m7CVhU0EoVz"
}, 
"xyz-store.biz.id": {
"zone": "8ae812c35a94b7bd2da993a777b8b16d", 
"apitoken": "oqZafkd3mSt1bABD9MMTidpCtD9VZdiPTjElVKJB"
}, 
"rafatharxamalia.my.id": {
"zone": "eadca8b2f2c8b93a8413b8594ad7ef48", 
"apitoken": "GEl7ZdaTnJuJJMjNQbT2nsf__hPxr4DumLbMD2xa"
}, 
"tokopanelku.my.id": {
"zone": "1acc96e9e3be7da6799d49b7927678bf", 
"apitoken": "GMiEVWZ5xO843jjfZeDORZIDgEnnJ5Yo3yXkiB"
}, 
"manzz.my.id": {
"zone": "8acff3a918a2433e53162c952b7dcfb5", 
"apitoken": "hxQuBudz9oiKcvoIGhKO7lZDxlQuDTOPXbRwEb4K"
}, 
"xpanelprivate.biz.id": {
"zone": "f838b3f6d24b7167026e4db197d5689a", 
"apitoken": "IhfT4A4ORNgl0uO9U7uUKbDoefqF3xTpJ-NLk6Lt"
},
"roompanelpriv.my.id": {
"zone": "73f4d0171fe1f48db80aed6323e9330d",
"apitoken": "2c29LWyyTHGXNtccxA62QWCGmxRcLoGcB9Y35jrH"
},
"hilman-store.web.id": {
"zone": "4e214dfe36faa7c942bc68b5aecdd1e9",
"apitoken": "wpQCANKLRAtWb0XvTRed3vwSkOMMWKO2C75uwnKE"
},
"paneldigital.web.id": {
"zone": "2f33118c3db00b12c38d07cf1c823ed1", 
"apitoken": "6WS_Op6yuPOWcO17NiO-sOP8Vq9tjSAFZyAn82db"
},
"digital-market.web.id": {
"zone": "652c4800932a51249d42099dcfd55d0d", 
"apitoken": "wUQ8mx8_thiR0lq_sZ0bhyEjdo-UIs9iZojgTi7g"
},
"hilmanzoffc.web.id": {
"zone": "2627badfda28951bfb936fce0febc5b0",
"apitoken": "wZ3QAKn7zDx-tyb04HgCvmogqeM6je8jDNmiPZXq"
},
"hostingers-vvip.my.id": {
"zone": "2341ae01634b852230b7521af26c261f",
"apitoken": "Ztw1ouD8_lJf-QzRecgmijjsDJODFU4b-y697lPw"
},
"panelstore-vvip.biz.id": {
"zone": "a99445e7459f95735af8e44f43b03834",
"apitoken": "pOKX689oVlJCQBq1awwHkok-o3cKyOEk6vq8AGoe"
},
"hilmanofficial.tech": {
"zone": "c8705bfbfdca9c4e8e61eb2663ee87d6",
"apitoken": "hjqWa_eFAfoJNJyBu9WAlg8WO0ICtN5AYpZURgqe"
}, 
"thandev.my.id": {
"zone": "a2d5c6358889833d655bbcc8b722658f", 
"apitoken": "5pRg7xCP9q9V5Q4OPG_fN2Uu9lvO1BQHDG3IxY52"
}, 
"thangtg.xyz": {
"zone": "e0f0aa7c1b552528c4491b962792a94b", 
"apitoken": "_K8xAxwtMeAeuyxLc6H6MheHDXWFEVBFucPJRHq4"
}, 
"thanoffc.store": {
"zone": "9c9f5e3b6be87836c14caedd44669de6", 
"apitoken": "U9DDNRA4TVCpra_mTXlD6n0CgLpc57FwHn4pB9gQ"
},
"panelprivate.web.id": {
"zone": "61bcd80ff1ec9c3a5812f74d6ec24535",
"apitoken": "VnjVDtbb-fSTFIn-3Hckd_E_eseqyHH7u1TTAHMN"
},
"reseller-panel.me": {
"zone": "b1efab0f1d81a0137eb5d62e00d6e3f8",
"apitoken": "W3b66ootKk1pERNSB6DbyW383OXRCoakw3PQExyS"
},
"fayypedia.xyz": {
"zone": "061040b178a09e07bcb1c989dfc0c171", 
"apitoken": "VBkoU8H4ZcpZnb2Q_m_dHGtGL4IAeZUXGpwCg71S"
}, 
"fayzaafx.my.id": {
"zone": "2688ec16cf017d8b76b056992ef77b15", 
"apitoken": "ijjFxobV49FkPMFw1ed-wrjMyRWMF31_0hg8Q0ch"
}, 
"fayzaafx.xyz": {
"zone": "5f4a582dd80c518fb2c7a425256fb491", 
"apitoken": "iQbJQgfe6kTyEfdOy_EV8UAHKj80VgQg4t6rTjby"
}, 
"hexaneuro.biz.id": {
"zone": "16273869fda58585fc435e4582a5ff56",
"apitoken": "y4wV0um-bvrVTvFVPrNrGEi590bPowvosRyNiGMn"
},
"fayzaafx.web.id": {
"zone": "422abe2ae8a9225fe824441da4b84645",
"apitoken": "QaeiWSZkabCabpdutbHJ09hAyGtjUpPbCywRiWz2"
},
"zcake.us.kg": {
"zone": "63729ecb4fb36abf6a546aa8d0f2090d", 
"apitoken": "5zL3j880znmlh3Avpm8lIkrfhdU-khI6njLmJsKH"
},
"market-panel.site": {
"zone": "d06bf5450ae51612a400bab1c4450283",
"apitoken": "kmb6AkpJ6XvHMzw2m0KbYKZOycIURNYMPA7Wm0BE",
},
"admin-panel.tech": {
"zone": "305d4757160a88486d3780785c7c9887",
"apitoken": "UH-aDtxu5Mm9oU8khMd5ZVg22f7nhnSkCORBn8zP",
},
"kang-panel.tech": {
"zone": "28baf36eb9ced4be271bdb6ea3320f41",
"apitoken": "MBiKuyoS0e0zJc8LKUjSXyLmgAf1IV9u86FJmVny",
},
"web-cabul.me": {
"zone": "4b24636040f0f2d799a8a1aaea568e57",
"apitoken": "OvRX-DghNjcPF9rlKElGCLIsPvv3Nd3khuDAUZ3q",
},

"king-hosting.live": {
"zone": "2e6eb183148e0ef9add390af271a8bb2",
"apitoken": "kcnnE1sESybx-P_nLkkiKtfZFqGhRmwFg9wL0cf6",
},
"tokopanel.software": {
"zone": "cc9638d4c289130ba070484625e6aefa",
"apitoken": "bcAP5z3gHvmQTlQ59qNB9BWmf0JiGt0C99FU6SXs",
},
"pannel-private.me": {
"zone": "71ad41d3c25085bd7b8a1135632c7c63",
"apitoken": "HfGKPUu1KrOVc3q51nkoJYZFQvIpA-AFOP-t6SNZ",
},
"hitam.systems": {
"zone": "cfaba3ef0065acc82facc17f1b79d50b",
"apitoken": "4o3tZAc5jOzA00joKpLYhG_616qCJxNLGlhawMEY",
},
"panel-run-bot.engineer": {
"zone": "678298eaac2e2a0dea25f693310ec6e0",
"apitoken": "8UmNiZZqEIAqWbM7XlcZofyvhc70NMs2_gXmmkug",
},
"uchiha.tech": {
"zone": "1b09e81ec29d760ff33e476a084de6ed",
"apitoken": "nzLwv-2uzMt3Ihsd5MVV2aLJ9EoovxrVK7Y4b2To",
},
"buyer-vps.site": {
"zone": "354e1c784bed5a8d93f458ec1ff86f35",
"apitoken": "rzOLIO1c-Me1X0owStLFUZ0ggfs_cxHDab2A7krF",
},
"arzanoffc.online": {
"zone": "43ca801f5c6a73a77da5f0243f4f8c1d",
"apitoken": "RZQft_gJGOJDskx6L6SxREJCvOKw0hclLjHUCNLS",
},
"hexaneuro.biz.id": {
"zone": "16273869fda58585fc435e4582a5ff56",
"apitoken": "y4wV0um-bvrVTvFVPrNrGEi590bPowvosRyNiGMn"
 },   
"mypanel.tech": {
"zone": "9c5460deca7c84273b46f2f047783636",
"apitoken": "0IBfmlUlCkYqoFPWYaqCmqI3_vWxkrFNbxrQjzX2"
}, 
"kedai-panel.me": {
"zone": "3ab91ea96368234719c9de7d260742e2",
"apitoken": "O22A19W7trZZ52bAXtF77aUVdGDdAk8PjQqwM7qv"
}, 
"control-pannel.site": {
"zone": "20c517d7dcc25d9cf516f5c4cf2d21ba",
"apitoken": "mAA84Qs4nJvLTaup0HTGrpVbgaSk-4vfUrcdHgCH"
}, 
"mypanelstore.xyz": {
"zone": "72f7362d7686d9158a8e389851fc379c", 
"apitoken": "V2y-I2o1s5E1tdCPpUSnT4FokV6WuxEUC2FqqVIX"
},
"kenz-host.my.id": {
"zone": "df24766ae8eeb04b330b71b5facde5f4", 
"apitoken": "fyaxLxD0jNONtMWK3AmnaiLkkWi5Wg3Y9h8nqJh6"
},
"panelkishop.web.id": {
"zone": "8f4812b3c78ca478b5d162b6cb35d1b3", 
"apitoken": "3Y0cW3cVVIhyeWHytqFEbGDrdWaAC-k8twOEeFP2"
},
"tokopanelkishop.biz.id": {
"zone": "d87d4f320d9902f31fbbcc5ee23fafe8", 
"apitoken": "D00akOLxF3qzBzpYBp5SbpaLTmwYeybNsyAcDfiB"
},
"panelprivate.web.id": {
"zone": "61bcd80ff1ec9c3a5812f74d6ec24535", 
"apitoken": "VnjVDtbb-fSTFIn-3Hckd_E_eseqyHH7u1TTAHMN"
},
"rikionline.shop": {
"zone": "082ec80d7367d6d4f7c52600034ac635", 
"apitoken": "r3XUyNYtxNQYwZtGUIAChRqe0uTzwV4eVO7JpJ_l"
},
"market-panel.site": {
"zone": "d06bf5450ae51612a400bab1c4450283", 
"apitoken": "kmb6AkpJ6XvHMzw2m0KbYKZOycIURNYMPA7Wm0BE"
}, 
"admin-panel.tech": {
"zone": "305d4757160a88486d3780785c7c9887", 
"apitoken": "UH-aDtxu5Mm9oU8khMd5ZVg22f7nhnSkCORBn8zP"
}, 
"kang-panel.tech": {
"zone": "28baf36eb9ced4be271bdb6ea3320f41", 
"apitoken": "MBiKuyoS0e0zJc8LKUjSXyLmgAf1IV9u86FJmVny"
}, 
"buyer-vps.site": {
"zone": "354e1c784bed5a8d93f458ec1ff86f35", 
"apitoken": "rzOLIO1c-Me1X0owStLFUZ0ggfs_cxHDab2A7krF"
}, 
"shopserver.us.kg": {
"zone": "54ca38e266bfdf2dcdb7f51fd79c2db5", 
"apitoken": "4qOupI-Of-6yNrBaeS1-H0KySuKCd0wS-x0P5XQ4"
},
"tokopanel.software": {
"zone": "cc9638d4c289130ba070484625e6aefa", 
"apitoken": "bcAP5z3gHvmQTlQ59qNB9BWmf0JiGt0C99FU6SXs"
},
"serverku.biz.id": {
"zone": "4e4feaba70b41ed78295d2dcc090dd3a", 
"apitoken": "oof_QRNdUC4aMQ3xIB8dmkGaZu7rk2J-0P_tN55l"
}, 
"privatserver.my.id": {
"zone": "699bb9eb65046a886399c91daacb1968", 
"apitoken": "CrQMyDn2fhchlGne2ogAw7PvJLsg4x8vasBv__6D"
}, 
"panelwebsite.biz.id": {
"zone": "2d6aab40136299392d66eed44a7b1122", 
"apitoken": "cj17Lzg9otqwkYIVzgL0pcVA4GfcXqePHAOhCqa_"
}, 
"mypanelstore.web.id": {
"zone": "c61c442d70392500611499c5af816532", 
"apitoken": "N_VhWv2ZK6UJxLdCnxMfZx9PtzAdmPGM3HmOjZR4"
}, 
"pteroserver.us.kg": {
"zone": "f693559a94aebc553a68c27a3ffe3b55", 
"apitoken": "qRxwgS3Kl_ziCXti2p4BHbWTvGUYzAuYmVM28ZEp"
}, 
"digitalserver.us.kg": {
"zone": "df13e6e4faa4de9edaeb8e1f05cf1a36", 
"apitoken": "sH60tbg10UH8gpNrlYpf3UMse1CNJ01EKJ69YVqb"
}, 
"shopserver.us.kg": {
"zone": "54ca38e266bfdf2dcdb7f51fd79c2db5", 
"apitoken": "GRe4rg-vhb4c8iSjKCALHJC0LaxkzNPgmmgcDGpm"
}
}

// --------------( Settings Message )-------------- \\
global.mess = {
	owner: "*`[ ◇ ] : 𝐾ℎ𝑢𝑠𝑢𝑠 𝑂𝑤𝑛𝑒𝑟 Only`*",
	seller: "*`[ ◇ ] : 𝐾ℎ𝑢𝑠𝑢𝑠 𝑆𝑒𝑙𝑙𝑒𝑟 𝑃𝑎𝑛𝑒𝑙 𝑆𝑒𝑟𝑣𝑒𝑟 1`*",
	seller2: "*`[ ◇ ] : 𝐾ℎ𝑢𝑠𝑢𝑠 𝑆𝑒𝑙𝑙𝑒𝑟 𝑃𝑎𝑛𝑒𝑙 𝑆𝑒𝑟𝑣𝑒𝑟 2`*",
	admin: "*`[ ◇ ] : 𝐾ℎ𝑢𝑠𝑢𝑠 𝐴𝑑𝑚𝑖𝑛`*",
	botAdmin: "*`[ ◇ ] : 𝐾ℎ𝑢𝑠𝑢𝑠 𝑆𝑎𝑎𝑡 𝐵𝑜𝑡 𝑀𝑒𝑛𝑗𝑎𝑑𝑖 𝐴𝑑𝑚𝑖𝑛`*",
	group: "*`[ ◇ ] : 𝐾ℎ𝑢𝑠𝑢𝑠 𝐺𝑟𝑜𝑢𝑝 𝑂𝑛𝑙𝑦`*",
	prem: "*`[ ◇ ] : 𝐾ℎ𝑢𝑠𝑢𝑠 𝑃𝑒𝑛𝑔𝑢𝑛𝑎 𝑃𝑟𝑒𝑚𝑖𝑢𝑚`*",
	wait: '*`[ ◇ ] : 𝑆𝑎𝑏𝑎𝑟 𝑆𝑒𝑑𝑎𝑛𝑔 𝐷𝑖 𝑃𝑟𝑜𝑠𝑒𝑠`*',
	error: '*`[ ◇ ] : 𝐸𝑟𝑟𝑜𝑟 𝐵𝑎𝑛𝑔`*', 
	bugrespon: '*`[ ◇ ] : 𝑆𝑎𝑏𝑎𝑟 𝑆𝑒𝑑𝑎𝑛𝑔 𝐷𝑖 𝑃𝑟𝑜𝑠𝑒𝑠`*',
	done: '*`[ ◇ ] : 𝑆𝑒𝑙𝑒𝑠𝑎𝑖 𝑁𝑖ℎ 𝐵𝑎𝑛𝑔 𝑃𝑟𝑜𝑠𝑒𝑠𝑛𝑦𝑎`*'
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})